import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_APP_NAME": "Laravel"};import { Bn as markRaw, Ft as onMounted, In as isReactive, Kn as ref, M as Fragment, Ot as nextTick, U as computed, Ut as provide, Wn as reactive, Yn as shallowRef, a as createApp, gn as watch, jt as onBeforeUnmount, nt as defineComponent, o as createSSRApp, pt as h, xt as inject, zt as onUnmounted } from "/node_modules/.vite/deps/vue.runtime.esm-bundler-Bo_ScjpA.js?v=cebe2491";
//#region node_modules/es-toolkit/dist/_internal/globalThis.mjs
var globalThis_ = typeof globalThis === "object" && globalThis || typeof window === "object" && window || typeof self === "object" && self || typeof global === "object" && global || (function() {
	return this;
})();
//#endregion
//#region node_modules/es-toolkit/dist/function/debounce.mjs
/**
* Creates a debounced function that delays invoking the provided function until after `debounceMs` milliseconds
* have elapsed since the last time the debounced function was invoked. The debounced function also has a `cancel`
* method to cancel any pending execution.
*
* @template F - The type of function.
* @param func - The function to debounce.
* @param debounceMs - The number of milliseconds to delay.
* @param options - The options object
* @param options.signal - An optional AbortSignal to cancel the debounced function.
* @param options.edges - An optional array specifying whether the function should be invoked on the leading edge, trailing edge, or both.
* @returns A new debounced function with a `cancel` method.
*
* @example
* const debouncedFunction = debounce(() => {
*   console.log('Function executed');
* }, 1000);
*
* // Will log 'Function executed' after 1 second if not called again in that time
* debouncedFunction();
*
* // Will not log anything as the previous call is canceled
* debouncedFunction.cancel();
*
* // With AbortSignal
* const controller = new AbortController();
* const signal = controller.signal;
* const debouncedWithSignal = debounce(() => {
*  console.log('Function executed');
* }, 1000, { signal });
*
* debouncedWithSignal();
*
* // Will cancel the debounced function call
* controller.abort();
*/
function debounce$2(func, debounceMs, { signal, edges } = {}) {
	let pendingThis = void 0;
	let pendingArgs = null;
	const leading = edges != null && edges.includes("leading");
	const trailing = edges == null || edges.includes("trailing");
	const invoke = () => {
		if (pendingArgs !== null) {
			func.apply(pendingThis, pendingArgs);
			pendingThis = void 0;
			pendingArgs = null;
		}
	};
	const onTimerEnd = () => {
		if (trailing) invoke();
		cancel();
	};
	let timeoutId = null;
	const schedule = () => {
		if (timeoutId != null) clearTimeout(timeoutId);
		timeoutId = setTimeout(() => {
			timeoutId = null;
			onTimerEnd();
		}, debounceMs);
	};
	const cancelTimer = () => {
		if (timeoutId !== null) {
			clearTimeout(timeoutId);
			timeoutId = null;
		}
	};
	const cancel = () => {
		cancelTimer();
		pendingThis = void 0;
		pendingArgs = null;
	};
	const flush = () => {
		invoke();
	};
	const debounced = function(...args) {
		if (signal?.aborted) return;
		pendingThis = this;
		pendingArgs = args;
		const isFirstCall = timeoutId == null;
		schedule();
		if (leading && isFirstCall) invoke();
	};
	debounced.schedule = schedule;
	debounced.cancel = cancel;
	debounced.flush = flush;
	signal?.addEventListener("abort", cancel, { once: true });
	return debounced;
}
//#endregion
//#region node_modules/es-toolkit/dist/function/noop.mjs
/**
* A no-operation function that does nothing.
* This can be used as a placeholder or default function.
*
* @example
* noop(); // Does nothing
*
* @returns This function does not return anything.
*/
function noop$2() {}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isPrimitive.mjs
/**
* Checks whether a value is a JavaScript primitive.
* JavaScript primitives include null, undefined, strings, numbers, booleans, symbols, and bigints.
*
* @param value The value to check.
* @returns Returns true if `value` is a primitive, false otherwise.
*
* @example
* isPrimitive(null); // true
* isPrimitive(undefined); // true
* isPrimitive('123'); // true
* isPrimitive(false); // true
* isPrimitive(true); // true
* isPrimitive(Symbol('a')); // true
* isPrimitive(123n); // true
* isPrimitive({}); // false
* isPrimitive(new Date()); // false
* isPrimitive(new Map()); // false
* isPrimitive(new Set()); // false
* isPrimitive([1, 2, 3]); // false
*/
function isPrimitive(value) {
	return value == null || typeof value !== "object" && typeof value !== "function";
}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isTypedArray.mjs
/**
* Checks if a value is a TypedArray.
* @param x The value to check.
* @returns Returns true if `x` is a TypedArray, false otherwise.
*
* @example
* const arr = new Uint8Array([1, 2, 3]);
* isTypedArray(arr); // true
*
* const regularArray = [1, 2, 3];
* isTypedArray(regularArray); // false
*
* const buffer = new ArrayBuffer(16);
* isTypedArray(buffer); // false
*/
function isTypedArray$1(x) {
	return ArrayBuffer.isView(x) && !(x instanceof DataView);
}
//#endregion
//#region node_modules/es-toolkit/dist/object/clone.mjs
/**
* Creates a shallow clone of the given object.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @returns A shallow clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = clone(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = clone(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = clone(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*/
function clone(obj) {
	if (isPrimitive(obj)) return obj;
	if (Array.isArray(obj) || isTypedArray$1(obj) || obj instanceof ArrayBuffer || typeof SharedArrayBuffer !== "undefined" && obj instanceof SharedArrayBuffer) return obj.slice(0);
	const prototype = Object.getPrototypeOf(obj);
	if (prototype == null) return Object.assign(Object.create(prototype), obj);
	const Constructor = prototype.constructor;
	if (obj instanceof Date || obj instanceof Map || obj instanceof Set) return new Constructor(obj);
	if (obj instanceof RegExp) {
		const newRegExp = new Constructor(obj);
		newRegExp.lastIndex = obj.lastIndex;
		return newRegExp;
	}
	if (obj instanceof DataView) return new Constructor(obj.buffer.slice(0));
	if (obj instanceof Error) {
		let newError;
		if (obj instanceof AggregateError) newError = new Constructor(obj.errors, obj.message, { cause: obj.cause });
		else newError = new Constructor(obj.message, { cause: obj.cause });
		newError.stack = obj.stack;
		Object.assign(newError, obj);
		return newError;
	}
	if (typeof File !== "undefined" && obj instanceof File) return new Constructor([obj], obj.name, {
		type: obj.type,
		lastModified: obj.lastModified
	});
	if (typeof obj === "object") return Object.assign(Object.create(prototype), obj);
	return obj;
}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isBuffer.mjs
/**
* Checks if the given value is a Buffer instance.
*
* This function tests whether the provided value is an instance of Buffer.
* It returns `true` if the value is a Buffer, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `Buffer`.
*
* @param x - The value to check if it is a Buffer.
* @returns Returns `true` if `x` is a Buffer, else `false`.
*
* @example
* const buffer = Buffer.from("test");
* console.log(isBuffer(buffer)); // true
*
* const notBuffer = "not a buffer";
* console.log(isBuffer(notBuffer)); // false
*/
function isBuffer(x) {
	return typeof globalThis_.Buffer !== "undefined" && globalThis_.Buffer.isBuffer(x);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/getSymbols.mjs
function getSymbols(object) {
	return Object.getOwnPropertySymbols(object).filter((symbol) => Object.prototype.propertyIsEnumerable.call(object, symbol));
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/getTag.mjs
/**
* Gets the `toStringTag` of `value`.
*
* @private
* @param {T} value The value to query.
* @returns {string} Returns the `Object.prototype.toString.call` result.
*/
function getTag(value) {
	if (value == null) return value === void 0 ? "[object Undefined]" : "[object Null]";
	return Object.prototype.toString.call(value);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/tags.mjs
var regexpTag = "[object RegExp]";
var stringTag = "[object String]";
var numberTag = "[object Number]";
var booleanTag = "[object Boolean]";
var argumentsTag = "[object Arguments]";
var symbolTag = "[object Symbol]";
var dateTag = "[object Date]";
var mapTag = "[object Map]";
var setTag = "[object Set]";
var arrayTag = "[object Array]";
var functionTag = "[object Function]";
var arrayBufferTag = "[object ArrayBuffer]";
var objectTag = "[object Object]";
var errorTag = "[object Error]";
var dataViewTag = "[object DataView]";
var uint8ArrayTag = "[object Uint8Array]";
var uint8ClampedArrayTag = "[object Uint8ClampedArray]";
var uint16ArrayTag = "[object Uint16Array]";
var uint32ArrayTag = "[object Uint32Array]";
var bigUint64ArrayTag = "[object BigUint64Array]";
var int8ArrayTag = "[object Int8Array]";
var int16ArrayTag = "[object Int16Array]";
var int32ArrayTag = "[object Int32Array]";
var bigInt64ArrayTag = "[object BigInt64Array]";
var float32ArrayTag = "[object Float32Array]";
var float64ArrayTag = "[object Float64Array]";
//#endregion
//#region node_modules/es-toolkit/dist/object/cloneDeepWith.mjs
/**
* Deeply clones the given object.
*
* You can customize the deep cloning process using the `cloneValue` function.
* The function takes the current value `value`, the property name `key`, and the entire object `obj` as arguments.
* If the function returns a value, that value is used;
* if it returns `undefined`, the default cloning method is used.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @param [cloneValue] - A function to customize the cloning process.
* @returns A deep clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = cloneDeepWith(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an object with a customizer
* const obj = { a: 1, b: 2 };
* const clonedObj = cloneDeepWith(obj, (value) => {
*   if (typeof value === 'number') {
*     return value * 2; // Double the number
*   }
* });
* console.log(clonedObj); // { a: 2, b: 4 }
* console.log(clonedObj === obj); // false
*
* @example
* // Clone an array with a customizer
* const arr = [1, 2, 3];
* const clonedArr = cloneDeepWith(arr, (value) => {
*   if (typeof value === 'number') {
*     return value + 1; // Increment each number
*   }
* });
* console.log(clonedArr); // [2, 3, 4]
* console.log(clonedArr === arr); // false
*/
function cloneDeepWith$1(obj, cloneValue) {
	return cloneDeepWithImpl(obj, void 0, obj, /* @__PURE__ */ new Map(), cloneValue);
}
function cloneDeepWithImpl(valueToClone, keyToClone, objectToClone, stack = /* @__PURE__ */ new Map(), cloneValue = void 0) {
	const cloned = cloneValue?.(valueToClone, keyToClone, objectToClone, stack);
	if (cloned !== void 0) return cloned;
	if (isPrimitive(valueToClone)) return valueToClone;
	if (stack.has(valueToClone)) return stack.get(valueToClone);
	if (Array.isArray(valueToClone)) {
		const result = new Array(valueToClone.length);
		stack.set(valueToClone, result);
		for (let i = 0; i < valueToClone.length; i++) result[i] = cloneDeepWithImpl(valueToClone[i], i, objectToClone, stack, cloneValue);
		if (Object.hasOwn(valueToClone, "index")) result.index = valueToClone.index;
		if (Object.hasOwn(valueToClone, "input")) result.input = valueToClone.input;
		return result;
	}
	if (valueToClone instanceof Date) return new Date(valueToClone.getTime());
	if (valueToClone instanceof RegExp) {
		const result = new RegExp(valueToClone.source, valueToClone.flags);
		result.lastIndex = valueToClone.lastIndex;
		return result;
	}
	if (valueToClone instanceof Map) {
		const result = /* @__PURE__ */ new Map();
		stack.set(valueToClone, result);
		for (const [key, value] of valueToClone) result.set(key, cloneDeepWithImpl(value, key, objectToClone, stack, cloneValue));
		return result;
	}
	if (valueToClone instanceof Set) {
		const result = /* @__PURE__ */ new Set();
		stack.set(valueToClone, result);
		for (const value of valueToClone) result.add(cloneDeepWithImpl(value, void 0, objectToClone, stack, cloneValue));
		return result;
	}
	if (isBuffer(valueToClone)) return valueToClone.subarray();
	if (isTypedArray$1(valueToClone)) {
		const result = new (Object.getPrototypeOf(valueToClone)).constructor(valueToClone.length);
		stack.set(valueToClone, result);
		for (let i = 0; i < valueToClone.length; i++) result[i] = cloneDeepWithImpl(valueToClone[i], i, objectToClone, stack, cloneValue);
		return result;
	}
	if (valueToClone instanceof ArrayBuffer || typeof SharedArrayBuffer !== "undefined" && valueToClone instanceof SharedArrayBuffer) return valueToClone.slice(0);
	if (valueToClone instanceof DataView) {
		const result = new DataView(valueToClone.buffer.slice(0), valueToClone.byteOffset, valueToClone.byteLength);
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (typeof File !== "undefined" && valueToClone instanceof File) {
		const result = new File([valueToClone], valueToClone.name, { type: valueToClone.type });
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (typeof Blob !== "undefined" && valueToClone instanceof Blob) {
		const result = new Blob([valueToClone], { type: valueToClone.type });
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (valueToClone instanceof Error) {
		const result = structuredClone(valueToClone);
		stack.set(valueToClone, result);
		result.message = valueToClone.message;
		result.name = valueToClone.name;
		result.stack = valueToClone.stack;
		result.cause = valueToClone.cause;
		result.constructor = valueToClone.constructor;
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (valueToClone instanceof Boolean) {
		const result = new Boolean(valueToClone.valueOf());
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (valueToClone instanceof Number) {
		const result = new Number(valueToClone.valueOf());
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (valueToClone instanceof String) {
		const result = new String(valueToClone.valueOf());
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	if (typeof valueToClone === "object" && isCloneableObject(valueToClone)) {
		const result = Object.create(Object.getPrototypeOf(valueToClone));
		stack.set(valueToClone, result);
		copyProperties(result, valueToClone, objectToClone, stack, cloneValue);
		return result;
	}
	return valueToClone;
}
function copyProperties(target, source, objectToClone = target, stack, cloneValue) {
	const keys = [...Object.keys(source), ...getSymbols(source)];
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		const descriptor = Object.getOwnPropertyDescriptor(target, key);
		if (descriptor == null || descriptor.writable) target[key] = cloneDeepWithImpl(source[key], key, objectToClone, stack, cloneValue);
	}
}
function isCloneableObject(object) {
	switch (getTag(object)) {
		case argumentsTag:
		case arrayTag:
		case arrayBufferTag:
		case dataViewTag:
		case booleanTag:
		case dateTag:
		case float32ArrayTag:
		case float64ArrayTag:
		case int8ArrayTag:
		case int16ArrayTag:
		case int32ArrayTag:
		case mapTag:
		case numberTag:
		case objectTag:
		case regexpTag:
		case setTag:
		case stringTag:
		case symbolTag:
		case uint8ArrayTag:
		case uint8ClampedArrayTag:
		case uint16ArrayTag:
		case uint32ArrayTag: return true;
		default: return false;
	}
}
//#endregion
//#region node_modules/es-toolkit/dist/object/cloneDeep.mjs
/**
* Creates a deep clone of the given object.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @returns A deep clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = cloneDeep(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = cloneDeep(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an array with nested objects
* const arr = [1, { a: 1 }, [1, 2, 3]];
* const clonedArr = cloneDeep(arr);
* arr[1].a = 2;
* console.log(arr); // [1, { a: 2 }, [1, 2, 3]]
* console.log(clonedArr); // [1, { a: 1 }, [1, 2, 3]]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = cloneDeep(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*
* @example
* // Clone an object with nested objects
* const obj = { a: 1, b: { c: 1 } };
* const clonedObj = cloneDeep(obj);
* obj.b.c = 2;
* console.log(obj); // { a: 1, b: { c: 2 } }
* console.log(clonedObj); // { a: 1, b: { c: 1 } }
* console.log(clonedObj === obj); // false
*/
function cloneDeep$1(obj) {
	return cloneDeepWithImpl(obj, void 0, obj, /* @__PURE__ */ new Map(), void 0);
}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isPlainObject.mjs
/**
* Checks if a given value is a plain object.
*
* @param value - The value to check.
* @returns True if the value is a plain object, otherwise false.
*
* @example
* ```typescript
* // ✅👇 True
*
* isPlainObject({ });                       // ✅
* isPlainObject({ key: 'value' });          // ✅
* isPlainObject({ key: new Date() });       // ✅
* isPlainObject(new Object());              // ✅
* isPlainObject(Object.create(null));       // ✅
* isPlainObject({ nested: { key: true} });  // ✅
* isPlainObject(new Proxy({}, {}));         // ✅
* isPlainObject({ [Symbol('tag')]: 'A' });  // ✅
*
* // ✅👇 (cross-realms, node context, workers, ...)
* const runInNewContext = await import('node:vm').then(
*     (mod) => mod.runInNewContext
* );
* isPlainObject(runInNewContext('({})'));   // ✅
*
* // ❌👇 False
*
* class Test { };
* isPlainObject(new Test())           // ❌
* isPlainObject(10);                  // ❌
* isPlainObject(null);                // ❌
* isPlainObject('hello');             // ❌
* isPlainObject([]);                  // ❌
* isPlainObject(new Date());          // ❌
* isPlainObject(new Uint8Array([1])); // ❌
* isPlainObject(Buffer.from('ABC'));  // ❌
* isPlainObject(Promise.resolve({})); // ❌
* isPlainObject(Object.create({}));   // ❌
* isPlainObject(new (class Cls {}));  // ❌
* isPlainObject(globalThis);          // ❌,
* ```
*/
function isPlainObject$2(value) {
	if (!value || typeof value !== "object") return false;
	const proto = Object.getPrototypeOf(value);
	if (!(proto === null || proto === Object.prototype || Object.getPrototypeOf(proto) === null)) return false;
	return Object.prototype.toString.call(value) === "[object Object]";
}
//#endregion
//#region node_modules/es-toolkit/dist/_internal/isUnsafeProperty.mjs
/**
* Checks if a property key is unsafe to access or copy directly.
*
* This function is used in functions like `get`, `unset`, and `merge` to prevent
* prototype pollution attacks by identifying `__proto__`, which modifies the object's
* prototype chain. `constructor` and `prototype` stay accessible here because lodash
* keeps reads of them unrestricted; write paths use `isUnsafeToWriteProperty` instead,
* which also blocks those keys.
*
* @param key - The property key to check
* @returns `true` if the property is unsafe to access directly, `false` otherwise
* @internal
*/
function isUnsafeProperty(key) {
	return key === "__proto__";
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isPlainObject.mjs
/**
* Checks if a given value is a plain object.
*
* A plain object is an object created by the `{}` literal, `new Object()`, or
* `Object.create(null)`.
*
* This function also handles objects with custom
* `Symbol.toStringTag` properties.
*
* `Symbol.toStringTag` is a built-in symbol that a constructor can use to customize the
* default string description of objects.
*
* @param [object] - The value to check.
* @returns True if the value is a plain object, otherwise false.
*
* @example
* console.log(isPlainObject({})); // true
* console.log(isPlainObject([])); // false
* console.log(isPlainObject(null)); // false
* console.log(isPlainObject(Object.create(null))); // true
* console.log(isPlainObject(new Map())); // false
*/
function isPlainObject$1(object) {
	if (typeof object !== "object") return false;
	if (object == null) return false;
	if (Object.getPrototypeOf(object) === null) return true;
	if (Object.prototype.toString.call(object) !== "[object Object]") {
		const tag = object[Symbol.toStringTag];
		if (tag == null) return false;
		if (!Object.getOwnPropertyDescriptor(object, Symbol.toStringTag)?.writable) return false;
		return object.toString() === `[object ${tag}]`;
	}
	let proto = object;
	while (Object.getPrototypeOf(proto) !== null) proto = Object.getPrototypeOf(proto);
	return Object.getPrototypeOf(object) === proto;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/util/eq.mjs
/**
* Performs a `SameValueZero` comparison between two values to determine if they are equivalent.
*
* @param value The value to compare.
* @param other The other value to compare.
* @returns Returns `true` if the values are equivalent, else `false`.
*
* @example
* eq(1, 1); // true
* eq(0, -0); // true
* eq(NaN, NaN); // true
* eq('a', Object('a')); // false
*/
function eq(value, other) {
	return value === other || Number.isNaN(value) && Number.isNaN(other);
}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isEqualWith.mjs
/**
* Compares two values for equality using a custom comparison function.
*
* The custom function allows for fine-tuned control over the comparison process. If it returns a boolean, that result determines the equality. If it returns undefined, the function falls back to the default equality comparison.
*
* This function also uses the custom equality function to compare values inside objects,
* arrays, maps, sets, and other complex structures, ensuring a deep comparison.
*
* This approach provides flexibility in handling complex comparisons while maintaining efficient default behavior for simpler cases.
*
* The custom comparison function can take up to six parameters:
* - `x`: The value from the first object `a`.
* - `y`: The value from the second object `b`.
* - `property`: The property key used to get `x` and `y`.
* - `xParent`: The parent of the first value `x`.
* - `yParent`: The parent of the second value `y`.
* - `stack`: An internal stack (Map) to handle circular references.
*
* @param a - The first value to compare.
* @param b - The second value to compare.
* @param areValuesEqual - A function to customize the comparison.
*   If it returns a boolean, that result will be used. If it returns undefined,
*   the default equality comparison will be used.
* @returns `true` if the values are equal according to the customizer, otherwise `false`.
*
* @example
* const customizer = (a, b) => {
*   if (typeof a === 'string' && typeof b === 'string') {
*     return a.toLowerCase() === b.toLowerCase();
*   }
* };
* isEqualWith('Hello', 'hello', customizer); // true
* isEqualWith({ a: 'Hello' }, { a: 'hello' }, customizer); // true
* isEqualWith([1, 2, 3], [1, 2, 3], customizer); // true
*/
function isEqualWith(a, b, areValuesEqual) {
	return isEqualWithImpl(a, b, void 0, void 0, void 0, void 0, areValuesEqual);
}
function isEqualWithImpl(a, b, property, aParent, bParent, stack, areValuesEqual) {
	const result = areValuesEqual(a, b, property, aParent, bParent, stack);
	if (result !== void 0) return result;
	if (typeof a === typeof b) switch (typeof a) {
		case "bigint":
		case "string":
		case "boolean":
		case "symbol":
		case "undefined": return a === b;
		case "number": return a === b || Object.is(a, b);
		case "function": return a === b;
		case "object": return areObjectsEqual(a, b, stack, areValuesEqual);
	}
	return areObjectsEqual(a, b, stack, areValuesEqual);
}
function areObjectsEqual(a, b, stack, areValuesEqual) {
	if (Object.is(a, b)) return true;
	let aTag = getTag(a);
	let bTag = getTag(b);
	if (aTag === "[object Arguments]") aTag = objectTag;
	if (bTag === "[object Arguments]") bTag = objectTag;
	if (aTag !== bTag) return false;
	switch (aTag) {
		case stringTag: return a.toString() === b.toString();
		case numberTag: return eq(a.valueOf(), b.valueOf());
		case booleanTag:
		case dateTag:
		case symbolTag: return Object.is(a.valueOf(), b.valueOf());
		case regexpTag: return a.source === b.source && a.flags === b.flags;
		case functionTag: return a === b;
	}
	stack = stack ?? /* @__PURE__ */ new Map();
	const aStack = stack.get(a);
	const bStack = stack.get(b);
	if (aStack != null && bStack != null) return aStack === b;
	stack.set(a, b);
	stack.set(b, a);
	try {
		switch (aTag) {
			case mapTag:
				if (a.size !== b.size) return false;
				for (const [key, value] of a.entries()) if (!b.has(key) || !isEqualWithImpl(value, b.get(key), key, a, b, stack, areValuesEqual)) return false;
				return true;
			case setTag: {
				if (a.size !== b.size) return false;
				const aValues = Array.from(a.values());
				const bValues = Array.from(b.values());
				for (let i = 0; i < aValues.length; i++) {
					const aValue = aValues[i];
					const index = bValues.findIndex((bValue) => {
						return isEqualWithImpl(aValue, bValue, void 0, a, b, stack, areValuesEqual);
					});
					if (index === -1) return false;
					bValues.splice(index, 1);
				}
				return true;
			}
			case arrayTag:
			case uint8ArrayTag:
			case uint8ClampedArrayTag:
			case uint16ArrayTag:
			case uint32ArrayTag:
			case bigUint64ArrayTag:
			case int8ArrayTag:
			case int16ArrayTag:
			case int32ArrayTag:
			case bigInt64ArrayTag:
			case float32ArrayTag:
			case float64ArrayTag:
				if (isBuffer(a) !== isBuffer(b)) return false;
				if (a.length !== b.length) return false;
				for (let i = 0; i < a.length; i++) if (!isEqualWithImpl(a[i], b[i], i, a, b, stack, areValuesEqual)) return false;
				return true;
			case arrayBufferTag:
				if (a.byteLength !== b.byteLength) return false;
				return areObjectsEqual(new Uint8Array(a), new Uint8Array(b), stack, areValuesEqual);
			case dataViewTag:
				if (a.byteLength !== b.byteLength || a.byteOffset !== b.byteOffset) return false;
				return areObjectsEqual(new Uint8Array(a), new Uint8Array(b), stack, areValuesEqual);
			case errorTag: return a.name === b.name && a.message === b.message;
			case objectTag: {
				if (!(areObjectsEqual(a.constructor, b.constructor, stack, areValuesEqual) || isPlainObject$2(a) && isPlainObject$2(b))) return false;
				const aKeys = [...Object.keys(a), ...getSymbols(a)];
				const bKeys = [...Object.keys(b), ...getSymbols(b)];
				if (aKeys.length !== bKeys.length) return false;
				for (let i = 0; i < aKeys.length; i++) {
					const propKey = aKeys[i];
					const aProp = a[propKey];
					if (!Object.hasOwn(b, propKey)) return false;
					const bProp = b[propKey];
					if (!isEqualWithImpl(aProp, bProp, propKey, a, b, stack, areValuesEqual)) return false;
				}
				return true;
			}
			default: return false;
		}
	} finally {
		stack.delete(a);
		stack.delete(b);
	}
}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isEqual.mjs
/**
* Checks if two values are equal, including support for `Date`, `RegExp`, and deep object comparison.
*
* @param a - The first value to compare.
* @param b - The second value to compare.
* @returns `true` if the values are equal, otherwise `false`.
*
* @example
* isEqual(1, 1); // true
* isEqual({ a: 1 }, { a: 1 }); // true
* isEqual(/abc/g, /abc/g); // true
* isEqual(new Date('2020-01-01'), new Date('2020-01-01')); // true
* isEqual([1, 2, 3], [1, 2, 3]); // true
*/
function isEqual(a, b) {
	return isEqualWith(a, b, noop$2);
}
//#endregion
//#region node_modules/es-toolkit/dist/predicate/isLength.mjs
/**
* Checks if a given value is a valid length.
*
* A valid length is of type `number`, is a non-negative integer, and is less than or equal to
* JavaScript's maximum safe integer (`Number.MAX_SAFE_INTEGER`).
* It returns `true` if the value is a valid length, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the
* argument to a valid length (`number`).
*
* @param value The value to check.
* @returns Returns `true` if `value` is a valid length, else `false`.
*
* @example
* isLength(0); // true
* isLength(42); // true
* isLength(-1); // false
* isLength(1.5); // false
* isLength(Number.MAX_SAFE_INTEGER); // true
* isLength(Number.MAX_SAFE_INTEGER + 1); // false
*/
function isLength(value) {
	return Number.isSafeInteger(value) && value >= 0;
}
//#endregion
//#region node_modules/es-toolkit/dist/string/escape.mjs
var htmlEscapes = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
};
/**
* Converts the characters "&", "<", ">", '"', and "'" in `str` to their corresponding HTML entities.
* For example, "<" becomes "&lt;".
*
* @param str  The string to escape.
* @returns Returns the escaped string.
*
* @example
* escape('This is a <div> element.'); // returns 'This is a &lt;div&gt; element.'
* escape('This is a "quote"'); // returns 'This is a &quot;quote&quot;'
* escape("This is a 'quote'"); // returns 'This is a &#39;quote&#39;'
* escape('This is a & symbol'); // returns 'This is a &amp; symbol'
*/
function escape$1(str) {
	return str.replace(/[&<>"']/g, (match) => htmlEscapes[match]);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isArrayLike.mjs
/**
* Checks if `value` is array-like.
*
* @param value The value to check.
* @returns Returns `true` if `value` is array-like, else `false`.
*
* @example
* isArrayLike([1, 2, 3]); // true
* isArrayLike('abc'); // true
* isArrayLike({ 0: 'a', length: 1 }); // true
* isArrayLike({}); // false
* isArrayLike(null); // false
* isArrayLike(undefined); // false
*/
function isArrayLike(value) {
	return value != null && typeof value !== "function" && isLength(value.length);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isSymbol.mjs
/**
* Check whether a value is a symbol.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `symbol`.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a symbol, else `false`.
* @example
* isSymbol(Symbol.iterator);
* // => true
*
* isSymbol('abc');
* // => false
*/
function isSymbol(value) {
	return typeof value === "symbol" || value instanceof Symbol;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/util/toString.mjs
/**
* Converts `value` to a string.
*
* An empty string is returned for `null` and `undefined` values.
* The sign of `-0` is preserved.
*
* @param value - The value to convert.
* @returns Returns the converted string.
*
* @example
* toString(null) // returns ''
* toString(undefined) // returns ''
* toString(-0) // returns '-0'
* toString([1, 2, -0]) // returns '1,2,-0'
* toString([Symbol('a'), Symbol('b')]) // returns 'Symbol(a),Symbol(b)'
*/
function toString(value) {
	if (value == null) return "";
	return baseToString(value);
}
function baseToString(value) {
	if (typeof value === "string") return value;
	if (Array.isArray(value)) return value.map(baseToString).join(",");
	if (isSymbol(value)) return value.toString();
	const result = value + "";
	if (result === "0" && Object.is(Number(value), -0)) return "-0";
	return result;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/toKey.mjs
/**
* Converts `value` to a string key if it's not a string or symbol.
*
* @private
* @param {unknown} value The value to inspect.
* @returns {string|symbol} Returns the key.
*/
function toKey(value) {
	if (typeof value === "string" || typeof value === "symbol") return value;
	if (Object.is(value?.valueOf?.(), -0)) return "-0";
	return String(value);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/util/toPath.mjs
/**
* Converts a deep key string into an array of path segments.
*
* This function takes a string representing a deep key (e.g., 'a.b.c' or 'a[b][c]') and breaks it down into an array of strings, each representing a segment of the path.
*
* @param deepKey - The deep key string to convert.
* @returns An array of strings, each representing a segment of the path.
*
* Examples:
*
* toPath('a.b.c') // Returns ['a', 'b', 'c']
* toPath('a[b][c]') // Returns ['a', 'b', 'c']
* toPath('.a.b.c') // Returns ['', 'a', 'b', 'c']
* toPath('a["b.c"].d') // Returns ['a', 'b.c', 'd']
* toPath('') // Returns []
* toPath('.a[b].c.d[e]["f.g"].h') // Returns ['', 'a', 'b', 'c', 'd', 'e', 'f.g', 'h']
*/
function toPath(deepKey) {
	if (Array.isArray(deepKey)) return deepKey.map(toKey);
	if (typeof deepKey === "symbol") return [deepKey];
	deepKey = toString(deepKey);
	const result = [];
	const length = deepKey.length;
	if (length === 0) return result;
	let index = 0;
	let key = "";
	let quoteChar = "";
	let bracket = false;
	let bracketHadQuote = false;
	const bracketNumberRegex = /^-?\d+(?:\.\d+)?$/;
	if (deepKey.charCodeAt(0) === 46) result.push("");
	while (index < length) {
		const char = deepKey[index];
		if (quoteChar) if (char === "\\" && index + 1 < length) {
			index++;
			key += deepKey[index];
		} else if (char === quoteChar) quoteChar = "";
		else key += char;
		else if (bracket) if (char === "\"" || char === "'") {
			quoteChar = char;
			bracketHadQuote = true;
		} else if (char === "]") {
			bracket = false;
			if (!bracketHadQuote && key.includes(".") && !bracketNumberRegex.test(key)) {
				const segments = key.split(".");
				for (let i = 0; i < segments.length; i++) if (segments[i] !== "") result.push(segments[i]);
			} else result.push(key);
			key = "";
		} else key += char;
		else if (char === "[") {
			bracket = true;
			bracketHadQuote = false;
			if (key) {
				result.push(key);
				key = "";
			}
		} else if (char === ".") {
			if (key) {
				result.push(key);
				key = "";
			}
			const next = deepKey[index + 1];
			if (next === void 0 || next === ".") result.push("");
		} else key += char;
		index++;
	}
	if (key) result.push(key);
	return result;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/isDeepKey.mjs
/** Matches any deep property path. Examples: `a.b`, `a[0]`, `a["b"]` */
var regexIsDeepProp$1 = /\.|(\[(?:[^[\]]*|(["'])(?:(?!\2)[^\\]|\\.)*?\2)\])/;
/**
* Checks if a given key is a deep key.
*
* A deep key is a string that contains a dot (.) or square brackets with a property accessor.
*
* @param {PropertyKey} key - The key to check.
* @returns {boolean} - Returns true if the key is a deep key, otherwise false.
*
* Examples:
*
* isDeepKey('a.b') // true
* isDeepKey('a[b]') // true
* isDeepKey('a') // false
* isDeepKey(123) // false
* isDeepKey('a.b.c') // true
* isDeepKey('a[b][c]') // true
* isDeepKey('a.') // false
* isDeepKey('.a') // false
* isDeepKey('a[b') // false
* isDeepKey('a]b]') // false
* isDeepKey('a][b') // false
* isDeepKey('') // false
* isDeepKey('a[0]') // true
*
*/
function isDeepKey(key) {
	switch (typeof key) {
		case "number":
		case "symbol": return false;
		case "string":
			if (key === "" || key.startsWith(".") || key.endsWith(".")) return false;
			return regexIsDeepProp$1.test(key);
		default: return false;
	}
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/get.mjs
/**
* Retrieves the value at a given path from an object. If the resolved value is undefined, the defaultValue is returned instead.
*
* @param object - The object to query.
* @param path - The path of the property to get.
* @param [defaultValue] - The value returned if the resolved value is undefined.
* @returns Returns the resolved value.
*
* @example
* const object = { a: { b: { c: 1 } } };
* get(object, 'a.b.c');
* // => 1
*
* get(object, ['a', 'b', 'c']);
* // => 1
*
* get(object, 'a.b.d', 'default');
* // => 'default'
*/
function get(object, path, defaultValue) {
	if (object == null) return defaultValue;
	switch (typeof path) {
		case "string": {
			if (isUnsafeProperty(path)) return defaultValue;
			const result = object[path];
			if (result === void 0) if (isDeepKey(path) && !Object.hasOwn(object, path)) return get(object, toPath(path), defaultValue);
			else return defaultValue;
			return result;
		}
		case "number":
		case "symbol": {
			if (typeof path === "number") path = toKey(path);
			const result = object[path];
			if (result === void 0) return defaultValue;
			return result;
		}
		default: {
			if (Array.isArray(path)) return getWithPath(object, path, defaultValue);
			if (Object.is(path?.valueOf(), -0)) path = "-0";
			else path = String(path);
			if (isUnsafeProperty(path)) return defaultValue;
			const result = object[path];
			if (result === void 0) return defaultValue;
			return result;
		}
	}
}
function getWithPath(object, path, defaultValue) {
	if (path.length === 0) return defaultValue;
	let current = object;
	for (let index = 0; index < path.length; index++) {
		if (current == null) return defaultValue;
		if (isUnsafeProperty(path[index])) return defaultValue;
		current = current[path[index]];
	}
	if (current === void 0) return defaultValue;
	return current;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isObject.mjs
/**
* Checks if the given value is an object. An object is a value that is
* not a primitive type (string, number, boolean, symbol, null, or undefined).
*
* This function tests whether the provided value is an object or not.
* It returns `true` if the value is an object, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to an object value.
*
* @param value - The value to check if it is an object.
* @returns `true` if the value is an object, `false` otherwise.
*
* @example
* const value1 = {};
* const value2 = [1, 2, 3];
* const value3 = () => {};
* const value4 = null;
*
* console.log(isObject(value1)); // true
* console.log(isObject(value2)); // true
* console.log(isObject(value3)); // true
* console.log(isObject(value4)); // false
*/
function isObject(value) {
	return value !== null && (typeof value === "object" || typeof value === "function");
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/cloneDeepWith.mjs
/**
* Creates a deep clone of the given object using a customizer function.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @param [cloneValue] - A function to customize the cloning process.
* @returns A deep clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = cloneDeepWith(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an object with a customizer
* const obj = { a: 1, b: 2 };
* const clonedObj = cloneDeepWith(obj, (value) => {
*   if (typeof value === 'number') {
*     return value * 2; // Double the number
*   }
* });
* console.log(clonedObj); // { a: 2, b: 4 }
* console.log(clonedObj === obj); // false
*
* @example
* // Clone an array with a customizer
* const arr = [1, 2, 3];
* const clonedArr = cloneDeepWith(arr, (value) => {
*   if (typeof value === 'number') {
*     return value + 1; // Increment each number
*   }
* });
* console.log(clonedArr); // [2, 3, 4]
* console.log(clonedArr === arr); // false
*/
function cloneDeepWith(obj, customizer) {
	return cloneDeepWith$1(obj, (value, key, object, stack) => {
		const cloned = customizer?.(value, key, object, stack);
		if (cloned !== void 0) return cloned;
		if (typeof obj !== "object") return;
		if (getTag(obj) === "[object Object]" && typeof obj.constructor !== "function") {
			const result = {};
			stack.set(obj, result);
			copyProperties(result, obj, object, stack);
			return result;
		}
		switch (Object.prototype.toString.call(obj)) {
			case numberTag:
			case stringTag:
			case booleanTag: {
				const result = new obj.constructor(obj?.valueOf());
				copyProperties(result, obj);
				return result;
			}
			case argumentsTag: {
				const result = {};
				copyProperties(result, obj);
				result.length = obj.length;
				result[Symbol.iterator] = obj[Symbol.iterator];
				return result;
			}
			default: return;
		}
	});
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/cloneDeep.mjs
/**
* Creates a deep clone of the given object.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @returns A deep clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = clone(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = cloneDeep(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an array with nested objects
* const arr = [1, { a: 1 }, [1, 2, 3]];
* const clonedArr = cloneDeep(arr);
* arr[1].a = 2;
* console.log(arr); // [1, { a: 2 }, [1, 2, 3]]
* console.log(clonedArr); // [1, { a: 1 }, [1, 2, 3]]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = cloneDeep(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*
* @example
* // Clone an object with nested objects
* const obj = { a: 1, b: { c: 1 } };
* const clonedObj = cloneDeep(obj);
* obj.b.c = 2;
* console.log(obj); // { a: 1, b: { c: 2 } }
* console.log(clonedObj); // { a: 1, b: { c: 1 } }
* console.log(clonedObj === obj); // false
*/
function cloneDeep(obj) {
	return cloneDeepWith(obj);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isArguments.mjs
/**
* Checks if the given value is an arguments object.
*
* This function tests whether the provided value is an arguments object or not.
* It returns `true` if the value is an arguments object, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to an arguments object.
*
* @param value - The value to test if it is an arguments object.
* @returns `true` if the value is an arguments, `false` otherwise.
*
* @example
* const args = (function() { return arguments; })();
* const strictArgs = (function() { 'use strict'; return arguments; })();
* const value = [1, 2, 3];
*
* console.log(isArguments(args)); // true
* console.log(isArguments(strictArgs)); // true
* console.log(isArguments(value)); // false
*/
function isArguments(value) {
	return value !== null && typeof value === "object" && getTag(value) === "[object Arguments]";
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/isIndex.mjs
var IS_UNSIGNED_INTEGER = /^(?:0|[1-9]\d*)$/;
function isIndex(value, length = Number.MAX_SAFE_INTEGER) {
	switch (typeof value) {
		case "number": return Number.isInteger(value) && value >= 0 && value < length;
		case "symbol": return false;
		case "string": return IS_UNSIGNED_INTEGER.test(value);
	}
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/has.mjs
/**
* Checks if a given path exists within an object.
*
* You can provide the path as a single property key, an array of property keys,
* or a string representing a deep path.
*
* If the path is an index and the object is an array or an arguments object, the function will verify
* if the index is valid and within the bounds of the array or arguments object, even if the array or
* arguments object is sparse (i.e., not all indexes are defined).
*
* @param object - The object to query.
* @param path - The path to check. This can be a single property key,
*        an array of property keys, or a string representing a deep path.
* @returns Returns `true` if the path exists in the object, `false` otherwise.
*
* @example
*
* const obj = { a: { b: { c: 3 } } };
*
* has(obj, 'a'); // true
* has(obj, ['a', 'b']); // true
* has(obj, ['a', 'b', 'c']); // true
* has(obj, 'a.b.c'); // true
* has(obj, 'a.b.d'); // false
* has(obj, ['a', 'b', 'c', 'd']); // false
* has([], 0); // false
* has([1, 2, 3], 2); // true
* has([1, 2, 3], 5); // false
*/
function has(object, path) {
	let resolvedPath;
	if (Array.isArray(path)) resolvedPath = path;
	else if (typeof path === "string" && isDeepKey(path) && !(path in Object(object))) resolvedPath = toPath(path);
	else resolvedPath = [path];
	if (resolvedPath.length === 0) return false;
	let current = object;
	for (let i = 0; i < resolvedPath.length; i++) {
		const key = toKey(resolvedPath[i]);
		if (current == null || !Object.hasOwn(current, key)) {
			if (!((Array.isArray(current) || isArguments(current)) && isIndex(key) && Number(key) < current.length)) return false;
		}
		current = current[key];
	}
	return true;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isObjectLike.mjs
/**
* Checks if the given value is object-like.
*
* A value is object-like if its type is object and it is not null.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to an object-like value.
*
* @param value - The value to test if it is an object-like.
* @returns `true` if the value is an object-like, `false` otherwise.
*
* @example
* const value1 = { a: 1 };
* const value2 = [1, 2, 3];
* const value3 = 'abc';
* const value4 = () => {};
* const value5 = null;
*
* console.log(isObjectLike(value1)); // true
* console.log(isObjectLike(value2)); // true
* console.log(isObjectLike(value3)); // false
* console.log(isObjectLike(value4)); // false
* console.log(isObjectLike(value5)); // false
*/
function isObjectLike(value) {
	return typeof value === "object" && value !== null;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isArrayLikeObject.mjs
/**
* Checks if the given value is a non-primitive, array-like object.
*
* @param value The value to check.
* @returns `true` if the value is a non-primitive, array-like object, `false` otherwise.
*
* @example
* isArrayLikeObject([1, 2, 3]); // true
* isArrayLikeObject({ 0: 'a', length: 1 }); // true
* isArrayLikeObject('abc'); // false
* isArrayLikeObject(()=>{}); // false
*/
function isArrayLikeObject(value) {
	return isObjectLike(value) && isArrayLike(value);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/isKey.mjs
/**  Matches any deep property path. (e.g. `a.b[0].c`)*/
var regexIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
/**  Matches any word character (alphanumeric & underscore).*/
var regexIsPlainProp = /^\w*$/;
/**
* Checks if `value` is a property name and not a property path. (It's ok that the `value` is not in the keys of the `object`)
* @param {unknown} value The value to check.
* @param {unknown} object The object to query.
* @returns {boolean} Returns `true` if `value` is a property name, else `false`.
*
* @example
* isKey('a', { a: 1 });
* // => true
*
* isKey('a.b', { a: { b: 2 } });
* // => false
*/
function isKey(value, object) {
	if (Array.isArray(value)) return false;
	if (typeof value === "number" || typeof value === "boolean" || value == null || isSymbol(value)) return true;
	return typeof value === "string" && (regexIsPlainProp.test(value) || !regexIsDeepProp.test(value)) || object != null && Object.hasOwn(object, value);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/predicate/isTypedArray.mjs
/**
* Checks if a value is a TypedArray.
* @param x The value to check.
* @returns Returns true if `x` is a TypedArray, false otherwise.
*
* @example
* const arr = new Uint8Array([1, 2, 3]);
* isTypedArray(arr); // true
*
* const regularArray = [1, 2, 3];
* isTypedArray(regularArray); // false
*
* const buffer = new ArrayBuffer(16);
* isTypedArray(buffer); // false
*/
function isTypedArray(x) {
	return isTypedArray$1(x);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/_internal/assignValue.mjs
var assignValue = (object, key, value) => {
	const objValue = object[key];
	if (!(Object.hasOwn(object, key) && eq(objValue, value)) || value === void 0 && !(key in object)) object[key] = value;
};
//#endregion
//#region node_modules/es-toolkit/dist/_internal/isUnsafeToWriteProperty.mjs
/**
* Checks if a property key is unsafe to write to.
*
* Writing through `__proto__`, `constructor`, or `prototype` can reach
* `Object.prototype` and pollute every object, so write paths like `set`,
* `update`, and `zipObjectDeep` abort when a path segment matches one of
* these keys, matching lodash's behavior.
*
* Read paths like `get` and `unset` use `isUnsafeProperty` instead, which
* only blocks `__proto__`; lodash keeps reads of `constructor` and
* `prototype` unrestricted.
*
* @param key - The property key to check
* @returns `true` if the property is unsafe to write to, `false` otherwise
* @internal
*/
function isUnsafeToWriteProperty(key) {
	return key === "__proto__" || key === "constructor" || key === "prototype";
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/updateWith.mjs
/**
* Updates the value at the specified path of the given object using an updater function and a customizer.
* If any part of the path does not exist, it will be created.
*
* @template T - The type of the object.
* @template R - The type of the return value.
* @param obj - The object to modify.
* @param path - The path of the property to update.
* @param updater - The function to produce the updated value.
* @param customizer - The function to customize the update process.
* @returns The modified object.
*
* @example
* const object = { 'a': [{ 'b': { 'c': 3 } }] };
* updateWith(object, 'a[0].b.c', (n) => n * n);
* // => { 'a': [{ 'b': { 'c': 9 } }] }
*/
function updateWith(obj, path, updater, customizer) {
	if (obj == null && !isObject(obj)) return obj;
	let resolvedPath;
	if (isKey(path, obj)) resolvedPath = [path];
	else if (Array.isArray(path)) resolvedPath = path;
	else resolvedPath = toPath(path);
	const updateValue = updater(get(obj, resolvedPath));
	let current = obj;
	for (let i = 0; i < resolvedPath.length && current != null; i++) {
		const key = toKey(resolvedPath[i]);
		if (isUnsafeToWriteProperty(key)) return obj;
		let newValue;
		if (i === resolvedPath.length - 1) newValue = updateValue;
		else {
			const objValue = current[key];
			const customizerResult = customizer?.(objValue, key, obj);
			newValue = customizerResult !== void 0 ? customizerResult : isObject(objValue) ? objValue : isIndex(resolvedPath[i + 1]) ? [] : {};
		}
		assignValue(current, key, newValue);
		current = current[key];
	}
	return obj;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/set.mjs
/**
* Sets the value at the specified path of the given object. If any part of the path does not exist, it will be created.
*
* @template T - The type of the object.
* @param obj - The object to modify.
* @param path - The path of the property to set.
* @param value - The value to set.
* @returns The modified object.
*
* @example
* // Set a value in a nested object
* const obj = { a: { b: { c: 3 } } };
* set(obj, 'a.b.c', 4);
* console.log(obj.a.b.c); // 4
*
* @example
* // Set a value in an array
* const arr = [1, 2, 3];
* set(arr, 1, 4);
* console.log(arr[1]); // 4
*
* @example
* // Create non-existent path and set value
* const obj = {};
* set(obj, 'a.b.c', 4);
* console.log(obj); // { a: { b: { c: 4 } } }
*/
function set(obj, path, value) {
	return updateWith(obj, path, () => value, () => void 0);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/function/debounce.mjs
function debounce$1(func, debounceMs = 0, options = {}) {
	if (typeof options !== "object") options = {};
	const { leading = false, trailing = true, maxWait } = options;
	const edges = Array(2);
	if (leading) edges[0] = "leading";
	if (trailing) edges[1] = "trailing";
	let result = void 0;
	let pendingAt = null;
	const _debounced = debounce$2(function(...args) {
		result = func.apply(this, args);
		pendingAt = null;
	}, debounceMs, { edges });
	const debounced = function(...args) {
		if (maxWait != null) {
			if (pendingAt === null) pendingAt = Date.now();
			if (Date.now() - pendingAt >= maxWait) {
				if (leading || trailing) result = func.apply(this, args);
				pendingAt = Date.now();
				_debounced.cancel();
				_debounced.schedule();
				return result;
			}
		}
		_debounced.apply(this, args);
		return result;
	};
	const flush = () => {
		_debounced.flush();
		return result;
	};
	debounced.cancel = _debounced.cancel;
	debounced.flush = flush;
	return debounced;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/mergeWith.mjs
/**
* Merges the properties of one or more source objects into the target object using a customizer function.
*
* This function performs a deep merge, recursively merging nested objects and arrays.
* If a property in the source object is an array or object and the corresponding property in the target object is also an array or object, they will be merged.
* If a property in the source object is `undefined`, it will not overwrite a defined property in the target object.
*
* You can provide a custom `merge` function to control how properties are merged. The `merge` function is called for each property that is being merged and receives the following arguments:
*
* - `targetValue`: The current value of the property in the target object.
* - `sourceValue`: The value of the property in the source object.
* - `key`: The key of the property being merged.
* - `target`: The target object.
* - `source`: The source object.
* - `stack`: A `Map` used to keep track of objects that have already been processed to handle circular references.
*
* The `merge` function should return the value to be set in the target object. If it returns `undefined`, a default deep merge will be applied for arrays and objects.
*
* The function can handle multiple source objects and will merge them all into the target object.
*
* @param object - The target object into which the source object properties will be merged. This object is modified in place.
* @param otherArgs - Additional source objects to merge into the target object, including the custom `merge` function.
* @returns The updated target object with properties from the source object(s) merged in.
*
* @example
* const target = { a: 1, b: 2 };
* const source = { b: 3, c: 4 };
*
* mergeWith(target, source, (targetValue, sourceValue) => {
*   if (typeof targetValue === 'number' && typeof sourceValue === 'number') {
*     return targetValue + sourceValue;
*   }
* });
* // Returns { a: 1, b: 5, c: 4 }
* @example
* const target = { a: [1], b: [2] };
* const source = { a: [3], b: [4] };
*
* const result = mergeWith(target, source, (objValue, srcValue) => {
*   if (Array.isArray(objValue)) {
*     return objValue.concat(srcValue);
*   }
* });
*
* expect(result).toEqual({ a: [1, 3], b: [2, 4] });
*/
function mergeWith(object, ...otherArgs) {
	const sources = otherArgs.slice(0, -1);
	const merge = otherArgs[otherArgs.length - 1];
	let result = object;
	for (let i = 0; i < sources.length; i++) {
		const source = sources[i];
		result = mergeWithDeep(result, source, merge, /* @__PURE__ */ new Map());
	}
	return result;
}
function mergeWithDeep(target, source, merge, stack) {
	if (isPrimitive(target)) target = Object(target);
	if (source == null || typeof source !== "object") return target;
	if (stack.has(source)) return clone(stack.get(source));
	stack.set(source, target);
	if (Array.isArray(source)) {
		source = source.slice();
		for (let i = 0; i < source.length; i++) if (!(i in source)) source[i] = void 0;
	}
	const sourceKeys = [...Object.keys(source), ...getSymbols(source)];
	for (let i = 0; i < sourceKeys.length; i++) {
		const key = sourceKeys[i];
		if (isUnsafeProperty(key)) continue;
		let sourceValue = source[key];
		let targetValue = target[key];
		if (isArguments(sourceValue)) sourceValue = { ...sourceValue };
		if (isArguments(targetValue)) targetValue = { ...targetValue };
		if (isBuffer(sourceValue)) sourceValue = cloneDeep(sourceValue);
		if (Array.isArray(sourceValue)) if (Array.isArray(targetValue)) {
			const cloned = [];
			const targetKeys = Reflect.ownKeys(targetValue);
			for (let i = 0; i < targetKeys.length; i++) {
				const targetKey = targetKeys[i];
				cloned[targetKey] = targetValue[targetKey];
			}
			targetValue = cloned;
		} else if (isArrayLikeObject(targetValue)) {
			const cloned = [];
			for (let i = 0; i < targetValue.length; i++) cloned[i] = targetValue[i];
			targetValue = cloned;
		} else targetValue = [];
		const merged = merge(targetValue, sourceValue, key, target, source, stack);
		if (merged !== void 0) target[key] = merged;
		else if (Array.isArray(sourceValue)) target[key] = mergeWithDeep(targetValue, sourceValue, merge, stack);
		else if (isObjectLike(targetValue) && isObjectLike(sourceValue) && (isPlainObject$1(targetValue) || isPlainObject$1(sourceValue) || isTypedArray(targetValue) || isTypedArray(sourceValue))) target[key] = mergeWithDeep(targetValue, sourceValue, merge, stack);
		else if (targetValue == null && isPlainObject$1(sourceValue)) target[key] = mergeWithDeep({}, sourceValue, merge, stack);
		else if (targetValue == null && isTypedArray(sourceValue)) target[key] = cloneDeep(sourceValue);
		else if (targetValue === void 0 || sourceValue !== void 0) target[key] = sourceValue;
	}
	return target;
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/merge.mjs
/**
* Merges the properties of one or more source objects into the target object.
*
* This function performs a deep merge, recursively merging nested objects and arrays.
* If a property in the source object is an array or object and the corresponding property in the target object is also an array or object, they will be merged.
* If a property in the source object is `undefined`, it will not overwrite a defined property in the target object.
*
* The function can handle multiple source objects and will merge them all into the target object.
*
* @param object - The target object into which the source object properties will be merged. This object is modified in place.
* @param sources - The source objects whose properties will be merged into the target object.
* @returns The updated target object with properties from the source object(s) merged in.
*
* @example
* const target = { a: 1, b: { x: 1, y: 2 } };
* const source = { b: { y: 3, z: 4 }, c: 5 };
*
* const result = merge(target, source);
* console.log(result);
* // Output: { a: 1, b: { x: 1, y: 3, z: 4 }, c: 5 }
*
* @example
* const target = { a: [1, 2], b: { x: 1 } };
* const source = { a: [3], b: { y: 2 } };
*
* const result = merge(target, source);
* console.log(result);
* // Output: { a: [3], b: { x: 1, y: 2 } }
*
* @example
* const target = { a: null };
* const source = { a: [1, 2, 3] };
*
* const result = merge(target, source);
* console.log(result);
* // Output: { a: [1, 2, 3] }
*/
function merge(object, ...sources) {
	return mergeWith(object, ...sources, noop$2);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/string/escape.mjs
/**
* Converts the characters "&", "<", ">", '"', and "'" in `str` to their corresponding HTML entities.
* For example, "<" becomes "&lt;".
*
* @param str  The string to escape.
* @returns Returns the escaped string.
*
* @example
* escape('This is a <div> element.'); // returns 'This is a &lt;div&gt; element.'
* escape('This is a "quote"'); // returns 'This is a &quot;quote&quot;'
* escape("This is a 'quote'"); // returns 'This is a &#39;quote&#39;'
* escape('This is a & symbol'); // returns 'This is a &amp; symbol'
*/
function escape(string) {
	return escape$1(toString(string));
}
//#endregion
//#region node_modules/laravel-precognition/dist/form.js
/**
* Determine if the value is a file.
*/
var isFile$1 = (value) => typeof File !== "undefined" && value instanceof File || value instanceof Blob || typeof FileList !== "undefined" && value instanceof FileList && value.length > 0;
/**
* Determine if the payload has any files.
*
* @see https://github.com/inertiajs/inertia/blob/master/packages/core/src/files.ts
*/
var hasFiles$1 = (data) => {
	if (data instanceof FormData) return true;
	return isFile$1(data) || typeof data === "object" && data !== null && Object.values(data).some((value) => hasFiles$1(value));
};
//#endregion
//#region node_modules/laravel-precognition/dist/http/errors.js
/**
* Error thrown when the server responds with a 4xx or 5xx status code.
*/
var HttpResponseError$1 = class extends Error {
	response;
	constructor(response) {
		super(`HTTP error ${response.status}`);
		this.name = "HttpResponseError";
		this.response = response;
	}
};
/**
* Error thrown when a request is cancelled/aborted.
*/
var HttpCancelledError$1 = class extends Error {
	constructor(message = "Request was cancelled") {
		super(message);
		this.name = "HttpCancelledError";
	}
};
/**
* Error thrown when a network error occurs (e.g., no connection).
*/
var HttpNetworkError$1 = class extends Error {
	constructor(message = "Network error") {
		super(message);
		this.name = "HttpNetworkError";
	}
};
//#endregion
//#region node_modules/laravel-precognition/dist/http/url.js
/**
* Build a query string from params.
*/
function buildQueryString(params) {
	const searchParams = new URLSearchParams();
	Object.entries(params).forEach(([key, value]) => {
		if (value === void 0 || value === null) return;
		if (Array.isArray(value)) value.forEach((item) => searchParams.append(`${key}[]`, String(item)));
		else if (typeof value === "object") searchParams.append(key, JSON.stringify(value));
		else searchParams.append(key, String(value));
	});
	return searchParams.toString();
}
/**
* Build the full URL with base URL and query params.
*/
function buildUrl(url, baseURL, params) {
	if (baseURL && !url.startsWith("http://") && !url.startsWith("https://")) url = baseURL.replace(/\/$/, "") + "/" + url.replace(/^\//, "");
	if (params && Object.keys(params).length > 0) {
		const queryString = buildQueryString(params);
		if (queryString) url += (url.includes("?") ? "&" : "?") + queryString;
	}
	return url;
}
//#endregion
//#region node_modules/laravel-precognition/dist/http/fetchClient.js
/**
* Get the X-Requested-With header from Laravel's bootstrap config if available.
*/
function getAjaxHeader() {
	if (typeof window === "undefined") return null;
	return window.axios?.defaults?.headers?.common?.["X-Requested-With"] ?? null;
}
/**
* Convert data to FormData recursively.
*/
function toFormData(data, formData = new FormData(), parentKey = null) {
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) appendToFormData(formData, parentKey ? `${parentKey}[${key}]` : key, data[key]);
	return formData;
}
function appendToFormData(formData, key, value) {
	if (Array.isArray(value)) return value.forEach((val, index) => appendToFormData(formData, `${key}[${index}]`, val));
	else if (value instanceof Date) return formData.append(key, value.toISOString());
	else if (typeof File !== "undefined" && value instanceof File) return formData.append(key, value, value.name);
	else if (value instanceof Blob) return formData.append(key, value);
	else if (typeof value === "boolean") return formData.append(key, value ? "1" : "0");
	else if (typeof value === "string") return formData.append(key, value);
	else if (typeof value === "number") return formData.append(key, `${value}`);
	else if (value === null || value === void 0) return formData.append(key, "");
	toFormData(value, formData, key);
}
/**
* Prepare the request body.
*/
function prepareBody(data, headers) {
	if (data === void 0 || data === null) return;
	if (data instanceof FormData) return data;
	if (typeof data === "object" && hasFiles$1(data)) return toFormData(data);
	if (typeof data === "object" || headers["Content-Type"]?.includes("application/json")) return JSON.stringify(data);
	return String(data);
}
/**
* Parse response headers into a plain object.
*/
function parseHeaders$1(headers) {
	const result = {};
	headers.forEach((value, key) => {
		result[key.toLowerCase()] = value;
	});
	return result;
}
/**
* Create a fetch-based HTTP client.
*/
function createFetchClient(options = {}) {
	let xsrfCookieName = options.xsrfCookieName ?? "XSRF-TOKEN";
	let xsrfHeaderName = options.xsrfHeaderName ?? "X-XSRF-TOKEN";
	function getXsrfToken() {
		if (typeof document === "undefined") return null;
		const match = document.cookie.match(new RegExp("(^|;\\s*)" + xsrfCookieName + "=([^;]*)"));
		return match ? decodeURIComponent(match[2]) : null;
	}
	return {
		setXsrfCookieName(name) {
			xsrfCookieName = name;
		},
		setXsrfHeaderName(name) {
			xsrfHeaderName = name;
		},
		async request(config) {
			const url = buildUrl(config.url, config.baseURL, config.params);
			const method = config.method.toUpperCase();
			const headers = {};
			const ajaxHeader = getAjaxHeader();
			if (ajaxHeader) headers["X-Requested-With"] = ajaxHeader;
			if (config.data !== void 0 && !["GET", "DELETE"].includes(method)) {
				if (!(config.data instanceof FormData) && !hasFiles$1(config.data)) headers["Content-Type"] = "application/json";
			}
			if (config.headers) Object.entries(config.headers).forEach(([key, value]) => {
				if (value !== void 0) headers[key] = String(value);
			});
			const xsrfToken = getXsrfToken();
			if (xsrfToken && ![
				"GET",
				"HEAD",
				"OPTIONS"
			].includes(method)) headers[xsrfHeaderName] = xsrfToken;
			let signal = config.signal;
			let timeoutId;
			const timeout = config.timeout ?? 3e4;
			if (timeout > 0 && !signal) {
				const controller = new AbortController();
				signal = controller.signal;
				timeoutId = setTimeout(() => controller.abort(), timeout);
			}
			const body = ["GET", "DELETE"].includes(method) ? void 0 : prepareBody(config.data, headers);
			if (body instanceof FormData) delete headers["Content-Type"];
			try {
				const response = await fetch(url, {
					method,
					headers,
					body,
					signal,
					credentials: config.credentials ?? "same-origin"
				});
				if (timeoutId) clearTimeout(timeoutId);
				let data;
				if (response.headers.get("content-type")?.includes("application/json")) data = await response.json();
				else data = await response.text();
				const httpResponse = {
					status: response.status,
					data,
					headers: parseHeaders$1(response.headers)
				};
				if (!response.ok) throw new HttpResponseError$1(httpResponse);
				return httpResponse;
			} catch (error) {
				if (timeoutId) clearTimeout(timeoutId);
				if (error instanceof HttpResponseError$1) throw error;
				if (error instanceof DOMException && error.name === "AbortError") throw new HttpCancelledError$1();
				if (error instanceof TypeError) throw new HttpNetworkError$1(error.message);
				throw error;
			}
		}
	};
}
/**
* Default fetch HTTP client instance.
*/
var fetchHttpClient = createFetchClient();
//#endregion
//#region node_modules/laravel-precognition/dist/client.js
/**
* The configured HTTP client.
*/
var httpClient$1 = fetchHttpClient;
/**
* The configured base URL.
*/
var baseURL = void 0;
/**
* The configured default timeout.
*/
var timeout = void 0;
/**
* The configured credentials mode.
*/
var credentials = "same-origin";
/**
* The request fingerprint resolver.
*/
var requestFingerprintResolver = (config) => `${config.method}:${config.baseURL ?? baseURL ?? ""}${config.url}`;
/**
* The precognition success resolver.
*/
var successResolver = (response) => response.status === 204 && response.headers["precognition-success"] === "true";
/**
* The abort controller cache.
*/
var abortControllers = {};
/**
* The precognitive HTTP client instance.
*/
var client = {
	get: (url, data = {}, config = {}) => request(mergeConfig("get", url, data, config)),
	post: (url, data = {}, config = {}) => request(mergeConfig("post", url, data, config)),
	patch: (url, data = {}, config = {}) => request(mergeConfig("patch", url, data, config)),
	put: (url, data = {}, config = {}) => request(mergeConfig("put", url, data, config)),
	delete: (url, data = {}, config = {}) => request(mergeConfig("delete", url, data, config)),
	useHttpClient(newHttpClient) {
		httpClient$1 = newHttpClient;
		return client;
	},
	withBaseURL(url) {
		baseURL = url;
		return client;
	},
	withTimeout(duration) {
		timeout = duration;
		return client;
	},
	withCredentials(value) {
		credentials = typeof value === "string" ? value : value ? "include" : "omit";
		return client;
	},
	fingerprintRequestsUsing(callback) {
		requestFingerprintResolver = callback === null ? () => null : callback;
		return client;
	},
	determineSuccessUsing(callback) {
		successResolver = callback;
		return client;
	},
	withXsrfCookieName(name) {
		fetchHttpClient.setXsrfCookieName(name);
		return client;
	},
	withXsrfHeaderName(name) {
		fetchHttpClient.setXsrfHeaderName(name);
		return client;
	}
};
/**
* Merge the client specified arguments with the provided configuration.
*/
var mergeConfig = (method, url, data, config) => ({
	url,
	method,
	...config,
	...["get", "delete"].includes(method) ? { params: merge({}, data, config?.params) } : { data: merge({}, data, config?.data) }
});
/**
* Send and handle a new request.
*/
var request = (userConfig = {}) => {
	const config = [
		resolveConfig,
		abortMatchingRequests,
		refreshAbortController
	].reduce((config, callback) => callback(config), userConfig);
	if ((config.onBefore ?? (() => true))() === false) return Promise.resolve(null);
	(config.onStart ?? (() => null))();
	return httpClient$1.request({
		method: config.method,
		url: config.url,
		baseURL: config.baseURL ?? baseURL,
		data: config.data,
		params: config.params,
		headers: config.headers,
		signal: config.signal,
		timeout: config.timeout,
		credentials
	}).then(async (response) => {
		if (config.precognitive) validatePrecognitionResponse(response);
		const status = response.status;
		let payload = response;
		if (config.precognitive && config.onPrecognitionSuccess && successResolver(response)) payload = await Promise.resolve(config.onPrecognitionSuccess(response) ?? payload);
		if (config.onSuccess && isSuccess(status)) payload = await Promise.resolve(config.onSuccess(payload) ?? payload);
		return (resolveStatusHandler(config, status) ?? ((response) => response))(payload) ?? payload;
	}, (error) => {
		if (isNotServerGeneratedError(error)) return Promise.reject(error);
		const httpError = error;
		if (config.precognitive) validatePrecognitionResponse(httpError.response);
		return (resolveStatusHandler(config, httpError.response.status) ?? ((_, error) => Promise.reject(error)))(httpError.response, httpError);
	}).finally(config.onFinish ?? (() => null));
};
/**
* Resolve the configuration.
*/
var resolveConfig = (config) => {
	const only = config.only ?? config.validate;
	return {
		...config,
		timeout: config.timeout ?? timeout,
		precognitive: config.precognitive !== false,
		fingerprint: typeof config.fingerprint === "undefined" ? requestFingerprintResolver(config, httpClient$1) : config.fingerprint,
		headers: {
			...config.headers,
			"Accept": "application/json",
			"Content-Type": resolveContentType(config),
			...config.precognitive !== false ? { Precognition: true } : {},
			...only ? { "Precognition-Validate-Only": Array.from(only).join() } : {}
		}
	};
};
/**
* Determine if the status is successful.
*/
var isSuccess = (status) => status >= 200 && status < 300;
/**
* Abort an existing request with the same configured fingerprint.
*/
var abortMatchingRequests = (config) => {
	if (typeof config.fingerprint !== "string") return config;
	abortControllers[config.fingerprint]?.abort();
	delete abortControllers[config.fingerprint];
	return config;
};
/**
* Create and configure the abort controller for a new request.
*/
var refreshAbortController = (config) => {
	if (typeof config.fingerprint !== "string" || config.signal || !config.precognitive) return config;
	abortControllers[config.fingerprint] = new AbortController();
	return {
		...config,
		signal: abortControllers[config.fingerprint].signal
	};
};
/**
* Ensure that the response is a Precognition response.
*/
var validatePrecognitionResponse = (response) => {
	if (response.headers?.precognition !== "true") throw Error("Did not receive a Precognition response. Ensure you have the Precognition middleware in place for the route.");
};
/**
* Determine if the error was not triggered by a server response.
*/
var isNotServerGeneratedError = (error) => {
	return !(error instanceof HttpResponseError$1) || typeof error.response?.status !== "number";
};
/**
* Resolve the handler for the given HTTP response status.
*/
var resolveStatusHandler = (config, code) => ({
	401: config.onUnauthorized,
	403: config.onForbidden,
	404: config.onNotFound,
	409: config.onConflict,
	422: config.onValidationError,
	423: config.onLocked
})[code];
/**
* Resolve the request's "Content-Type" header.
*/
var resolveContentType = (config) => config.headers?.["Content-Type"] ?? config.headers?.["Content-type"] ?? config.headers?.["content-type"] ?? (hasFiles$1(config.data) ? "multipart/form-data" : "application/json");
//#endregion
//#region node_modules/laravel-precognition/dist/validator.js
/**
* Expand a wildcard path to concrete paths using the given data.
*
* Examples:
* - 'users.*' with {users: [{name: 'A'}, {name: 'B'}]} => ['users.0', 'users.1']
* - 'users.*.name' with {users: [{name: 'A'}, {name: 'B'}]} => ['users.0.name', 'users.1.name']
* - 'author.*' with {author: {name: 'John', bio: 'Dev'}} => ['author.name', 'author.bio']
*/
var expandWildcardPaths = (pattern, data) => {
	if (!pattern.includes("*")) return [pattern];
	const parts = pattern.split(".");
	let paths = [""];
	for (const part of parts) if (part === "*") {
		const expanded = [];
		for (const path of paths) {
			const value = path ? get(data, path) : data;
			if (Array.isArray(value)) for (let index = 0; index < value.length; index++) expanded.push(path ? `${path}.${index}` : String(index));
			else if (value !== null && typeof value === "object") for (const key of Object.keys(value)) expanded.push(path ? `${path}.${key}` : key);
		}
		paths = expanded;
	} else paths = paths.map((path) => path ? `${path}.${part}` : part);
	return paths;
};
/**
* Determine if a key matches the given pattern.
*/
var keyMatchesPattern = (key, pattern) => {
	if (!pattern.includes("*")) return key === pattern;
	return new RegExp("^" + pattern.replace(/\./g, "\\.").replace(/\*/g, "[^.]+") + "$").test(key);
};
/**
* Omit entries from an object whose keys match the given patterns.
*/
var omitByPattern = (obj, patterns) => {
	return Object.fromEntries(Object.entries(obj).filter(([key]) => {
		return !patterns.some((pattern) => keyMatchesPattern(key, pattern));
	}));
};
var createValidator = (callback, initialData = {}) => {
	/**
	* Event listener state.
	*/
	const listeners = {
		errorsChanged: [],
		touchedChanged: [],
		validatingChanged: [],
		validatedChanged: []
	};
	/**
	* Validate files state.
	*/
	let validateFiles = false;
	/**
	* Processing validation state.
	*/
	let validating = false;
	/**
	* Set the validating inputs.
	*
	* Returns an array of listeners that should be invoked once all state
	* changes have taken place.
	*/
	const setValidating = (value) => {
		if (value !== validating) {
			validating = value;
			return listeners.validatingChanged;
		}
		return [];
	};
	/**
	* Inputs that have been validated.
	*/
	let validated = [];
	/**
	* Set the validated inputs.
	*
	* Returns an array of listeners that should be invoked once all state
	* changes have taken place.
	*/
	const setValidated = (value) => {
		const uniqueNames = [...new Set(value)];
		if (validated.length !== uniqueNames.length || !uniqueNames.every((name) => validated.includes(name))) {
			validated = uniqueNames;
			return listeners.validatedChanged;
		}
		return [];
	};
	/**
	* Valid validation state.
	*/
	const valid = () => validated.filter((name) => typeof errors[name] === "undefined");
	/**
	* Touched input state.
	*/
	let touched = [];
	/**
	* Set the touched inputs.
	*
	* Returns an array of listeners that should be invoked once all state
	* changes have taken place.
	*/
	const setTouched = (value) => {
		const uniqueNames = [...new Set(value)];
		if (touched.length !== uniqueNames.length || !uniqueNames.every((name) => touched.includes(name))) {
			touched = uniqueNames;
			return listeners.touchedChanged;
		}
		return [];
	};
	/**
	* Validation errors state.
	*/
	let errors = {};
	/**
	* Set the input errors.
	*
	* Returns an array of listeners that should be invoked once all state
	* changes have taken place.
	*/
	const setErrors = (value) => {
		const prepared = toValidationErrors(value);
		if (!isEqual(errors, prepared)) {
			errors = prepared;
			return listeners.errorsChanged;
		}
		return [];
	};
	/**
	* Forget the given input's errors.
	*
	* Returns an array of listeners that should be invoked once all state
	* changes have taken place.
	*/
	const forgetError = (name) => {
		const newErrors = { ...errors };
		delete newErrors[resolveName(name)];
		return setErrors(newErrors);
	};
	/**
	* Has errors state.
	*/
	const hasErrors = () => Object.keys(errors).length > 0;
	/**
	* Debouncing timeout state.
	*/
	let debounceTimeoutDuration = 1500;
	const setDebounceTimeout = (value) => {
		debounceTimeoutDuration = value;
		validator.cancel();
		validator = createValidator();
	};
	/**
	* The old data.
	*/
	let oldData = initialData;
	/**
	* The data currently being validated.
	*/
	let validatingData = null;
	/**
	* The old touched.
	*/
	let oldTouched = [];
	/**
	* The touched currently being validated.
	*/
	let validatingTouched = null;
	/**
	* Create a debounced validation callback.
	*/
	const createValidator = () => debounce$1((instanceConfig) => {
		callback({
			get: (url, data = {}, globalConfig = {}) => client.get(url, parseData(data), resolveConfig(globalConfig, instanceConfig, data)),
			post: (url, data = {}, globalConfig = {}) => client.post(url, parseData(data), resolveConfig(globalConfig, instanceConfig, data)),
			patch: (url, data = {}, globalConfig = {}) => client.patch(url, parseData(data), resolveConfig(globalConfig, instanceConfig, data)),
			put: (url, data = {}, globalConfig = {}) => client.put(url, parseData(data), resolveConfig(globalConfig, instanceConfig, data)),
			delete: (url, data = {}, globalConfig = {}) => client.delete(url, parseData(data), resolveConfig(globalConfig, instanceConfig, data))
		}).catch((error) => {
			if (error instanceof HttpCancelledError$1) return null;
			if (error instanceof HttpResponseError$1 && error.response?.status === 422) return null;
			return Promise.reject(error);
		});
	}, debounceTimeoutDuration, {
		leading: true,
		trailing: true
	});
	/**
	* Validator state.
	*/
	let validator = createValidator();
	/**
	* Resolve the configuration.
	*/
	const resolveConfig = (globalConfig, instanceConfig, data = {}) => {
		const config = {
			...globalConfig,
			...instanceConfig
		};
		const only = Array.from(config.only ?? config.validate ?? touched);
		return {
			...instanceConfig,
			...merge({}, globalConfig, instanceConfig),
			only,
			timeout: config.timeout ?? 5e3,
			onValidationError: (response, error) => {
				[...setValidated([...validated, ...only]), ...setErrors(merge(omitByPattern({ ...errors }, only), response.data.errors))].forEach((listener) => listener());
				return config.onValidationError ? config.onValidationError(response, error) : Promise.reject(error);
			},
			onSuccess: (response) => {
				setValidated([...validated, ...only]).forEach((listener) => listener());
				return config.onSuccess ? config.onSuccess(response) : response;
			},
			onPrecognitionSuccess: (response) => {
				[...setValidated([...validated, ...only]), ...setErrors(omitByPattern({ ...errors }, only))].forEach((listener) => listener());
				return config.onPrecognitionSuccess ? config.onPrecognitionSuccess(response) : response;
			},
			onBefore: () => {
				const hasWildcards = touched.some((name) => name.includes("*"));
				const expandedTouched = hasWildcards ? [...new Set(touched.flatMap((name) => expandWildcardPaths(name, data)))] : touched;
				if (config.onBeforeValidation && config.onBeforeValidation({
					data,
					touched: expandedTouched
				}, {
					data: oldData,
					touched: oldTouched
				}) === false) return false;
				if ((config.onBefore || (() => true))() === false) return false;
				if (hasWildcards) setTouched(expandedTouched).forEach((listener) => listener());
				validatingTouched = touched;
				validatingData = data;
				return true;
			},
			onStart: () => {
				setValidating(true).forEach((listener) => listener());
				(config.onStart ?? (() => null))();
			},
			onFinish: () => {
				setValidating(false).forEach((listener) => listener());
				oldTouched = validatingTouched;
				oldData = validatingData;
				validatingTouched = validatingData = null;
				(config.onFinish ?? (() => null))();
			}
		};
	};
	/**
	* Validate the given input.
	*/
	const validate = (name, value, config) => {
		if (typeof name === "undefined") {
			const only = Array.from(config?.only ?? config?.validate ?? []);
			setTouched([...touched, ...only]).forEach((listener) => listener());
			validator(config ?? {});
			return;
		}
		if (isFile$1(value) && !validateFiles) {
			console.warn("Precognition file validation is not active. Call the \"validateFiles\" function on your form to enable it.");
			return;
		}
		name = resolveName(name);
		if (name.includes("*") || get(oldData, name) !== value) {
			setTouched([name, ...touched]).forEach((listener) => listener());
			validator(config ?? {});
		}
	};
	/**
	* Parse the validated data.
	*/
	const parseData = (data) => validateFiles === false ? forgetFiles(data) : data;
	/**
	* The form validator instance.
	*/
	const form = {
		touched: () => touched,
		validate(name, value, config) {
			if (typeof name === "object" && !("target" in name)) {
				config = name;
				name = value = void 0;
			}
			validate(name, value, config);
			return form;
		},
		touch(input) {
			const inputs = Array.isArray(input) ? input : [resolveName(input)];
			setTouched([...touched, ...inputs]).forEach((listener) => listener());
			return form;
		},
		validating: () => validating,
		valid,
		errors: () => errors,
		hasErrors,
		setErrors(value) {
			setErrors(value).forEach((listener) => listener());
			return form;
		},
		forgetError(name) {
			forgetError(name).forEach((listener) => listener());
			return form;
		},
		defaults(data) {
			initialData = data;
			oldData = data;
			return form;
		},
		reset(...names) {
			if (names.length === 0) setTouched([]).forEach((listener) => listener());
			else {
				const newTouched = [...touched];
				names.forEach((name) => {
					if (newTouched.includes(name)) newTouched.splice(newTouched.indexOf(name), 1);
					set(oldData, name, get(initialData, name));
				});
				setTouched(newTouched).forEach((listener) => listener());
			}
			return form;
		},
		setTimeout(value) {
			setDebounceTimeout(value);
			return form;
		},
		on(event, callback) {
			listeners[event].push(callback);
			return form;
		},
		validateFiles() {
			validateFiles = true;
			return form;
		},
		withoutFileValidation() {
			validateFiles = false;
			return form;
		}
	};
	return form;
};
/**
* Normalise the validation errors as Inertia formatted errors.
*/
var toSimpleValidationErrors = (errors) => {
	return Object.keys(errors).reduce((carry, key) => ({
		...carry,
		[key]: Array.isArray(errors[key]) ? errors[key][0] : errors[key]
	}), {});
};
/**
* Normalise the validation errors as Laravel formatted errors.
*/
var toValidationErrors = (errors) => {
	return Object.keys(errors).reduce((carry, key) => ({
		...carry,
		[key]: typeof errors[key] === "string" ? [errors[key]] : errors[key]
	}), {});
};
/**
* Resolve the input's "name" attribute.
*/
var resolveName = (name) => {
	return typeof name !== "string" ? name.target.name : name;
};
/**
* Forget any files from the payload.
*/
var forgetFiles = (data) => {
	const newData = { ...data };
	Object.keys(newData).forEach((name) => {
		const value = newData[name];
		if (value === null) return;
		if (isFile$1(value)) {
			delete newData[name];
			return;
		}
		if (Array.isArray(value)) {
			newData[name] = Object.values(forgetFiles({ ...value }));
			return;
		}
		if (typeof value === "object") {
			newData[name] = forgetFiles(newData[name]);
			return;
		}
	});
	return newData;
};
//#endregion
//#region node_modules/@inertiajs/core/dist/index.js
var Config = class {
	config = {};
	defaults;
	constructor(defaults) {
		this.defaults = defaults;
	}
	extend(defaults) {
		if (defaults) this.defaults = {
			...this.defaults,
			...defaults
		};
		return this;
	}
	replace(newConfig) {
		this.config = newConfig;
	}
	get(key) {
		return has(this.config, key) ? get(this.config, key) : get(this.defaults, key);
	}
	set(keyOrValues, value) {
		if (typeof keyOrValues === "string") set(this.config, keyOrValues, value);
		else Object.entries(keyOrValues).forEach(([key, val]) => {
			set(this.config, key, val);
		});
	}
};
var config$1 = new Config({
	form: {
		recentlySuccessfulDuration: 2e3,
		forceIndicesArrayFormatInFormData: true,
		withAllErrors: false
	},
	prefetch: {
		cacheFor: 3e4,
		hoverDelay: 75
	}
});
function debounce(fn, delay) {
	let timeoutID;
	return function(...args) {
		clearTimeout(timeoutID);
		timeoutID = setTimeout(() => fn.apply(this, args), delay);
	};
}
function fireEvent(name, options) {
	return document.dispatchEvent(new CustomEvent(`inertia:${name}`, options));
}
var fireBeforeEvent = (visit) => {
	return fireEvent("before", {
		cancelable: true,
		detail: { visit }
	});
};
var fireErrorEvent = (errors, { page: page2, visitId } = {}) => {
	return fireEvent("error", { detail: {
		errors,
		page: page2,
		visitId
	} });
};
var fireNetworkErrorEvent = (error) => {
	return fireEvent("networkError", {
		cancelable: true,
		detail: { error }
	});
};
var fireFinishEvent = (visit) => {
	return fireEvent("finish", { detail: { visit } });
};
var fireHttpExceptionEvent = (response) => {
	return fireEvent("httpException", {
		cancelable: true,
		detail: { response }
	});
};
var fireBeforeUpdateEvent = (page2) => {
	return fireEvent("beforeUpdate", { detail: { page: page2 } });
};
var fireNavigateEvent = (page2, { cached = false, visitId } = {}) => {
	return fireEvent("navigate", { detail: {
		page: page2,
		cached,
		visitId
	} });
};
var fireClientVisitEvent = (page2, { replace, visitId }) => {
	return fireEvent("clientVisit", { detail: {
		page: page2,
		replace,
		visitId
	} });
};
var fireProgressEvent = (progress3) => {
	return fireEvent("progress", { detail: { progress: progress3 } });
};
var fireStartEvent = (visit) => {
	return fireEvent("start", { detail: { visit } });
};
var fireSuccessEvent = (page2, { visitId } = {}) => {
	return fireEvent("success", { detail: {
		page: page2,
		visitId
	} });
};
var firePrefetchedEvent = (response, visit) => {
	return fireEvent("prefetched", { detail: {
		fetchedAt: Date.now(),
		response,
		visit
	} });
};
var firePrefetchingEvent = (visit) => {
	return fireEvent("prefetching", { detail: { visit } });
};
var fireFlashEvent = (flash) => {
	return fireEvent("flash", { detail: { flash } });
};
var fireLocationEvent = (url, versionChange) => {
	return fireEvent("location", {
		cancelable: true,
		detail: {
			url,
			versionChange
		}
	});
};
var SessionStorage = class {
	static locationVisitKey = "inertiaLocationVisit";
	static set(key, value) {
		if (typeof window !== "undefined") window.sessionStorage.setItem(key, JSON.stringify(value));
	}
	static get(key) {
		if (typeof window !== "undefined") return JSON.parse(window.sessionStorage.getItem(key) || "null");
	}
	static merge(key, value) {
		const existing = this.get(key);
		if (existing === null) this.set(key, value);
		else this.set(key, {
			...existing,
			...value
		});
	}
	static remove(key) {
		if (typeof window !== "undefined") window.sessionStorage.removeItem(key);
	}
	static removeNested(key, nestedKey) {
		const existing = this.get(key);
		if (existing !== null) {
			delete existing[nestedKey];
			this.set(key, existing);
		}
	}
	static exists(key) {
		try {
			return this.get(key) !== null;
		} catch (error) {
			return false;
		}
	}
	static clear() {
		if (typeof window !== "undefined") window.sessionStorage.clear();
	}
};
var encryptHistory = async (data) => {
	if (typeof window === "undefined") throw new Error("Unable to encrypt history");
	const iv = getIv();
	const key = await getOrCreateKey(await getKeyFromSessionStorage());
	if (!key) throw new Error("Unable to encrypt history");
	return await encryptData(iv, key, data);
};
var historySessionStorageKeys = {
	key: "historyKey",
	iv: "historyIv"
};
var decryptHistory = async (data) => {
	const iv = getIv();
	const storedKey = await getKeyFromSessionStorage();
	if (!storedKey) throw new Error("Unable to decrypt history");
	return await decryptData(iv, storedKey, data);
};
var encryptData = async (iv, key, data) => {
	if (typeof window === "undefined") throw new Error("Unable to encrypt history");
	if (typeof window.crypto.subtle === "undefined") {
		console.warn("Encryption is not supported in this environment. SSL is required.");
		return Promise.resolve(data);
	}
	const textEncoder = new TextEncoder();
	const str = JSON.stringify(data);
	const encoded = new Uint8Array(str.length * 3);
	const result = textEncoder.encodeInto(str, encoded);
	return window.crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, encoded.subarray(0, result.written));
};
var decryptData = async (iv, key, data) => {
	if (typeof window.crypto.subtle === "undefined") {
		console.warn("Decryption is not supported in this environment. SSL is required.");
		return Promise.resolve(data);
	}
	const decrypted = await window.crypto.subtle.decrypt({
		name: "AES-GCM",
		iv
	}, key, data);
	return JSON.parse(new TextDecoder().decode(decrypted));
};
var getIv = () => {
	const ivString = SessionStorage.get(historySessionStorageKeys.iv);
	if (ivString) return new Uint8Array(ivString);
	const iv = window.crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	SessionStorage.set(historySessionStorageKeys.iv, Array.from(iv));
	return iv;
};
var createKey = async () => {
	if (typeof window.crypto.subtle === "undefined") {
		console.warn("Encryption is not supported in this environment. SSL is required.");
		return Promise.resolve(null);
	}
	return window.crypto.subtle.generateKey({
		name: "AES-GCM",
		length: 256
	}, true, ["encrypt", "decrypt"]);
};
var saveKey = async (key) => {
	if (typeof window.crypto.subtle === "undefined") {
		console.warn("Encryption is not supported in this environment. SSL is required.");
		return Promise.resolve();
	}
	const keyData = await window.crypto.subtle.exportKey("raw", key);
	SessionStorage.set(historySessionStorageKeys.key, Array.from(new Uint8Array(keyData)));
};
var getOrCreateKey = async (key) => {
	if (key) return key;
	const newKey = await createKey();
	if (!newKey) return null;
	await saveKey(newKey);
	return newKey;
};
var getKeyFromSessionStorage = async () => {
	const stringKey = SessionStorage.get(historySessionStorageKeys.key);
	if (!stringKey) return null;
	return await window.crypto.subtle.importKey("raw", new Uint8Array(stringKey), {
		name: "AES-GCM",
		length: 256
	}, true, ["encrypt", "decrypt"]);
};
var stripTopLevelUndefined = (obj) => {
	const result = {};
	for (const key of Object.keys(obj)) if (obj[key] !== void 0) result[key] = obj[key];
	return result;
};
var objectsAreEqual = (obj1, obj2, excludeKeys) => {
	if (obj1 === obj2) return true;
	for (const key in obj1) {
		if (excludeKeys.includes(key)) continue;
		if (obj1[key] === obj2[key]) continue;
		if (!compareValues(obj1[key], obj2[key])) return false;
	}
	for (const key in obj2) {
		if (excludeKeys.includes(key)) continue;
		if (!(key in obj1)) return false;
	}
	return true;
};
var compareValues = (value1, value2) => {
	switch (typeof value1) {
		case "object": return objectsAreEqual(value1, value2, []);
		case "function": return value1.toString() === value2.toString();
		default: return value1 === value2;
	}
};
var setPathPreservingIdentity = (target, path, value) => {
	const keys = toPath(path);
	if (keys.length === 0) return target;
	const copyAlongPath = (node, depth) => {
		if (depth === keys.length) return value;
		const key = keys[depth];
		const copy = Array.isArray(node) ? [...node] : node && typeof node === "object" ? { ...node } : /^(?:0|[1-9]\d*)$/.test(key) ? [] : {};
		copy[key] = copyAlongPath(node?.[key], depth + 1);
		return copy;
	};
	return copyAlongPath(target, 0);
};
var conversionMap = {
	ms: 1,
	s: 1e3,
	m: 6e4,
	h: 36e5,
	d: 864e5
};
var timeToMs = (time) => {
	if (typeof time === "number") return time;
	for (const [unit, conversion] of Object.entries(conversionMap)) if (time.endsWith(unit)) return parseFloat(time) * conversion;
	return parseInt(time);
};
var PrefetchedRequests = class {
	cached = [];
	inFlightRequests = [];
	removalTimers = [];
	currentUseId = null;
	add(params, sendFunc, { cacheFor, cacheTags }) {
		if (this.findInFlight(params)) return Promise.resolve();
		const existing = this.findCached(params);
		if (!params.fresh && existing && existing.staleTimestamp > Date.now()) return Promise.resolve();
		const [stale, prefetchExpiresIn] = this.extractStaleValues(cacheFor);
		const promise = new Promise((resolve, reject) => {
			sendFunc({
				...params,
				onCancel: () => {
					this.remove(params);
					params.onCancel();
					reject();
				},
				onError: (error) => {
					this.remove(params);
					params.onError(error);
					reject();
				},
				onPrefetching(visitParams) {
					params.onPrefetching(visitParams);
				},
				onPrefetched(response, visit) {
					params.onPrefetched(response, visit);
				},
				onPrefetchResponse(response) {
					resolve(response);
				},
				onPrefetchError(error) {
					prefetchedRequests.removeFromInFlight(params);
					reject(error);
				}
			});
		}).then((response) => {
			this.remove(params);
			const pageResponse = response.getPageResponse();
			page$1.mergeOncePropsIntoResponse(pageResponse);
			this.cached.push({
				params: { ...params },
				staleTimestamp: Date.now() + stale,
				expiresAt: Date.now() + prefetchExpiresIn,
				response: promise,
				singleUse: prefetchExpiresIn === 0,
				timestamp: Date.now(),
				inFlight: false,
				tags: Array.isArray(cacheTags) ? cacheTags : [cacheTags]
			});
			const oncePropExpiresIn = this.getShortestOncePropTtl(pageResponse);
			this.scheduleForRemoval(params, oncePropExpiresIn ? Math.min(prefetchExpiresIn, oncePropExpiresIn) : prefetchExpiresIn);
			this.removeFromInFlight(params);
			response.handlePrefetch();
			return response;
		});
		this.inFlightRequests.push({
			params: { ...params },
			response: promise,
			staleTimestamp: null,
			inFlight: true
		});
		return promise;
	}
	removeAll() {
		this.cached = [];
		this.removalTimers.forEach((removalTimer) => {
			clearTimeout(removalTimer.timer);
		});
		this.removalTimers = [];
	}
	removeByTags(tags) {
		this.cached = this.cached.filter((prefetched) => {
			return !prefetched.tags.some((tag) => tags.includes(tag));
		});
	}
	remove(params) {
		this.cached = this.cached.filter((prefetched) => {
			return !this.paramsAreEqual(prefetched.params, params);
		});
		this.clearTimer(params);
	}
	removeFromInFlight(params) {
		this.inFlightRequests = this.inFlightRequests.filter((prefetching) => {
			return !this.paramsAreEqual(prefetching.params, params);
		});
	}
	extractStaleValues(cacheFor) {
		const [stale, expires] = this.cacheForToStaleAndExpires(cacheFor);
		return [timeToMs(stale), timeToMs(expires)];
	}
	cacheForToStaleAndExpires(cacheFor) {
		if (!Array.isArray(cacheFor)) return [cacheFor, cacheFor];
		switch (cacheFor.length) {
			case 0: return [0, 0];
			case 1: return [cacheFor[0], cacheFor[0]];
			default: return [cacheFor[0], cacheFor[1]];
		}
	}
	clearTimer(params) {
		const timer = this.removalTimers.find((removalTimer) => {
			return this.paramsAreEqual(removalTimer.params, params);
		});
		if (timer) {
			clearTimeout(timer.timer);
			this.removalTimers = this.removalTimers.filter((removalTimer) => removalTimer !== timer);
		}
	}
	scheduleForRemoval(params, expiresIn) {
		if (typeof window === "undefined") return;
		this.clearTimer(params);
		if (expiresIn > 0) {
			const timer = window.setTimeout(() => this.remove(params), expiresIn);
			this.removalTimers.push({
				params,
				timer
			});
		}
	}
	get(params) {
		return this.findCached(params) || this.findInFlight(params);
	}
	use(prefetched, params) {
		const id = `${params.url.pathname}-${Date.now()}-${Math.random().toString(36).substring(7)}`;
		this.currentUseId = id;
		const consumedParams = {
			...params,
			cached: true
		};
		return prefetched.response.then((response) => {
			if (this.currentUseId !== id) return;
			response.mergeParams({
				...consumedParams,
				onPrefetched: () => {}
			});
			this.removeSingleUseItems(params);
			return response.handle();
		});
	}
	removeSingleUseItems(params) {
		this.cached = this.cached.filter((prefetched) => {
			if (!this.paramsAreEqual(prefetched.params, params)) return true;
			return !prefetched.singleUse;
		});
	}
	findCached(params) {
		return this.cached.find((prefetched) => {
			return this.paramsAreEqual(prefetched.params, params);
		}) || null;
	}
	findInFlight(params) {
		return this.inFlightRequests.find((prefetched) => {
			return this.paramsAreEqual(prefetched.params, params);
		}) || null;
	}
	withoutPurposePrefetchHeader(params) {
		const newParams = cloneDeep$1(params);
		if (newParams.headers["Purpose"] === "prefetch") delete newParams.headers["Purpose"];
		return newParams;
	}
	paramsAreEqual(params1, params2) {
		return objectsAreEqual(this.withoutPurposePrefetchHeader(params1), this.withoutPurposePrefetchHeader(params2), [
			"id",
			"showProgress",
			"replace",
			"prefetch",
			"preserveScroll",
			"preserveState",
			"onBefore",
			"onBeforeUpdate",
			"onStart",
			"onProgress",
			"onFinish",
			"onCancel",
			"onSuccess",
			"onError",
			"onFlash",
			"onPrefetched",
			"onCancelToken",
			"onPrefetching",
			"async",
			"viewTransition",
			"optimistic",
			"component",
			"pageProps",
			"cached"
		]);
	}
	updateCachedOncePropsFromCurrentPage() {
		this.cached.forEach((prefetched) => {
			prefetched.response.then((response) => {
				const pageResponse = response.getPageResponse();
				page$1.mergeOncePropsIntoResponse(pageResponse, { force: true });
				for (const [group, deferredProps] of Object.entries(pageResponse.deferredProps ?? {})) {
					const remaining = deferredProps.filter((prop) => get(pageResponse.props, prop) === void 0);
					if (remaining.length > 0) pageResponse.deferredProps[group] = remaining;
					else delete pageResponse.deferredProps[group];
				}
				const oncePropExpiresIn = this.getShortestOncePropTtl(pageResponse);
				if (oncePropExpiresIn === null) return;
				const prefetchExpiresIn = prefetched.expiresAt - Date.now();
				const expiresIn = Math.min(prefetchExpiresIn, oncePropExpiresIn);
				if (expiresIn > 0) this.scheduleForRemoval(prefetched.params, expiresIn);
				else this.remove(prefetched.params);
			});
		});
	}
	getShortestOncePropTtl(page2) {
		const expiryTimestamps = Object.values(page2.onceProps ?? {}).map((onceProp) => onceProp.expiresAt).filter((expiresAt) => !!expiresAt);
		if (expiryTimestamps.length === 0) return null;
		return Math.min(...expiryTimestamps) - Date.now();
	}
};
var prefetchedRequests = new PrefetchedRequests();
var elementInViewport = (el) => {
	if (el.offsetParent === null) return false;
	const rect = el.getBoundingClientRect();
	const verticallyVisible = rect.top < window.innerHeight && rect.bottom >= 0;
	const horizontallyVisible = rect.left < window.innerWidth && rect.right >= 0;
	return verticallyVisible && horizontallyVisible;
};
var getScrollableParent = (element) => {
	const allowsVerticalScroll = (el) => {
		const computedStyle = window.getComputedStyle(el);
		if (computedStyle.overflowY === "scroll") return true;
		if (computedStyle.overflowY !== "auto") return false;
		if (["visible", "clip"].includes(computedStyle.overflowX)) return true;
		return hasDimensionConstraint(computedStyle.maxHeight, el.style.height) || isConstrainedByLayout(el, "height");
	};
	const allowsHorizontalScroll = (el) => {
		const computedStyle = window.getComputedStyle(el);
		if (computedStyle.overflowX === "scroll") return true;
		if (computedStyle.overflowX !== "auto") return false;
		if (["visible", "clip"].includes(computedStyle.overflowY)) return true;
		return hasDimensionConstraint(computedStyle.maxWidth, el.style.width) || isConstrainedByLayout(el, "width");
	};
	const hasDimensionConstraint = (computedMaxDimension, inlineStyleDimension) => {
		if (computedMaxDimension && computedMaxDimension !== "none" && computedMaxDimension !== "0px") return true;
		if (inlineStyleDimension && inlineStyleDimension !== "auto" && inlineStyleDimension !== "0") return true;
		return false;
	};
	const isConstrainedByLayout = (el, dimension) => {
		const parent2 = el.parentElement;
		if (!parent2) return false;
		const parentStyle = window.getComputedStyle(parent2);
		if (["flex", "inline-flex"].includes(parentStyle.display)) {
			const isColumnLayout = ["column", "column-reverse"].includes(parentStyle.flexDirection);
			return dimension === "height" ? isColumnLayout : !isColumnLayout;
		}
		return ["grid", "inline-grid"].includes(parentStyle.display);
	};
	let parent = element?.parentElement;
	while (parent) {
		const allowsScroll = allowsVerticalScroll(parent) || allowsHorizontalScroll(parent);
		if (window.getComputedStyle(parent).display !== "contents" && allowsScroll) return parent;
		parent = parent.parentElement;
	}
	return null;
};
var getElementsInViewportFromCollection = (elements, referenceElement) => {
	if (!referenceElement) return elements.filter((element) => elementInViewport(element));
	const referenceIndex = elements.indexOf(referenceElement);
	const upwardElements = [];
	const downwardElements = [];
	for (let i = referenceIndex; i >= 0; i--) {
		const element = elements[i];
		if (elementInViewport(element)) upwardElements.push(element);
		else break;
	}
	for (let i = referenceIndex + 1; i < elements.length; i++) {
		const element = elements[i];
		if (elementInViewport(element)) downwardElements.push(element);
		else break;
	}
	return [...upwardElements.reverse(), ...downwardElements];
};
var requestAnimationFrame = (cb, times = 1) => {
	window.requestAnimationFrame(() => {
		if (times > 1) requestAnimationFrame(cb, times - 1);
		else cb();
	});
};
var getInitialPageFromDOM = (id) => {
	if (typeof window === "undefined") return null;
	const scriptEl = document.querySelector(`script[data-page="${id}"][type="application/json"]`);
	if (scriptEl?.textContent) return JSON.parse(scriptEl.textContent);
	return null;
};
var isServer = typeof window === "undefined";
var isFirefox = !isServer && /Firefox/i.test(window.navigator.userAgent);
var Scroll = class {
	static save() {
		history.saveScrollPositions(this.getScrollRegions());
	}
	static getScrollRegions() {
		return Array.from(this.regions()).map((region) => ({
			top: region.scrollTop,
			left: region.scrollLeft
		}));
	}
	static regions() {
		return document.querySelectorAll("[scroll-region]");
	}
	static scrollToTop() {
		if (isFirefox && getComputedStyle(document.documentElement).scrollBehavior === "smooth") return requestAnimationFrame(() => window.scrollTo(0, 0), 2);
		window.scrollTo(0, 0);
	}
	static reset() {
		if (!(isServer ? null : window.location.hash)) this.scrollToTop();
		this.regions().forEach((region) => {
			if (typeof region.scrollTo === "function") region.scrollTo(0, 0);
			else {
				region.scrollTop = 0;
				region.scrollLeft = 0;
			}
		});
		this.save();
		this.scrollToAnchor();
	}
	static scrollToAnchor() {
		const anchorHash = isServer ? null : window.location.hash;
		if (anchorHash) setTimeout(() => {
			const anchorElement = document.getElementById(anchorHash.slice(1));
			anchorElement ? anchorElement.scrollIntoView() : this.scrollToTop();
		});
	}
	static restore(scrollRegions) {
		if (isServer) return;
		window.requestAnimationFrame(() => {
			this.restoreDocument();
			this.restoreScrollRegions(scrollRegions);
		});
	}
	static restoreScrollRegions(scrollRegions) {
		if (isServer) return;
		this.regions().forEach((region, index) => {
			const scrollPosition = scrollRegions[index];
			if (!scrollPosition) return;
			if (typeof region.scrollTo === "function") region.scrollTo(scrollPosition.left, scrollPosition.top);
			else {
				region.scrollTop = scrollPosition.top;
				region.scrollLeft = scrollPosition.left;
			}
		});
	}
	static restoreDocument() {
		const scrollPosition = history.getDocumentScrollPosition();
		window.scrollTo(scrollPosition.left, scrollPosition.top);
	}
	static onScroll(event) {
		const target = event.target;
		if (typeof target.hasAttribute === "function" && target.hasAttribute("scroll-region")) this.save();
	}
	static onWindowScroll() {
		history.saveDocumentScrollPosition({
			top: window.scrollY,
			left: window.scrollX
		});
	}
};
var isFile = (value) => typeof File !== "undefined" && value instanceof File || value instanceof Blob || typeof FileList !== "undefined" && value instanceof FileList && value.length > 0;
function hasFiles(data) {
	return isFile(data) || data instanceof FormData && Array.from(data.values()).some((value) => hasFiles(value)) || typeof data === "object" && data !== null && Object.values(data).some((value) => hasFiles(value));
}
var isFormData = (value) => value instanceof FormData;
function objectToFormData(source, form = new FormData(), parentKey = null, queryStringArrayFormat = "brackets") {
	source = source || {};
	for (const key in source) if (Object.prototype.hasOwnProperty.call(source, key)) append(form, composeKey(parentKey, key, "indices"), source[key], queryStringArrayFormat);
	return form;
}
function composeKey(parent, key, format) {
	if (!parent) return key;
	return format === "brackets" ? `${parent}[]` : `${parent}[${key}]`;
}
function append(form, key, value, format) {
	if (Array.isArray(value)) return Array.from(value.keys()).forEach((index) => append(form, composeKey(key, index.toString(), format), value[index], format));
	else if (value instanceof Date) return form.append(key, value.toISOString());
	else if (value instanceof File) return form.append(key, value, value.name);
	else if (value instanceof Blob) return form.append(key, value);
	else if (typeof value === "boolean") return form.append(key, value ? "1" : "0");
	else if (typeof value === "string") return form.append(key, value);
	else if (typeof value === "number") return form.append(key, `${value}`);
	else if (value === null || value === void 0) return form.append(key, "");
	objectToFormData(value, form, key, format);
}
function hasIndices(url) {
	return /\[\d+\]/.test(decodeURIComponent(url.search));
}
function parse(query) {
	if (!query || query === "?") return {};
	const result = {};
	query.replace(/^\?/, "").split("&").filter(Boolean).forEach((segment) => {
		const [rawKey, rawValue] = splitPair(segment);
		set2(result, decode(rawKey), decode(rawValue));
	});
	return result;
}
function stringify(data, arrayFormat) {
	const pairs = [];
	build(data, "", pairs, arrayFormat);
	return pairs.length ? "?" + pairs.join("&") : "";
}
function splitPair(pair) {
	const index = pair.indexOf("=");
	return index === -1 ? [pair, ""] : [pair.substring(0, index), pair.substring(index + 1)];
}
function decode(value) {
	return decodeURIComponent(value.replace(/\+/g, " "));
}
function set2(target, key, value) {
	const keys = parseKey(key);
	if (keys.some((k) => k === "__proto__")) return;
	let current = target;
	while (keys.length > 1) {
		const segment = keys.shift();
		const nextIsArrayPush = keys[0] === "";
		if (typeof current[segment] !== "object" || current[segment] === null) current[segment] = nextIsArrayPush ? [] : {};
		current = current[segment];
	}
	const final = keys.shift();
	if (final === "" && Array.isArray(current)) current.push(value);
	else current[final] = value;
}
function parseKey(key) {
	const segments = [];
	const base = key.split("[")[0];
	if (base) segments.push(base);
	let match;
	const pattern = /\[([^\]]*)\]/g;
	while ((match = pattern.exec(key)) !== null) segments.push(match[1]);
	return segments;
}
function build(value, prefix, pairs, arrayFormat) {
	if (value === void 0) return;
	if (value === null) {
		pairs.push(`${prefix}=`);
		return;
	}
	if (Array.isArray(value)) {
		value.forEach((item, index) => {
			build(item, arrayFormat === "indices" ? `${prefix}[${index}]` : `${prefix}[]`, pairs, arrayFormat);
		});
		return;
	}
	if (typeof value === "object") {
		Object.keys(value).forEach((key) => {
			build(value[key], prefix ? `${prefix}[${key}]` : key, pairs, arrayFormat);
		});
		return;
	}
	pairs.push(`${prefix}=${encodeURIComponent(String(value))}`);
}
function hrefToUrl(href) {
	return new URL(href.toString(), typeof window === "undefined" ? void 0 : window.location.toString());
}
var transformUrlAndData = (href, data, method, forceFormData, queryStringArrayFormat) => {
	let url = typeof href === "string" ? hrefToUrl(href) : href;
	if ((hasFiles(data) || forceFormData) && !isFormData(data)) {
		if (config$1.get("form.forceIndicesArrayFormatInFormData")) queryStringArrayFormat = "indices";
		data = objectToFormData(data, new FormData(), null, queryStringArrayFormat);
	}
	if (isFormData(data)) return [url, data];
	const [_href, _data] = mergeDataIntoQueryString(method, url, data, queryStringArrayFormat);
	return [hrefToUrl(_href), _data];
};
function mergeDataIntoQueryString(method, href, data, qsArrayFormat = "brackets") {
	const hasDataForQueryString = method === "get" && !isFormData(data) && Object.keys(data).length > 0;
	const hasHost = urlHasProtocol(href.toString());
	const hasAbsolutePath = hasHost || href.toString().startsWith("/") || href.toString() === "";
	const hasRelativePath = !hasAbsolutePath && !href.toString().startsWith("#") && !href.toString().startsWith("?");
	const hasRelativePathWithDotPrefix = /^[.]{1,2}([/]|$)/.test(href.toString());
	const hasSearch = href.toString().includes("?") || hasDataForQueryString;
	const hasHash = href.toString().includes("#");
	const url = new URL(href.toString(), typeof window === "undefined" ? "http://localhost" : window.location.toString());
	if (hasDataForQueryString) {
		const arrayFormat = hasIndices(url) ? "indices" : qsArrayFormat;
		url.search = stringify({
			...parse(url.search),
			...data
		}, arrayFormat);
	}
	return [[
		hasHost ? `${url.protocol}//${url.host}` : "",
		hasAbsolutePath ? url.pathname : "",
		hasRelativePath ? url.pathname.substring(hasRelativePathWithDotPrefix ? 0 : 1) : "",
		hasSearch ? url.search : "",
		hasHash ? url.hash : ""
	].join(""), hasDataForQueryString ? {} : data];
}
function urlWithoutHash(url) {
	url = new URL(url.href);
	url.hash = "";
	return url;
}
var setHashIfSameUrl = (originUrl, destinationUrl) => {
	if (originUrl.hash && !destinationUrl.hash && urlWithoutHash(originUrl).href === destinationUrl.href) destinationUrl.hash = originUrl.hash;
};
var isSameUrlWithoutHash = (url1, url2) => {
	return urlWithoutHash(url1).href === urlWithoutHash(url2).href;
};
var isSameUrlWithoutQueryOrHash = (url1, url2) => {
	return url1.origin === url2.origin && url1.pathname === url2.pathname;
};
function isUrlMethodPair(href) {
	return href !== null && typeof href === "object" && href !== void 0 && "url" in href && "method" in href;
}
function resolveUrlMethodPairComponent(pair) {
	if (!pair.component) return null;
	if (typeof pair.component !== "string") {
		console.error(`The "component" property on the URL method pair received multiple components (${Object.keys(pair.component).join(", ")}), but only a single component string is supported for instant visits. Use the withComponent() method to specify which component to use.`);
		return null;
	}
	return pair.component;
}
function urlHasProtocol(url) {
	return /^([a-z][a-z0-9+.-]*:)?\/\/[^/]/i.test(url);
}
function urlToString(url, absolute) {
	const urlObj = typeof url === "string" ? hrefToUrl(url) : url;
	return absolute ? `${urlObj.protocol}//${urlObj.host}${urlObj.pathname}${urlObj.search}${urlObj.hash}` : `${urlObj.pathname}${urlObj.search}${urlObj.hash}`;
}
var CurrentPage = class {
	page;
	swapComponent;
	resolveComponent;
	onFlashCallback;
	componentId = {};
	listeners = [];
	isFirstPageLoad = true;
	cleared = false;
	pendingDeferredProps = null;
	historyQuotaExceeded = false;
	optimisticBaseline = {};
	pendingOptimistics = [];
	optimisticCounter = 0;
	init({ initialPage, swapComponent, resolveComponent, onFlash }) {
		this.page = {
			...initialPage,
			flash: initialPage.flash ?? {},
			rescuedProps: initialPage.rescuedProps ?? []
		};
		this.swapComponent = swapComponent;
		this.resolveComponent = resolveComponent;
		this.onFlashCallback = onFlash;
		eventHandler.on("historyQuotaExceeded", () => {
			this.historyQuotaExceeded = true;
		});
		return this;
	}
	set(page2, { replace = false, preserveScroll = false, preserveState = false, viewTransition = false, cached = false, initialRender = false, visitId } = {}) {
		if (Object.keys(page2.deferredProps || {}).length) {
			this.pendingDeferredProps = {
				deferredProps: page2.deferredProps,
				component: page2.component,
				url: page2.url
			};
			if (page2.initialDeferredProps === void 0) page2.initialDeferredProps = page2.deferredProps;
		}
		this.componentId = {};
		const componentId = this.componentId;
		if (page2.clearHistory) history.clear();
		return this.resolve(page2.component, page2).then((component) => {
			if (componentId !== this.componentId) return;
			page2.rememberedState ??= {};
			const isServer3 = typeof window === "undefined";
			const location = !isServer3 ? window.location : new URL(page2.url);
			const scrollRegions = !isServer3 && preserveScroll ? Scroll.getScrollRegions() : [];
			replace = replace || isSameUrlWithoutHash(hrefToUrl(page2.url), location);
			const pageForHistory = {
				...page2,
				flash: {}
			};
			return new Promise((resolve) => replace ? history.replaceState(pageForHistory, resolve) : history.pushState(pageForHistory, resolve)).then(() => {
				const isNewComponent = !this.isTheSame(page2);
				if (!isNewComponent && Object.keys(page2.props.errors || {}).length > 0) viewTransition = false;
				this.page = page2;
				this.cleared = false;
				if (this.hasOnceProps()) prefetchedRequests.updateCachedOncePropsFromCurrentPage();
				if (isNewComponent) this.fireEventsFor("newComponent");
				if (this.isFirstPageLoad) this.fireEventsFor("firstLoad");
				this.isFirstPageLoad = false;
				if (this.historyQuotaExceeded) {
					this.historyQuotaExceeded = false;
					return;
				}
				return this.swap({
					component,
					page: page2,
					preserveState,
					viewTransition,
					initialRender
				}).then(() => {
					if (preserveScroll) window.requestAnimationFrame(() => Scroll.restoreScrollRegions(scrollRegions));
					else Scroll.reset();
					if (this.pendingDeferredProps && this.pendingDeferredProps.component === page2.component && this.pendingDeferredProps.url === page2.url) eventHandler.fireInternalEvent("loadDeferredProps", this.pendingDeferredProps.deferredProps);
					this.pendingDeferredProps = null;
					if (!replace) fireNavigateEvent(page2, {
						cached,
						visitId
					});
				});
			});
		});
	}
	setQuietly(page2, { preserveState = false } = {}) {
		return this.resolve(page2.component, page2).then((component) => {
			this.page = page2;
			this.cleared = false;
			history.setCurrent(page2);
			return this.swap({
				component,
				page: page2,
				preserveState,
				viewTransition: false
			});
		});
	}
	clear() {
		this.cleared = true;
	}
	isCleared() {
		return this.cleared;
	}
	get() {
		return this.page;
	}
	getWithoutFlashData() {
		return {
			...this.page,
			flash: {}
		};
	}
	hasOnceProps() {
		return Object.keys(this.page.onceProps ?? {}).length > 0;
	}
	merge(data) {
		this.page = {
			...this.page,
			...data
		};
	}
	setPropsQuietly(props) {
		this.page = {
			...this.page,
			props
		};
		return this.resolve(this.page.component, this.page).then((component) => {
			return this.swap({
				component,
				page: this.page,
				preserveState: true,
				viewTransition: false
			});
		});
	}
	setFlash(flash) {
		this.page = {
			...this.page,
			flash
		};
		this.onFlashCallback?.(flash);
	}
	setUrlHash(hash) {
		if (!this.page.url.includes(hash)) this.page.url += hash;
	}
	remember(data) {
		this.page.rememberedState = data;
	}
	swap({ component, page: page2, preserveState, viewTransition, initialRender = false }) {
		const doSwap = () => this.swapComponent({
			component,
			page: page2,
			preserveState,
			initialRender
		});
		if (!viewTransition || !document?.startViewTransition || document.visibilityState === "hidden") return doSwap();
		const viewTransitionCallback = typeof viewTransition === "boolean" ? () => null : viewTransition;
		const ignoreSkippedTransition = (promise) => {
			promise.catch((error) => {
				if (!(error instanceof DOMException)) throw error;
			});
		};
		return new Promise((resolve) => {
			const transitionResult = document.startViewTransition(() => doSwap().then(resolve));
			ignoreSkippedTransition(transitionResult.ready);
			ignoreSkippedTransition(transitionResult.finished);
			ignoreSkippedTransition(transitionResult.updateCallbackDone);
			viewTransitionCallback(transitionResult);
		});
	}
	resolve(component, page2) {
		return Promise.resolve(this.resolveComponent(component, page2));
	}
	nextOptimisticId() {
		return ++this.optimisticCounter;
	}
	setBaseline(key, value) {
		if (!(key in this.optimisticBaseline)) this.optimisticBaseline[key] = value;
	}
	updateBaseline(key, value) {
		if (key in this.optimisticBaseline) this.optimisticBaseline[key] = value;
	}
	hasBaseline(key) {
		return key in this.optimisticBaseline;
	}
	registerOptimistic(id, callback) {
		this.pendingOptimistics.push({
			id,
			callback
		});
	}
	unregisterOptimistic(id) {
		this.pendingOptimistics = this.pendingOptimistics.filter((entry) => entry.id !== id);
	}
	replayOptimistics() {
		const baselineKeys = Object.keys(this.optimisticBaseline);
		if (baselineKeys.length === 0) return {};
		const props = cloneDeep$1(this.page.props);
		for (const key of baselineKeys) props[key] = cloneDeep$1(this.optimisticBaseline[key]);
		for (const { callback } of this.pendingOptimistics) {
			const result = callback(cloneDeep$1(props));
			if (result) Object.assign(props, result);
		}
		const replayedProps = {};
		for (const key of baselineKeys) replayedProps[key] = props[key];
		return replayedProps;
	}
	pendingOptimisticCount() {
		return this.pendingOptimistics.length;
	}
	clearOptimisticState() {
		this.optimisticBaseline = {};
		this.pendingOptimistics = [];
	}
	isTheSame(page2) {
		return this.page.component === page2.component;
	}
	on(event, callback) {
		this.listeners.push({
			event,
			callback
		});
		return () => {
			this.listeners = this.listeners.filter((listener) => listener.event !== event && listener.callback !== callback);
		};
	}
	fireEventsFor(event) {
		this.listeners.filter((listener) => listener.event === event).forEach((listener) => listener.callback());
	}
	mergeOncePropsIntoResponse(response, { force = false } = {}) {
		Object.entries(response.onceProps ?? {}).forEach(([key, onceProp]) => {
			const existingOnceProp = this.page.onceProps?.[key];
			if (existingOnceProp === void 0) return;
			if (force || get(response.props, onceProp.prop) === void 0) {
				set(response.props, onceProp.prop, get(this.page.props, existingOnceProp.prop));
				response.onceProps[key].expiresAt = existingOnceProp.expiresAt;
			}
		});
	}
};
var page$1 = new CurrentPage();
var Queue = class {
	items = [];
	processingPromise = null;
	add(item) {
		this.items.push(item);
		return this.process();
	}
	process() {
		this.processingPromise ??= this.processNext().finally(() => {
			this.processingPromise = null;
		});
		return this.processingPromise;
	}
	processNext() {
		const next = this.items.shift();
		if (next) return Promise.resolve(next()).then(() => this.processNext());
		return Promise.resolve();
	}
};
var isServer2 = typeof window === "undefined";
var queue = new Queue();
var isChromeIOS = !isServer2 && /CriOS/.test(window.navigator.userAgent);
var History = class {
	rememberedState = "rememberedState";
	scrollRegions = "scrollRegions";
	preserveUrl = false;
	current = {};
	initialState = null;
	remember(data, key) {
		this.replaceState({
			...page$1.getWithoutFlashData(),
			rememberedState: {
				...page$1.get()?.rememberedState ?? {},
				[key]: data
			}
		});
	}
	restore(key) {
		if (!isServer2) return this.current[this.rememberedState]?.[key] !== void 0 ? this.current[this.rememberedState]?.[key] : this.initialState?.[this.rememberedState]?.[key];
	}
	pushState(page2, cb = null) {
		if (isServer2) return;
		if (this.preserveUrl) {
			cb && cb();
			return;
		}
		this.current = page2;
		queue.add(() => {
			return this.getPageData(page2).then((data) => {
				const doPush = () => this.doPushState({ page: data }, page2.url).then(() => cb?.());
				if (isChromeIOS) return new Promise((resolve) => {
					setTimeout(() => doPush().then(resolve));
				});
				return doPush();
			});
		});
	}
	clonePageProps(page2) {
		try {
			structuredClone(page2.props);
			return page2;
		} catch {
			return {
				...page2,
				props: cloneDeep$1(page2.props)
			};
		}
	}
	getPageData(page2) {
		const pageWithClonedProps = this.clonePageProps(page2);
		return new Promise((resolve) => {
			return page2.encryptHistory ? encryptHistory(pageWithClonedProps).then(resolve) : resolve(pageWithClonedProps);
		});
	}
	processQueue() {
		return queue.process();
	}
	decrypt(page2 = null) {
		if (isServer2) return Promise.resolve(page2 ?? page$1.get());
		const pageData = page2 ?? window.history.state?.page;
		return this.decryptPageData(pageData).then((data) => {
			if (!data) throw new Error("Unable to decrypt history");
			if (this.initialState === null) this.initialState = data ?? void 0;
			else this.current = data ?? {};
			return data;
		});
	}
	decryptPageData(pageData) {
		return pageData instanceof ArrayBuffer ? decryptHistory(pageData) : Promise.resolve(pageData);
	}
	saveScrollPositions(scrollRegions) {
		queue.add(() => {
			return Promise.resolve().then(() => {
				if (!window.history.state?.page) return;
				if (isEqual(this.getScrollRegions(), scrollRegions)) return;
				return this.doReplaceState({
					page: window.history.state.page,
					scrollRegions
				});
			});
		});
	}
	saveDocumentScrollPosition(scrollRegion) {
		queue.add(() => {
			return Promise.resolve().then(() => {
				if (!window.history.state?.page) return;
				if (isEqual(this.getDocumentScrollPosition(), scrollRegion)) return;
				return this.doReplaceState({
					page: window.history.state.page,
					documentScrollPosition: scrollRegion
				});
			});
		});
	}
	getScrollRegions() {
		return window.history.state?.scrollRegions || [];
	}
	getDocumentScrollPosition() {
		return window.history.state?.documentScrollPosition || {
			top: 0,
			left: 0
		};
	}
	replaceState(page2, cb = null) {
		if (isEqual(this.current, page2)) {
			cb && cb();
			return;
		}
		const { flash, ...pageWithoutFlash } = page2;
		page$1.merge(pageWithoutFlash);
		if (isServer2) return;
		if (this.preserveUrl) {
			cb && cb();
			return;
		}
		this.current = page2;
		queue.add(() => {
			return this.getPageData(page2).then((data) => {
				const doReplace = () => this.doReplaceState({ page: data }, page2.url).then(() => cb?.());
				if (isChromeIOS) return new Promise((resolve) => {
					setTimeout(() => doReplace().then(resolve));
				});
				return doReplace();
			});
		});
	}
	isHistoryThrottleError(error) {
		return error instanceof Error && error.name === "SecurityError" && (error.message.includes("history.pushState") || error.message.includes("history.replaceState"));
	}
	isQuotaExceededError(error) {
		return error instanceof Error && error.name === "QuotaExceededError";
	}
	withThrottleProtection(cb) {
		return Promise.resolve().then(() => {
			try {
				return cb();
			} catch (error) {
				if (!this.isHistoryThrottleError(error)) throw error;
				console.error(error.message);
			}
		});
	}
	doReplaceState(data, url) {
		return this.withThrottleProtection(() => {
			window.history.replaceState({
				...data,
				scrollRegions: data.scrollRegions ?? window.history.state?.scrollRegions,
				documentScrollPosition: data.documentScrollPosition ?? window.history.state?.documentScrollPosition
			}, "", url);
		});
	}
	doPushState(data, url) {
		return this.withThrottleProtection(() => {
			try {
				window.history.pushState(data, "", url);
			} catch (error) {
				if (!this.isQuotaExceededError(error)) throw error;
				eventHandler.fireInternalEvent("historyQuotaExceeded", url);
			}
		});
	}
	getState(key, defaultValue) {
		return this.current?.[key] ?? defaultValue;
	}
	deleteState(key) {
		if (this.current[key] !== void 0) {
			delete this.current[key];
			this.replaceState(this.current);
		}
	}
	clearInitialState(key) {
		if (this.initialState && this.initialState[key] !== void 0) delete this.initialState[key];
	}
	browserHasHistoryEntry() {
		return !isServer2 && !!window.history.state?.page;
	}
	clear() {
		SessionStorage.remove(historySessionStorageKeys.key);
		SessionStorage.remove(historySessionStorageKeys.iv);
	}
	setCurrent(page2) {
		this.current = page2;
	}
	isValidState(state) {
		return !!state.page;
	}
	getAllState() {
		return this.current;
	}
};
if (typeof window !== "undefined" && window.history.scrollRestoration) window.history.scrollRestoration = "manual";
var history = new History();
var EventHandler = class {
	internalListeners = [];
	init() {
		if (typeof window !== "undefined") {
			window.addEventListener("popstate", this.handlePopstateEvent.bind(this));
			window.addEventListener("pageshow", this.handlePageshowEvent.bind(this));
			window.addEventListener("scroll", debounce(Scroll.onWindowScroll.bind(Scroll), 100), true);
		}
		if (typeof document !== "undefined") document.addEventListener("scroll", debounce(Scroll.onScroll.bind(Scroll), 100), true);
	}
	onGlobalEvent(type, callback) {
		const listener = ((event) => {
			const response = callback(event);
			if (event.cancelable && !event.defaultPrevented && response === false) event.preventDefault();
		});
		return this.registerListener(`inertia:${type}`, listener);
	}
	on(event, callback) {
		this.internalListeners.push({
			event,
			listener: callback
		});
		return () => {
			this.internalListeners = this.internalListeners.filter((listener) => listener.listener !== callback);
		};
	}
	onMissingHistoryItem() {
		page$1.clear();
		this.fireInternalEvent("missingHistoryItem");
	}
	fireInternalEvent(event, ...args) {
		this.internalListeners.filter((listener) => listener.event === event).forEach((listener) => listener.listener(...args));
	}
	registerListener(type, listener) {
		document.addEventListener(type, listener);
		return () => document.removeEventListener(type, listener);
	}
	handlePageshowEvent(event) {
		if (event.persisted) history.decrypt().catch(() => this.onMissingHistoryItem());
	}
	handlePopstateEvent(event) {
		const state = event.state || null;
		if (state === null) {
			const url = hrefToUrl(page$1.get().url);
			url.hash = window.location.hash;
			history.replaceState({
				...page$1.getWithoutFlashData(),
				url: url.href
			});
			Scroll.reset();
			return;
		}
		if (!history.isValidState(state)) return this.onMissingHistoryItem();
		history.decrypt(state.page).then((data) => {
			if (page$1.get().version !== data.version) {
				this.onMissingHistoryItem();
				return;
			}
			router.cancelAll({ prefetch: false });
			page$1.setQuietly(data, { preserveState: false }).then(() => {
				Scroll.restore(history.getScrollRegions());
				fireNavigateEvent(page$1.get());
				const pendingDeferred = {};
				const pageProps = page$1.get().props;
				for (const [group, props] of Object.entries(data.initialDeferredProps ?? data.deferredProps ?? {})) {
					const missing = props.filter((prop) => get(pageProps, prop) === void 0);
					if (missing.length > 0) pendingDeferred[group] = missing;
				}
				if (Object.keys(pendingDeferred).length > 0) this.fireInternalEvent("loadDeferredProps", pendingDeferred);
			});
		}).catch(() => {
			this.onMissingHistoryItem();
		});
	}
};
var eventHandler = new EventHandler();
var NavigationType = class {
	type;
	constructor() {
		this.type = this.resolveType();
	}
	resolveType() {
		if (typeof window === "undefined") return "navigate";
		return (window.performance?.getEntriesByType("navigation")[0])?.type ?? "navigate";
	}
	get() {
		return this.type;
	}
	isBackForward() {
		return this.type === "back_forward";
	}
	isReload() {
		return this.type === "reload";
	}
};
var navigationType = new NavigationType();
function uid() {
	const cryptoObj = typeof window !== "undefined" ? window.crypto : void 0;
	if (cryptoObj?.randomUUID) return cryptoObj.randomUUID();
	const randomByte = () => cryptoObj?.getRandomValues ? cryptoObj.getRandomValues(/* @__PURE__ */ new Uint8Array(1))[0] : Math.floor(Math.random() * 256);
	return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) => (+c ^ randomByte() & 15 >> +c / 4).toString(16));
}
var InitialVisit = class {
	static handle() {
		this.clearRememberedStateOnReload();
		[
			this.handleBackForward,
			this.handleLocation,
			this.handleDefault
		].find((handler) => handler.bind(this)());
	}
	static clearRememberedStateOnReload() {
		if (navigationType.isReload()) {
			history.deleteState(history.rememberedState);
			history.clearInitialState(history.rememberedState);
		}
	}
	static handleBackForward() {
		if (!navigationType.isBackForward() || !history.browserHasHistoryEntry()) return false;
		const scrollRegions = history.getScrollRegions();
		history.decrypt().then((data) => {
			const visitId = uid();
			page$1.set(data, {
				preserveScroll: true,
				preserveState: true,
				visitId
			}).then(() => {
				Scroll.restore(scrollRegions);
				fireNavigateEvent(page$1.get(), { visitId });
			});
		}).catch(() => {
			eventHandler.onMissingHistoryItem();
		});
		return true;
	}
	/**
	* @link https://inertiajs.com/redirects#external-redirects
	*/
	static handleLocation() {
		if (!SessionStorage.exists(SessionStorage.locationVisitKey)) return false;
		const locationVisit = SessionStorage.get(SessionStorage.locationVisitKey) || {};
		SessionStorage.remove(SessionStorage.locationVisitKey);
		if (typeof window !== "undefined") page$1.setUrlHash(window.location.hash);
		history.decrypt(page$1.get()).then(() => {
			const visitId = uid();
			const rememberedState = history.getState(history.rememberedState, {});
			const scrollRegions = history.getScrollRegions();
			page$1.remember(rememberedState);
			page$1.set(page$1.get(), {
				preserveScroll: locationVisit.preserveScroll,
				preserveState: true,
				initialRender: true,
				visitId
			}).then(() => {
				if (locationVisit.preserveScroll) Scroll.restore(scrollRegions);
				this.fireInitialEvents(visitId);
			});
		}).catch(() => {
			eventHandler.onMissingHistoryItem();
		});
		return true;
	}
	static handleDefault() {
		if (typeof window !== "undefined") page$1.setUrlHash(window.location.hash);
		const visitId = uid();
		page$1.set(page$1.get(), {
			preserveScroll: true,
			preserveState: true,
			initialRender: true,
			visitId
		}).then(() => {
			if (navigationType.isReload()) Scroll.restore(history.getScrollRegions());
			else Scroll.scrollToAnchor();
			this.fireInitialEvents(visitId);
		});
	}
	static fireInitialEvents(visitId) {
		const page2 = page$1.get();
		fireNavigateEvent(page2, { visitId });
		if (Object.keys(page2.flash).length > 0) queueMicrotask(() => fireFlashEvent(page2.flash));
	}
};
var Poll = class {
	intervalId = null;
	timeoutId = null;
	throttle = false;
	keepAlive = false;
	cb;
	interval;
	cbCount = 0;
	mode;
	inFlight = false;
	currentCancel = null;
	stopped = true;
	instanceId = 0;
	constructor(interval, cb, options) {
		this.keepAlive = options.keepAlive ?? false;
		this.mode = options.mode ?? "overlap";
		this.cb = cb;
		this.interval = interval;
		if (options.autoStart ?? true) this.start();
	}
	stop() {
		this.stopped = true;
		this.instanceId++;
		this.inFlight = false;
		this.currentCancel = null;
		if (this.intervalId) {
			clearInterval(this.intervalId);
			this.intervalId = null;
		}
		if (this.timeoutId) {
			clearTimeout(this.timeoutId);
			this.timeoutId = null;
		}
	}
	start() {
		if (typeof window === "undefined") return;
		this.stop();
		this.stopped = false;
		if (this.mode === "rest") {
			this.scheduleNext();
			return;
		}
		this.intervalId = window.setInterval(() => this.tick(), this.interval);
	}
	isInBackground(hidden2) {
		this.throttle = this.keepAlive ? false : hidden2;
		if (this.throttle) this.cbCount = 0;
	}
	scheduleNext() {
		if (this.stopped) return;
		this.timeoutId = window.setTimeout(() => {
			this.timeoutId = null;
			this.tick();
		}, this.interval);
	}
	tick() {
		if (!this.throttle || this.cbCount % 10 === 0) this.fire();
		else if (this.mode === "rest") this.scheduleNext();
		if (this.throttle) this.cbCount++;
	}
	fire() {
		if (this.inFlight && this.mode === "cancel") this.currentCancel?.();
		const instance = this.instanceId;
		this.cb({
			onStart: (cancel) => {
				if (instance !== this.instanceId) return;
				this.inFlight = true;
				this.currentCancel = cancel;
			},
			onFinish: () => {
				if (instance !== this.instanceId) return;
				this.inFlight = false;
				this.currentCancel = null;
				if (this.mode === "rest") this.scheduleNext();
			}
		});
	}
};
var Polls = class {
	polls = [];
	constructor() {
		this.setupVisibilityListener();
	}
	get count() {
		return this.polls.length;
	}
	add(interval, cb, options) {
		const poll = new Poll(interval, cb, options);
		this.polls.push(poll);
		return {
			stop: () => poll.stop(),
			start: () => poll.start(),
			destroy: () => {
				poll.stop();
				this.polls = this.polls.filter((p) => p !== poll);
			}
		};
	}
	clear() {
		this.polls.forEach((poll) => poll.stop());
		this.polls = [];
	}
	setupVisibilityListener() {
		if (typeof document === "undefined") return;
		document.addEventListener("visibilitychange", () => {
			this.polls.forEach((poll) => poll.isInBackground(document.hidden));
		}, false);
	}
};
var polls = new Polls();
var HttpHandlers = class {
	requestHandlers = [];
	responseHandlers = [];
	errorHandlers = [];
	onRequest(handler) {
		this.requestHandlers.push(handler);
		return () => {
			this.requestHandlers = this.requestHandlers.filter((h) => h !== handler);
		};
	}
	onResponse(handler) {
		this.responseHandlers.push(handler);
		return () => {
			this.responseHandlers = this.responseHandlers.filter((h) => h !== handler);
		};
	}
	onError(handler) {
		this.errorHandlers.push(handler);
		return () => {
			this.errorHandlers = this.errorHandlers.filter((h) => h !== handler);
		};
	}
	async processRequest(config2) {
		let result = config2;
		for (const handler of this.requestHandlers) result = await handler(result);
		return result;
	}
	async processResponse(response) {
		let result = response;
		for (const handler of this.responseHandlers) result = await handler(result);
		return result;
	}
	async processError(error) {
		for (const handler of this.errorHandlers) await handler(error);
	}
};
var httpHandlers = new HttpHandlers();
var HttpError = class extends Error {
	code;
	url;
	constructor(message, code, url) {
		super(url ? `${message} (${url})` : message);
		this.name = "HttpError";
		this.code = code;
		this.url = url;
	}
};
var HttpResponseError = class extends HttpError {
	response;
	constructor(message, response, url) {
		super(message, "ERR_HTTP_RESPONSE", url);
		this.name = "HttpResponseError";
		this.response = response;
	}
};
var HttpCancelledError = class extends HttpError {
	constructor(message = "Request was cancelled", url) {
		super(message, "ERR_CANCELLED", url);
		this.name = "HttpCancelledError";
	}
};
var HttpNetworkError = class extends HttpError {
	cause;
	constructor(message, url, cause) {
		super(message, "ERR_NETWORK", url);
		this.name = "HttpNetworkError";
		this.cause = cause;
	}
};
function getCookie(name) {
	const match = document.cookie.match(new RegExp("(^|;\\s*)(" + name + ")=([^;]*)"));
	return match ? decodeURIComponent(match[3]) : null;
}
function parseHeaders(xhr) {
	const headers = {};
	xhr.getAllResponseHeaders().split("\r\n").forEach((line) => {
		const index = line.indexOf(":");
		if (index > 0) headers[line.slice(0, index).toLowerCase().trim()] = line.slice(index + 1).trim();
	});
	return headers;
}
function isFormDataRequestBody(value) {
	return typeof FormData !== "undefined" && value instanceof FormData;
}
function isRawRequestBody(value) {
	return typeof value === "string" || isFormDataRequestBody(value) || typeof Blob !== "undefined" && value instanceof Blob || typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer || typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView(value) || typeof URLSearchParams !== "undefined" && value instanceof URLSearchParams;
}
function setHeaders(xhr, config2) {
	if (!config2.headers) return;
	const isFormData2 = isFormDataRequestBody(config2.data);
	Object.entries(config2.headers).forEach(([key, value]) => {
		if (key.toLowerCase() !== "content-type" || !isFormData2) xhr.setRequestHeader(key, String(value));
	});
}
function buildUrlWithParams(url, params) {
	if (!params || Object.keys(params).length === 0) return url;
	const [urlWithParams] = mergeDataIntoQueryString("get", url, params);
	return urlWithParams;
}
var XhrHttpClient = class {
	xsrfCookieName;
	xsrfHeaderName;
	constructor(options = {}) {
		this.xsrfCookieName = options.xsrfCookieName ?? "XSRF-TOKEN";
		this.xsrfHeaderName = options.xsrfHeaderName ?? "X-XSRF-TOKEN";
	}
	async request(config2) {
		const processedConfig = await httpHandlers.processRequest(config2);
		try {
			const response = await this.doRequest(processedConfig);
			return await httpHandlers.processResponse(response);
		} catch (error) {
			if (error instanceof HttpResponseError || error instanceof HttpNetworkError || error instanceof HttpCancelledError) await httpHandlers.processError(error);
			throw error;
		}
	}
	doRequest(config2) {
		return new Promise((resolve, reject) => {
			const xhr = new XMLHttpRequest();
			const url = buildUrlWithParams(config2.url, config2.params);
			xhr.open(config2.method.toUpperCase(), url, true);
			const xsrfToken = getCookie(this.xsrfCookieName);
			if (xsrfToken) xhr.setRequestHeader(this.xsrfHeaderName, xsrfToken);
			if (!Object.keys(config2.headers ?? {}).some((key) => key.toLowerCase() === "x-requested-with")) xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
			let body = null;
			if (config2.data !== null && config2.data !== void 0) {
				if (isRawRequestBody(config2.data)) body = config2.data;
				else if (typeof config2.data === "object") {
					body = JSON.stringify(config2.data);
					if (!config2.headers?.["Content-Type"] && !config2.headers?.["content-type"]) xhr.setRequestHeader("Content-Type", "application/json");
				} else body = String(config2.data);
			}
			setHeaders(xhr, config2);
			if (config2.onUploadProgress) xhr.upload.onprogress = (event) => {
				const progress3 = event.lengthComputable ? event.loaded / event.total : void 0;
				config2.onUploadProgress({
					progress: progress3,
					percentage: progress3 ? Math.round(progress3 * 100) : 0,
					loaded: event.loaded,
					total: event.lengthComputable ? event.total : void 0
				});
			};
			if (config2.signal) config2.signal.addEventListener("abort", () => xhr.abort());
			xhr.onabort = () => reject(new HttpCancelledError("Request was cancelled", config2.url));
			xhr.onerror = () => reject(new HttpNetworkError("Network error", config2.url));
			xhr.onload = () => {
				const response = {
					status: xhr.status,
					data: xhr.responseText,
					headers: parseHeaders(xhr)
				};
				if (xhr.status >= 400) reject(new HttpResponseError(`Request failed with status ${xhr.status}`, response, config2.url));
				else resolve(response);
			};
			xhr.send(body);
		});
	}
};
var httpClient = new XhrHttpClient();
function isHttpClientOptions(client) {
	return !("request" in client);
}
var http = {
	/**
	* Get the current HTTP client
	*/
	getClient() {
		return httpClient;
	},
	/**
	* Set the HTTP client to use for all Inertia requests
	*/
	setClient(clientOrOptions) {
		if (!isHttpClientOptions(clientOrOptions)) {
			httpClient = clientOrOptions;
			return;
		}
		httpClient = new XhrHttpClient(clientOrOptions);
		if (clientOrOptions.xsrfCookieName) client.withXsrfCookieName(clientOrOptions.xsrfCookieName);
		if (clientOrOptions.xsrfHeaderName) client.withXsrfHeaderName(clientOrOptions.xsrfHeaderName);
	},
	/**
	* Register a request handler that runs before each request
	*/
	onRequest: httpHandlers.onRequest.bind(httpHandlers),
	/**
	* Register a response handler that runs after each successful response
	*/
	onResponse: httpHandlers.onResponse.bind(httpHandlers),
	/**
	* Register an error handler that runs when a request fails
	*/
	onError: httpHandlers.onError.bind(httpHandlers),
	/**
	* Process a request config through all registered request handlers.
	* For use by custom HttpClient implementations.
	*/
	processRequest: httpHandlers.processRequest.bind(httpHandlers),
	/**
	* Process a response through all registered response handlers.
	* For use by custom HttpClient implementations.
	*/
	processResponse: httpHandlers.processResponse.bind(httpHandlers),
	/**
	* Process an error through all registered error handlers.
	* For use by custom HttpClient implementations.
	*/
	processError: httpHandlers.processError.bind(httpHandlers)
};
var VisitInterceptors = class {
	requestHandlers = [];
	responseHandlers = [];
	onVisitRequest(handler) {
		this.requestHandlers.push(handler);
		return () => {
			this.requestHandlers = this.requestHandlers.filter((h) => h !== handler);
		};
	}
	onVisitResponse(handler) {
		this.responseHandlers.push(handler);
		return () => {
			this.responseHandlers = this.responseHandlers.filter((h) => h !== handler);
		};
	}
	async processRequest(visit, config2) {
		let result = config2;
		for (const handler of this.requestHandlers) result = await handler(visit, result);
		return result;
	}
	async processResponse(visit, response) {
		let result = response;
		for (const handler of this.responseHandlers) result = await handler(visit, result);
		return result;
	}
};
var interceptors = new VisitInterceptors();
function exposeInterceptors() {
	if (typeof window === "undefined") return;
	window.__inertia_interceptors__ = interceptors;
}
var RequestParams = class _RequestParams {
	callbacks = [];
	params;
	constructor(params) {
		if (!params.prefetch) this.params = params;
		else {
			const wrappedCallbacks = {
				onBefore: this.wrapCallback(params, "onBefore"),
				onBeforeUpdate: this.wrapCallback(params, "onBeforeUpdate"),
				onStart: this.wrapCallback(params, "onStart"),
				onProgress: this.wrapCallback(params, "onProgress"),
				onFinish: this.wrapCallback(params, "onFinish"),
				onCancel: this.wrapCallback(params, "onCancel"),
				onSuccess: this.wrapCallback(params, "onSuccess"),
				onError: this.wrapCallback(params, "onError"),
				onHttpException: this.wrapCallback(params, "onHttpException"),
				onNetworkError: this.wrapCallback(params, "onNetworkError"),
				onFlash: this.wrapCallback(params, "onFlash"),
				onCancelToken: this.wrapCallback(params, "onCancelToken"),
				onPrefetched: this.wrapCallback(params, "onPrefetched"),
				onPrefetching: this.wrapCallback(params, "onPrefetching")
			};
			this.params = {
				...params,
				...wrappedCallbacks,
				onPrefetchResponse: params.onPrefetchResponse || (() => {}),
				onPrefetchError: params.onPrefetchError || (() => {})
			};
		}
	}
	static create(params) {
		return new _RequestParams(params);
	}
	data() {
		return this.params.method === "get" ? null : this.params.data;
	}
	queryParams() {
		return this.params.method === "get" ? this.params.data : {};
	}
	isPartial() {
		return this.params.only.length > 0 || this.params.except.length > 0 || this.params.reset.length > 0;
	}
	isPrefetch() {
		return this.params.prefetch === true;
	}
	isDeferredPropsRequest() {
		return this.params.deferredProps === true;
	}
	isPollRequest() {
		return this.params.poll === true;
	}
	onCancelToken(cb) {
		this.params.onCancelToken({ cancel: cb });
	}
	markAsFinished() {
		this.params.completed = true;
		this.params.cancelled = false;
		this.params.interrupted = false;
	}
	markAsCancelled({ cancelled = true, interrupted = false }) {
		this.params.onCancel();
		this.params.completed = false;
		this.params.cancelled = cancelled;
		this.params.interrupted = interrupted;
	}
	wasCancelledAtAll() {
		return this.params.cancelled || this.params.interrupted;
	}
	onFinish() {
		this.params.onFinish(this.params);
	}
	onStart() {
		this.params.onStart(this.params);
	}
	onPrefetching() {
		this.params.onPrefetching(this.params);
	}
	onPrefetchResponse(response) {
		if (this.params.onPrefetchResponse) this.params.onPrefetchResponse(response);
	}
	onPrefetchError(error) {
		if (this.params.onPrefetchError) this.params.onPrefetchError(error);
	}
	all() {
		return this.params;
	}
	headers() {
		const headers = { ...this.params.headers };
		if (this.isPartial()) headers["X-Inertia-Partial-Component"] = page$1.get().component;
		const only = this.params.only.concat(this.params.reset);
		if (only.length > 0) headers["X-Inertia-Partial-Data"] = only.join(",");
		if (this.params.except.length > 0) headers["X-Inertia-Partial-Except"] = this.params.except.join(",");
		if (this.params.reset.length > 0) headers["X-Inertia-Reset"] = this.params.reset.join(",");
		if (this.params.errorBag && this.params.errorBag.length > 0) headers["X-Inertia-Error-Bag"] = this.params.errorBag;
		return headers;
	}
	setPreserveOptions(page2) {
		this.params.preserveScroll = _RequestParams.resolvePreserveOption(this.params.preserveScroll, page2);
		this.params.preserveState = _RequestParams.resolvePreserveOption(this.params.preserveState, page2);
	}
	runCallbacks() {
		this.callbacks.forEach(({ name, args }) => {
			this.params[name](...args);
		});
	}
	merge(toMerge) {
		this.params = {
			...this.params,
			...toMerge
		};
	}
	wrapCallback(params, name) {
		return (...args) => {
			this.recordCallback(name, args);
			params[name](...args);
		};
	}
	recordCallback(name, args) {
		this.callbacks.push({
			name,
			args
		});
	}
	static resolvePreserveOption(value, page2) {
		if (typeof value === "function") return value(page2);
		if (value === "errors") return Object.keys(page2.props.errors || {}).length > 0;
		return value;
	}
};
var dialog_default = {
	createIframeAndPage(html) {
		if (typeof html === "object") html = `All Inertia requests must receive a valid Inertia response, however a plain JSON response was received.<hr>${JSON.stringify(html)}`;
		const page2 = document.createElement("html");
		page2.innerHTML = html;
		page2.querySelectorAll("a").forEach((a) => a.setAttribute("target", "_top"));
		const iframe = document.createElement("iframe");
		iframe.style.backgroundColor = "white";
		iframe.style.borderRadius = "5px";
		iframe.style.width = "100%";
		iframe.style.height = "100%";
		iframe.setAttribute("sandbox", "allow-scripts");
		return {
			iframe,
			page: page2
		};
	},
	show(html) {
		const { iframe, page: page2 } = this.createIframeAndPage(html);
		iframe.style.boxSizing = "border-box";
		iframe.style.display = "block";
		const dialog = document.createElement("dialog");
		dialog.id = "inertia-error-dialog";
		Object.assign(dialog.style, {
			width: "calc(100vw - 100px)",
			height: "calc(100vh - 100px)",
			padding: "0",
			margin: "auto",
			border: "none",
			backgroundColor: "transparent"
		});
		const dialogStyleElement = document.createElement("style");
		dialogStyleElement.textContent = `
      dialog#inertia-error-dialog::backdrop {
        background-color: rgba(0, 0, 0, 0.6);
      }

      dialog#inertia-error-dialog:focus {
        outline: none;
      }
    `;
		const nonce = config$1.get("nonce");
		if (nonce) dialogStyleElement.nonce = nonce;
		document.head.appendChild(dialogStyleElement);
		dialog.addEventListener("click", (event) => {
			if (event.target === dialog) dialog.close();
		});
		dialog.addEventListener("close", () => {
			dialogStyleElement.remove();
			dialog.remove();
		});
		dialog.appendChild(iframe);
		document.body.prepend(dialog);
		dialog.showModal();
		dialog.focus();
		iframe.srcdoc = page2.outerHTML;
	}
};
var isPathOrSubPath = (path, candidate) => {
	return path === candidate || path.startsWith(`${candidate}.`);
};
var partialReloadRequestsProp = (visit, prop) => {
	const { only, except } = visit;
	if (only.length === 0 && except.length === 0) return false;
	if (only.length > 0 && !only.some((candidate) => isPathOrSubPath(prop, candidate))) return false;
	if (except.length > 0 && except.some((candidate) => isPathOrSubPath(prop, candidate))) return false;
	return true;
};
var partialReloadRequestsSomeProps = (visit, props) => {
	return props.some((prop) => partialReloadRequestsProp(visit, prop));
};
var queue2 = new Queue();
var Response = class _Response {
	constructor(requestParams, response, originatingPage) {
		this.requestParams = requestParams;
		this.response = response;
		this.originatingPage = originatingPage;
	}
	requestParams;
	response;
	originatingPage;
	wasPrefetched = false;
	processed = false;
	static create(params, response, originatingPage) {
		return new _Response(params, response, originatingPage);
	}
	isProcessed() {
		return this.processed;
	}
	async handlePrefetch() {
		if (isSameUrlWithoutHash(this.requestParams.all().url, window.location)) this.handle();
	}
	async handle() {
		return queue2.add(() => this.process());
	}
	async process() {
		if (this.requestParams.all().prefetch) {
			this.wasPrefetched = true;
			this.requestParams.all().prefetch = false;
			this.requestParams.all().onPrefetched(this.response, this.requestParams.all());
			firePrefetchedEvent(this.response, this.requestParams.all());
			return Promise.resolve();
		}
		this.requestParams.runCallbacks();
		this.processed = true;
		if (!this.isInertiaResponse()) return this.handleNonInertiaResponse();
		if (this.isHttpException()) {
			const response = {
				...this.response,
				data: this.getDataFromResponse(this.response.data)
			};
			if (this.requestParams.all().onHttpException(response) === false) return;
			if (!fireHttpExceptionEvent(response)) return;
		}
		await history.processQueue();
		history.preserveUrl = this.requestParams.all().preserveUrl;
		await this.setPage();
		const { flash } = page$1.get();
		if (Object.keys(flash).length > 0 && !this.requestParams.isDeferredPropsRequest()) {
			fireFlashEvent(flash);
			this.requestParams.all().onFlash(flash);
		}
		const errors = page$1.get().props.errors || {};
		if (Object.keys(errors).length > 0) {
			const scopedErrors = this.getScopedErrors(errors);
			fireErrorEvent(scopedErrors, {
				page: page$1.get(),
				visitId: this.requestParams.all().id
			});
			return this.requestParams.all().onError(scopedErrors);
		}
		router.flushByCacheTags(this.requestParams.all().invalidateCacheTags || []);
		if (!this.wasPrefetched) router.flush(page$1.get().url);
		fireSuccessEvent(page$1.get(), { visitId: this.requestParams.all().id });
		await this.requestParams.all().onSuccess(page$1.get());
		history.preserveUrl = false;
	}
	mergeParams(params) {
		this.requestParams.merge(params);
	}
	getPageResponse() {
		const data = this.getDataFromResponse(this.response.data);
		if (typeof data === "object") return this.response.data = {
			...data,
			flash: data.flash ?? {},
			rescuedProps: data.rescuedProps ?? []
		};
		return this.response.data = data;
	}
	async handleNonInertiaResponse() {
		if (this.isInertiaRedirect()) {
			router.visit(this.getHeader("x-inertia-redirect"), {
				...this.requestParams.all(),
				method: "get",
				data: {}
			});
			return;
		}
		if (this.isLocationVisit()) {
			const locationUrl = hrefToUrl(this.getHeader("x-inertia-location"));
			setHashIfSameUrl(this.requestParams.all().url, locationUrl);
			return this.locationVisit(locationUrl);
		}
		const response = {
			...this.response,
			data: this.getDataFromResponse(this.response.data)
		};
		if (this.requestParams.all().onHttpException(response) === false) return;
		if (fireHttpExceptionEvent(response)) return dialog_default.show(response.data);
	}
	isInertiaResponse() {
		return this.hasHeader("x-inertia");
	}
	isHttpException() {
		return this.response.status >= 400;
	}
	hasStatus(status2) {
		return this.response.status === status2;
	}
	getHeader(header) {
		return this.response.headers[header];
	}
	hasHeader(header) {
		return this.getHeader(header) !== void 0;
	}
	isInertiaRedirect() {
		return this.hasStatus(409) && this.hasHeader("x-inertia-redirect");
	}
	isLocationVisit() {
		return this.hasStatus(409) && this.hasHeader("x-inertia-location");
	}
	/**
	* @link https://inertiajs.com/redirects#external-redirects
	*/
	locationVisit(url) {
		try {
			if (typeof window === "undefined") return;
			const responseVersion = this.getHeader("x-inertia-version");
			const versionChange = !!responseVersion && responseVersion !== page$1.get().version;
			if (!fireLocationEvent(url, versionChange)) return;
			if (versionChange && this.requestParams.all().async) return;
			SessionStorage.set(SessionStorage.locationVisitKey, { preserveScroll: this.requestParams.all().preserveScroll === true });
			if (isSameUrlWithoutHash(window.location, url)) window.location.reload();
			else window.location.href = url.href;
		} catch (error) {
			return false;
		}
	}
	async setPage() {
		const pageResponse = this.getPageResponse();
		if (!this.shouldSetPage(pageResponse)) return Promise.resolve();
		this.response = await interceptors.processResponse(this.requestParams.all(), this.response);
		this.mergeProps(pageResponse);
		page$1.mergeOncePropsIntoResponse(pageResponse);
		this.preserveOptimisticProps(pageResponse);
		this.preserveEqualProps(pageResponse);
		await this.setRememberedState(pageResponse);
		this.requestParams.setPreserveOptions(pageResponse);
		pageResponse.url = history.preserveUrl ? page$1.get().url : this.pageUrl(pageResponse);
		this.requestParams.all().onBeforeUpdate(pageResponse);
		fireBeforeUpdateEvent(pageResponse);
		return page$1.set(pageResponse, {
			replace: this.requestParams.all().replace,
			preserveScroll: this.requestParams.all().preserveScroll,
			preserveState: this.requestParams.all().preserveState,
			viewTransition: this.requestParams.all().viewTransition,
			cached: this.requestParams.all().cached,
			visitId: this.requestParams.all().id
		});
	}
	getDataFromResponse(response) {
		if (typeof response !== "string") return response;
		try {
			return JSON.parse(response);
		} catch (error) {
			return response;
		}
	}
	shouldSetPage(pageResponse) {
		if (!this.requestParams.all().async) return true;
		if (this.originatingPage.component !== pageResponse.component) return true;
		if (this.originatingPage.component !== page$1.get().component) return false;
		const originatingUrl = hrefToUrl(this.originatingPage.url);
		const currentPageUrl = hrefToUrl(page$1.get().url);
		return originatingUrl.origin === currentPageUrl.origin && originatingUrl.pathname === currentPageUrl.pathname;
	}
	pageUrl(pageResponse) {
		const responseUrl = hrefToUrl(pageResponse.url);
		if (pageResponse.preserveFragment) responseUrl.hash = this.requestParams.all().url.hash;
		else setHashIfSameUrl(this.requestParams.all().url, responseUrl);
		return responseUrl.pathname + responseUrl.search + responseUrl.hash;
	}
	preserveOptimisticProps(pageResponse) {
		if (!router.hasPendingOptimistic()) return;
		for (const key of Object.keys(pageResponse.props)) if (page$1.hasBaseline(key)) {
			page$1.updateBaseline(key, pageResponse.props[key]);
			pageResponse.props[key] = page$1.get().props[key];
		}
	}
	preserveEqualProps(pageResponse) {
		if (pageResponse.component !== page$1.get().component) return;
		const currentPageProps = page$1.get().props;
		Object.entries(pageResponse.props).forEach(([key, value]) => {
			if (isEqual(value, currentPageProps[key])) pageResponse.props[key] = currentPageProps[key];
		});
	}
	mergeProps(pageResponse) {
		if (!this.requestParams.isPartial() || pageResponse.component !== page$1.get().component) return;
		const propsToAppend = pageResponse.mergeProps || [];
		const propsToPrepend = pageResponse.prependProps || [];
		const propsToDeepMerge = pageResponse.deepMergeProps || [];
		const matchPropsOn = pageResponse.matchPropsOn || [];
		const mergeProp = (prop, shouldAppend) => {
			const currentProp = get(page$1.get().props, prop);
			const incomingProp = get(pageResponse.props, prop);
			if (Array.isArray(incomingProp)) {
				const newArray = this.mergeOrMatchItems(currentProp || [], incomingProp, prop, matchPropsOn, shouldAppend);
				set(pageResponse.props, prop, newArray);
			} else if (typeof incomingProp === "object" && incomingProp !== null) {
				const newObject = {
					...currentProp || {},
					...incomingProp
				};
				set(pageResponse.props, prop, newObject);
			}
		};
		propsToAppend.forEach((prop) => mergeProp(prop, true));
		propsToPrepend.forEach((prop) => mergeProp(prop, false));
		propsToDeepMerge.forEach((prop) => {
			const currentProp = get(page$1.get().props, prop);
			const incomingProp = get(pageResponse.props, prop);
			const deepMerge = (target, source, matchProp) => {
				if (Array.isArray(source)) return this.mergeOrMatchItems(target, source, matchProp, matchPropsOn);
				if (typeof source === "object" && source !== null) return Object.keys(source).reduce((acc, key) => {
					acc[key] = deepMerge(target ? target[key] : void 0, source[key], `${matchProp}.${key}`);
					return acc;
				}, { ...target });
				return source;
			};
			set(pageResponse.props, prop, deepMerge(currentProp, incomingProp, prop));
		});
		const nestedTopKeys = new Set([...this.requestParams.all().only, ...this.requestParams.all().except].filter((prop) => prop.includes(".")).map((prop) => prop.split(".")[0]));
		for (const key of nestedTopKeys) {
			const currentValue = page$1.get().props[key];
			if (this.isObject(currentValue) && this.isObject(pageResponse.props[key])) pageResponse.props[key] = this.deepMergeObjects(currentValue, pageResponse.props[key]);
		}
		pageResponse.props = {
			...page$1.get().props,
			...pageResponse.props
		};
		if (this.shouldPreserveErrors(pageResponse)) pageResponse.props.errors = page$1.get().props.errors;
		if (page$1.get().scrollProps) pageResponse.scrollProps = {
			...page$1.get().scrollProps || {},
			...pageResponse.scrollProps || {}
		};
		if (page$1.hasOnceProps()) pageResponse.onceProps = {
			...page$1.get().onceProps || {},
			...pageResponse.onceProps || {}
		};
		if (this.requestParams.isDeferredPropsRequest()) pageResponse.flash = { ...page$1.get().flash };
		const currentOriginalDeferred = page$1.get().initialDeferredProps;
		if (currentOriginalDeferred && Object.keys(currentOriginalDeferred).length > 0) pageResponse.initialDeferredProps = currentOriginalDeferred;
		pageResponse.rescuedProps = this.mergeRescuedProps(pageResponse);
	}
	mergeRescuedProps(pageResponse) {
		const currentRescued = page$1.get().rescuedProps ?? [];
		const incomingRescued = pageResponse.rescuedProps ?? [];
		const newRescued = new Set(currentRescued.filter((prop) => !partialReloadRequestsProp(this.requestParams.all(), prop)));
		incomingRescued.forEach((prop) => newRescued.add(prop));
		return Array.from(newRescued);
	}
	/**
	* By default, the Laravel adapter shares validation errors via Inertia::always(),
	* so responses always include errors, even when empty. Components like
	* InfiniteScroll and WhenVisible, as well as loading deferred props,
	* perform async requests that should practically never reset errors.
	*/
	shouldPreserveErrors(pageResponse) {
		if (!this.requestParams.all().preserveErrors) return false;
		const currentErrors = page$1.get().props.errors;
		if (!currentErrors || Object.keys(currentErrors).length === 0) return false;
		const responseErrors = pageResponse.props.errors;
		if (responseErrors && Object.keys(responseErrors).length > 0) return false;
		return true;
	}
	isObject(item) {
		return item && typeof item === "object" && !Array.isArray(item);
	}
	deepMergeObjects(target, source) {
		const result = { ...target };
		for (const key of Object.keys(source)) {
			const targetValue = target[key];
			const sourceValue = source[key];
			if (this.isObject(targetValue) && this.isObject(sourceValue)) result[key] = this.deepMergeObjects(targetValue, sourceValue);
			else result[key] = sourceValue;
		}
		return result;
	}
	mergeOrMatchItems(existingItems, newItems, matchProp, matchPropsOn, shouldAppend = true) {
		const items = Array.isArray(existingItems) ? existingItems : [];
		const matchingKey = matchPropsOn.find((key) => {
			return key.split(".").slice(0, -1).join(".") === matchProp;
		});
		if (!matchingKey) return shouldAppend ? [...items, ...newItems] : [...newItems, ...items];
		const uniqueProperty = matchingKey.split(".").pop() || "";
		const newItemsMap = /* @__PURE__ */ new Map();
		newItems.forEach((item) => {
			if (this.hasUniqueProperty(item, uniqueProperty)) newItemsMap.set(item[uniqueProperty], item);
		});
		return shouldAppend ? this.appendWithMatching(items, newItems, newItemsMap, uniqueProperty) : this.prependWithMatching(items, newItems, newItemsMap, uniqueProperty);
	}
	appendWithMatching(existingItems, newItems, newItemsMap, uniqueProperty) {
		const updatedExisting = existingItems.map((item) => {
			if (this.hasUniqueProperty(item, uniqueProperty) && newItemsMap.has(item[uniqueProperty])) return newItemsMap.get(item[uniqueProperty]);
			return item;
		});
		const newItemsToAdd = newItems.filter((item) => {
			if (!this.hasUniqueProperty(item, uniqueProperty)) return true;
			return !existingItems.some((existing) => this.hasUniqueProperty(existing, uniqueProperty) && existing[uniqueProperty] === item[uniqueProperty]);
		});
		return [...updatedExisting, ...newItemsToAdd];
	}
	prependWithMatching(existingItems, newItems, newItemsMap, uniqueProperty) {
		const untouchedExisting = existingItems.filter((item) => {
			if (this.hasUniqueProperty(item, uniqueProperty)) return !newItemsMap.has(item[uniqueProperty]);
			return true;
		});
		return [...newItems, ...untouchedExisting];
	}
	hasUniqueProperty(item, property) {
		return item && typeof item === "object" && property in item;
	}
	async setRememberedState(pageResponse) {
		const rememberedState = await history.getState(history.rememberedState, {});
		if (this.requestParams.all().preserveState && rememberedState && pageResponse.component === page$1.get().component) pageResponse.rememberedState = rememberedState;
	}
	getScopedErrors(errors) {
		if (!this.requestParams.all().errorBag) return errors;
		return errors[this.requestParams.all().errorBag || ""] || {};
	}
};
var Request = class _Request {
	constructor(params, page2, { optimistic = false } = {}) {
		this.page = page2;
		this.requestParams = RequestParams.create(params);
		this.cancelToken = new AbortController();
		this.optimistic = optimistic;
	}
	page;
	response;
	cancelToken;
	requestParams;
	requestHasFinished = false;
	optimistic;
	static create(params, page2, options) {
		return new _Request(params, page2, options);
	}
	isPrefetch() {
		return this.requestParams.isPrefetch();
	}
	getUrl() {
		return this.requestParams.all().url;
	}
	isOptimistic() {
		return this.optimistic;
	}
	isPendingOptimistic() {
		return this.isOptimistic() && (!this.response || !this.response.isProcessed());
	}
	async send() {
		this.requestParams.onCancelToken(() => {
			if (this.response) return;
			this.cancel({ cancelled: true });
		});
		fireStartEvent(this.requestParams.all());
		this.requestParams.onStart();
		if (this.requestParams.all().prefetch) {
			this.requestParams.onPrefetching();
			firePrefetchingEvent(this.requestParams.all());
		}
		const originallyPrefetch = this.requestParams.all().prefetch;
		const config2 = {
			method: this.requestParams.all().method,
			url: urlWithoutHash(this.requestParams.all().url).href,
			data: this.requestParams.data(),
			signal: this.cancelToken.signal,
			headers: this.getHeaders(),
			onUploadProgress: this.onProgress.bind(this)
		};
		const processedConfig = await interceptors.processRequest(this.requestParams.all(), config2);
		return http.getClient().request(processedConfig).then((response) => {
			this.response = Response.create(this.requestParams, response, this.page);
			return this.response.handle();
		}).catch((error) => {
			if (error instanceof HttpResponseError) {
				this.response = Response.create(this.requestParams, error.response, this.page);
				return this.response.handle();
			}
			return Promise.reject(error);
		}).catch((error) => {
			if (error instanceof HttpCancelledError) return;
			if (this.requestParams.all().onNetworkError(error) === false) return;
			if (fireNetworkErrorEvent(error)) {
				if (originallyPrefetch) this.requestParams.onPrefetchError(error);
				return Promise.reject(error);
			}
		}).finally(() => {
			this.finish();
			if (originallyPrefetch && this.response) this.requestParams.onPrefetchResponse(this.response);
		});
	}
	finish() {
		if (this.requestParams.wasCancelledAtAll()) return;
		this.requestParams.markAsFinished();
		this.fireFinishEvents();
	}
	fireFinishEvents() {
		if (this.requestHasFinished) return;
		this.requestHasFinished = true;
		fireFinishEvent(this.requestParams.all());
		this.requestParams.onFinish();
	}
	cancel({ cancelled = false, interrupted = false }) {
		if (this.requestHasFinished) return;
		this.cancelToken.abort();
		this.requestParams.markAsCancelled({
			cancelled,
			interrupted
		});
		this.fireFinishEvents();
	}
	onProgress(progress3) {
		if (this.requestParams.data() instanceof FormData) {
			fireProgressEvent(progress3);
			this.requestParams.all().onProgress(progress3);
		}
	}
	getHeaders() {
		const headers = {
			...this.requestParams.headers(),
			Accept: "text/html, application/xhtml+xml",
			"X-Requested-With": "XMLHttpRequest",
			"X-Inertia": true
		};
		const page2 = page$1.get();
		if (page2.version) headers["X-Inertia-Version"] = page2.version;
		const onceProps = Object.entries(page2.onceProps || {}).filter(([, onceProp]) => {
			if (get(page2.props, onceProp.prop) === void 0) return false;
			return !onceProp.expiresAt || onceProp.expiresAt > Date.now();
		}).map(([key]) => key);
		if (onceProps.length > 0) headers["X-Inertia-Except-Once-Props"] = onceProps.join(",");
		return headers;
	}
};
var RequestStream = class {
	requests = [];
	maxConcurrent;
	interruptible;
	constructor({ maxConcurrent, interruptible }) {
		this.maxConcurrent = maxConcurrent;
		this.interruptible = interruptible;
	}
	send(request) {
		this.requests.push(request);
		request.send().finally(() => {
			this.requests = this.requests.filter((r) => r !== request);
		});
	}
	interruptInFlight() {
		this.cancel({ interrupted: true }, false);
	}
	cancelInFlight(options = {}) {
		const shouldCancel = typeof options === "function" ? options : (request) => {
			const { prefetch = true, optimistic = true } = options;
			return (prefetch || !request.isPrefetch()) && (optimistic || !request.isOptimistic());
		};
		this.requests.filter(shouldCancel).forEach((request) => request.cancel({ cancelled: true }));
	}
	cancel({ cancelled = false, interrupted = false } = {}, force = false) {
		if (!force && !this.shouldCancel()) return;
		this.requests.shift()?.cancel({
			cancelled,
			interrupted
		});
	}
	shouldCancel() {
		return this.interruptible && this.requests.length >= this.maxConcurrent;
	}
	hasPendingOptimistic() {
		return this.requests.some((request) => request.isPendingOptimistic());
	}
};
var noop$1 = () => {};
var Router = class {
	syncRequestStream = new RequestStream({
		maxConcurrent: 1,
		interruptible: true
	});
	asyncRequestStream = new RequestStream({
		maxConcurrent: Infinity,
		interruptible: false
	});
	clientVisitQueue = new Queue();
	pendingOptimisticCallback = void 0;
	init({ initialPage, resolveComponent, swapComponent, onFlash }) {
		page$1.init({
			initialPage,
			resolveComponent,
			swapComponent,
			onFlash
		});
		InitialVisit.handle();
		eventHandler.init();
		eventHandler.on("missingHistoryItem", () => {
			if (typeof window !== "undefined") this.visit(window.location.href, {
				preserveState: true,
				preserveScroll: true,
				replace: true
			});
		});
		eventHandler.on("loadDeferredProps", (deferredProps) => {
			this.loadDeferredProps(deferredProps);
		});
		eventHandler.on("historyQuotaExceeded", (url) => {
			window.location.href = url;
		});
	}
	optimistic(callback) {
		this.pendingOptimisticCallback = callback;
		return this;
	}
	get(url, data = {}, options = {}) {
		return this.visit(url, {
			...options,
			method: "get",
			data
		});
	}
	post(url, data = {}, options = {}) {
		return this.visit(url, {
			preserveState: true,
			...options,
			method: "post",
			data
		});
	}
	put(url, data = {}, options = {}) {
		return this.visit(url, {
			preserveState: true,
			...options,
			method: "put",
			data
		});
	}
	patch(url, data = {}, options = {}) {
		return this.visit(url, {
			preserveState: true,
			...options,
			method: "patch",
			data
		});
	}
	delete(url, options = {}) {
		return this.visit(url, {
			preserveState: true,
			...options,
			method: "delete"
		});
	}
	reload(options = {}) {
		return this.doReload(options);
	}
	doReload(options = {}) {
		if (typeof window === "undefined") return;
		return this.visit(window.location.href, {
			...options,
			preserveScroll: true,
			preserveState: true,
			async: true,
			headers: {
				...options.headers || {},
				"Cache-Control": "no-cache"
			}
		});
	}
	remember(data, key = "default") {
		history.remember(data, key);
	}
	restore(key = "default") {
		return history.restore(key);
	}
	on(type, callback) {
		if (typeof window === "undefined") return () => {};
		return eventHandler.onGlobalEvent(type, callback);
	}
	once(type, callback) {
		if (typeof window === "undefined") return () => {};
		const remove2 = this.on(type, (event) => {
			remove2();
			return callback(event);
		});
		return remove2;
	}
	hasPendingOptimistic() {
		return this.asyncRequestStream.hasPendingOptimistic();
	}
	get activePolls() {
		return polls.count;
	}
	cancelAll({ async = true, prefetch = true, sync = true } = {}) {
		if (async) this.asyncRequestStream.cancelInFlight({ prefetch });
		if (sync) this.syncRequestStream.cancelInFlight();
	}
	poll(interval, requestOptions = {}, options = {}) {
		return polls.add(interval, ({ onStart, onFinish }) => {
			const resolved = typeof requestOptions === "function" ? requestOptions() : requestOptions;
			this.doReload({
				poll: true,
				preserveErrors: true,
				...resolved,
				onCancelToken: (token) => {
					onStart(token.cancel);
					resolved.onCancelToken?.(token);
				},
				onFinish: (visit) => {
					onFinish();
					resolved.onFinish?.(visit);
				}
			});
		}, {
			autoStart: options.autoStart ?? true,
			keepAlive: options.keepAlive ?? false,
			mode: options.mode
		});
	}
	visit(href, options = {}) {
		options.optimistic = options.optimistic ?? this.pendingOptimisticCallback;
		this.pendingOptimisticCallback = void 0;
		if (options.optimistic) options.async = options.async ?? true;
		const visit = this.getPendingVisit(href, {
			...options,
			showProgress: options.showProgress ?? (!options.async || !!options.optimistic)
		});
		const events = this.getVisitEvents(options);
		if (events.onBefore(visit) === false || !fireBeforeEvent(visit)) return;
		const currentPageUrl = hrefToUrl(page$1.get().url);
		if (!(visit.only.length > 0 || visit.except.length > 0 || visit.reset.length > 0 ? isSameUrlWithoutQueryOrHash(visit.url, currentPageUrl) : isSameUrlWithoutHash(visit.url, currentPageUrl))) this.asyncRequestStream.cancelInFlight((request) => !request.isPrefetch() && !request.isOptimistic() && isSameUrlWithoutQueryOrHash(request.getUrl(), currentPageUrl));
		if (!visit.async) this.syncRequestStream.interruptInFlight();
		if (options.optimistic) this.applyOptimisticUpdate(options.optimistic, events);
		if (!page$1.isCleared() && !visit.preserveUrl) Scroll.save();
		const requestParams = {
			...visit,
			...events
		};
		const sendRequest = () => {
			const prefetched = prefetchedRequests.get(requestParams);
			if (prefetched) {
				progress.reveal(prefetched.inFlight);
				prefetchedRequests.use(prefetched, requestParams);
			} else {
				progress.reveal(true);
				(visit.async ? this.asyncRequestStream : this.syncRequestStream).send(Request.create(requestParams, page$1.get(), { optimistic: !!options.optimistic }));
			}
		};
		if (Array.isArray(visit.component)) {
			console.error(`The "component" prop received an array of components (${visit.component.join(", ")}), but only a single component string is supported for instant visits. Pass an explicit component name instead.`);
			visit.component = null;
		}
		if (visit.component) history.processQueue().then(() => {
			this.performInstantSwap(visit).then(() => {
				requestParams.preserveScroll = true;
				requestParams.preserveState = true;
				requestParams.replace = true;
				requestParams.viewTransition = false;
				sendRequest();
			});
		});
		else sendRequest();
	}
	getCached(href, options = {}) {
		return prefetchedRequests.findCached(this.getPrefetchParams(href, options));
	}
	flush(href, options = {}) {
		prefetchedRequests.remove(this.getPrefetchParams(href, options));
	}
	flushAll() {
		prefetchedRequests.removeAll();
	}
	flushByCacheTags(tags) {
		prefetchedRequests.removeByTags(Array.isArray(tags) ? tags : [tags]);
	}
	getPrefetching(href, options = {}) {
		return prefetchedRequests.findInFlight(this.getPrefetchParams(href, options));
	}
	prefetch(href, options = {}, prefetchOptions = {}) {
		if ((options.method ?? (isUrlMethodPair(href) ? href.method : "get")) !== "get") throw new Error("Prefetch requests must use the GET method");
		const visit = this.getPendingVisit(href, {
			...options,
			async: true,
			showProgress: false,
			prefetch: true,
			viewTransition: false
		});
		if (visit.url.origin + visit.url.pathname + visit.url.search === window.location.origin + window.location.pathname + window.location.search) return;
		const events = this.getVisitEvents(options);
		if (events.onBefore(visit) === false || !fireBeforeEvent(visit)) return;
		progress.hide();
		this.asyncRequestStream.interruptInFlight();
		const requestParams = {
			...visit,
			...events
		};
		const ensureCurrentPageIsSet = () => {
			return new Promise((resolve) => {
				const checkIfPageIsDefined = () => {
					if (page$1.get()) resolve();
					else setTimeout(checkIfPageIsDefined, 50);
				};
				checkIfPageIsDefined();
			});
		};
		ensureCurrentPageIsSet().then(() => {
			prefetchedRequests.add(requestParams, (params) => {
				this.asyncRequestStream.send(Request.create(params, page$1.get()));
			}, {
				cacheFor: config$1.get("prefetch.cacheFor"),
				cacheTags: [],
				...prefetchOptions
			});
		});
	}
	clearHistory() {
		history.clear();
	}
	decryptHistory() {
		return history.decrypt();
	}
	resolveComponent(component, page2) {
		return page$1.resolve(component, page2);
	}
	replace(params) {
		this.clientVisit(params, { replace: true });
	}
	replaceProp(name, value, options) {
		this.replace({
			preserveScroll: true,
			preserveState: true,
			props(currentProps) {
				return setPathPreservingIdentity(currentProps, name, typeof value === "function" ? value(get(currentProps, name), currentProps) : value);
			},
			...options || {}
		});
	}
	appendToProp(name, value, options) {
		this.replaceProp(name, (currentValue, currentProps) => {
			const newValue = typeof value === "function" ? value(currentValue, currentProps) : value;
			if (!Array.isArray(currentValue)) currentValue = currentValue !== void 0 ? [currentValue] : [];
			return [...currentValue, newValue];
		}, options);
	}
	prependToProp(name, value, options) {
		this.replaceProp(name, (currentValue, currentProps) => {
			const newValue = typeof value === "function" ? value(currentValue, currentProps) : value;
			if (!Array.isArray(currentValue)) currentValue = currentValue !== void 0 ? [currentValue] : [];
			return [newValue, ...currentValue];
		}, options);
	}
	push(params) {
		this.clientVisit(params);
	}
	flash(keyOrData, value) {
		const current = page$1.get().flash;
		let flash;
		if (typeof keyOrData === "function") flash = keyOrData(current);
		else if (typeof keyOrData === "string") flash = {
			...current,
			[keyOrData]: value
		};
		else if (keyOrData && Object.keys(keyOrData).length) flash = {
			...current,
			...keyOrData
		};
		else return;
		page$1.setFlash(flash);
		if (Object.keys(flash).length) fireFlashEvent(flash);
	}
	clientVisit(params, { replace = false } = {}) {
		this.clientVisitQueue.add(() => this.performClientVisit(params, { replace }));
	}
	performClientVisit(params, { replace = false } = {}) {
		const current = page$1.get();
		const onceProps = typeof params.props === "function" ? Object.fromEntries(Object.values(current.onceProps ?? {}).map((onceProp) => [onceProp.prop, get(current.props, onceProp.prop)])) : {};
		const props = typeof params.props === "function" ? params.props(current.props, onceProps) : params.props ?? current.props;
		const flash = typeof params.flash === "function" ? params.flash(current.flash) : params.flash;
		const { viewTransition, onError, onFinish, onFlash, onSuccess, ...pageParams } = params;
		const page2 = {
			...current,
			...pageParams,
			flash: flash ?? {},
			props
		};
		const preserveScroll = RequestParams.resolvePreserveOption(params.preserveScroll ?? false, page2);
		const preserveState = RequestParams.resolvePreserveOption(params.preserveState ?? false, page2);
		const visitId = this.createVisitId();
		return page$1.set(page2, {
			replace,
			preserveScroll,
			preserveState,
			viewTransition,
			visitId
		}).then(() => {
			fireClientVisitEvent(page$1.get(), {
				replace,
				visitId
			});
			const currentFlash = page$1.get().flash;
			if (Object.keys(currentFlash).length > 0) {
				fireFlashEvent(currentFlash);
				onFlash?.(currentFlash);
			}
			const errors = page$1.get().props.errors || {};
			if (Object.keys(errors).length === 0) {
				onSuccess?.(page$1.get());
				return;
			}
			const scopedErrors = params.errorBag ? errors[params.errorBag || ""] || {} : errors;
			onError?.(scopedErrors);
		}).finally(() => onFinish?.(params));
	}
	performInstantSwap(visit) {
		const current = page$1.get();
		const sharedProps = Object.fromEntries((current.sharedProps ?? []).filter((key) => key in current.props).map((key) => [key, current.props[key]]));
		const resolvedPageProps = typeof visit.pageProps === "function" ? visit.pageProps(cloneDeep$1(current.props), cloneDeep$1(sharedProps)) : visit.pageProps;
		const intermediateProps = resolvedPageProps !== null ? { ...resolvedPageProps } : { ...sharedProps };
		const onceProps = this.preserveOncePropsOnInstantVisit(current, intermediateProps);
		const intermediatePage = {
			component: visit.component,
			url: visit.url.pathname + visit.url.search + visit.url.hash,
			version: current.version,
			props: {
				...intermediateProps,
				errors: {}
			},
			flash: {},
			rescuedProps: [],
			clearHistory: false,
			encryptHistory: current.encryptHistory,
			sharedProps: current.sharedProps,
			onceProps,
			rememberedState: {}
		};
		return page$1.set(intermediatePage, {
			replace: visit.replace,
			preserveScroll: RequestParams.resolvePreserveOption(visit.preserveScroll, intermediatePage),
			preserveState: false,
			viewTransition: visit.viewTransition,
			visitId: visit.id
		});
	}
	/**
	* Once props are remembered client-side, so the placeholder page must preserve their values
	* and registry. Otherwise the swap discards the value, and an in-flight prefetch that already
	* claimed the prop resolves with nothing to restore it from.
	*/
	preserveOncePropsOnInstantVisit(current, props) {
		const onceProps = {};
		Object.entries(current.onceProps ?? {}).forEach(([key, onceProp]) => {
			if (get(props, onceProp.prop) !== void 0) return;
			const currentValue = get(current.props, onceProp.prop);
			if (currentValue === void 0) return;
			set(props, onceProp.prop, currentValue);
			onceProps[key] = onceProp;
		});
		return onceProps;
	}
	getPrefetchParams(href, options) {
		return {
			...this.getPendingVisit(href, {
				...options,
				async: true,
				showProgress: false,
				prefetch: true,
				viewTransition: false
			}),
			...this.getVisitEvents(options)
		};
	}
	createVisitId() {
		return uid();
	}
	getPendingVisit(href, options) {
		if (isUrlMethodPair(href)) {
			const urlMethodPair = href;
			href = urlMethodPair.url;
			options.method = options.method ?? urlMethodPair.method;
		}
		const defaultVisitOptionsCallback = config$1.get("visitOptions");
		const configuredOptions = defaultVisitOptionsCallback ? defaultVisitOptionsCallback(href.toString(), cloneDeep$1(options)) || {} : {};
		const mergedOptions = {
			method: "get",
			data: {},
			replace: false,
			preserveScroll: false,
			preserveState: false,
			only: [],
			except: [],
			headers: {},
			errorBag: "",
			forceFormData: false,
			queryStringArrayFormat: "brackets",
			async: false,
			showProgress: true,
			fresh: false,
			reset: [],
			preserveUrl: false,
			preserveErrors: false,
			prefetch: false,
			invalidateCacheTags: [],
			viewTransition: false,
			component: null,
			pageProps: null,
			cached: false,
			...stripTopLevelUndefined(options),
			...stripTopLevelUndefined(configuredOptions)
		};
		const [url, _data] = transformUrlAndData(href, mergedOptions.data, mergedOptions.method, mergedOptions.forceFormData, mergedOptions.queryStringArrayFormat);
		const visit = {
			id: this.createVisitId(),
			cancelled: false,
			completed: false,
			interrupted: false,
			...mergedOptions,
			url,
			data: _data
		};
		if (visit.prefetch) visit.headers["Purpose"] = "prefetch";
		return visit;
	}
	getVisitEvents(options) {
		return {
			onCancelToken: options.onCancelToken || noop$1,
			onBefore: options.onBefore || noop$1,
			onBeforeUpdate: options.onBeforeUpdate || noop$1,
			onStart: options.onStart || noop$1,
			onProgress: options.onProgress || noop$1,
			onFinish: options.onFinish || noop$1,
			onCancel: options.onCancel || noop$1,
			onSuccess: options.onSuccess || noop$1,
			onError: options.onError || noop$1,
			onHttpException: options.onHttpException || noop$1,
			onNetworkError: options.onNetworkError || noop$1,
			onFlash: options.onFlash || noop$1,
			onPrefetched: options.onPrefetched || noop$1,
			onPrefetching: options.onPrefetching || noop$1
		};
	}
	applyOptimisticUpdate(optimistic, events) {
		const currentProps = page$1.get().props;
		const optimisticProps = optimistic(cloneDeep$1(currentProps));
		if (!optimisticProps) return;
		const changedKeys = [];
		for (const key of Object.keys(optimisticProps)) if (!isEqual(currentProps[key], optimisticProps[key])) changedKeys.push(key);
		if (changedKeys.length === 0) return;
		const id = page$1.nextOptimisticId();
		const component = page$1.get().component;
		for (const key of changedKeys) page$1.setBaseline(key, cloneDeep$1(currentProps[key]));
		page$1.registerOptimistic(id, optimistic);
		page$1.setPropsQuietly({
			...currentProps,
			...optimisticProps
		});
		let shouldRestore = true;
		const originalOnSuccess = events.onSuccess;
		events.onSuccess = (page2) => {
			shouldRestore = false;
			return originalOnSuccess(page2);
		};
		const originalOnFinish = events.onFinish;
		events.onFinish = (visit) => {
			page$1.unregisterOptimistic(id);
			if (shouldRestore && page$1.get().component === component) {
				const replayedProps = page$1.replayOptimistics();
				if (Object.keys(replayedProps).length > 0) page$1.setPropsQuietly({
					...page$1.get().props,
					...replayedProps
				});
			}
			if (page$1.pendingOptimisticCount() === 0) page$1.clearOptimisticState();
			return originalOnFinish(visit);
		};
	}
	loadDeferredProps(deferred) {
		if (deferred) Object.values(deferred).forEach((props) => {
			this.doReload({
				only: props,
				deferredProps: true,
				preserveErrors: true
			});
		});
	}
};
var UseFormUtils = class {
	/**
	* Creates a callback that returns a UrlMethodPair.
	*
	* createWayfinderCallback(urlMethodPair)
	* createWayfinderCallback(method, url)
	* createWayfinderCallback(() => urlMethodPair)
	* createWayfinderCallback(() => method, () => url)
	*/
	static createWayfinderCallback(...args) {
		return () => {
			if (args.length === 1) return isUrlMethodPair(args[0]) ? args[0] : args[0]();
			return {
				method: typeof args[0] === "function" ? args[0]() : args[0],
				url: typeof args[1] === "function" ? args[1]() : args[1]
			};
		};
	}
	/**
	* Parses all useForm() arguments into { rememberKey, data, precognitionEndpoint }.
	*
	* useForm()
	* useForm(data)
	* useForm(rememberKey, data)
	* useForm(method, url, data)
	* useForm(urlMethodPair, data)
	*
	*/
	static parseUseFormArguments(...args) {
		if (args.length === 0) return {
			rememberKey: null,
			data: {},
			precognitionEndpoint: null
		};
		if (args.length === 1) return {
			rememberKey: null,
			data: args[0],
			precognitionEndpoint: null
		};
		if (args.length === 2) {
			if (typeof args[0] === "string") return {
				rememberKey: args[0],
				data: args[1],
				precognitionEndpoint: null
			};
			return {
				rememberKey: null,
				data: args[1],
				precognitionEndpoint: this.createWayfinderCallback(args[0])
			};
		}
		return {
			rememberKey: null,
			data: args[2],
			precognitionEndpoint: this.createWayfinderCallback(args[0], args[1])
		};
	}
	/**
	* Parses all submission arguments into { method, url, options }.
	* It uses the Precognition endpoint if no explicit method/url are provided.
	*
	* form.submit(method, url)
	* form.submit(method, url, options)
	* form.submit(urlMethodPair)
	* form.submit(urlMethodPair, options)
	* form.submit()
	* form.submit(options)
	*/
	static parseSubmitArguments(args, precognitionEndpoint) {
		if (args.length === 3 || args.length === 2 && typeof args[0] === "string") return {
			method: args[0],
			url: args[1],
			options: args[2] ?? {}
		};
		if (isUrlMethodPair(args[0])) return {
			...args[0],
			options: args[1] ?? {}
		};
		return {
			...precognitionEndpoint(),
			options: args[0] ?? {}
		};
	}
	/**
	* Merges headers into the Precognition validate() arguments.
	*/
	static mergeHeadersForValidation(field, config2, headers) {
		const merge = (config3) => {
			config3.headers = {
				...headers ?? {},
				...config3.headers ?? {}
			};
			return config3;
		};
		if (field && typeof field === "object" && !("target" in field)) field = merge(field);
		else if (config2 && typeof config2 === "object") config2 = merge(config2);
		else if (typeof field === "string") config2 = merge(config2 ?? {});
		else field = merge(field ?? {});
		return [field, config2];
	}
};
function undotKey(key) {
	if (!key.includes(".")) return key;
	const transformSegment = (segment) => {
		if (segment.startsWith("[") && segment.endsWith("]")) return segment;
		return segment.split(".").reduce((result, part, index) => index === 0 ? part : `${result}[${part}]`);
	};
	return key.replace(/\\\./g, "__ESCAPED_DOT__").split(/(\[[^\]]*\])/).filter(Boolean).map(transformSegment).join("").replace(/__ESCAPED_DOT__/g, ".");
}
function parseKey2(key) {
	const path = [];
	const pattern = /([^\[\]]+)|\[(\d*)\]/g;
	let match;
	while ((match = pattern.exec(key)) !== null) if (match[1] !== void 0) path.push(match[1]);
	else if (match[2] !== void 0) path.push(match[2] === "" ? "" : Number(match[2]));
	return path;
}
function setNestedObject(obj, path, value) {
	let current = obj;
	for (let i = 0; i < path.length - 1; i++) {
		if (!(path[i] in current)) current[path[i]] = {};
		current = current[path[i]];
	}
	current[path[path.length - 1]] = value;
}
function objectHasSequentialNumericKeys(value) {
	const keys = Object.keys(value);
	const numericKeys = keys.filter((k) => /^\d+$/.test(k)).map(Number).sort((a, b) => a - b);
	return keys.length === numericKeys.length && numericKeys.length > 0 && numericKeys[0] === 0 && numericKeys.every((n, i) => n === i);
}
function convertSequentialObjectsToArrays(value) {
	if (Array.isArray(value)) return value.map(convertSequentialObjectsToArrays);
	if (typeof value !== "object" || value === null || isFile(value)) return value;
	if (objectHasSequentialNumericKeys(value)) {
		const result2 = [];
		for (let i = 0; i < Object.keys(value).length; i++) result2[i] = convertSequentialObjectsToArrays(value[i]);
		return result2;
	}
	const result = {};
	for (const key in value) result[key] = convertSequentialObjectsToArrays(value[key]);
	return result;
}
function formDataToObject(source) {
	const form = {};
	for (const [key, value] of source.entries()) {
		if (value instanceof File && value.size === 0 && value.name === "") continue;
		const path = parseKey2(undotKey(key));
		if (path[path.length - 1] === "") {
			const arrayPath = path.slice(0, -1);
			const existing = get(form, arrayPath);
			if (Array.isArray(existing)) existing.push(value);
			else if (existing && typeof existing === "object" && !isFile(existing)) {
				const numericKeys = Object.keys(existing).filter((k) => /^\d+$/.test(k)).map(Number).sort((a, b) => a - b);
				set(form, arrayPath, numericKeys.length > 0 ? [...numericKeys.map((k) => existing[k]), value] : [value]);
			} else set(form, arrayPath, [value]);
			continue;
		}
		setNestedObject(form, path.map(String), value);
	}
	return convertSequentialObjectsToArrays(form);
}
var serverHeadProviderId = "server";
function ensureElementHasInertiaAttribute(element, index) {
	if (element.match(/\sdata-inertia(=|\s|>)/)) return element;
	return element.replace(/^<([a-zA-Z][^\s/>]*)/, `<$1 data-inertia="server-head-${index}"`);
}
function resolveServerHead(page2, serverHead) {
	if (!serverHead) return [];
	const elements = typeof serverHead === "function" ? serverHead(page2) : page2.props[serverHead === true ? "head" : serverHead];
	if (!Array.isArray(elements)) return [];
	return elements.map((element) => typeof element === "string" ? element.trim() : element).filter((element) => typeof element === "string" && element.length > 0).map(ensureElementHasInertiaAttribute);
}
var Renderer = {
	buildDOMElement(tag) {
		const template = document.createElement("template");
		template.innerHTML = tag;
		const node = template.content.firstChild;
		if (!tag.startsWith("<script ")) return node;
		const script = document.createElement("script");
		script.innerHTML = node.innerHTML;
		node.getAttributeNames().forEach((name) => {
			script.setAttribute(name, node.getAttribute(name) || "");
		});
		return script;
	},
	isInertiaManagedElement(element) {
		return element.nodeType === Node.ELEMENT_NODE && element.getAttribute("data-inertia") !== null;
	},
	findMatchingElementIndex(element, elements) {
		const key = element.getAttribute("data-inertia");
		if (key !== null) return elements.findIndex((element2) => element2.getAttribute("data-inertia") === key);
		return -1;
	},
	update: debounce(function(elements) {
		const sourceElements = elements.map((element) => this.buildDOMElement(element));
		const targetElements = Array.from(document.head.childNodes).filter((element) => this.isInertiaManagedElement(element));
		if (sourceElements.some((element) => element instanceof HTMLTitleElement)) document.head.querySelectorAll("title:not([data-inertia])").forEach((title) => title.remove());
		targetElements.forEach((targetElement) => {
			const index = this.findMatchingElementIndex(targetElement, sourceElements);
			if (index === -1) {
				targetElement.remove();
				return;
			}
			const sourceElement = sourceElements.splice(index, 1)[0];
			if (sourceElement && !targetElement.isEqualNode(sourceElement)) targetElement.replaceWith(sourceElement);
		});
		sourceElements.forEach((element) => {
			document.head.appendChild(element);
		});
	}, 1)
};
function createHeadManager(isServer3, titleCallback, onUpdate, initialServerHead = []) {
	const states = initialServerHead.length ? { [serverHeadProviderId]: initialServerHead } : {};
	let lastProviderId = 0;
	function connect() {
		const id = lastProviderId += 1;
		states[id] = [];
		return id.toString();
	}
	function disconnect(id) {
		if (id === null || Object.keys(states).indexOf(id) === -1) return;
		delete states[id];
		commit();
	}
	function reconnect(id) {
		if (Object.keys(states).indexOf(id) === -1) states[id] = [];
	}
	function update(id, elements = []) {
		if (id !== null && Object.keys(states).indexOf(id) > -1) states[id] = elements;
		commit();
	}
	function updateServerHead(elements = []) {
		if (elements.length) states[serverHeadProviderId] = elements;
		else delete states[serverHeadProviderId];
		commit();
	}
	function collect() {
		const title = titleCallback("");
		const serverHead = states[serverHeadProviderId] || [];
		const providerHead = Object.keys(states).filter((id) => id !== serverHeadProviderId).flatMap((id) => states[id]);
		const defaults = { ...title ? { title: `<title data-inertia="">${title}</title>` } : {} };
		const elements = serverHead.concat(providerHead).reduce((carry, element) => {
			if (element.indexOf("<") === -1) return carry;
			if (element.indexOf("<title ") === 0) {
				const title2 = element.match(/(<title [^>]+>)(.*?)(<\/title>)/s);
				carry.title = title2 ? `${title2[1]}${titleCallback(title2[2])}${title2[3]}` : element;
				return carry;
			}
			const match = element.match(/ data-inertia=(["'])[^"']+\1/);
			if (match) carry[match[0]] = element;
			else carry[Object.keys(carry).length] = element;
			return carry;
		}, defaults);
		return Object.values(elements);
	}
	function commit() {
		isServer3 ? onUpdate(collect()) : Renderer.update(collect());
	}
	commit();
	return {
		forceUpdate: commit,
		updateServerHead,
		createProvider: function() {
			const id = connect();
			return {
				reconnect: () => reconnect(id),
				update: (elements) => update(id, elements),
				disconnect: () => disconnect(id)
			};
		}
	};
}
var MERGE_INTENT_HEADER = "X-Inertia-Infinite-Scroll-Merge-Intent";
var useInfiniteScrollData = (options) => {
	const getScrollPropFromCurrentPage = () => {
		const scrollProp = page$1.get().scrollProps?.[options.getPropName()];
		if (scrollProp) return scrollProp;
		throw new Error(`The page object does not contain a scroll prop named "${options.getPropName()}".`);
	};
	const state = {
		component: null,
		loading: false,
		previousPage: null,
		nextPage: null,
		lastLoadedPage: null,
		requestCount: 0
	};
	const resetState = () => {
		const scrollProp = getScrollPropFromCurrentPage();
		state.component = page$1.get().component;
		state.loading = false;
		state.previousPage = scrollProp.previousPage;
		state.nextPage = scrollProp.nextPage;
		state.lastLoadedPage = scrollProp.currentPage;
		state.requestCount = 0;
	};
	const getRememberKey = () => `inertia:infinite-scroll-data:${options.getPropName()}`;
	if (typeof window !== "undefined") {
		resetState();
		const rememberedState = router.restore(getRememberKey());
		if (rememberedState && typeof rememberedState === "object" && rememberedState.lastLoadedPage === getScrollPropFromCurrentPage().currentPage) {
			state.previousPage = rememberedState.previousPage;
			state.nextPage = rememberedState.nextPage;
			state.lastLoadedPage = rememberedState.lastLoadedPage;
			state.requestCount = rememberedState.requestCount || 0;
		}
	}
	const removeEventListener = router.on("success", (event) => {
		if (state.component === event.detail.page.component && getScrollPropFromCurrentPage().reset) {
			resetState();
			options.onReset?.();
		}
	});
	const getScrollPropKeyForSide = (side) => {
		return side === "next" ? "nextPage" : "previousPage";
	};
	const findPageToLoad = (side) => {
		const pagePropName = getScrollPropKeyForSide(side);
		return state[pagePropName];
	};
	const syncStateOnSuccess = (side) => {
		const scrollProp = getScrollPropFromCurrentPage();
		const paginationProp = getScrollPropKeyForSide(side);
		state.lastLoadedPage = scrollProp.currentPage;
		state[paginationProp] = scrollProp[paginationProp];
		state.requestCount += 1;
		router.remember({
			previousPage: state.previousPage,
			nextPage: state.nextPage,
			lastLoadedPage: state.lastLoadedPage,
			requestCount: state.requestCount
		}, getRememberKey());
	};
	const getPageName = () => getScrollPropFromCurrentPage().pageName;
	const getRequestCount = () => state.requestCount;
	const fetchPage = (side, reloadOptions = {}) => {
		const page2 = findPageToLoad(side);
		if (state.loading || page2 === null) return;
		state.loading = true;
		router.reload({
			preserveErrors: true,
			...reloadOptions,
			data: {
				...reloadOptions.data || {},
				[getPageName()]: page2
			},
			only: [...reloadOptions.only || [], options.getPropName()],
			preserveUrl: true,
			headers: {
				[MERGE_INTENT_HEADER]: side === "previous" ? "prepend" : "append",
				...reloadOptions.headers
			},
			onBefore: (visit) => {
				side === "next" ? options.onBeforeNextRequest() : options.onBeforePreviousRequest();
				reloadOptions.onBefore?.(visit);
			},
			onBeforeUpdate: (page3) => {
				options.onBeforeUpdate();
				reloadOptions.onBeforeUpdate?.(page3);
			},
			onSuccess: (page3) => {
				syncStateOnSuccess(side);
				reloadOptions.onSuccess?.(page3);
			},
			onFinish: (visit) => {
				state.loading = false;
				const completed = visit.completed;
				const page3 = completed ? state.lastLoadedPage : null;
				side === "next" ? options.onCompleteNextRequest(page3, {
					page: page3,
					completed
				}) : options.onCompletePreviousRequest(page3, {
					page: page3,
					completed
				});
				reloadOptions.onFinish?.(visit);
			}
		});
	};
	const getLastLoadedPage = () => state.lastLoadedPage;
	const hasPrevious = () => !!state.previousPage;
	const hasNext = () => !!state.nextPage;
	const fetchPrevious = (reloadOptions) => fetchPage("previous", reloadOptions);
	const fetchNext = (reloadOptions) => fetchPage("next", reloadOptions);
	return {
		getLastLoadedPage,
		getPageName,
		getRequestCount,
		hasPrevious,
		hasNext,
		fetchNext,
		fetchPrevious,
		removeEventListener
	};
};
var useIntersectionObservers = () => {
	const intersectionObservers = [];
	const newIntersectionObserver = (callback, options = {}) => {
		const observer = new IntersectionObserver((entries) => {
			for (const entry of entries) if (entry.isIntersecting) callback(entry);
		}, options);
		intersectionObservers.push(observer);
		return observer;
	};
	const flushAll = () => {
		intersectionObservers.forEach((observer) => observer.disconnect());
		intersectionObservers.length = 0;
	};
	return {
		new: newIntersectionObserver,
		flushAll
	};
};
var INFINITE_SCROLL_PAGE_KEY = "infiniteScrollPage";
var INFINITE_SCROLL_IGNORE_KEY = "infiniteScrollIgnore";
var getPageFromElement = (element) => element.dataset[INFINITE_SCROLL_PAGE_KEY];
var useInfiniteScrollElementManager = (options) => {
	const intersectionObservers = useIntersectionObservers();
	let itemsObserver;
	let startElementObserver;
	let endElementObserver;
	let itemsMutationObserver;
	let triggersEnabled = false;
	const setupObservers = () => {
		itemsMutationObserver = new MutationObserver((mutations) => {
			mutations.forEach((mutation) => {
				mutation.addedNodes.forEach((node) => {
					if (node.nodeType !== Node.ELEMENT_NODE) return;
					addedElements.add(node);
				});
			});
			rememberElementsDebounced();
		});
		itemsMutationObserver.observe(options.getItemsElement(), { childList: true });
		itemsObserver = intersectionObservers.new((entry) => options.onItemIntersected(entry.target));
		const observerOptions = {
			root: options.getScrollableParent(),
			rootMargin: `${Math.max(1, options.getTriggerMargin())}px`
		};
		startElementObserver = intersectionObservers.new(options.onPreviousTriggered, observerOptions);
		endElementObserver = intersectionObservers.new(options.onNextTriggered, observerOptions);
	};
	const enableTriggers = () => {
		if (triggersEnabled) disableTriggers();
		const startElement = options.getStartElement();
		const endElement = options.getEndElement();
		if (startElement && options.shouldFetchPrevious()) startElementObserver.observe(startElement);
		if (endElement && options.shouldFetchNext()) endElementObserver.observe(endElement);
		triggersEnabled = true;
	};
	const disableTriggers = () => {
		if (!triggersEnabled) return;
		startElementObserver.disconnect();
		endElementObserver.disconnect();
		triggersEnabled = false;
	};
	const refreshTriggers = () => {
		if (triggersEnabled) enableTriggers();
	};
	const flushAll = () => {
		disableTriggers();
		intersectionObservers.flushAll();
		itemsMutationObserver?.disconnect();
	};
	const addedElements = /* @__PURE__ */ new Set();
	const elementIsUntagged = (element) => !(INFINITE_SCROLL_PAGE_KEY in element.dataset) && !(INFINITE_SCROLL_IGNORE_KEY in element.dataset);
	const processManuallyAddedElements = () => {
		Array.from(addedElements).forEach((element) => {
			if (elementIsUntagged(element)) element.dataset[INFINITE_SCROLL_IGNORE_KEY] = "true";
			itemsObserver.observe(element);
		});
		addedElements.clear();
	};
	const findUntaggedElements = (containerElement) => {
		return Array.from(containerElement.querySelectorAll(`:scope > *:not([data-infinite-scroll-page]):not([data-infinite-scroll-ignore])`));
	};
	let hasRestoredElements = false;
	const processServerLoadedElements = (loadedPage) => {
		if (!hasRestoredElements) {
			hasRestoredElements = true;
			if (restoreElements()) return;
		}
		findUntaggedElements(options.getItemsElement()).forEach((element) => {
			if (elementIsUntagged(element)) element.dataset[INFINITE_SCROLL_PAGE_KEY] = loadedPage?.toString() || "1";
			itemsObserver.observe(element);
		});
		rememberElements();
	};
	const getElementsRememberKey = () => `inertia:infinite-scroll-elements:${options.getPropName()}`;
	const rememberElements = () => {
		const pageElementRange = {};
		const childNodes = options.getItemsElement().childNodes;
		for (let index = 0; index < childNodes.length; index++) {
			const node = childNodes[index];
			if (node.nodeType !== Node.ELEMENT_NODE) continue;
			const page2 = getPageFromElement(node);
			if (typeof page2 === "undefined") continue;
			if (!(page2 in pageElementRange)) pageElementRange[page2] = {
				from: index,
				to: index
			};
			else pageElementRange[page2].to = index;
		}
		router.remember(pageElementRange, getElementsRememberKey());
	};
	const rememberElementsDebounced = debounce(rememberElements, 250);
	const restoreElements = () => {
		const pageElementRange = router.restore(getElementsRememberKey());
		if (!pageElementRange || typeof pageElementRange !== "object") return false;
		const childNodes = options.getItemsElement().childNodes;
		for (let index = 0; index < childNodes.length; index++) {
			const node = childNodes[index];
			if (node.nodeType !== Node.ELEMENT_NODE) continue;
			const element = node;
			let elementPage;
			for (const [page2, range] of Object.entries(pageElementRange)) if (index >= range.from && index <= range.to) {
				elementPage = page2;
				break;
			}
			if (elementPage) element.dataset[INFINITE_SCROLL_PAGE_KEY] = elementPage;
			else if (!elementIsUntagged(element)) continue;
			else element.dataset[INFINITE_SCROLL_IGNORE_KEY] = "true";
			itemsObserver.observe(element);
		}
		return true;
	};
	return {
		setupObservers,
		enableTriggers,
		disableTriggers,
		refreshTriggers,
		flushAll,
		processManuallyAddedElements,
		processServerLoadedElements
	};
};
var queue3 = new Queue();
var initialUrl;
var payloadUrl;
var initialUrlWasAbsolute = null;
var useInfiniteScrollQueryString = (options) => {
	let enabled = true;
	const queuePageUpdate = (page2) => {
		queue3.add(() => {
			return new Promise((resolve) => {
				if (!enabled) {
					initialUrl = payloadUrl = null;
					return resolve();
				}
				if (!initialUrl || !payloadUrl) {
					const currentPageUrl = page$1.get().url;
					initialUrl = hrefToUrl(currentPageUrl);
					payloadUrl = hrefToUrl(currentPageUrl);
					initialUrlWasAbsolute = urlHasProtocol(currentPageUrl);
				}
				const pageName = options.getPageName();
				const searchParams = payloadUrl.searchParams;
				if (page2 === "1") searchParams.delete(pageName);
				else searchParams.set(pageName, page2);
				setTimeout(() => resolve());
			});
		}).finally(() => {
			if (enabled && initialUrl && payloadUrl && initialUrl.href !== payloadUrl.href && initialUrlWasAbsolute !== null) router.replace({
				url: urlToString(payloadUrl, initialUrlWasAbsolute),
				preserveScroll: true,
				preserveState: true
			});
			initialUrl = payloadUrl = initialUrlWasAbsolute = null;
		});
	};
	return {
		onItemIntersected: debounce((itemElement) => {
			const itemsElement = options.getItemsElement();
			if (!enabled || options.shouldPreserveUrl() || !itemElement || !itemsElement) return;
			const pageMap = /* @__PURE__ */ new Map();
			getElementsInViewportFromCollection([...itemsElement.children], itemElement).forEach((element) => {
				const page2 = getPageFromElement(element) ?? "1";
				if (pageMap.has(page2)) pageMap.set(page2, pageMap.get(page2) + 1);
				else pageMap.set(page2, 1);
			});
			const mostVisiblePage = Array.from(pageMap.entries()).sort((a, b) => b[1] - a[1])[0]?.[0];
			if (mostVisiblePage !== void 0) queuePageUpdate(mostVisiblePage);
		}, 250),
		cancel: () => enabled = false
	};
};
var useInfiniteScrollPreservation = (options) => {
	const createCallbacks = () => {
		let currentScrollTop;
		let referenceElement = null;
		let referenceElementTop = 0;
		const captureScrollPosition = () => {
			const scrollableContainer = options.getScrollableParent();
			const itemsElement = options.getItemsElement();
			currentScrollTop = scrollableContainer?.scrollTop || window.scrollY;
			const visibleElements = getElementsInViewportFromCollection([...itemsElement.children]);
			if (visibleElements.length > 0) {
				referenceElement = visibleElements[0];
				const containerRect = scrollableContainer?.getBoundingClientRect() || { top: 0 };
				const containerTop = scrollableContainer ? containerRect.top : 0;
				referenceElementTop = referenceElement.getBoundingClientRect().top - containerTop;
			}
		};
		const restoreScrollPosition = () => {
			if (!referenceElement) return;
			let attempts = 0;
			let restored = false;
			const restore = () => {
				attempts++;
				if (restored || attempts > 10) return false;
				const scrollableContainer = options.getScrollableParent();
				const containerRect = scrollableContainer?.getBoundingClientRect() || { top: 0 };
				const containerTop = scrollableContainer ? containerRect.top : 0;
				const adjustment = referenceElement.getBoundingClientRect().top - containerTop - referenceElementTop;
				if (adjustment === 0) {
					window.requestAnimationFrame(restore);
					return;
				}
				if (scrollableContainer) scrollableContainer.scrollTo({ top: currentScrollTop + adjustment });
				else window.scrollTo(0, window.scrollY + adjustment);
				restored = true;
			};
			window.requestAnimationFrame(restore);
		};
		return {
			captureScrollPosition,
			restoreScrollPosition
		};
	};
	return { createCallbacks };
};
function useInfiniteScroll(options) {
	const queryStringManager = useInfiniteScrollQueryString({
		...options,
		getPageName: () => dataManager.getPageName()
	});
	const scrollPreservation = useInfiniteScrollPreservation(options);
	const elementManager = useInfiniteScrollElementManager({
		...options,
		onItemIntersected: queryStringManager.onItemIntersected,
		onPreviousTriggered: () => dataManager.fetchPrevious(),
		onNextTriggered: () => dataManager.fetchNext()
	});
	const dataManager = useInfiniteScrollData({
		...options,
		onBeforeUpdate: elementManager.processManuallyAddedElements,
		onCompletePreviousRequest: (_, details) => {
			options.onCompletePreviousRequest(details);
			if (details.completed) requestAnimationFrame(() => elementManager.processServerLoadedElements(details.page), 2);
		},
		onCompleteNextRequest: (_, details) => {
			options.onCompleteNextRequest(details);
			if (details.completed) requestAnimationFrame(() => elementManager.processServerLoadedElements(details.page), 2);
		},
		onReset: options.onDataReset
	});
	const addScrollPreservationCallbacks = (reloadOptions) => {
		const { captureScrollPosition, restoreScrollPosition } = scrollPreservation.createCallbacks();
		const originalOnBeforeUpdate = reloadOptions.onBeforeUpdate || (() => {});
		const originalOnSuccess = reloadOptions.onSuccess || (() => {});
		reloadOptions.onBeforeUpdate = (page2) => {
			originalOnBeforeUpdate(page2);
			captureScrollPosition();
		};
		reloadOptions.onSuccess = (page2) => {
			originalOnSuccess(page2);
			restoreScrollPosition();
		};
		return reloadOptions;
	};
	const originalFetchNext = dataManager.fetchNext;
	dataManager.fetchNext = (reloadOptions = {}) => {
		reloadOptions = {
			...options.getReloadOptions?.(),
			...reloadOptions
		};
		if (options.inReverseMode()) reloadOptions = addScrollPreservationCallbacks(reloadOptions);
		originalFetchNext(reloadOptions);
	};
	const originalFetchPrevious = dataManager.fetchPrevious;
	dataManager.fetchPrevious = (reloadOptions = {}) => {
		reloadOptions = {
			...options.getReloadOptions?.(),
			...reloadOptions
		};
		if (!options.inReverseMode()) reloadOptions = addScrollPreservationCallbacks(reloadOptions);
		originalFetchPrevious(reloadOptions);
	};
	const removeEventListener = router.on("success", () => requestAnimationFrame(elementManager.refreshTriggers, 2));
	return {
		dataManager,
		elementManager,
		flush: () => {
			removeEventListener();
			dataManager.removeEventListener();
			elementManager.flushAll();
			queryStringManager.cancel();
		}
	};
}
function createLayoutPropsStore() {
	let shared = {};
	let named = {};
	let snapshot = {
		shared,
		named
	};
	const listeners = /* @__PURE__ */ new Set();
	let pendingNotify = false;
	const updateSnapshot = () => {
		snapshot = {
			shared,
			named
		};
	};
	const notify = () => {
		if (pendingNotify) return;
		pendingNotify = true;
		queueMicrotask(() => {
			pendingNotify = false;
			listeners.forEach((fn) => fn());
		});
	};
	return {
		set(props) {
			const merged = {
				...shared,
				...props
			};
			if (isEqual(shared, merged)) return;
			shared = merged;
			updateSnapshot();
			notify();
		},
		setFor(name, props) {
			const current = named[name] || {};
			const merged = {
				...current,
				...props
			};
			if (isEqual(current, merged)) return;
			named = {
				...named,
				[name]: merged
			};
			updateSnapshot();
			notify();
		},
		reset() {
			shared = {};
			named = {};
			updateSnapshot();
			notify();
		},
		subscribe(callback) {
			listeners.add(callback);
			return () => listeners.delete(callback);
		},
		get: () => snapshot
	};
}
function isPlainObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function hasComponentKey(value) {
	return isPlainObject(value) && "component" in value;
}
function hasComponentEntry(value, isComponent) {
	return "component" in value && isComponent(value.component);
}
function isNamedLayouts(value, isComponent) {
	if (!isPlainObject(value) || isComponent(value) || hasComponentEntry(value, isComponent)) return false;
	return Object.values(value).every((v) => isComponent(v) || Array.isArray(v) && isComponent(v[0]) || hasComponentKey(v) && isComponent(v.component));
}
function isPropsObject(value, isComponent) {
	return isPlainObject(value) && !isComponent(value) && !hasComponentEntry(value, isComponent) && !isNamedLayouts(value, isComponent);
}
function isPropsObjectOrCallback(value, isComponent) {
	if (isPropsObject(value, isComponent)) return true;
	if (!isPlainObject(value) || isComponent(value) || hasComponentEntry(value, isComponent)) return false;
	const values = Object.values(value);
	return values.length > 0 && values.every((v) => typeof v === "function");
}
function isTuple(value, isComponent) {
	return Array.isArray(value) && value.length === 2 && isComponent(value[0]) && isPlainObject(value[1]) && !isComponent(value[1]);
}
function extract(item, isComponent) {
	if (Array.isArray(item) && isComponent(item[0])) return {
		component: item[0],
		props: item[1] ?? {}
	};
	if (hasComponentKey(item) && isComponent(item.component)) return {
		component: item.component,
		props: item.props ?? {}
	};
	if (isComponent(item)) return {
		component: item,
		props: {}
	};
	throw new Error(`Invalid layout definition: received ${typeof item}`);
}
function normalizeLayouts(layout, isComponent, isRenderFunction) {
	if (!layout || isRenderFunction && isRenderFunction(layout)) return [];
	if (isNamedLayouts(layout, isComponent)) return Object.entries(layout).map(([name, value]) => ({
		...extract(value, isComponent),
		name
	}));
	if (isTuple(layout, isComponent)) return [{
		component: layout[0],
		props: layout[1] ?? {}
	}];
	if (Array.isArray(layout)) return layout.map((item) => extract(item, isComponent));
	if (hasComponentKey(layout) && isComponent(layout.component)) return [{
		component: layout.component,
		props: layout.props ?? {}
	}];
	if (isComponent(layout)) return [{
		component: layout,
		props: {}
	}];
	return [];
}
function isContentEditableOrPrevented(event) {
	return event.target instanceof HTMLElement && event.target.isContentEditable || event.defaultPrevented;
}
function shouldIntercept(event) {
	const isLink = event.currentTarget.tagName.toLowerCase() === "a";
	const target = isLink ? event.currentTarget.target : "";
	return !(isContentEditableOrPrevented(event) || isLink && event.altKey || isLink && event.ctrlKey || isLink && event.metaKey || isLink && event.shiftKey || isLink && target !== "" && target !== "_self" || isLink && "button" in event && event.button !== 0);
}
function shouldNavigate(event) {
	const isButton = event.currentTarget.tagName.toLowerCase() === "button";
	return !isContentEditableOrPrevented(event) && (event.key === "Enter" || isButton && event.key === " ");
}
var baseComponentSelector = "nprogress";
var usePopover;
var progress2;
var settings = {
	minimum: .08,
	easing: "linear",
	speed: 200,
	trickle: true,
	trickleSpeed: 200,
	showSpinner: true,
	barSelector: ".bar, [role=\"bar\"]",
	spinnerSelector: ".spinner, [role=\"spinner\"]",
	parent: "body",
	color: "#29d",
	includeCSS: true,
	popover: null,
	template: [
		"<div class=\"bar\">",
		"<div class=\"peg\"></div>",
		"</div>",
		"<div class=\"spinner\">",
		"<div class=\"spinner-icon\"></div>",
		"</div>"
	].join("")
};
var status = null;
var hidden = false;
var configure = (options) => {
	Object.assign(settings, options);
	usePopover = settings.popover ?? "popover" in HTMLElement.prototype;
	if (settings.includeCSS) injectCSS(settings.color);
	progress2 = document.createElement("div");
	progress2.id = baseComponentSelector;
	progress2.setAttribute("aria-hidden", "true");
	progress2.innerHTML = settings.template;
	if (usePopover) progress2.popover = "manual";
};
var set7 = (n) => {
	const started = isStarted();
	n = clamp(n, settings.minimum, 1);
	status = n === 1 ? null : n;
	const progress3 = render(!started);
	const bar = progress3.querySelector(settings.barSelector);
	const speed = settings.speed;
	const ease = settings.easing;
	progress3.offsetWidth;
	queue4((next) => {
		const barStyles = {
			transition: `all ${speed}ms ${ease}`,
			transform: `translate3d(${toBarPercentage(n)}%,0,0)`
		};
		for (const key in barStyles) bar.style[key] = barStyles[key];
		if (n !== 1) return setTimeout(next, speed);
		progress3.style.transition = "none";
		progress3.style.opacity = "1";
		progress3.offsetWidth;
		setTimeout(() => {
			progress3.style.transition = `all ${speed}ms linear`;
			progress3.style.opacity = "0";
			setTimeout(() => {
				remove();
				progress3.style.transition = "";
				progress3.style.opacity = "";
				next();
			}, speed);
		}, speed);
	});
};
var isStarted = () => typeof status === "number";
var start = () => {
	if (!status) set7(0);
	const work = function() {
		setTimeout(function() {
			if (!status) return;
			increaseByRandom();
			work();
		}, settings.trickleSpeed);
	};
	if (settings.trickle) work();
};
var done = (force) => {
	if (!force && !status) return;
	increaseByRandom(.3 + .5 * Math.random());
	set7(1);
};
var increaseByRandom = (amount) => {
	const n = status;
	if (n === null) return start();
	if (n > 1) return;
	amount = typeof amount === "number" ? amount : (() => {
		const ranges = {
			.1: [0, .2],
			.04: [.2, .5],
			.02: [.5, .8],
			.005: [.8, .99]
		};
		for (const r in ranges) if (n >= ranges[r][0] && n < ranges[r][1]) return parseFloat(r);
		return 0;
	})();
	return set7(clamp(n + amount, 0, .994));
};
var render = (fromStart) => {
	if (isRendered()) return document.getElementById(baseComponentSelector);
	document.documentElement.classList.add(`${baseComponentSelector}-busy`);
	const bar = progress2.querySelector(settings.barSelector);
	const perc = fromStart ? "-100" : toBarPercentage(status || 0);
	bar.style.transition = "all 0 linear";
	bar.style.transform = `translate3d(${perc}%,0,0)`;
	if (!settings.showSpinner) progress2.querySelector(settings.spinnerSelector)?.remove();
	if (usePopover) {
		document.body.appendChild(progress2);
		if (!hidden) progress2.showPopover();
	} else {
		const parent = getParent();
		if (parent !== document.body) parent.classList.add(`${baseComponentSelector}-custom-parent`);
		parent.appendChild(progress2);
		if (hidden) progress2.style.display = "none";
	}
	return progress2;
};
var getParent = () => {
	return document.querySelector(settings.parent);
};
var remove = () => {
	document.documentElement.classList.remove(`${baseComponentSelector}-busy`);
	if (usePopover && progress2?.isConnected) try {
		progress2.hidePopover();
	} catch {}
	if (!usePopover) getParent().classList.remove(`${baseComponentSelector}-custom-parent`);
	progress2?.remove();
};
var isRendered = () => {
	return document.getElementById(baseComponentSelector) !== null;
};
function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}
var toBarPercentage = (n) => (-1 + n) * 100;
var queue4 = /* @__PURE__ */ (() => {
	const pending = [];
	const next = () => {
		const fn = pending.shift();
		if (fn) fn(next);
	};
	return (fn) => {
		pending.push(fn);
		if (pending.length === 1) next();
	};
})();
var injectCSS = (color) => {
	const element = document.createElement("style");
	const nonce = config$1.get("nonce");
	if (nonce) element.nonce = nonce;
	element.textContent = `
    #${baseComponentSelector} {
      pointer-events: none;
      background: none;
      border: none;
      margin: 0;
      padding: 0;
      overflow: visible;
      inset: unset;
      width: 100%;
      height: 0;
      position: fixed;
      top: 0;
      left: 0;
    }

    #${baseComponentSelector}::backdrop {
      display: none;
    }

    #${baseComponentSelector} .bar {
      background: ${color};

      position: fixed;
      z-index: 1031;
      top: 0;
      left: 0;

      width: 100%;
      height: 2px;
    }

    #${baseComponentSelector} .peg {
      display: block;
      position: absolute;
      right: 0px;
      width: 100px;
      height: 100%;
      box-shadow: 0 0 10px ${color}, 0 0 5px ${color};
      opacity: 1.0;

      transform: rotate(3deg) translate(0px, -4px);
    }

    #${baseComponentSelector} .spinner {
      display: block;
      position: fixed;
      z-index: 1031;
      top: 15px;
      right: 15px;
    }

    #${baseComponentSelector} .spinner-icon {
      width: 18px;
      height: 18px;
      box-sizing: border-box;

      border: solid 2px transparent;
      border-top-color: ${color};
      border-left-color: ${color};
      border-radius: 50%;

      animation: ${baseComponentSelector}-spinner 400ms linear infinite;
    }

    .${baseComponentSelector}-custom-parent {
      overflow: hidden;
      position: relative;
    }

    .${baseComponentSelector}-custom-parent #${baseComponentSelector} .spinner,
    .${baseComponentSelector}-custom-parent #${baseComponentSelector} .bar {
      position: absolute;
    }

    @keyframes ${baseComponentSelector}-spinner {
      0%   { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;
	document.head.appendChild(element);
};
var show = () => {
	hidden = false;
	if (!progress2?.isConnected) return;
	if (usePopover) try {
		progress2.showPopover();
	} catch {}
	else progress2.style.display = "";
};
var hide = () => {
	hidden = true;
	if (!progress2?.isConnected) return;
	if (usePopover) try {
		progress2.hidePopover();
	} catch {}
	else progress2.style.display = "none";
};
var progress_component_default = {
	configure,
	isStarted,
	done,
	set: set7,
	remove,
	start,
	status,
	show,
	hide
};
var Progress = class {
	hideCount = 0;
	start() {
		progress_component_default.start();
	}
	reveal(force = false) {
		this.hideCount = Math.max(0, this.hideCount - 1);
		if (force || this.hideCount === 0) progress_component_default.show();
	}
	hide() {
		this.hideCount++;
		progress_component_default.hide();
	}
	set(status2) {
		progress_component_default.set(Math.max(0, Math.min(1, status2)));
	}
	finish() {
		progress_component_default.done();
	}
	reset() {
		progress_component_default.set(0);
	}
	remove() {
		progress_component_default.done();
		progress_component_default.remove();
	}
	isStarted() {
		return progress_component_default.isStarted();
	}
	getStatus() {
		return progress_component_default.status;
	}
};
var progress = new Progress();
function addEventListeners(delay) {
	document.addEventListener("inertia:start", (e) => handleStartEvent(e, delay));
	document.addEventListener("inertia:progress", handleProgressEvent);
}
function handleStartEvent(event, delay) {
	if (!event.detail.visit.showProgress) progress.hide();
	const timeout = setTimeout(() => progress.start(), delay);
	document.addEventListener("inertia:finish", (e) => finish(e, timeout), { once: true });
}
function handleProgressEvent(event) {
	if (progress.isStarted() && event.detail.progress?.percentage) progress.set(Math.max(progress.getStatus(), event.detail.progress.percentage / 100 * .9));
}
function finish(event, timeout) {
	clearTimeout(timeout);
	if (!progress.isStarted()) return;
	if (event.detail.visit.completed) progress.finish();
	else if (event.detail.visit.interrupted) progress.reset();
	else if (event.detail.visit.cancelled) progress.remove();
}
function setupProgress({ delay = 250, color = "#29d", includeCSS = true, showSpinner = false, popover = null } = {}) {
	addEventListeners(delay);
	progress_component_default.configure({
		showSpinner,
		includeCSS,
		color,
		popover
	});
}
var FormComponentResetSymbol = /* @__PURE__ */ Symbol("FormComponentReset");
function isFormElement(element) {
	return element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement;
}
function resetInputElement(input, defaultValues) {
	const oldValue = input.value;
	const oldChecked = input.checked;
	switch (input.type.toLowerCase()) {
		case "checkbox":
			input.checked = defaultValues.includes(input.value);
			break;
		case "radio":
			input.checked = defaultValues[0] === input.value;
			break;
		case "file":
			input.value = "";
			break;
		case "button":
		case "submit":
		case "reset":
		case "image": break;
		default: input.value = defaultValues[0] !== null && defaultValues[0] !== void 0 ? String(defaultValues[0]) : "";
	}
	return input.value !== oldValue || input.checked !== oldChecked;
}
function resetSelectElement(select, defaultValues) {
	const oldValue = select.value;
	const oldSelectedOptions = Array.from(select.selectedOptions).map((opt) => opt.value);
	if (select.multiple) {
		const defaultStrings = defaultValues.map((value) => String(value));
		Array.from(select.options).forEach((option) => {
			option.selected = defaultStrings.includes(option.value);
		});
	} else select.value = defaultValues[0] !== void 0 ? String(defaultValues[0]) : "";
	const newSelectedOptions = Array.from(select.selectedOptions).map((opt) => opt.value);
	return select.multiple ? JSON.stringify(oldSelectedOptions.sort()) !== JSON.stringify(newSelectedOptions.sort()) : select.value !== oldValue;
}
function resetFormElement(element, defaultValues) {
	if (element.disabled) {
		if (element instanceof HTMLInputElement) {
			const oldValue = element.value;
			const oldChecked = element.checked;
			switch (element.type.toLowerCase()) {
				case "checkbox":
				case "radio":
					element.checked = element.defaultChecked;
					return element.checked !== oldChecked;
				case "file":
					element.value = "";
					return oldValue !== "";
				case "button":
				case "submit":
				case "reset":
				case "image": return false;
				default:
					element.value = element.defaultValue;
					return element.value !== oldValue;
			}
		} else if (element instanceof HTMLSelectElement) {
			const oldSelectedOptions = Array.from(element.selectedOptions).map((opt) => opt.value);
			Array.from(element.options).forEach((option) => {
				option.selected = option.defaultSelected;
			});
			const newSelectedOptions = Array.from(element.selectedOptions).map((opt) => opt.value);
			return JSON.stringify(oldSelectedOptions.sort()) !== JSON.stringify(newSelectedOptions.sort());
		} else if (element instanceof HTMLTextAreaElement) {
			const oldValue = element.value;
			element.value = element.defaultValue;
			return element.value !== oldValue;
		}
		return false;
	}
	if (element instanceof HTMLInputElement) return resetInputElement(element, defaultValues);
	else if (element instanceof HTMLSelectElement) return resetSelectElement(element, defaultValues);
	else if (element instanceof HTMLTextAreaElement) {
		const oldValue = element.value;
		element.value = defaultValues[0] !== void 0 ? String(defaultValues[0]) : "";
		return element.value !== oldValue;
	}
	return false;
}
function resetFieldElements(elements, defaultValues) {
	let hasChanged = false;
	if (elements instanceof RadioNodeList || elements instanceof HTMLCollection) Array.from(elements).forEach((node, index) => {
		if (node instanceof Element && isFormElement(node)) {
			if (node instanceof HTMLInputElement && ["checkbox", "radio"].includes(node.type.toLowerCase())) {
				if (resetFormElement(node, defaultValues)) hasChanged = true;
			} else if (resetFormElement(node, defaultValues[index] !== void 0 ? [defaultValues[index]] : [defaultValues[0] ?? null].filter(Boolean))) hasChanged = true;
		}
	});
	else if (isFormElement(elements)) hasChanged = resetFormElement(elements, defaultValues);
	return hasChanged;
}
function resetFormFields(formElement, defaults, fieldNames) {
	if (!formElement) return;
	const resetEntireForm = !fieldNames || fieldNames.length === 0;
	if (resetEntireForm) {
		const formData = new FormData(formElement);
		const formElementNames = Array.from(formElement.elements).map((el) => isFormElement(el) ? el.name : "").filter(Boolean);
		fieldNames = [.../* @__PURE__ */ new Set([
			...defaults.keys(),
			...formData.keys(),
			...formElementNames
		])];
	}
	let hasChanged = false;
	fieldNames.forEach((fieldName) => {
		const elements = formElement.elements.namedItem(fieldName);
		if (elements) {
			if (resetFieldElements(elements, defaults.getAll(fieldName))) hasChanged = true;
		}
	});
	if (hasChanged && resetEntireForm) formElement.dispatchEvent(new CustomEvent("reset", {
		bubbles: true,
		cancelable: true,
		detail: { [FormComponentResetSymbol]: true }
	}));
}
function buildSSRBody(id, page2, html) {
	return `<script data-page="${id}" type="application/json">${JSON.stringify(page2).replace(/\//g, "\\/").replace(/</g, "\\u003c")}<\/script><div data-server-rendered="true" id="${id}">${html}</div>`;
}
var router = new Router();
/* NProgress, (c) 2013, 2014 Rico Sta. Cruz - http://ricostacruz.com/nprogress
* @license MIT */
//#endregion
//#region node_modules/@inertiajs/vue3/dist/index.js
var store = createLayoutPropsStore();
var state = ref(store.get());
store.subscribe(() => {
	state.value = store.get();
});
function setLayoutProps(nameOrProps, props) {
	if (typeof nameOrProps === "string") store.setFor(nameOrProps, props);
	else store.set(nameOrProps);
}
function resetLayoutProps() {
	store.reset();
	state.value = store.get();
}
var remember_default = { created() {
	if (!this.$options.remember) return;
	if (Array.isArray(this.$options.remember)) this.$options.remember = { data: this.$options.remember };
	if (typeof this.$options.remember === "string") this.$options.remember = { data: [this.$options.remember] };
	if (typeof this.$options.remember.data === "string") this.$options.remember = { data: [this.$options.remember.data] };
	const rememberKey = this.$options.remember.key instanceof Function ? this.$options.remember.key.call(this) : this.$options.remember.key;
	const restored = router.restore(rememberKey);
	const rememberable = this.$options.remember.data.filter((key2) => {
		return !(this[key2] !== null && typeof this[key2] === "object" && this[key2].__rememberable === false);
	});
	const hasCallbacks = (key2) => {
		return this[key2] !== null && typeof this[key2] === "object" && typeof this[key2].__remember === "function" && typeof this[key2].__restore === "function";
	};
	rememberable.forEach((key2) => {
		if (this[key2] !== void 0 && restored !== void 0 && restored[key2] !== void 0) hasCallbacks(key2) ? this[key2].__restore(restored[key2]) : this[key2] = restored[key2];
		this.$watch(key2, () => {
			router.remember(rememberable.reduce((data, key3) => ({
				...data,
				[key3]: cloneDeep$1(hasCallbacks(key3) ? this[key3].__remember() : this[key3])
			}), {}), rememberKey);
		}, {
			immediate: true,
			deep: true
		});
	});
} };
function useFormState(options) {
	const { data: dataOption, rememberKey } = options;
	let { precognitionEndpoint } = options;
	const isDataFunction = typeof dataOption === "function";
	const resolveData = () => isDataFunction ? dataOption() : dataOption;
	const restored = rememberKey ? router.restore(rememberKey) : null;
	let defaults = cloneDeep$1(restored?.data ?? cloneDeep$1(resolveData()));
	let transform = (data) => data;
	let validatorRef = null;
	let withAllErrors = null;
	const withAllErrorsEnabled = () => withAllErrors ?? config.get("form.withAllErrors");
	let recentlySuccessfulTimeoutId;
	let defaultsCalledInOnSuccess = false;
	let rememberExcludeKeys = [];
	const typedForm = reactive({
		...cloneDeep$1(defaults),
		isDirty: false,
		errors: {},
		hasErrors: false,
		processing: false,
		progress: null,
		wasSuccessful: false,
		recentlySuccessful: false,
		withPrecognition(...args) {
			precognitionEndpoint = UseFormUtils.createWayfinderCallback(...args);
			const formWithPrecognition = this;
			const validator = createValidator((client) => {
				const { method, url } = precognitionEndpoint();
				const transformedData = cloneDeep$1(transform(this.data()));
				return client[method](url, transformedData);
			}, cloneDeep$1(defaults));
			validatorRef = validator;
			validator.on("validatingChanged", () => {
				formWithPrecognition.validating = validator.validating();
			}).on("validatedChanged", () => {
				formWithPrecognition.__valid = validator.valid();
			}).on("touchedChanged", () => {
				formWithPrecognition.__touched = validator.touched();
			}).on("errorsChanged", () => {
				const validationErrors = withAllErrorsEnabled() ? validator.errors() : toSimpleValidationErrors(validator.errors());
				this.errors = {};
				this.setError(validationErrors);
				formWithPrecognition.__valid = validator.valid();
			});
			const tap = (value, callback) => {
				callback(value);
				return value;
			};
			Object.assign(formWithPrecognition, {
				__touched: [],
				__valid: [],
				validating: false,
				validator: () => validator,
				withAllErrors: () => tap(formWithPrecognition, () => withAllErrors = true),
				valid: (field) => formWithPrecognition.__valid.includes(field),
				invalid: (field) => field in this.errors,
				setValidationTimeout: (duration) => tap(formWithPrecognition, () => validator.setTimeout(duration)),
				validateFiles: () => tap(formWithPrecognition, () => validator.validateFiles()),
				withoutFileValidation: () => tap(formWithPrecognition, () => validator.withoutFileValidation()),
				touch: (field, ...fields) => {
					if (Array.isArray(field)) validator.touch(field);
					else if (typeof field === "string") validator.touch([field, ...fields]);
					else validator.touch(field);
					return formWithPrecognition;
				},
				touched: (field) => typeof field === "string" ? formWithPrecognition.__touched.includes(field) : formWithPrecognition.__touched.length > 0,
				validate: (field, config3) => {
					if (typeof field === "object" && !("target" in field)) {
						config3 = field;
						field = void 0;
					}
					if (field === void 0) validator.validate(config3);
					else {
						const fieldName = resolveName(field);
						const transformedData = transform(this.data());
						validator.validate(fieldName, get(transformedData, fieldName), config3);
					}
					return formWithPrecognition;
				},
				setErrors: (errors) => tap(formWithPrecognition, () => this.setError(errors)),
				forgetError: (field) => tap(formWithPrecognition, () => this.clearErrors(resolveName(field)))
			});
			return formWithPrecognition;
		},
		data() {
			return Object.keys(defaults).reduce((carry, key2) => {
				return set(carry, key2, get(this, key2));
			}, {});
		},
		transform(callback) {
			transform = callback;
			return this;
		},
		defaults(fieldOrFields, maybeValue) {
			if (isDataFunction) throw new Error("You cannot call `defaults()` when using a function to define your form data.");
			defaultsCalledInOnSuccess = true;
			if (typeof fieldOrFields === "undefined") {
				defaults = cloneDeep$1(this.data());
				this.isDirty = false;
			} else defaults = typeof fieldOrFields === "string" ? set(cloneDeep$1(defaults), fieldOrFields, maybeValue) : Object.assign({}, cloneDeep$1(defaults), fieldOrFields);
			validatorRef?.defaults(defaults);
			return this;
		},
		reset(...fields) {
			const clonedData = cloneDeep$1(isDataFunction ? cloneDeep$1(resolveData()) : defaults);
			if (fields.length === 0) {
				if (isDataFunction) defaults = clonedData;
				Object.assign(this, clonedData);
			} else fields.filter((key2) => has(clonedData, key2)).forEach((key2) => {
				if (isDataFunction) set(defaults, key2, get(clonedData, key2));
				set(this, key2, get(clonedData, key2));
			});
			validatorRef?.reset(...fields);
			return this;
		},
		setError(fieldOrFields, maybeValue) {
			const errors = typeof fieldOrFields === "string" ? { [fieldOrFields]: maybeValue } : fieldOrFields;
			Object.assign(this.errors, errors);
			this.hasErrors = Object.keys(this.errors).length > 0;
			validatorRef?.setErrors(errors);
			return this;
		},
		clearErrors(...fields) {
			this.errors = Object.keys(this.errors).reduce((carry, field) => ({
				...carry,
				...fields.length > 0 && !fields.includes(field) ? { [field]: this.errors[field] } : {}
			}), {});
			this.hasErrors = Object.keys(this.errors).length > 0;
			if (validatorRef) {
				if (fields.length === 0) validatorRef.setErrors({});
				else fields.forEach(validatorRef.forgetError);
			}
			return this;
		},
		resetAndClearErrors(...fields) {
			this.reset(...fields);
			this.clearErrors(...fields);
			return this;
		},
		__rememberable: rememberKey === null,
		__remember() {
			const formData = this.data();
			if (rememberExcludeKeys.length > 0) {
				const filtered = { ...formData };
				rememberExcludeKeys.forEach((k) => delete filtered[k]);
				return {
					data: filtered,
					errors: this.errors
				};
			}
			return {
				data: formData,
				errors: this.errors
			};
		},
		__restore(restored2) {
			Object.assign(this, restored2.data);
			this.setError(restored2.errors);
		}
	});
	if (restored?.errors) typedForm.setError(restored.errors);
	watch(typedForm, () => {
		typedForm.isDirty = !isEqual(typedForm.data(), defaults);
	}, {
		immediate: true,
		deep: true
	});
	watch(typedForm, (newValue) => {
		if (!rememberKey) return;
		const storedData = router.restore(rememberKey);
		const newData = cloneDeep$1(newValue.__remember());
		if (!isEqual(storedData, newData)) router.remember(newData, rememberKey);
	}, {
		immediate: true,
		deep: true
	});
	if (precognitionEndpoint) typedForm.withPrecognition(precognitionEndpoint);
	return {
		form: typedForm,
		setDefaults: (newDefaults) => {
			defaults = newDefaults;
		},
		getTransform: () => transform,
		getPrecognitionEndpoint: () => precognitionEndpoint ?? null,
		markAsSuccessful: () => {
			typedForm.clearErrors();
			typedForm.wasSuccessful = true;
			typedForm.recentlySuccessful = true;
			recentlySuccessfulTimeoutId = setTimeout(() => typedForm.recentlySuccessful = false, config.get("form.recentlySuccessfulDuration"));
		},
		wasDefaultsCalledInOnSuccess: () => defaultsCalledInOnSuccess,
		resetDefaultsCalledInOnSuccess: () => {
			defaultsCalledInOnSuccess = false;
		},
		setRememberExcludeKeys: (keys) => {
			rememberExcludeKeys = keys;
		},
		resetBeforeSubmit: () => {
			typedForm.wasSuccessful = false;
			typedForm.recentlySuccessful = false;
			clearTimeout(recentlySuccessfulTimeoutId);
		},
		finishProcessing: () => {
			typedForm.processing = false;
			typedForm.progress = null;
		},
		withAllErrors: {
			enabled: withAllErrorsEnabled,
			enable: () => {
				withAllErrors = true;
			}
		}
	};
}
var reservedFormKeys = null;
var bootstrapping = false;
function validateFormDataKeys(data) {
	if (bootstrapping) return;
	if (reservedFormKeys === null) {
		bootstrapping = true;
		reservedFormKeys = new Set(Object.keys(useForm({})));
		bootstrapping = false;
	}
	const conflicts = Object.keys(data).filter((key2) => reservedFormKeys.has(key2));
	if (conflicts.length > 0) console.error(`[Inertia] useForm() data contains field(s) that conflict with form properties: ${conflicts.map((k) => `"${k}"`).join(", ")}. These fields will be overwritten by form methods/properties. Please rename these fields.`);
}
function useForm(...args) {
	const { rememberKey, data, precognitionEndpoint } = UseFormUtils.parseUseFormArguments(...args);
	validateFormDataKeys(typeof data === "function" ? cloneDeep$1(data()) : cloneDeep$1(data));
	let cancelToken = null;
	let pendingOptimisticCallback = null;
	const { form: baseForm, setDefaults, getTransform, getPrecognitionEndpoint, markAsSuccessful, wasDefaultsCalledInOnSuccess, resetDefaultsCalledInOnSuccess, setRememberExcludeKeys, resetBeforeSubmit, finishProcessing } = useFormState({
		data,
		rememberKey,
		precognitionEndpoint
	});
	const form = baseForm;
	const createSubmitMethod = (method) => (url, options = {}) => {
		form.submit(method, url, options);
	};
	Object.assign(form, {
		submit(...args2) {
			const { method, url, options } = UseFormUtils.parseSubmitArguments(args2, getPrecognitionEndpoint());
			resetDefaultsCalledInOnSuccess();
			const _options = {
				...options,
				onCancelToken: (token) => {
					cancelToken = token;
					return options.onCancelToken?.(token);
				},
				onBefore: (visit) => {
					resetBeforeSubmit();
					return options.onBefore?.(visit);
				},
				onStart: (visit) => {
					form.processing = true;
					return options.onStart?.(visit);
				},
				onProgress: (event) => {
					form.progress = event ?? null;
					return options.onProgress?.(event);
				},
				onSuccess: async (page2) => {
					markAsSuccessful();
					const onSuccess = options.onSuccess ? await options.onSuccess(page2) : null;
					if (!wasDefaultsCalledInOnSuccess()) {
						setDefaults(cloneDeep$1(form.data()));
						form.isDirty = false;
					}
					return onSuccess;
				},
				onError: (errors) => {
					form.clearErrors().setError(errors);
					return options.onError?.(errors);
				},
				onCancel: () => {
					return options.onCancel?.();
				},
				onFinish: (visit) => {
					finishProcessing();
					cancelToken = null;
					return options.onFinish?.(visit);
				}
			};
			_options.optimistic = _options.optimistic ?? pendingOptimisticCallback ?? void 0;
			pendingOptimisticCallback = null;
			const transformedData = getTransform()(form.data());
			if (method === "delete") router.delete(url, {
				..._options,
				data: transformedData
			});
			else router[method](url, transformedData, _options);
		},
		get: createSubmitMethod("get"),
		post: createSubmitMethod("post"),
		put: createSubmitMethod("put"),
		patch: createSubmitMethod("patch"),
		delete: createSubmitMethod("delete"),
		cancel() {
			if (cancelToken) cancelToken.cancel();
		},
		dontRemember(...keys) {
			setRememberExcludeKeys(keys);
			return form;
		},
		optimistic(callback) {
			pendingOptimisticCallback = callback;
			return form;
		}
	});
	return getPrecognitionEndpoint() ? form : form;
}
function isComponent(value) {
	if (!value) return false;
	if (typeof value === "function") return true;
	if (typeof value === "object") {
		const obj = value;
		return typeof obj.render === "function" || typeof obj.setup === "function" || typeof obj.template === "string" || "__file" in obj || "__name" in obj;
	}
	return false;
}
function isRenderFunction(value) {
	if (typeof value !== "function") return false;
	const fn = value;
	return fn.length === 2 && typeof fn.prototype === "undefined";
}
var component = ref(void 0);
var page = ref();
var pageAccessor = null;
var layout = shallowRef(null);
var key = ref(void 0);
var headManager;
var app_default = defineComponent({
	name: "Inertia",
	props: {
		initialPage: {
			type: Object,
			required: true
		},
		initialComponent: {
			type: Object,
			required: false
		},
		resolveComponent: {
			type: Function,
			required: false
		},
		titleCallback: {
			type: Function,
			required: false,
			default: (title) => title
		},
		onHeadUpdate: {
			type: Function,
			required: false,
			default: () => () => {}
		},
		defaultLayout: {
			type: Function,
			required: false
		},
		serverHead: {
			type: [
				Boolean,
				String,
				Function
			],
			required: false
		}
	},
	setup({ initialPage, initialComponent, resolveComponent, titleCallback, onHeadUpdate, defaultLayout, serverHead }) {
		component.value = initialComponent ? markRaw(initialComponent) : void 0;
		page.value = {
			...initialPage,
			flash: initialPage.flash ?? {}
		};
		key.value = void 0;
		const isServer = typeof window === "undefined";
		headManager = createHeadManager(isServer, (title) => titleCallback ? titleCallback(title, page.value) : title, onHeadUpdate || (() => {}), resolveServerHead(initialPage, serverHead));
		if (!isServer) {
			router.init({
				initialPage,
				resolveComponent,
				swapComponent: async (options) => {
					if (!options.preserveState) resetLayoutProps();
					component.value = markRaw(options.component);
					page.value = options.page;
					key.value = options.preserveState ? key.value : Date.now();
				},
				onFlash: (flash) => {
					page.value = {
						...page.value,
						flash
					};
				}
			});
			const syncServerHead = (event) => {
				headManager.updateServerHead(resolveServerHead(event.detail.page, serverHead));
			};
			router.on("navigate", syncServerHead);
			router.on("clientVisit", syncServerHead);
		}
		return () => {
			if (component.value) {
				component.value.inheritAttrs = !!component.value.inheritAttrs;
				const child = h(component.value, {
					...page.value.props,
					key: key.value
				});
				if (layout.value) {
					component.value.layout = layout.value;
					layout.value = null;
				}
				if (component.value.layout && isRenderFunction(component.value.layout)) return component.value.layout(h, child);
				let effectiveLayout;
				let callbackProps = null;
				const layoutValue = component.value.layout;
				if (typeof layoutValue === "function" && layoutValue.length <= 1 && typeof layoutValue.prototype === "undefined") {
					const result = layoutValue(page.value.props);
					if (isPropsObjectOrCallback(result, isComponent)) {
						effectiveLayout = defaultLayout?.(page.value.component, page.value);
						callbackProps = result;
					} else effectiveLayout = result;
				} else if (isPropsObject(layoutValue, isComponent)) {
					effectiveLayout = defaultLayout?.(page.value.component, page.value);
					callbackProps = layoutValue;
				} else effectiveLayout = layoutValue ?? defaultLayout?.(page.value.component, page.value);
				if (effectiveLayout) {
					let layouts = normalizeLayouts(effectiveLayout, isComponent, component.value.layout && !callbackProps ? isRenderFunction : void 0);
					if (callbackProps) layouts = layouts.map((l) => ({
						...l,
						props: {
							...l.props,
							...callbackProps
						}
					}));
					if (layouts.length > 0) {
						const dynamicProps = isServer ? {
							shared: {},
							named: {}
						} : state.value;
						return layouts.reduceRight((childNode, layout2) => {
							const layoutComponent = layout2.component;
							layoutComponent.inheritAttrs = !!layoutComponent.inheritAttrs;
							return h(layoutComponent, {
								...page.value.props,
								...layout2.props,
								...dynamicProps.shared,
								...layout2.name ? dynamicProps.named[layout2.name] || {} : {}
							}, () => childNode);
						}, child);
					}
				}
				return child;
			}
		};
	}
});
var plugin = { install(app) {
	router.form = useForm;
	Object.defineProperty(app.config.globalProperties, "$inertia", { get: () => router });
	Object.defineProperty(app.config.globalProperties, "$page", { get: () => page.value });
	Object.defineProperty(app.config.globalProperties, "$headManager", { get: () => headManager });
	app.mixin(remember_default);
} };
function usePage() {
	if (!pageAccessor) pageAccessor = reactive({
		props: computed(() => page.value?.props),
		url: computed(() => page.value?.url),
		component: computed(() => page.value?.component),
		version: computed(() => page.value?.version),
		clearHistory: computed(() => page.value?.clearHistory),
		deferredProps: computed(() => page.value?.deferredProps),
		rescuedProps: computed(() => page.value?.rescuedProps),
		mergeProps: computed(() => page.value?.mergeProps),
		prependProps: computed(() => page.value?.prependProps),
		deepMergeProps: computed(() => page.value?.deepMergeProps),
		matchPropsOn: computed(() => page.value?.matchPropsOn),
		rememberedState: computed(() => page.value?.rememberedState),
		encryptHistory: computed(() => page.value?.encryptHistory),
		scrollProps: computed(() => page.value?.scrollProps),
		flash: computed(() => page.value?.flash)
	});
	return pageAccessor;
}
async function createInertiaApp({ id = "app", resolve, setup, title, progress: progress2 = {}, page: page2, render, defaults = {}, nonce, http: http3, layout: layout2, serverHead, withApp, dev = !!import.meta.env?.DEV } = {}) {
	config.replace(defaults);
	if (nonce) config.set("nonce", nonce);
	if (http3) http.setClient(http3);
	if (dev) exposeInterceptors();
	const isServer = typeof window === "undefined";
	const resolveComponent = (name, page3) => Promise.resolve(resolve(name, page3)).then((module) => module.default || module);
	if (isServer && !page2 && !render) return async (page3, renderToString) => {
		let head2 = [];
		const props = {
			initialPage: page3,
			initialComponent: await resolveComponent(page3.component, page3),
			resolveComponent,
			titleCallback: title,
			onHeadUpdate: (elements) => head2 = elements,
			defaultLayout: layout2,
			serverHead
		};
		let vueApp2;
		if (setup) vueApp2 = setup({
			el: null,
			App: app_default,
			props,
			plugin
		});
		else {
			vueApp2 = createSSRApp({ render: () => h(app_default, props) });
			vueApp2.use(plugin);
			if (withApp) withApp(vueApp2, {
				ssr: true,
				page: page3
			});
		}
		const body = buildSSRBody(id, page3, await renderToString(vueApp2));
		return {
			head: head2,
			body
		};
	};
	const initialPage = page2 || getInitialPageFromDOM(id);
	let head = [];
	const vueApp = await Promise.all([resolveComponent(initialPage.component, initialPage), router.decryptHistory().catch(() => {})]).then(([initialComponent]) => {
		const props = {
			initialPage,
			initialComponent,
			resolveComponent,
			titleCallback: title,
			onHeadUpdate: isServer ? (elements) => head = elements : void 0,
			defaultLayout: layout2,
			serverHead
		};
		if (isServer) return setup({
			el: null,
			App: app_default,
			props,
			plugin
		});
		const el = document.getElementById(id);
		if (setup) return setup({
			el,
			App: app_default,
			props,
			plugin
		});
		if (el.hasAttribute("data-server-rendered")) {
			const app = createSSRApp({ render: () => h(app_default, props) });
			app.use(plugin);
			if (withApp) withApp(app, {
				ssr: false,
				page: initialPage
			});
			app.mount(el);
		} else {
			const app = createApp({ render: () => h(app_default, props) });
			app.use(plugin);
			if (withApp) withApp(app, {
				ssr: false,
				page: initialPage
			});
			app.mount(el);
		}
	});
	if (!isServer && progress2) setupProgress(progress2);
	if (isServer && render && vueApp) {
		const body = buildSSRBody(id, initialPage, await render(vueApp));
		return {
			head,
			body
		};
	}
}
var deferred_default = defineComponent({
	name: "Deferred",
	props: { data: {
		type: [String, Array],
		required: true
	} },
	slots: Object,
	setup(props, { slots }) {
		const reloading = ref(false);
		const activeReloads = /* @__PURE__ */ new Set();
		const page2 = usePage();
		const keys = computed(() => Array.isArray(props.data) ? props.data : [props.data]);
		const rescuedKeys = computed(() => new Set(page2.rescuedProps));
		let removeStartListener = null;
		let removeFinishListener = null;
		onMounted(() => {
			removeStartListener = router.on("start", (e) => {
				const visit = e.detail.visit;
				if (visit.preserveState === true && isSameUrlWithoutQueryOrHash(visit.url, window.location) && partialReloadRequestsSomeProps(visit, keys.value)) {
					activeReloads.add(visit);
					reloading.value = true;
				}
			});
			removeFinishListener = router.on("finish", (e) => {
				const visit = e.detail.visit;
				if (activeReloads.has(visit)) {
					activeReloads.delete(visit);
					reloading.value = activeReloads.size > 0;
				}
			});
		});
		onUnmounted(() => {
			removeStartListener?.();
			removeFinishListener?.();
			activeReloads.clear();
		});
		return () => {
			if (!slots.fallback) throw new Error("`<Deferred>` requires a `<template #fallback>` slot");
			const propsAreDefined = keys.value.every((key2) => get(page2.props, key2) !== void 0);
			const hasRescuedProps = keys.value.some((key2) => rescuedKeys.value.has(key2));
			const slotProps = { reloading: reloading.value };
			if (propsAreDefined && !hasRescuedProps) return h(Fragment, { key: "default" }, slots.default?.(slotProps) ?? []);
			if (hasRescuedProps && slots.rescue) return h(Fragment, { key: "rescue" }, slots.rescue(slotProps));
			return h(Fragment, { key: "fallback" }, slots.fallback({}));
		};
	}
});
var noop = () => void 0;
var FormContextKey = /* @__PURE__ */ Symbol("InertiaFormContext");
var Form = defineComponent({
	name: "Form",
	slots: Object,
	props: {
		action: {
			type: [String, Object],
			default: ""
		},
		method: {
			type: String,
			default: "get"
		},
		headers: {
			type: Object,
			default: () => ({})
		},
		queryStringArrayFormat: {
			type: String,
			default: "brackets"
		},
		errorBag: {
			type: [String, null],
			default: null
		},
		showProgress: {
			type: Boolean,
			default: true
		},
		transform: {
			type: Function,
			default: (data) => data
		},
		options: {
			type: Object,
			default: () => ({})
		},
		resetOnError: {
			type: [Boolean, Array],
			default: false
		},
		resetOnSuccess: {
			type: [Boolean, Array],
			default: false
		},
		setDefaultsOnSuccess: {
			type: Boolean,
			default: false
		},
		onCancelToken: {
			type: Function,
			default: noop
		},
		onBefore: {
			type: Function,
			default: noop
		},
		onStart: {
			type: Function,
			default: noop
		},
		onProgress: {
			type: Function,
			default: noop
		},
		onFinish: {
			type: Function,
			default: noop
		},
		onCancel: {
			type: Function,
			default: noop
		},
		onSuccess: {
			type: Function,
			default: noop
		},
		onError: {
			type: Function,
			default: noop
		},
		onSubmitComplete: {
			type: Function,
			default: noop
		},
		disableWhileProcessing: {
			type: Boolean,
			default: false
		},
		cancelOnUnmount: {
			type: Boolean,
			default: false
		},
		invalidateCacheTags: {
			type: [String, Array],
			default: () => []
		},
		validateFiles: {
			type: Boolean,
			default: false
		},
		validationTimeout: {
			type: Number,
			default: 1500
		},
		optimistic: {
			type: Function,
			default: void 0
		},
		withAllErrors: {
			type: Boolean,
			default: null
		},
		component: {
			type: String,
			default: null
		},
		instant: {
			type: Boolean,
			default: false
		}
	},
	setup(props, { slots, attrs, expose }) {
		const getTransformedData = () => {
			const [_url, data] = getUrlAndData();
			return props.transform(data);
		};
		const form = useForm({}).withPrecognition(() => method.value, () => getUrlAndData()[0]).transform(getTransformedData).setValidationTimeout(props.validationTimeout);
		if (props.validateFiles) form.validateFiles();
		if (props.withAllErrors ?? config$1.get("form.withAllErrors")) form.withAllErrors();
		const formElement = ref();
		const method = computed(() => isUrlMethodPair(props.action) ? props.action.method : props.method.toLowerCase());
		const resolvedComponent = computed(() => {
			if (props.component) return props.component;
			if (props.instant && isUrlMethodPair(props.action)) return resolveUrlMethodPairComponent(props.action);
			return null;
		});
		const isDirty = ref(false);
		const defaultData = ref(new FormData());
		const onFormUpdate = (event) => {
			if (event.type === "reset" && event.detail?.[FormComponentResetSymbol]) event.preventDefault();
			isDirty.value = event.type === "reset" ? false : !isEqual(getData(), formDataToObject(defaultData.value));
		};
		const formEvents = [
			"input",
			"change",
			"reset"
		];
		onMounted(() => {
			defaultData.value = getFormData();
			form.defaults(getData());
			formEvents.forEach((e) => formElement.value.addEventListener(e, onFormUpdate));
		});
		watch(() => props.validateFiles, (value) => value ? form.validateFiles() : form.withoutFileValidation());
		watch(() => props.validationTimeout, (value) => form.setValidationTimeout(value));
		onBeforeUnmount(() => {
			formEvents.forEach((e) => formElement.value?.removeEventListener(e, onFormUpdate));
			if (props.cancelOnUnmount) form.cancel();
		});
		const getFormData = (submitter) => new FormData(formElement.value, submitter);
		const getData = (submitter) => formDataToObject(getFormData(submitter));
		const getUrlAndData = (submitter) => {
			return mergeDataIntoQueryString(method.value, isUrlMethodPair(props.action) ? props.action.url : props.action, getData(submitter), props.queryStringArrayFormat);
		};
		const submit = (submitter) => {
			const [url, data] = getUrlAndData(submitter);
			if (submitter?.getAttribute("formtarget") === "_blank" && method.value === "get") {
				window.open(url, "_blank");
				return;
			}
			const maybeReset = (resetOption) => {
				if (!resetOption) return;
				if (resetOption === true) reset();
				else if (resetOption.length > 0) reset(...resetOption);
			};
			const submitOptions = {
				headers: props.headers,
				queryStringArrayFormat: props.queryStringArrayFormat,
				errorBag: props.errorBag,
				showProgress: props.showProgress,
				invalidateCacheTags: props.invalidateCacheTags,
				component: resolvedComponent.value,
				optimistic: props.optimistic ? (pageProps) => props.optimistic(pageProps, data) : void 0,
				onCancelToken: props.onCancelToken,
				onBefore: props.onBefore,
				onStart: props.onStart,
				onProgress: props.onProgress,
				onFinish: props.onFinish,
				onCancel: props.onCancel,
				onSuccess: async (...args) => {
					const result = await props.onSuccess?.(...args);
					props.onSubmitComplete?.(exposed);
					maybeReset(props.resetOnSuccess);
					if (props.setDefaultsOnSuccess === true) defaults();
					return result;
				},
				onError: (...args) => {
					props.onError?.(...args);
					maybeReset(props.resetOnError);
				},
				...props.options
			};
			form.transform(() => props.transform(data)).submit(method.value, url, submitOptions);
			form.transform(getTransformedData);
		};
		const reset = (...fields) => {
			resetFormFields(formElement.value, defaultData.value, fields);
			form.reset(...fields);
		};
		const clearErrors = (...fields) => {
			form.clearErrors(...fields);
		};
		const resetAndClearErrors = (...fields) => {
			clearErrors(...fields);
			reset(...fields);
		};
		const defaults = () => {
			defaultData.value = getFormData();
			isDirty.value = false;
		};
		const exposed = {
			get errors() {
				return form.errors;
			},
			get hasErrors() {
				return form.hasErrors;
			},
			get processing() {
				return form.processing;
			},
			get progress() {
				return form.progress;
			},
			get wasSuccessful() {
				return form.wasSuccessful;
			},
			get recentlySuccessful() {
				return form.recentlySuccessful;
			},
			get validating() {
				return form.validating;
			},
			clearErrors,
			resetAndClearErrors,
			setError: (fieldOrFields, maybeValue) => form.setError(typeof fieldOrFields === "string" ? { [fieldOrFields]: maybeValue } : fieldOrFields),
			get isDirty() {
				return isDirty.value;
			},
			reset,
			submit,
			cancel: () => form.cancel(),
			defaults,
			getData,
			getFormData,
			touch: form.touch,
			valid: form.valid,
			invalid: form.invalid,
			touched: form.touched,
			validate: (field, config3) => form.validate(...UseFormUtils.mergeHeadersForValidation(field, config3, props.headers)),
			validator: () => form.validator()
		};
		expose(exposed);
		provide(FormContextKey, exposed);
		return () => {
			return h("form", {
				...attrs,
				ref: formElement,
				action: isUrlMethodPair(props.action) ? props.action.url : props.action,
				method: method.value,
				onSubmit: (event) => {
					event.preventDefault();
					submit(event.submitter);
				},
				inert: props.disableWhileProcessing && form.processing
			}, slots.default ? slots.default(exposed) : []);
		};
	}
});
function useFormContext() {
	return inject(FormContextKey);
}
function createForm() {
	return Form;
}
var form_default = Form;
function isUnaryTag(node) {
	return typeof node.type === "string" && [
		"area",
		"base",
		"br",
		"col",
		"embed",
		"hr",
		"img",
		"input",
		"keygen",
		"link",
		"meta",
		"param",
		"source",
		"track",
		"wbr"
	].indexOf(node.type) > -1;
}
function renderTagStart(node) {
	node.props = node.props || {};
	node.props["data-inertia"] = node.props["head-key"] !== void 0 ? node.props["head-key"] : "";
	const attrs = Object.keys(node.props).reduce((carry, name) => {
		const value = String(node.props[name]);
		if (["key", "head-key"].includes(name)) return carry;
		else if (value === "") return carry + ` ${name}`;
		else return carry + ` ${name}="${escape(value)}"`;
	}, "");
	return `<${String(node.type)}${attrs}>`;
}
function renderTagChildren(node) {
	const { children } = node;
	if (typeof children === "string") return children;
	if (Array.isArray(children)) return children.reduce((html, child) => {
		return html + renderTag(child);
	}, "");
	return "";
}
function isFunctionNode(node) {
	return typeof node.type === "function";
}
function isComponentNode(node) {
	return typeof node.type === "object";
}
function isCommentNode(node) {
	return /(comment|cmt)/i.test(node.type.toString());
}
function isFragmentNode(node) {
	return /(fragment|fgt|symbol\(\))/i.test(node.type.toString());
}
function isTextNode(node) {
	return /(text|txt)/i.test(node.type.toString());
}
function renderTag(node) {
	if (isTextNode(node)) return String(node.children);
	else if (isFragmentNode(node)) return "";
	else if (isCommentNode(node)) return "";
	let html = renderTagStart(node);
	if (node.children) html += renderTagChildren(node);
	if (!isUnaryTag(node)) html += `</${String(node.type)}>`;
	return html;
}
function addTitleElement(elements, title) {
	if (title && !elements.find((tag) => tag.startsWith("<title"))) elements.push(`<title data-inertia="">${escape(title)}</title>`);
	return elements;
}
function renderNodes(nodes, title) {
	return addTitleElement(nodes.flatMap((node) => resolveNode(node)).map((node) => renderTag(node)).filter((node) => node), title);
}
function resolveNode(node) {
	if (isFunctionNode(node)) return resolveNode(node.type());
	else if (isComponentNode(node)) {
		console.warn(`Using components in the <Head> component is not supported.`);
		return [];
	} else if (isTextNode(node) && node.children) return node;
	else if (isFragmentNode(node) && node.children) return node.children.flatMap((child) => resolveNode(child));
	else if (isCommentNode(node)) return [];
	else return node;
}
var head_default = defineComponent({
	props: { title: {
		type: String,
		required: false
	} },
	setup(props, { slots }) {
		const provider = headManager.createProvider();
		onBeforeUnmount(() => {
			provider.disconnect();
		});
		return () => {
			provider.update(renderNodes(slots.default ? slots.default() : [], props.title));
		};
	}
});
var resolveHTMLElement = (value, fallback) => {
	if (!value) return fallback;
	if (typeof value === "string") return document.querySelector(value);
	if (typeof value === "function") return value() || null;
	return fallback;
};
var infiniteScroll_default = defineComponent({
	name: "InfiniteScroll",
	slots: Object,
	props: {
		data: {
			type: String,
			required: true
		},
		buffer: {
			type: Number,
			default: 0
		},
		onlyNext: {
			type: Boolean,
			default: false
		},
		onlyPrevious: {
			type: Boolean,
			default: false
		},
		as: {
			type: String,
			default: "div"
		},
		manual: {
			type: Boolean,
			default: false
		},
		manualAfter: {
			type: Number,
			default: 0
		},
		preserveUrl: {
			type: Boolean,
			default: false
		},
		reverse: {
			type: Boolean,
			default: false
		},
		autoScroll: {
			type: Boolean,
			default: void 0
		},
		itemsElement: {
			type: [
				String,
				Function,
				Object
			],
			default: null
		},
		startElement: {
			type: [
				String,
				Function,
				Object
			],
			default: null
		},
		endElement: {
			type: [
				String,
				Function,
				Object
			],
			default: null
		},
		params: {
			type: Object,
			default: () => ({})
		}
	},
	inheritAttrs: false,
	setup(props, { slots, attrs, expose }) {
		const itemsElementRef = ref(null);
		const startElementRef = ref(null);
		const endElementRef = ref(null);
		const itemsElement = computed(() => resolveHTMLElement(props.itemsElement, itemsElementRef.value));
		const scrollableParent = computed(() => getScrollableParent(itemsElement.value));
		const startElement = computed(() => resolveHTMLElement(props.startElement, startElementRef.value));
		const endElement = computed(() => resolveHTMLElement(props.endElement, endElementRef.value));
		const loadingPrevious = ref(false);
		const loadingNext = ref(false);
		const requestCount = ref(0);
		const hasPreviousPage = ref(false);
		const hasNextPage = ref(false);
		const syncStateFromDataManager = () => {
			requestCount.value = dataManager.getRequestCount();
			hasPreviousPage.value = dataManager.hasPrevious();
			hasNextPage.value = dataManager.hasNext();
		};
		const { dataManager, elementManager, flush: flushInfiniteScroll } = useInfiniteScroll({
			getPropName: () => props.data,
			inReverseMode: () => props.reverse,
			shouldFetchNext: () => !props.onlyPrevious,
			shouldFetchPrevious: () => !props.onlyNext,
			shouldPreserveUrl: () => props.preserveUrl,
			getReloadOptions: () => props.params,
			getTriggerMargin: () => props.buffer,
			getStartElement: () => startElement.value,
			getEndElement: () => endElement.value,
			getItemsElement: () => itemsElement.value,
			getScrollableParent: () => scrollableParent.value,
			onBeforePreviousRequest: () => loadingPrevious.value = true,
			onBeforeNextRequest: () => loadingNext.value = true,
			onCompletePreviousRequest: ({ completed }) => {
				loadingPrevious.value = false;
				if (completed) syncStateFromDataManager();
			},
			onCompleteNextRequest: ({ completed }) => {
				loadingNext.value = false;
				if (completed) syncStateFromDataManager();
			},
			onDataReset: syncStateFromDataManager
		});
		syncStateFromDataManager();
		if (typeof window === "undefined") {
			const scrollProp = usePage().scrollProps?.[props.data];
			if (scrollProp) {
				hasPreviousPage.value = !!scrollProp.previousPage;
				hasNextPage.value = !!scrollProp.nextPage;
			}
		}
		const autoLoad = computed(() => !manualMode.value);
		const manualMode = computed(() => props.manual || props.manualAfter > 0 && requestCount.value >= props.manualAfter);
		const scrollToBottom = () => {
			if (scrollableParent.value) scrollableParent.value.scrollTo({
				top: scrollableParent.value.scrollHeight,
				behavior: "instant"
			});
			else window.scrollTo({
				top: document.body.scrollHeight,
				behavior: "instant"
			});
		};
		onMounted(() => {
			elementManager.setupObservers();
			elementManager.processServerLoadedElements(dataManager.getLastLoadedPage());
			if (props.autoScroll !== void 0 ? props.autoScroll : props.reverse) scrollToBottom();
			if (autoLoad.value) elementManager.enableTriggers();
		});
		onUnmounted(flushInfiniteScroll);
		watch(() => [
			autoLoad.value,
			props.onlyNext,
			props.onlyPrevious
		], ([enabled]) => {
			enabled ? elementManager.enableTriggers() : elementManager.disableTriggers();
		});
		expose({
			fetchNext: dataManager.fetchNext,
			fetchPrevious: dataManager.fetchPrevious,
			hasPrevious: dataManager.hasPrevious,
			hasNext: dataManager.hasNext
		});
		return () => {
			const renderElements = [];
			const sharedExposed = {
				loadingPrevious: loadingPrevious.value,
				loadingNext: loadingNext.value,
				hasPrevious: hasPreviousPage.value,
				hasNext: hasNextPage.value
			};
			if (!props.startElement) {
				const headerAutoMode = autoLoad.value && !props.onlyNext;
				const exposedPrevious = {
					loading: loadingPrevious.value,
					fetch: dataManager.fetchPrevious,
					autoMode: headerAutoMode,
					manualMode: !headerAutoMode,
					hasMore: hasPreviousPage.value,
					...sharedExposed
				};
				renderElements.push(h("div", { ref: startElementRef }, slots.previous ? slots.previous(exposedPrevious) : loadingPrevious.value ? slots.loading?.(exposedPrevious) : void 0));
			}
			renderElements.push(h(props.as, {
				...attrs,
				ref: itemsElementRef
			}, slots.default?.({
				loading: loadingPrevious.value || loadingNext.value,
				loadingPrevious: loadingPrevious.value,
				loadingNext: loadingNext.value
			})));
			if (!props.endElement) {
				const footerAutoMode = autoLoad.value && !props.onlyPrevious;
				const exposedNext = {
					loading: loadingNext.value,
					fetch: dataManager.fetchNext,
					autoMode: footerAutoMode,
					manualMode: !footerAutoMode,
					hasMore: hasNextPage.value,
					...sharedExposed
				};
				renderElements.push(h("div", { ref: endElementRef }, slots.next ? slots.next(exposedNext) : loadingNext.value ? slots.loading?.(exposedNext) : void 0));
			}
			return h(Fragment, {}, props.reverse ? [...renderElements].reverse() : renderElements);
		};
	}
});
var noop2 = () => {};
var link_default = defineComponent({
	name: "Link",
	props: {
		as: {
			type: [String, Object],
			default: "a"
		},
		data: {
			type: Object,
			default: () => ({})
		},
		href: {
			type: [String, Object],
			default: ""
		},
		method: {
			type: String,
			default: "get"
		},
		replace: {
			type: Boolean,
			default: false
		},
		preserveScroll: {
			type: [
				Boolean,
				String,
				Function
			],
			default: false
		},
		preserveState: {
			type: [
				Boolean,
				String,
				Function
			],
			default: null
		},
		preserveUrl: {
			type: Boolean,
			default: false
		},
		only: {
			type: Array,
			default: () => []
		},
		except: {
			type: Array,
			default: () => []
		},
		headers: {
			type: Object,
			default: () => ({})
		},
		queryStringArrayFormat: {
			type: String,
			default: "brackets"
		},
		async: {
			type: Boolean,
			default: false
		},
		prefetch: {
			type: [
				Boolean,
				String,
				Array
			],
			default: false
		},
		cacheFor: {
			type: [
				Number,
				String,
				Array
			],
			default: 0
		},
		onStart: {
			type: Function,
			default: noop2
		},
		onProgress: {
			type: Function,
			default: noop2
		},
		onFinish: {
			type: Function,
			default: noop2
		},
		onBefore: {
			type: Function,
			default: noop2
		},
		onCancel: {
			type: Function,
			default: noop2
		},
		onSuccess: {
			type: Function,
			default: noop2
		},
		onError: {
			type: Function,
			default: noop2
		},
		onCancelToken: {
			type: Function,
			default: noop2
		},
		onPrefetching: {
			type: Function,
			default: noop2
		},
		onPrefetched: {
			type: Function,
			default: noop2
		},
		cacheTags: {
			type: [String, Array],
			default: () => []
		},
		viewTransition: {
			type: [Boolean, Object],
			default: false
		},
		component: {
			type: String,
			default: null
		},
		instant: {
			type: Boolean,
			default: false
		},
		pageProps: {
			type: [Object, Function],
			default: null
		}
	},
	setup(props, { slots, attrs }) {
		const inFlightCount = ref(0);
		const hoverTimeout = ref();
		const prefetchModes = computed(() => {
			if (props.prefetch === true) return ["hover"];
			if (props.prefetch === false) return [];
			if (Array.isArray(props.prefetch)) return props.prefetch;
			return [props.prefetch];
		});
		const cacheForValue = computed(() => {
			if (props.cacheFor !== 0) return props.cacheFor;
			if (prefetchModes.value.length === 1 && prefetchModes.value[0] === "click") return 0;
			return config.get("prefetch.cacheFor");
		});
		onMounted(() => {
			if (prefetchModes.value.includes("mount")) prefetch();
		});
		onUnmounted(() => {
			clearTimeout(hoverTimeout.value);
		});
		const method = computed(() => isUrlMethodPair(props.href) ? props.href.method : (props.method ?? "get").toLowerCase());
		const as = computed(() => {
			if (typeof props.as !== "string" || props.as.toLowerCase() !== "a") return props.as;
			return method.value !== "get" ? "button" : props.as.toLowerCase();
		});
		const mergeDataArray = computed(() => mergeDataIntoQueryString(method.value, isUrlMethodPair(props.href) ? props.href.url : props.href, props.data || {}, props.queryStringArrayFormat));
		const href = computed(() => mergeDataArray.value[0]);
		const data = computed(() => mergeDataArray.value[1]);
		const resolvedComponent = computed(() => {
			if (props.component) return props.component;
			if (props.instant && isUrlMethodPair(props.href)) return resolveUrlMethodPairComponent(props.href);
			return null;
		});
		const elProps = computed(() => {
			if (as.value === "button") return { type: "button" };
			if (as.value === "a" || typeof as.value !== "string") return { href: href.value };
			return {};
		});
		const baseParams = computed(() => ({
			data: data.value,
			method: method.value,
			replace: props.replace,
			preserveScroll: props.preserveScroll,
			preserveState: props.preserveState ?? method.value !== "get",
			preserveUrl: props.preserveUrl,
			only: props.only,
			except: props.except,
			headers: props.headers,
			async: props.async,
			component: resolvedComponent.value,
			pageProps: props.pageProps
		}));
		const visitParams = computed(() => ({
			...baseParams.value,
			viewTransition: props.viewTransition,
			onCancelToken: props.onCancelToken,
			onBefore: props.onBefore,
			onStart: (visit) => {
				inFlightCount.value++;
				props.onStart?.(visit);
			},
			onProgress: props.onProgress,
			onFinish: (visit) => {
				inFlightCount.value--;
				props.onFinish?.(visit);
			},
			onCancel: props.onCancel,
			onSuccess: props.onSuccess,
			onError: props.onError
		}));
		const prefetch = () => {
			router.prefetch(href.value, {
				...baseParams.value,
				onPrefetching: props.onPrefetching,
				onPrefetched: props.onPrefetched
			}, {
				cacheFor: cacheForValue.value,
				cacheTags: props.cacheTags
			});
		};
		const regularEvents = { onClick: (event) => {
			if (shouldIntercept(event)) {
				event.preventDefault();
				router.visit(href.value, visitParams.value);
			}
		} };
		const prefetchHoverEvents = {
			onMouseenter: () => {
				hoverTimeout.value = setTimeout(() => {
					prefetch();
				}, config.get("prefetch.hoverDelay"));
			},
			onMouseleave: () => {
				clearTimeout(hoverTimeout.value);
			},
			onClick: (event) => {
				clearTimeout(hoverTimeout.value);
				regularEvents.onClick(event);
			}
		};
		const prefetchClickEvents = {
			onMousedown: (event) => {
				if (shouldIntercept(event)) {
					event.preventDefault();
					prefetch();
				}
			},
			onKeydown: (event) => {
				if (shouldNavigate(event)) {
					event.preventDefault();
					prefetch();
				}
			},
			onMouseup: (event) => {
				if (shouldIntercept(event)) {
					event.preventDefault();
					router.visit(href.value, visitParams.value);
				}
			},
			onKeyup: (event) => {
				if (shouldNavigate(event)) {
					event.preventDefault();
					router.visit(href.value, visitParams.value);
				}
			},
			onClick: (event) => {
				if (shouldIntercept(event)) event.preventDefault();
			}
		};
		return () => {
			return h(as.value, {
				...attrs,
				...elProps.value,
				"data-loading": inFlightCount.value > 0 ? "" : void 0,
				...(() => {
					if (prefetchModes.value.includes("hover")) return prefetchHoverEvents;
					if (prefetchModes.value.includes("click")) return prefetchClickEvents;
					return regularEvents;
				})()
			}, slots);
		};
	}
});
function useHttp(...args) {
	const { rememberKey, data, precognitionEndpoint } = UseFormUtils.parseUseFormArguments(...args);
	let abortController = null;
	let pendingOptimisticCallback = null;
	const { form: baseForm, setDefaults, getTransform, getPrecognitionEndpoint, markAsSuccessful, wasDefaultsCalledInOnSuccess, resetDefaultsCalledInOnSuccess, setRememberExcludeKeys, resetBeforeSubmit, finishProcessing, withAllErrors } = useFormState({
		data,
		rememberKey,
		precognitionEndpoint
	});
	const form = baseForm;
	form.response = null;
	const submit = async (method, url, options) => {
		if (options.onBefore?.() === false) return Promise.reject(/* @__PURE__ */ new Error("Request cancelled by onBefore"));
		resetDefaultsCalledInOnSuccess();
		resetBeforeSubmit();
		abortController = new AbortController();
		options.onCancelToken?.({ cancel: () => abortController?.abort() });
		options.optimistic = options.optimistic ?? pendingOptimisticCallback ?? void 0;
		pendingOptimisticCallback = null;
		let snapshot;
		if (options.optimistic) {
			snapshot = cloneDeep$1(form.data());
			const optimisticData = options.optimistic(cloneDeep$1(snapshot));
			if (optimisticData) Object.keys(optimisticData).forEach((key2) => {
				form[key2] = optimisticData[key2];
			});
		}
		form.processing = true;
		options.onStart?.();
		const transformedData = getTransform()(form.data());
		const useFormData = hasFiles(transformedData);
		let requestUrl = url;
		let requestData;
		let contentType;
		if (method === "get") {
			const [urlWithParams] = mergeDataIntoQueryString(method, url, transformedData);
			requestUrl = urlWithParams;
		} else if (useFormData) requestData = objectToFormData(transformedData);
		else {
			requestData = JSON.stringify(transformedData);
			contentType = "application/json";
		}
		try {
			const response = await http.getClient().request({
				method,
				url: requestUrl,
				data: requestData,
				headers: {
					Accept: "application/json",
					...contentType ? { "Content-Type": contentType } : {},
					...options.headers
				},
				signal: abortController.signal,
				onUploadProgress: (event) => {
					form.progress = event;
					options.onProgress?.(event);
				}
			});
			const responseData = response.data ? JSON.parse(response.data) : null;
			if (response.status >= 200 && response.status < 300) {
				markAsSuccessful();
				form.response = responseData;
				options.onSuccess?.(responseData, response);
				if (!wasDefaultsCalledInOnSuccess()) setDefaults(cloneDeep$1(form.data()));
				form.isDirty = false;
				return responseData;
			}
			throw new HttpResponseError(`Request failed with status ${response.status}`, response, url);
		} catch (error) {
			if (snapshot) Object.keys(snapshot).forEach((key2) => {
				form[key2] = snapshot[key2];
			});
			if (error instanceof HttpResponseError) {
				if (error.response.status === 422) {
					const validationErrors = JSON.parse(error.response.data).errors || {};
					const processedErrors = withAllErrors.enabled() ? validationErrors : toSimpleValidationErrors(validationErrors);
					form.clearErrors().setError(processedErrors);
					options.onError?.(processedErrors);
					return;
				}
				options.onHttpException?.(error.response);
				throw error;
			}
			if (error instanceof HttpCancelledError || error instanceof Error && error.name === "AbortError") {
				options.onCancel?.();
				throw new HttpCancelledError("Request was cancelled", url);
			}
			options.onNetworkError?.(error instanceof Error ? error : /* @__PURE__ */ new Error("Unknown error"));
			throw error;
		} finally {
			finishProcessing();
			abortController = null;
			options.onFinish?.();
		}
	};
	const createSubmitMethod = (method) => async (url, options = {}) => {
		return submit(method, url, options);
	};
	Object.assign(form, {
		submit(...args2) {
			const parsed = UseFormUtils.parseSubmitArguments(args2, getPrecognitionEndpoint());
			return submit(parsed.method, parsed.url, parsed.options);
		},
		get: createSubmitMethod("get"),
		post: createSubmitMethod("post"),
		put: createSubmitMethod("put"),
		patch: createSubmitMethod("patch"),
		delete: createSubmitMethod("delete"),
		cancel() {
			if (abortController) abortController.abort();
		},
		dontRemember(...keys) {
			setRememberExcludeKeys(keys);
			return form;
		},
		optimistic(callback) {
			pendingOptimisticCallback = callback;
			return form;
		},
		withAllErrors() {
			withAllErrors.enable();
			return form;
		}
	});
	const originalWithPrecognition = form.withPrecognition;
	form.withPrecognition = (...args2) => {
		originalWithPrecognition.call(form, ...args2);
		return form;
	};
	return getPrecognitionEndpoint() ? form : form;
}
function usePoll(interval, requestOptions = {}, options = {
	keepAlive: false,
	autoStart: true
}) {
	const autoStart = options.autoStart ?? true;
	const { stop, start, destroy } = router.poll(interval, requestOptions, {
		...options,
		autoStart: false
	});
	const polling = ref(autoStart);
	onMounted(() => {
		if (autoStart) start();
	});
	onUnmounted(() => {
		destroy();
	});
	return {
		polling,
		stop: () => {
			stop();
			polling.value = false;
		},
		start: () => {
			start();
			polling.value = true;
		}
	};
}
function usePrefetch(options = {}) {
	const isPrefetching = ref(false);
	const lastUpdatedAt = ref(null);
	const isPrefetched = ref(false);
	const cached = typeof window === "undefined" ? null : router.getCached(window.location.pathname, options);
	const inFlight = typeof window === "undefined" ? null : router.getPrefetching(window.location.pathname, options);
	lastUpdatedAt.value = cached?.staleTimestamp || null;
	isPrefetching.value = inFlight !== null;
	isPrefetched.value = cached !== null;
	let onPrefetchedListener;
	let onPrefetchingListener;
	onMounted(() => {
		onPrefetchingListener = router.on("prefetching", (e) => {
			if (e.detail.visit.url.pathname === window.location.pathname) isPrefetching.value = true;
		});
		onPrefetchedListener = router.on("prefetched", (e) => {
			if (e.detail.visit.url.pathname === window.location.pathname) {
				isPrefetching.value = false;
				isPrefetched.value = true;
			}
		});
	});
	onUnmounted(() => {
		onPrefetchedListener();
		onPrefetchingListener();
	});
	return {
		lastUpdatedAt,
		isPrefetching,
		isPrefetched,
		flush: () => router.flush(window.location.pathname, options)
	};
}
function useRemember(data, key2) {
	if (typeof data === "object" && data !== null && data.__rememberable === false) return data;
	const restored = router.restore(key2);
	const type = isReactive(data) ? reactive : ref;
	const hasCallbacks = typeof data.__remember === "function" && typeof data.__restore === "function";
	const remembered = type(restored === void 0 ? data : hasCallbacks ? data.__restore(cloneDeep$1(restored)) : cloneDeep$1(restored));
	watch(remembered, (newValue) => {
		router.remember(cloneDeep$1(hasCallbacks ? data.__remember() : newValue), key2);
	}, {
		immediate: true,
		deep: true
	});
	return remembered;
}
var whenVisible_default = defineComponent({
	name: "WhenVisible",
	slots: Object,
	props: {
		data: { type: [String, Array] },
		params: { type: Object },
		buffer: {
			type: Number,
			default: 0
		},
		as: {
			type: String,
			default: "div"
		},
		always: {
			type: Boolean,
			default: false
		}
	},
	setup(props, { slots }) {
		const loaded = ref(false);
		const fetching = ref(false);
		const observer = ref(null);
		const elementRef = ref(null);
		const page2 = usePage();
		const keys = computed(() => {
			return props.data ? Array.isArray(props.data) ? props.data : [props.data] : [];
		});
		function getReloadParams() {
			const reloadParams = {
				preserveErrors: true,
				...props.params
			};
			if (props.data) reloadParams.only = Array.isArray(props.data) ? props.data : [props.data];
			return reloadParams;
		}
		function registerObserver() {
			if (typeof window === "undefined") return;
			observer.value?.disconnect();
			observer.value = new IntersectionObserver((entries) => {
				if (!entries[0].isIntersecting) return;
				if (fetching.value) return;
				if (!props.always && loaded.value) return;
				fetching.value = true;
				const reloadParams = getReloadParams();
				router.reload({
					...reloadParams,
					onStart: (e) => {
						fetching.value = true;
						reloadParams.onStart?.(e);
					},
					onFinish: (e) => {
						loaded.value = true;
						fetching.value = false;
						reloadParams.onFinish?.(e);
						if (!props.always) observer.value?.disconnect();
					}
				});
			}, { rootMargin: `${props.buffer}px` });
			if (elementRef.value) observer.value.observe(elementRef.value);
		}
		watch(() => keys.value.map((key2) => get(page2.props, key2)), () => {
			const exists = keys.value.length > 0 && keys.value.every((key2) => get(page2.props, key2) !== void 0);
			loaded.value = exists;
			if (exists && !props.always) return;
			if (!observer.value || !exists) nextTick(registerObserver);
		}, { immediate: true });
		onUnmounted(() => {
			observer.value?.disconnect();
		});
		return () => {
			const els = [];
			if (props.always || !loaded.value) els.push(h(props.as, { ref: elementRef }));
			if (!loaded.value) els.push(slots.fallback ? slots.fallback({}) : null);
			else if (slots.default) els.push(slots.default({ fetching: fetching.value }));
			return els;
		};
	}
});
var config = config$1.extend({});
//#endregion
export { app_default as App, deferred_default as Deferred, form_default as Form, head_default as Head, infiniteScroll_default as InfiniteScroll, link_default as Link, whenVisible_default as WhenVisible, config, createForm, createInertiaApp, http, progress, resetLayoutProps, router, setLayoutProps, useForm, useFormContext, useHttp, usePage, usePoll, usePrefetch, useRemember };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGluZXJ0aWFqc192dWUzLmpzIiwibmFtZXMiOlsiZGVib3VuY2UiLCJub29wIiwiaXNUeXBlZEFycmF5IiwiaXNUeXBlZEFycmF5IiwiY2xvbmVEZWVwV2l0aCIsImlzVHlwZWRBcnJheSIsImNsb25lRGVlcCIsImlzUGxhaW5PYmplY3QiLCJpc1BsYWluT2JqZWN0IiwiaXNQbGFpbk9iamVjdCIsIm5vb3AiLCJlc2NhcGUiLCJyZWdleElzRGVlcFByb3AiLCJkZWJvdW5jZSIsImRlYm91bmNlJDEiLCJpc1BsYWluT2JqZWN0Iiwibm9vcCIsImlzRmlsZSIsImhhc0ZpbGVzIiwiSHR0cFJlc3BvbnNlRXJyb3IiLCJIdHRwQ2FuY2VsbGVkRXJyb3IiLCJIdHRwTmV0d29ya0Vycm9yIiwiaGFzRmlsZXMiLCJwYXJzZUhlYWRlcnMiLCJIdHRwUmVzcG9uc2VFcnJvciIsIkh0dHBDYW5jZWxsZWRFcnJvciIsIkh0dHBOZXR3b3JrRXJyb3IiLCJodHRwQ2xpZW50IiwiSHR0cFJlc3BvbnNlRXJyb3IiLCJoYXNGaWxlcyIsImRlYm91bmNlIiwiSHR0cENhbmNlbGxlZEVycm9yIiwiSHR0cFJlc3BvbnNlRXJyb3IiLCJpc0ZpbGUiLCJjb25maWciLCJjbG9uZURlZXAiLCJnZXQyIiwiY2xvbmVEZWVwMiIsImdldDMiLCJwYWdlIiwiY2xvbmVEZWVwMyIsImdldDQiLCJpc0VxdWFsMiIsImdldDUiLCJnZXQ2Iiwibm9vcCIsImdldDciLCJjbG9uZURlZXA0IiwiaXNFcXVhbDMiLCJnZXQ4IiwiaXNFcXVhbDQiLCJjbG9uZURlZXAiLCJyb3V0ZXIyIiwiY2xvbmVEZWVwMiIsIlVzZUZvcm1VdGlsczIiLCJjbG9uZURlZXAzIiwicmVmMiIsInJvdXRlcjQiLCJyZWFjdGl2ZTIiLCJoMiIsInJvdXRlcjUiLCJkZWZpbmVDb21wb25lbnQyIiwicmVmMyIsImNvbXB1dGVkMiIsInJvdXRlcjYiLCJnZXQyIiwiaDMiLCJkZWZpbmVDb21wb25lbnQzIiwiY29uZmlnMiIsInJlZjQiLCJjb21wdXRlZDMiLCJpc0VxdWFsMiIsIlVzZUZvcm1VdGlsczMiLCJoNCIsImRlZmluZUNvbXBvbmVudDQiLCJkZWZpbmVDb21wb25lbnQ1IiwicmVmNSIsImNvbXB1dGVkNCIsImg1IiwiRnJhZ21lbnQyIiwiZGVmaW5lQ29tcG9uZW50NiIsInJlZjYiLCJjb21wdXRlZDUiLCJpc1VybE1ldGhvZFBhaXIyIiwibWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nMiIsInJlc29sdmVVcmxNZXRob2RQYWlyQ29tcG9uZW50MiIsImg2IiwiVXNlRm9ybVV0aWxzNCIsImNsb25lRGVlcDQiLCJtZXJnZURhdGFJbnRvUXVlcnlTdHJpbmczIiwidG9TaW1wbGVWYWxpZGF0aW9uRXJyb3JzMiIsInJvdXRlcjgiLCJyZWY3IiwicmVmOCIsInJvdXRlcjkiLCJyb3V0ZXIxMCIsInJlYWN0aXZlMyIsInJlZjkiLCJjbG9uZURlZXA1IiwiZGVmaW5lQ29tcG9uZW50NyIsInJlZjEwIiwiY29tcHV0ZWQ2IiwiZ2V0MyIsImg3IiwiY29yZUNvbmZpZyJdLCJzb3VyY2VzIjpbIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9faW50ZXJuYWwvZ2xvYmFsVGhpcy5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvZnVuY3Rpb24vZGVib3VuY2UubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2Z1bmN0aW9uL25vb3AubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L3ByZWRpY2F0ZS9pc1ByaW1pdGl2ZS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvcHJlZGljYXRlL2lzVHlwZWRBcnJheS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3Qvb2JqZWN0L2Nsb25lLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9wcmVkaWNhdGUvaXNCdWZmZXIubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9faW50ZXJuYWwvZ2V0U3ltYm9scy5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L19pbnRlcm5hbC9nZXRUYWcubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9faW50ZXJuYWwvdGFncy5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3Qvb2JqZWN0L2Nsb25lRGVlcFdpdGgubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L29iamVjdC9jbG9uZURlZXAubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L3ByZWRpY2F0ZS9pc1BsYWluT2JqZWN0Lm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9faW50ZXJuYWwvaXNVbnNhZmVQcm9wZXJ0eS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L3ByZWRpY2F0ZS9pc1BsYWluT2JqZWN0Lm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvdXRpbC9lcS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvcHJlZGljYXRlL2lzRXF1YWxXaXRoLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9wcmVkaWNhdGUvaXNFcXVhbC5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvcHJlZGljYXRlL2lzTGVuZ3RoLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9zdHJpbmcvZXNjYXBlLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvcHJlZGljYXRlL2lzQXJyYXlMaWtlLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvcHJlZGljYXRlL2lzU3ltYm9sLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvdXRpbC90b1N0cmluZy5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L19pbnRlcm5hbC90b0tleS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L3V0aWwvdG9QYXRoLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvX2ludGVybmFsL2lzRGVlcEtleS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L29iamVjdC9nZXQubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9wcmVkaWNhdGUvaXNPYmplY3QubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9vYmplY3QvY2xvbmVEZWVwV2l0aC5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L29iamVjdC9jbG9uZURlZXAubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9wcmVkaWNhdGUvaXNBcmd1bWVudHMubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9faW50ZXJuYWwvaXNJbmRleC5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L29iamVjdC9oYXMubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9wcmVkaWNhdGUvaXNPYmplY3RMaWtlLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvcHJlZGljYXRlL2lzQXJyYXlMaWtlT2JqZWN0Lm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvX2ludGVybmFsL2lzS2V5Lm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvcHJlZGljYXRlL2lzVHlwZWRBcnJheS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvY29tcGF0L19pbnRlcm5hbC9hc3NpZ25WYWx1ZS5tanMiLCIuLi8uLi9lcy10b29sa2l0L2Rpc3QvX2ludGVybmFsL2lzVW5zYWZlVG9Xcml0ZVByb3BlcnR5Lm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvb2JqZWN0L3VwZGF0ZVdpdGgubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9vYmplY3Qvc2V0Lm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvZnVuY3Rpb24vZGVib3VuY2UubWpzIiwiLi4vLi4vZXMtdG9vbGtpdC9kaXN0L2NvbXBhdC9vYmplY3QvbWVyZ2VXaXRoLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvb2JqZWN0L21lcmdlLm1qcyIsIi4uLy4uL2VzLXRvb2xraXQvZGlzdC9jb21wYXQvc3RyaW5nL2VzY2FwZS5tanMiLCIuLi8uLi9sYXJhdmVsLXByZWNvZ25pdGlvbi9kaXN0L2Zvcm0uanMiLCIuLi8uLi9sYXJhdmVsLXByZWNvZ25pdGlvbi9kaXN0L2h0dHAvZXJyb3JzLmpzIiwiLi4vLi4vbGFyYXZlbC1wcmVjb2duaXRpb24vZGlzdC9odHRwL3VybC5qcyIsIi4uLy4uL2xhcmF2ZWwtcHJlY29nbml0aW9uL2Rpc3QvaHR0cC9mZXRjaENsaWVudC5qcyIsIi4uLy4uL2xhcmF2ZWwtcHJlY29nbml0aW9uL2Rpc3QvY2xpZW50LmpzIiwiLi4vLi4vbGFyYXZlbC1wcmVjb2duaXRpb24vZGlzdC92YWxpZGF0b3IuanMiLCIuLi8uLi9AaW5lcnRpYWpzL2NvcmUvZGlzdC9pbmRleC5qcyIsIi4uLy4uL0BpbmVydGlhanMvdnVlMy9kaXN0L2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vI3JlZ2lvbiBzcmMvX2ludGVybmFsL2dsb2JhbFRoaXMudHNcbmNvbnN0IGdsb2JhbFRoaXNfID0gdHlwZW9mIGdsb2JhbFRoaXMgPT09IFwib2JqZWN0XCIgJiYgZ2xvYmFsVGhpcyB8fCB0eXBlb2Ygd2luZG93ID09PSBcIm9iamVjdFwiICYmIHdpbmRvdyB8fCB0eXBlb2Ygc2VsZiA9PT0gXCJvYmplY3RcIiAmJiBzZWxmIHx8IHR5cGVvZiBnbG9iYWwgPT09IFwib2JqZWN0XCIgJiYgZ2xvYmFsIHx8IChmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXM7XG59KSgpO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBnbG9iYWxUaGlzXyB9O1xuIiwiLy8jcmVnaW9uIHNyYy9mdW5jdGlvbi9kZWJvdW5jZS50c1xuLyoqXG4qIENyZWF0ZXMgYSBkZWJvdW5jZWQgZnVuY3Rpb24gdGhhdCBkZWxheXMgaW52b2tpbmcgdGhlIHByb3ZpZGVkIGZ1bmN0aW9uIHVudGlsIGFmdGVyIGBkZWJvdW5jZU1zYCBtaWxsaXNlY29uZHNcbiogaGF2ZSBlbGFwc2VkIHNpbmNlIHRoZSBsYXN0IHRpbWUgdGhlIGRlYm91bmNlZCBmdW5jdGlvbiB3YXMgaW52b2tlZC4gVGhlIGRlYm91bmNlZCBmdW5jdGlvbiBhbHNvIGhhcyBhIGBjYW5jZWxgXG4qIG1ldGhvZCB0byBjYW5jZWwgYW55IHBlbmRpbmcgZXhlY3V0aW9uLlxuKlxuKiBAdGVtcGxhdGUgRiAtIFRoZSB0eXBlIG9mIGZ1bmN0aW9uLlxuKiBAcGFyYW0gZnVuYyAtIFRoZSBmdW5jdGlvbiB0byBkZWJvdW5jZS5cbiogQHBhcmFtIGRlYm91bmNlTXMgLSBUaGUgbnVtYmVyIG9mIG1pbGxpc2Vjb25kcyB0byBkZWxheS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb3B0aW9ucyBvYmplY3RcbiogQHBhcmFtIG9wdGlvbnMuc2lnbmFsIC0gQW4gb3B0aW9uYWwgQWJvcnRTaWduYWwgdG8gY2FuY2VsIHRoZSBkZWJvdW5jZWQgZnVuY3Rpb24uXG4qIEBwYXJhbSBvcHRpb25zLmVkZ2VzIC0gQW4gb3B0aW9uYWwgYXJyYXkgc3BlY2lmeWluZyB3aGV0aGVyIHRoZSBmdW5jdGlvbiBzaG91bGQgYmUgaW52b2tlZCBvbiB0aGUgbGVhZGluZyBlZGdlLCB0cmFpbGluZyBlZGdlLCBvciBib3RoLlxuKiBAcmV0dXJucyBBIG5ldyBkZWJvdW5jZWQgZnVuY3Rpb24gd2l0aCBhIGBjYW5jZWxgIG1ldGhvZC5cbipcbiogQGV4YW1wbGVcbiogY29uc3QgZGVib3VuY2VkRnVuY3Rpb24gPSBkZWJvdW5jZSgoKSA9PiB7XG4qICAgY29uc29sZS5sb2coJ0Z1bmN0aW9uIGV4ZWN1dGVkJyk7XG4qIH0sIDEwMDApO1xuKlxuKiAvLyBXaWxsIGxvZyAnRnVuY3Rpb24gZXhlY3V0ZWQnIGFmdGVyIDEgc2Vjb25kIGlmIG5vdCBjYWxsZWQgYWdhaW4gaW4gdGhhdCB0aW1lXG4qIGRlYm91bmNlZEZ1bmN0aW9uKCk7XG4qXG4qIC8vIFdpbGwgbm90IGxvZyBhbnl0aGluZyBhcyB0aGUgcHJldmlvdXMgY2FsbCBpcyBjYW5jZWxlZFxuKiBkZWJvdW5jZWRGdW5jdGlvbi5jYW5jZWwoKTtcbipcbiogLy8gV2l0aCBBYm9ydFNpZ25hbFxuKiBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuKiBjb25zdCBzaWduYWwgPSBjb250cm9sbGVyLnNpZ25hbDtcbiogY29uc3QgZGVib3VuY2VkV2l0aFNpZ25hbCA9IGRlYm91bmNlKCgpID0+IHtcbiogIGNvbnNvbGUubG9nKCdGdW5jdGlvbiBleGVjdXRlZCcpO1xuKiB9LCAxMDAwLCB7IHNpZ25hbCB9KTtcbipcbiogZGVib3VuY2VkV2l0aFNpZ25hbCgpO1xuKlxuKiAvLyBXaWxsIGNhbmNlbCB0aGUgZGVib3VuY2VkIGZ1bmN0aW9uIGNhbGxcbiogY29udHJvbGxlci5hYm9ydCgpO1xuKi9cbmZ1bmN0aW9uIGRlYm91bmNlKGZ1bmMsIGRlYm91bmNlTXMsIHsgc2lnbmFsLCBlZGdlcyB9ID0ge30pIHtcblx0bGV0IHBlbmRpbmdUaGlzID0gdm9pZCAwO1xuXHRsZXQgcGVuZGluZ0FyZ3MgPSBudWxsO1xuXHRjb25zdCBsZWFkaW5nID0gZWRnZXMgIT0gbnVsbCAmJiBlZGdlcy5pbmNsdWRlcyhcImxlYWRpbmdcIik7XG5cdGNvbnN0IHRyYWlsaW5nID0gZWRnZXMgPT0gbnVsbCB8fCBlZGdlcy5pbmNsdWRlcyhcInRyYWlsaW5nXCIpO1xuXHRjb25zdCBpbnZva2UgPSAoKSA9PiB7XG5cdFx0aWYgKHBlbmRpbmdBcmdzICE9PSBudWxsKSB7XG5cdFx0XHRmdW5jLmFwcGx5KHBlbmRpbmdUaGlzLCBwZW5kaW5nQXJncyk7XG5cdFx0XHRwZW5kaW5nVGhpcyA9IHZvaWQgMDtcblx0XHRcdHBlbmRpbmdBcmdzID0gbnVsbDtcblx0XHR9XG5cdH07XG5cdGNvbnN0IG9uVGltZXJFbmQgPSAoKSA9PiB7XG5cdFx0aWYgKHRyYWlsaW5nKSBpbnZva2UoKTtcblx0XHRjYW5jZWwoKTtcblx0fTtcblx0bGV0IHRpbWVvdXRJZCA9IG51bGw7XG5cdGNvbnN0IHNjaGVkdWxlID0gKCkgPT4ge1xuXHRcdGlmICh0aW1lb3V0SWQgIT0gbnVsbCkgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cdFx0dGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR0aW1lb3V0SWQgPSBudWxsO1xuXHRcdFx0b25UaW1lckVuZCgpO1xuXHRcdH0sIGRlYm91bmNlTXMpO1xuXHR9O1xuXHRjb25zdCBjYW5jZWxUaW1lciA9ICgpID0+IHtcblx0XHRpZiAodGltZW91dElkICE9PSBudWxsKSB7XG5cdFx0XHRjbGVhclRpbWVvdXQodGltZW91dElkKTtcblx0XHRcdHRpbWVvdXRJZCA9IG51bGw7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBjYW5jZWwgPSAoKSA9PiB7XG5cdFx0Y2FuY2VsVGltZXIoKTtcblx0XHRwZW5kaW5nVGhpcyA9IHZvaWQgMDtcblx0XHRwZW5kaW5nQXJncyA9IG51bGw7XG5cdH07XG5cdGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuXHRcdGludm9rZSgpO1xuXHR9O1xuXHRjb25zdCBkZWJvdW5jZWQgPSBmdW5jdGlvbiguLi5hcmdzKSB7XG5cdFx0aWYgKHNpZ25hbD8uYWJvcnRlZCkgcmV0dXJuO1xuXHRcdHBlbmRpbmdUaGlzID0gdGhpcztcblx0XHRwZW5kaW5nQXJncyA9IGFyZ3M7XG5cdFx0Y29uc3QgaXNGaXJzdENhbGwgPSB0aW1lb3V0SWQgPT0gbnVsbDtcblx0XHRzY2hlZHVsZSgpO1xuXHRcdGlmIChsZWFkaW5nICYmIGlzRmlyc3RDYWxsKSBpbnZva2UoKTtcblx0fTtcblx0ZGVib3VuY2VkLnNjaGVkdWxlID0gc2NoZWR1bGU7XG5cdGRlYm91bmNlZC5jYW5jZWwgPSBjYW5jZWw7XG5cdGRlYm91bmNlZC5mbHVzaCA9IGZsdXNoO1xuXHRzaWduYWw/LmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBjYW5jZWwsIHsgb25jZTogdHJ1ZSB9KTtcblx0cmV0dXJuIGRlYm91bmNlZDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVib3VuY2UgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvZnVuY3Rpb24vbm9vcC50c1xuLyoqXG4qIEEgbm8tb3BlcmF0aW9uIGZ1bmN0aW9uIHRoYXQgZG9lcyBub3RoaW5nLlxuKiBUaGlzIGNhbiBiZSB1c2VkIGFzIGEgcGxhY2Vob2xkZXIgb3IgZGVmYXVsdCBmdW5jdGlvbi5cbipcbiogQGV4YW1wbGVcbiogbm9vcCgpOyAvLyBEb2VzIG5vdGhpbmdcbipcbiogQHJldHVybnMgVGhpcyBmdW5jdGlvbiBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcuXG4qL1xuZnVuY3Rpb24gbm9vcCgpIHt9XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IG5vb3AgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvcHJlZGljYXRlL2lzUHJpbWl0aXZlLnRzXG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSB2YWx1ZSBpcyBhIEphdmFTY3JpcHQgcHJpbWl0aXZlLlxuKiBKYXZhU2NyaXB0IHByaW1pdGl2ZXMgaW5jbHVkZSBudWxsLCB1bmRlZmluZWQsIHN0cmluZ3MsIG51bWJlcnMsIGJvb2xlYW5zLCBzeW1ib2xzLCBhbmQgYmlnaW50cy5cbipcbiogQHBhcmFtIHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiogQHJldHVybnMgUmV0dXJucyB0cnVlIGlmIGB2YWx1ZWAgaXMgYSBwcmltaXRpdmUsIGZhbHNlIG90aGVyd2lzZS5cbipcbiogQGV4YW1wbGVcbiogaXNQcmltaXRpdmUobnVsbCk7IC8vIHRydWVcbiogaXNQcmltaXRpdmUodW5kZWZpbmVkKTsgLy8gdHJ1ZVxuKiBpc1ByaW1pdGl2ZSgnMTIzJyk7IC8vIHRydWVcbiogaXNQcmltaXRpdmUoZmFsc2UpOyAvLyB0cnVlXG4qIGlzUHJpbWl0aXZlKHRydWUpOyAvLyB0cnVlXG4qIGlzUHJpbWl0aXZlKFN5bWJvbCgnYScpKTsgLy8gdHJ1ZVxuKiBpc1ByaW1pdGl2ZSgxMjNuKTsgLy8gdHJ1ZVxuKiBpc1ByaW1pdGl2ZSh7fSk7IC8vIGZhbHNlXG4qIGlzUHJpbWl0aXZlKG5ldyBEYXRlKCkpOyAvLyBmYWxzZVxuKiBpc1ByaW1pdGl2ZShuZXcgTWFwKCkpOyAvLyBmYWxzZVxuKiBpc1ByaW1pdGl2ZShuZXcgU2V0KCkpOyAvLyBmYWxzZVxuKiBpc1ByaW1pdGl2ZShbMSwgMiwgM10pOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGlzUHJpbWl0aXZlKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZSA9PSBudWxsIHx8IHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUgIT09IFwiZnVuY3Rpb25cIjtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNQcmltaXRpdmUgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvcHJlZGljYXRlL2lzVHlwZWRBcnJheS50c1xuLyoqXG4qIENoZWNrcyBpZiBhIHZhbHVlIGlzIGEgVHlwZWRBcnJheS5cbiogQHBhcmFtIHggVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBSZXR1cm5zIHRydWUgaWYgYHhgIGlzIGEgVHlwZWRBcnJheSwgZmFsc2Ugb3RoZXJ3aXNlLlxuKlxuKiBAZXhhbXBsZVxuKiBjb25zdCBhcnIgPSBuZXcgVWludDhBcnJheShbMSwgMiwgM10pO1xuKiBpc1R5cGVkQXJyYXkoYXJyKTsgLy8gdHJ1ZVxuKlxuKiBjb25zdCByZWd1bGFyQXJyYXkgPSBbMSwgMiwgM107XG4qIGlzVHlwZWRBcnJheShyZWd1bGFyQXJyYXkpOyAvLyBmYWxzZVxuKlxuKiBjb25zdCBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoMTYpO1xuKiBpc1R5cGVkQXJyYXkoYnVmZmVyKTsgLy8gZmFsc2VcbiovXG5mdW5jdGlvbiBpc1R5cGVkQXJyYXkoeCkge1xuXHRyZXR1cm4gQXJyYXlCdWZmZXIuaXNWaWV3KHgpICYmICEoeCBpbnN0YW5jZW9mIERhdGFWaWV3KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNUeXBlZEFycmF5IH07XG4iLCJpbXBvcnQgeyBpc1ByaW1pdGl2ZSB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNQcmltaXRpdmUubWpzXCI7XG5pbXBvcnQgeyBpc1R5cGVkQXJyYXkgfSBmcm9tIFwiLi4vcHJlZGljYXRlL2lzVHlwZWRBcnJheS5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvb2JqZWN0L2Nsb25lLnRzXG4vKipcbiogQ3JlYXRlcyBhIHNoYWxsb3cgY2xvbmUgb2YgdGhlIGdpdmVuIG9iamVjdC5cbipcbiogQHRlbXBsYXRlIFQgLSBUaGUgdHlwZSBvZiB0aGUgb2JqZWN0LlxuKiBAcGFyYW0gb2JqIC0gVGhlIG9iamVjdCB0byBjbG9uZS5cbiogQHJldHVybnMgQSBzaGFsbG93IGNsb25lIG9mIHRoZSBnaXZlbiBvYmplY3QuXG4qXG4qIEBleGFtcGxlXG4qIC8vIENsb25lIGEgcHJpbWl0aXZlIHZhbHVlXG4qIGNvbnN0IG51bSA9IDI5O1xuKiBjb25zdCBjbG9uZWROdW0gPSBjbG9uZShudW0pO1xuKiBjb25zb2xlLmxvZyhjbG9uZWROdW0pOyAvLyAyOVxuKiBjb25zb2xlLmxvZyhjbG9uZWROdW0gPT09IG51bSk7IC8vIHRydWVcbipcbiogQGV4YW1wbGVcbiogLy8gQ2xvbmUgYW4gYXJyYXlcbiogY29uc3QgYXJyID0gWzEsIDIsIDNdO1xuKiBjb25zdCBjbG9uZWRBcnIgPSBjbG9uZShhcnIpO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIpOyAvLyBbMSwgMiwgM11cbiogY29uc29sZS5sb2coY2xvbmVkQXJyID09PSBhcnIpOyAvLyBmYWxzZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBvYmplY3RcbiogY29uc3Qgb2JqID0geyBhOiAxLCBiOiAnZXMtdG9vbGtpdCcsIGM6IFsxLCAyLCAzXSB9O1xuKiBjb25zdCBjbG9uZWRPYmogPSBjbG9uZShvYmopO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmopOyAvLyB7IGE6IDEsIGI6ICdlcy10b29sa2l0JywgYzogWzEsIDIsIDNdIH1cbiogY29uc29sZS5sb2coY2xvbmVkT2JqID09PSBvYmopOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGNsb25lKG9iaikge1xuXHRpZiAoaXNQcmltaXRpdmUob2JqKSkgcmV0dXJuIG9iajtcblx0aWYgKEFycmF5LmlzQXJyYXkob2JqKSB8fCBpc1R5cGVkQXJyYXkob2JqKSB8fCBvYmogaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciB8fCB0eXBlb2YgU2hhcmVkQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgb2JqIGluc3RhbmNlb2YgU2hhcmVkQXJyYXlCdWZmZXIpIHJldHVybiBvYmouc2xpY2UoMCk7XG5cdGNvbnN0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihvYmopO1xuXHRpZiAocHJvdG90eXBlID09IG51bGwpIHJldHVybiBPYmplY3QuYXNzaWduKE9iamVjdC5jcmVhdGUocHJvdG90eXBlKSwgb2JqKTtcblx0Y29uc3QgQ29uc3RydWN0b3IgPSBwcm90b3R5cGUuY29uc3RydWN0b3I7XG5cdGlmIChvYmogaW5zdGFuY2VvZiBEYXRlIHx8IG9iaiBpbnN0YW5jZW9mIE1hcCB8fCBvYmogaW5zdGFuY2VvZiBTZXQpIHJldHVybiBuZXcgQ29uc3RydWN0b3Iob2JqKTtcblx0aWYgKG9iaiBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuXHRcdGNvbnN0IG5ld1JlZ0V4cCA9IG5ldyBDb25zdHJ1Y3RvcihvYmopO1xuXHRcdG5ld1JlZ0V4cC5sYXN0SW5kZXggPSBvYmoubGFzdEluZGV4O1xuXHRcdHJldHVybiBuZXdSZWdFeHA7XG5cdH1cblx0aWYgKG9iaiBpbnN0YW5jZW9mIERhdGFWaWV3KSByZXR1cm4gbmV3IENvbnN0cnVjdG9yKG9iai5idWZmZXIuc2xpY2UoMCkpO1xuXHRpZiAob2JqIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRsZXQgbmV3RXJyb3I7XG5cdFx0aWYgKG9iaiBpbnN0YW5jZW9mIEFnZ3JlZ2F0ZUVycm9yKSBuZXdFcnJvciA9IG5ldyBDb25zdHJ1Y3RvcihvYmouZXJyb3JzLCBvYmoubWVzc2FnZSwgeyBjYXVzZTogb2JqLmNhdXNlIH0pO1xuXHRcdGVsc2UgbmV3RXJyb3IgPSBuZXcgQ29uc3RydWN0b3Iob2JqLm1lc3NhZ2UsIHsgY2F1c2U6IG9iai5jYXVzZSB9KTtcblx0XHRuZXdFcnJvci5zdGFjayA9IG9iai5zdGFjaztcblx0XHRPYmplY3QuYXNzaWduKG5ld0Vycm9yLCBvYmopO1xuXHRcdHJldHVybiBuZXdFcnJvcjtcblx0fVxuXHRpZiAodHlwZW9mIEZpbGUgIT09IFwidW5kZWZpbmVkXCIgJiYgb2JqIGluc3RhbmNlb2YgRmlsZSkgcmV0dXJuIG5ldyBDb25zdHJ1Y3Rvcihbb2JqXSwgb2JqLm5hbWUsIHtcblx0XHR0eXBlOiBvYmoudHlwZSxcblx0XHRsYXN0TW9kaWZpZWQ6IG9iai5sYXN0TW9kaWZpZWRcblx0fSk7XG5cdGlmICh0eXBlb2Ygb2JqID09PSBcIm9iamVjdFwiKSByZXR1cm4gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKHByb3RvdHlwZSksIG9iaik7XG5cdHJldHVybiBvYmo7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNsb25lIH07XG4iLCJpbXBvcnQgeyBnbG9iYWxUaGlzXyB9IGZyb20gXCIuLi9faW50ZXJuYWwvZ2xvYmFsVGhpcy5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvcHJlZGljYXRlL2lzQnVmZmVyLnRzXG4vKipcbiogQ2hlY2tzIGlmIHRoZSBnaXZlbiB2YWx1ZSBpcyBhIEJ1ZmZlciBpbnN0YW5jZS5cbipcbiogVGhpcyBmdW5jdGlvbiB0ZXN0cyB3aGV0aGVyIHRoZSBwcm92aWRlZCB2YWx1ZSBpcyBhbiBpbnN0YW5jZSBvZiBCdWZmZXIuXG4qIEl0IHJldHVybnMgYHRydWVgIGlmIHRoZSB2YWx1ZSBpcyBhIEJ1ZmZlciwgYW5kIGBmYWxzZWAgb3RoZXJ3aXNlLlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGNhbiBhbHNvIHNlcnZlIGFzIGEgdHlwZSBwcmVkaWNhdGUgaW4gVHlwZVNjcmlwdCwgbmFycm93aW5nIHRoZSB0eXBlIG9mIHRoZSBhcmd1bWVudCB0byBgQnVmZmVyYC5cbipcbiogQHBhcmFtIHggLSBUaGUgdmFsdWUgdG8gY2hlY2sgaWYgaXQgaXMgYSBCdWZmZXIuXG4qIEByZXR1cm5zIFJldHVybnMgYHRydWVgIGlmIGB4YCBpcyBhIEJ1ZmZlciwgZWxzZSBgZmFsc2VgLlxuKlxuKiBAZXhhbXBsZVxuKiBjb25zdCBidWZmZXIgPSBCdWZmZXIuZnJvbShcInRlc3RcIik7XG4qIGNvbnNvbGUubG9nKGlzQnVmZmVyKGJ1ZmZlcikpOyAvLyB0cnVlXG4qXG4qIGNvbnN0IG5vdEJ1ZmZlciA9IFwibm90IGEgYnVmZmVyXCI7XG4qIGNvbnNvbGUubG9nKGlzQnVmZmVyKG5vdEJ1ZmZlcikpOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGlzQnVmZmVyKHgpIHtcblx0cmV0dXJuIHR5cGVvZiBnbG9iYWxUaGlzXy5CdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgZ2xvYmFsVGhpc18uQnVmZmVyLmlzQnVmZmVyKHgpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc0J1ZmZlciB9O1xuIiwiLy8jcmVnaW9uIHNyYy9jb21wYXQvX2ludGVybmFsL2dldFN5bWJvbHMudHNcbmZ1bmN0aW9uIGdldFN5bWJvbHMob2JqZWN0KSB7XG5cdHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKG9iamVjdCkuZmlsdGVyKChzeW1ib2wpID0+IE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChvYmplY3QsIHN5bWJvbCkpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBnZXRTeW1ib2xzIH07XG4iLCIvLyNyZWdpb24gc3JjL2NvbXBhdC9faW50ZXJuYWwvZ2V0VGFnLnRzXG4vKipcbiogR2V0cyB0aGUgYHRvU3RyaW5nVGFnYCBvZiBgdmFsdWVgLlxuKlxuKiBAcHJpdmF0ZVxuKiBAcGFyYW0ge1R9IHZhbHVlIFRoZSB2YWx1ZSB0byBxdWVyeS5cbiogQHJldHVybnMge3N0cmluZ30gUmV0dXJucyB0aGUgYE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbGAgcmVzdWx0LlxuKi9cbmZ1bmN0aW9uIGdldFRhZyh2YWx1ZSkge1xuXHRpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIHZhbHVlID09PSB2b2lkIDAgPyBcIltvYmplY3QgVW5kZWZpbmVkXVwiIDogXCJbb2JqZWN0IE51bGxdXCI7XG5cdHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBnZXRUYWcgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvY29tcGF0L19pbnRlcm5hbC90YWdzLnRzXG5jb25zdCByZWdleHBUYWcgPSBcIltvYmplY3QgUmVnRXhwXVwiO1xuY29uc3Qgc3RyaW5nVGFnID0gXCJbb2JqZWN0IFN0cmluZ11cIjtcbmNvbnN0IG51bWJlclRhZyA9IFwiW29iamVjdCBOdW1iZXJdXCI7XG5jb25zdCBib29sZWFuVGFnID0gXCJbb2JqZWN0IEJvb2xlYW5dXCI7XG5jb25zdCBhcmd1bWVudHNUYWcgPSBcIltvYmplY3QgQXJndW1lbnRzXVwiO1xuY29uc3Qgc3ltYm9sVGFnID0gXCJbb2JqZWN0IFN5bWJvbF1cIjtcbmNvbnN0IGRhdGVUYWcgPSBcIltvYmplY3QgRGF0ZV1cIjtcbmNvbnN0IG1hcFRhZyA9IFwiW29iamVjdCBNYXBdXCI7XG5jb25zdCBzZXRUYWcgPSBcIltvYmplY3QgU2V0XVwiO1xuY29uc3QgYXJyYXlUYWcgPSBcIltvYmplY3QgQXJyYXldXCI7XG5jb25zdCBmdW5jdGlvblRhZyA9IFwiW29iamVjdCBGdW5jdGlvbl1cIjtcbmNvbnN0IGFycmF5QnVmZmVyVGFnID0gXCJbb2JqZWN0IEFycmF5QnVmZmVyXVwiO1xuY29uc3Qgb2JqZWN0VGFnID0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbmNvbnN0IGVycm9yVGFnID0gXCJbb2JqZWN0IEVycm9yXVwiO1xuY29uc3QgZGF0YVZpZXdUYWcgPSBcIltvYmplY3QgRGF0YVZpZXddXCI7XG5jb25zdCB1aW50OEFycmF5VGFnID0gXCJbb2JqZWN0IFVpbnQ4QXJyYXldXCI7XG5jb25zdCB1aW50OENsYW1wZWRBcnJheVRhZyA9IFwiW29iamVjdCBVaW50OENsYW1wZWRBcnJheV1cIjtcbmNvbnN0IHVpbnQxNkFycmF5VGFnID0gXCJbb2JqZWN0IFVpbnQxNkFycmF5XVwiO1xuY29uc3QgdWludDMyQXJyYXlUYWcgPSBcIltvYmplY3QgVWludDMyQXJyYXldXCI7XG5jb25zdCBiaWdVaW50NjRBcnJheVRhZyA9IFwiW29iamVjdCBCaWdVaW50NjRBcnJheV1cIjtcbmNvbnN0IGludDhBcnJheVRhZyA9IFwiW29iamVjdCBJbnQ4QXJyYXldXCI7XG5jb25zdCBpbnQxNkFycmF5VGFnID0gXCJbb2JqZWN0IEludDE2QXJyYXldXCI7XG5jb25zdCBpbnQzMkFycmF5VGFnID0gXCJbb2JqZWN0IEludDMyQXJyYXldXCI7XG5jb25zdCBiaWdJbnQ2NEFycmF5VGFnID0gXCJbb2JqZWN0IEJpZ0ludDY0QXJyYXldXCI7XG5jb25zdCBmbG9hdDMyQXJyYXlUYWcgPSBcIltvYmplY3QgRmxvYXQzMkFycmF5XVwiO1xuY29uc3QgZmxvYXQ2NEFycmF5VGFnID0gXCJbb2JqZWN0IEZsb2F0NjRBcnJheV1cIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYXJndW1lbnRzVGFnLCBhcnJheUJ1ZmZlclRhZywgYXJyYXlUYWcsIGJpZ0ludDY0QXJyYXlUYWcsIGJpZ1VpbnQ2NEFycmF5VGFnLCBib29sZWFuVGFnLCBkYXRhVmlld1RhZywgZGF0ZVRhZywgZXJyb3JUYWcsIGZsb2F0MzJBcnJheVRhZywgZmxvYXQ2NEFycmF5VGFnLCBmdW5jdGlvblRhZywgaW50MTZBcnJheVRhZywgaW50MzJBcnJheVRhZywgaW50OEFycmF5VGFnLCBtYXBUYWcsIG51bWJlclRhZywgb2JqZWN0VGFnLCByZWdleHBUYWcsIHNldFRhZywgc3RyaW5nVGFnLCBzeW1ib2xUYWcsIHVpbnQxNkFycmF5VGFnLCB1aW50MzJBcnJheVRhZywgdWludDhBcnJheVRhZywgdWludDhDbGFtcGVkQXJyYXlUYWcgfTtcbiIsImltcG9ydCB7IGlzUHJpbWl0aXZlIH0gZnJvbSBcIi4uL3ByZWRpY2F0ZS9pc1ByaW1pdGl2ZS5tanNcIjtcbmltcG9ydCB7IGlzVHlwZWRBcnJheSB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNUeXBlZEFycmF5Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0U3ltYm9scyB9IGZyb20gXCIuLi9jb21wYXQvX2ludGVybmFsL2dldFN5bWJvbHMubWpzXCI7XG5pbXBvcnQgeyBnZXRUYWcgfSBmcm9tIFwiLi4vY29tcGF0L19pbnRlcm5hbC9nZXRUYWcubWpzXCI7XG5pbXBvcnQgeyBhcmd1bWVudHNUYWcsIGFycmF5QnVmZmVyVGFnLCBhcnJheVRhZywgYm9vbGVhblRhZywgZGF0YVZpZXdUYWcsIGRhdGVUYWcsIGZsb2F0MzJBcnJheVRhZywgZmxvYXQ2NEFycmF5VGFnLCBpbnQxNkFycmF5VGFnLCBpbnQzMkFycmF5VGFnLCBpbnQ4QXJyYXlUYWcsIG1hcFRhZywgbnVtYmVyVGFnLCBvYmplY3RUYWcsIHJlZ2V4cFRhZywgc2V0VGFnLCBzdHJpbmdUYWcsIHN5bWJvbFRhZywgdWludDE2QXJyYXlUYWcsIHVpbnQzMkFycmF5VGFnLCB1aW50OEFycmF5VGFnLCB1aW50OENsYW1wZWRBcnJheVRhZyB9IGZyb20gXCIuLi9jb21wYXQvX2ludGVybmFsL3RhZ3MubWpzXCI7XG5pbXBvcnQgeyBpc0J1ZmZlciB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNCdWZmZXIubWpzXCI7XG4vLyNyZWdpb24gc3JjL29iamVjdC9jbG9uZURlZXBXaXRoLnRzXG4vKipcbiogRGVlcGx5IGNsb25lcyB0aGUgZ2l2ZW4gb2JqZWN0LlxuKlxuKiBZb3UgY2FuIGN1c3RvbWl6ZSB0aGUgZGVlcCBjbG9uaW5nIHByb2Nlc3MgdXNpbmcgdGhlIGBjbG9uZVZhbHVlYCBmdW5jdGlvbi5cbiogVGhlIGZ1bmN0aW9uIHRha2VzIHRoZSBjdXJyZW50IHZhbHVlIGB2YWx1ZWAsIHRoZSBwcm9wZXJ0eSBuYW1lIGBrZXlgLCBhbmQgdGhlIGVudGlyZSBvYmplY3QgYG9iamAgYXMgYXJndW1lbnRzLlxuKiBJZiB0aGUgZnVuY3Rpb24gcmV0dXJucyBhIHZhbHVlLCB0aGF0IHZhbHVlIGlzIHVzZWQ7XG4qIGlmIGl0IHJldHVybnMgYHVuZGVmaW5lZGAsIHRoZSBkZWZhdWx0IGNsb25pbmcgbWV0aG9kIGlzIHVzZWQuXG4qXG4qIEB0ZW1wbGF0ZSBUIC0gVGhlIHR5cGUgb2YgdGhlIG9iamVjdC5cbiogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gY2xvbmUuXG4qIEBwYXJhbSBbY2xvbmVWYWx1ZV0gLSBBIGZ1bmN0aW9uIHRvIGN1c3RvbWl6ZSB0aGUgY2xvbmluZyBwcm9jZXNzLlxuKiBAcmV0dXJucyBBIGRlZXAgY2xvbmUgb2YgdGhlIGdpdmVuIG9iamVjdC5cbipcbiogQGV4YW1wbGVcbiogLy8gQ2xvbmUgYSBwcmltaXRpdmUgdmFsdWVcbiogY29uc3QgbnVtID0gMjk7XG4qIGNvbnN0IGNsb25lZE51bSA9IGNsb25lRGVlcFdpdGgobnVtKTtcbiogY29uc29sZS5sb2coY2xvbmVkTnVtKTsgLy8gMjlcbiogY29uc29sZS5sb2coY2xvbmVkTnVtID09PSBudW0pOyAvLyB0cnVlXG4qXG4qIEBleGFtcGxlXG4qIC8vIENsb25lIGFuIG9iamVjdCB3aXRoIGEgY3VzdG9taXplclxuKiBjb25zdCBvYmogPSB7IGE6IDEsIGI6IDIgfTtcbiogY29uc3QgY2xvbmVkT2JqID0gY2xvbmVEZWVwV2l0aChvYmosICh2YWx1ZSkgPT4ge1xuKiAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4qICAgICByZXR1cm4gdmFsdWUgKiAyOyAvLyBEb3VibGUgdGhlIG51bWJlclxuKiAgIH1cbiogfSk7XG4qIGNvbnNvbGUubG9nKGNsb25lZE9iaik7IC8vIHsgYTogMiwgYjogNCB9XG4qIGNvbnNvbGUubG9nKGNsb25lZE9iaiA9PT0gb2JqKTsgLy8gZmFsc2VcbipcbiogQGV4YW1wbGVcbiogLy8gQ2xvbmUgYW4gYXJyYXkgd2l0aCBhIGN1c3RvbWl6ZXJcbiogY29uc3QgYXJyID0gWzEsIDIsIDNdO1xuKiBjb25zdCBjbG9uZWRBcnIgPSBjbG9uZURlZXBXaXRoKGFyciwgKHZhbHVlKSA9PiB7XG4qICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcbiogICAgIHJldHVybiB2YWx1ZSArIDE7IC8vIEluY3JlbWVudCBlYWNoIG51bWJlclxuKiAgIH1cbiogfSk7XG4qIGNvbnNvbGUubG9nKGNsb25lZEFycik7IC8vIFsyLCAzLCA0XVxuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIgPT09IGFycik7IC8vIGZhbHNlXG4qL1xuZnVuY3Rpb24gY2xvbmVEZWVwV2l0aChvYmosIGNsb25lVmFsdWUpIHtcblx0cmV0dXJuIGNsb25lRGVlcFdpdGhJbXBsKG9iaiwgdm9pZCAwLCBvYmosIC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksIGNsb25lVmFsdWUpO1xufVxuZnVuY3Rpb24gY2xvbmVEZWVwV2l0aEltcGwodmFsdWVUb0Nsb25lLCBrZXlUb0Nsb25lLCBvYmplY3RUb0Nsb25lLCBzdGFjayA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksIGNsb25lVmFsdWUgPSB2b2lkIDApIHtcblx0Y29uc3QgY2xvbmVkID0gY2xvbmVWYWx1ZT8uKHZhbHVlVG9DbG9uZSwga2V5VG9DbG9uZSwgb2JqZWN0VG9DbG9uZSwgc3RhY2spO1xuXHRpZiAoY2xvbmVkICE9PSB2b2lkIDApIHJldHVybiBjbG9uZWQ7XG5cdGlmIChpc1ByaW1pdGl2ZSh2YWx1ZVRvQ2xvbmUpKSByZXR1cm4gdmFsdWVUb0Nsb25lO1xuXHRpZiAoc3RhY2suaGFzKHZhbHVlVG9DbG9uZSkpIHJldHVybiBzdGFjay5nZXQodmFsdWVUb0Nsb25lKTtcblx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWVUb0Nsb25lKSkge1xuXHRcdGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheSh2YWx1ZVRvQ2xvbmUubGVuZ3RoKTtcblx0XHRzdGFjay5zZXQodmFsdWVUb0Nsb25lLCByZXN1bHQpO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWVUb0Nsb25lLmxlbmd0aDsgaSsrKSByZXN1bHRbaV0gPSBjbG9uZURlZXBXaXRoSW1wbCh2YWx1ZVRvQ2xvbmVbaV0sIGksIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKTtcblx0XHRpZiAoT2JqZWN0Lmhhc093bih2YWx1ZVRvQ2xvbmUsIFwiaW5kZXhcIikpIHJlc3VsdC5pbmRleCA9IHZhbHVlVG9DbG9uZS5pbmRleDtcblx0XHRpZiAoT2JqZWN0Lmhhc093bih2YWx1ZVRvQ2xvbmUsIFwiaW5wdXRcIikpIHJlc3VsdC5pbnB1dCA9IHZhbHVlVG9DbG9uZS5pbnB1dDtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdGlmICh2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBEYXRlKSByZXR1cm4gbmV3IERhdGUodmFsdWVUb0Nsb25lLmdldFRpbWUoKSk7XG5cdGlmICh2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBSZWdFeHApIHtcblx0XHRjb25zdCByZXN1bHQgPSBuZXcgUmVnRXhwKHZhbHVlVG9DbG9uZS5zb3VyY2UsIHZhbHVlVG9DbG9uZS5mbGFncyk7XG5cdFx0cmVzdWx0Lmxhc3RJbmRleCA9IHZhbHVlVG9DbG9uZS5sYXN0SW5kZXg7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHRpZiAodmFsdWVUb0Nsb25lIGluc3RhbmNlb2YgTWFwKSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRzdGFjay5zZXQodmFsdWVUb0Nsb25lLCByZXN1bHQpO1xuXHRcdGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHZhbHVlVG9DbG9uZSkgcmVzdWx0LnNldChrZXksIGNsb25lRGVlcFdpdGhJbXBsKHZhbHVlLCBrZXksIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHRpZiAodmFsdWVUb0Nsb25lIGluc3RhbmNlb2YgU2V0KSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRzdGFjay5zZXQodmFsdWVUb0Nsb25lLCByZXN1bHQpO1xuXHRcdGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVUb0Nsb25lKSByZXN1bHQuYWRkKGNsb25lRGVlcFdpdGhJbXBsKHZhbHVlLCB2b2lkIDAsIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHRpZiAoaXNCdWZmZXIodmFsdWVUb0Nsb25lKSkgcmV0dXJuIHZhbHVlVG9DbG9uZS5zdWJhcnJheSgpO1xuXHRpZiAoaXNUeXBlZEFycmF5KHZhbHVlVG9DbG9uZSkpIHtcblx0XHRjb25zdCByZXN1bHQgPSBuZXcgKE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWx1ZVRvQ2xvbmUpKS5jb25zdHJ1Y3Rvcih2YWx1ZVRvQ2xvbmUubGVuZ3RoKTtcblx0XHRzdGFjay5zZXQodmFsdWVUb0Nsb25lLCByZXN1bHQpO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWVUb0Nsb25lLmxlbmd0aDsgaSsrKSByZXN1bHRbaV0gPSBjbG9uZURlZXBXaXRoSW1wbCh2YWx1ZVRvQ2xvbmVbaV0sIGksIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdGlmICh2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciB8fCB0eXBlb2YgU2hhcmVkQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgdmFsdWVUb0Nsb25lIGluc3RhbmNlb2YgU2hhcmVkQXJyYXlCdWZmZXIpIHJldHVybiB2YWx1ZVRvQ2xvbmUuc2xpY2UoMCk7XG5cdGlmICh2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBEYXRhVmlldykge1xuXHRcdGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRhVmlldyh2YWx1ZVRvQ2xvbmUuYnVmZmVyLnNsaWNlKDApLCB2YWx1ZVRvQ2xvbmUuYnl0ZU9mZnNldCwgdmFsdWVUb0Nsb25lLmJ5dGVMZW5ndGgpO1xuXHRcdHN0YWNrLnNldCh2YWx1ZVRvQ2xvbmUsIHJlc3VsdCk7XG5cdFx0Y29weVByb3BlcnRpZXMocmVzdWx0LCB2YWx1ZVRvQ2xvbmUsIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdGlmICh0eXBlb2YgRmlsZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBGaWxlKSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gbmV3IEZpbGUoW3ZhbHVlVG9DbG9uZV0sIHZhbHVlVG9DbG9uZS5uYW1lLCB7IHR5cGU6IHZhbHVlVG9DbG9uZS50eXBlIH0pO1xuXHRcdHN0YWNrLnNldCh2YWx1ZVRvQ2xvbmUsIHJlc3VsdCk7XG5cdFx0Y29weVByb3BlcnRpZXMocmVzdWx0LCB2YWx1ZVRvQ2xvbmUsIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdGlmICh0eXBlb2YgQmxvYiAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBCbG9iKSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gbmV3IEJsb2IoW3ZhbHVlVG9DbG9uZV0sIHsgdHlwZTogdmFsdWVUb0Nsb25lLnR5cGUgfSk7XG5cdFx0c3RhY2suc2V0KHZhbHVlVG9DbG9uZSwgcmVzdWx0KTtcblx0XHRjb3B5UHJvcGVydGllcyhyZXN1bHQsIHZhbHVlVG9DbG9uZSwgb2JqZWN0VG9DbG9uZSwgc3RhY2ssIGNsb25lVmFsdWUpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0aWYgKHZhbHVlVG9DbG9uZSBpbnN0YW5jZW9mIEVycm9yKSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gc3RydWN0dXJlZENsb25lKHZhbHVlVG9DbG9uZSk7XG5cdFx0c3RhY2suc2V0KHZhbHVlVG9DbG9uZSwgcmVzdWx0KTtcblx0XHRyZXN1bHQubWVzc2FnZSA9IHZhbHVlVG9DbG9uZS5tZXNzYWdlO1xuXHRcdHJlc3VsdC5uYW1lID0gdmFsdWVUb0Nsb25lLm5hbWU7XG5cdFx0cmVzdWx0LnN0YWNrID0gdmFsdWVUb0Nsb25lLnN0YWNrO1xuXHRcdHJlc3VsdC5jYXVzZSA9IHZhbHVlVG9DbG9uZS5jYXVzZTtcblx0XHRyZXN1bHQuY29uc3RydWN0b3IgPSB2YWx1ZVRvQ2xvbmUuY29uc3RydWN0b3I7XG5cdFx0Y29weVByb3BlcnRpZXMocmVzdWx0LCB2YWx1ZVRvQ2xvbmUsIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdGlmICh2YWx1ZVRvQ2xvbmUgaW5zdGFuY2VvZiBCb29sZWFuKSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gbmV3IEJvb2xlYW4odmFsdWVUb0Nsb25lLnZhbHVlT2YoKSk7XG5cdFx0c3RhY2suc2V0KHZhbHVlVG9DbG9uZSwgcmVzdWx0KTtcblx0XHRjb3B5UHJvcGVydGllcyhyZXN1bHQsIHZhbHVlVG9DbG9uZSwgb2JqZWN0VG9DbG9uZSwgc3RhY2ssIGNsb25lVmFsdWUpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0aWYgKHZhbHVlVG9DbG9uZSBpbnN0YW5jZW9mIE51bWJlcikge1xuXHRcdGNvbnN0IHJlc3VsdCA9IG5ldyBOdW1iZXIodmFsdWVUb0Nsb25lLnZhbHVlT2YoKSk7XG5cdFx0c3RhY2suc2V0KHZhbHVlVG9DbG9uZSwgcmVzdWx0KTtcblx0XHRjb3B5UHJvcGVydGllcyhyZXN1bHQsIHZhbHVlVG9DbG9uZSwgb2JqZWN0VG9DbG9uZSwgc3RhY2ssIGNsb25lVmFsdWUpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0aWYgKHZhbHVlVG9DbG9uZSBpbnN0YW5jZW9mIFN0cmluZykge1xuXHRcdGNvbnN0IHJlc3VsdCA9IG5ldyBTdHJpbmcodmFsdWVUb0Nsb25lLnZhbHVlT2YoKSk7XG5cdFx0c3RhY2suc2V0KHZhbHVlVG9DbG9uZSwgcmVzdWx0KTtcblx0XHRjb3B5UHJvcGVydGllcyhyZXN1bHQsIHZhbHVlVG9DbG9uZSwgb2JqZWN0VG9DbG9uZSwgc3RhY2ssIGNsb25lVmFsdWUpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0aWYgKHR5cGVvZiB2YWx1ZVRvQ2xvbmUgPT09IFwib2JqZWN0XCIgJiYgaXNDbG9uZWFibGVPYmplY3QodmFsdWVUb0Nsb25lKSkge1xuXHRcdGNvbnN0IHJlc3VsdCA9IE9iamVjdC5jcmVhdGUoT2JqZWN0LmdldFByb3RvdHlwZU9mKHZhbHVlVG9DbG9uZSkpO1xuXHRcdHN0YWNrLnNldCh2YWx1ZVRvQ2xvbmUsIHJlc3VsdCk7XG5cdFx0Y29weVByb3BlcnRpZXMocmVzdWx0LCB2YWx1ZVRvQ2xvbmUsIG9iamVjdFRvQ2xvbmUsIHN0YWNrLCBjbG9uZVZhbHVlKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdHJldHVybiB2YWx1ZVRvQ2xvbmU7XG59XG5mdW5jdGlvbiBjb3B5UHJvcGVydGllcyh0YXJnZXQsIHNvdXJjZSwgb2JqZWN0VG9DbG9uZSA9IHRhcmdldCwgc3RhY2ssIGNsb25lVmFsdWUpIHtcblx0Y29uc3Qga2V5cyA9IFsuLi5PYmplY3Qua2V5cyhzb3VyY2UpLCAuLi5nZXRTeW1ib2xzKHNvdXJjZSldO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBrZXkgPSBrZXlzW2ldO1xuXHRcdGNvbnN0IGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KTtcblx0XHRpZiAoZGVzY3JpcHRvciA9PSBudWxsIHx8IGRlc2NyaXB0b3Iud3JpdGFibGUpIHRhcmdldFtrZXldID0gY2xvbmVEZWVwV2l0aEltcGwoc291cmNlW2tleV0sIGtleSwgb2JqZWN0VG9DbG9uZSwgc3RhY2ssIGNsb25lVmFsdWUpO1xuXHR9XG59XG5mdW5jdGlvbiBpc0Nsb25lYWJsZU9iamVjdChvYmplY3QpIHtcblx0c3dpdGNoIChnZXRUYWcob2JqZWN0KSkge1xuXHRcdGNhc2UgYXJndW1lbnRzVGFnOlxuXHRcdGNhc2UgYXJyYXlUYWc6XG5cdFx0Y2FzZSBhcnJheUJ1ZmZlclRhZzpcblx0XHRjYXNlIGRhdGFWaWV3VGFnOlxuXHRcdGNhc2UgYm9vbGVhblRhZzpcblx0XHRjYXNlIGRhdGVUYWc6XG5cdFx0Y2FzZSBmbG9hdDMyQXJyYXlUYWc6XG5cdFx0Y2FzZSBmbG9hdDY0QXJyYXlUYWc6XG5cdFx0Y2FzZSBpbnQ4QXJyYXlUYWc6XG5cdFx0Y2FzZSBpbnQxNkFycmF5VGFnOlxuXHRcdGNhc2UgaW50MzJBcnJheVRhZzpcblx0XHRjYXNlIG1hcFRhZzpcblx0XHRjYXNlIG51bWJlclRhZzpcblx0XHRjYXNlIG9iamVjdFRhZzpcblx0XHRjYXNlIHJlZ2V4cFRhZzpcblx0XHRjYXNlIHNldFRhZzpcblx0XHRjYXNlIHN0cmluZ1RhZzpcblx0XHRjYXNlIHN5bWJvbFRhZzpcblx0XHRjYXNlIHVpbnQ4QXJyYXlUYWc6XG5cdFx0Y2FzZSB1aW50OENsYW1wZWRBcnJheVRhZzpcblx0XHRjYXNlIHVpbnQxNkFycmF5VGFnOlxuXHRcdGNhc2UgdWludDMyQXJyYXlUYWc6IHJldHVybiB0cnVlO1xuXHRcdGRlZmF1bHQ6IHJldHVybiBmYWxzZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjbG9uZURlZXBXaXRoLCBjbG9uZURlZXBXaXRoSW1wbCwgY29weVByb3BlcnRpZXMgfTtcbiIsImltcG9ydCB7IGNsb25lRGVlcFdpdGhJbXBsIH0gZnJvbSBcIi4vY2xvbmVEZWVwV2l0aC5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvb2JqZWN0L2Nsb25lRGVlcC50c1xuLyoqXG4qIENyZWF0ZXMgYSBkZWVwIGNsb25lIG9mIHRoZSBnaXZlbiBvYmplY3QuXG4qXG4qIEB0ZW1wbGF0ZSBUIC0gVGhlIHR5cGUgb2YgdGhlIG9iamVjdC5cbiogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gY2xvbmUuXG4qIEByZXR1cm5zIEEgZGVlcCBjbG9uZSBvZiB0aGUgZ2l2ZW4gb2JqZWN0LlxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhIHByaW1pdGl2ZSB2YWx1ZVxuKiBjb25zdCBudW0gPSAyOTtcbiogY29uc3QgY2xvbmVkTnVtID0gY2xvbmVEZWVwKG51bSk7XG4qIGNvbnNvbGUubG9nKGNsb25lZE51bSk7IC8vIDI5XG4qIGNvbnNvbGUubG9nKGNsb25lZE51bSA9PT0gbnVtKTsgLy8gdHJ1ZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBhcnJheVxuKiBjb25zdCBhcnIgPSBbMSwgMiwgM107XG4qIGNvbnN0IGNsb25lZEFyciA9IGNsb25lRGVlcChhcnIpO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIpOyAvLyBbMSwgMiwgM11cbiogY29uc29sZS5sb2coY2xvbmVkQXJyID09PSBhcnIpOyAvLyBmYWxzZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBhcnJheSB3aXRoIG5lc3RlZCBvYmplY3RzXG4qIGNvbnN0IGFyciA9IFsxLCB7IGE6IDEgfSwgWzEsIDIsIDNdXTtcbiogY29uc3QgY2xvbmVkQXJyID0gY2xvbmVEZWVwKGFycik7XG4qIGFyclsxXS5hID0gMjtcbiogY29uc29sZS5sb2coYXJyKTsgLy8gWzEsIHsgYTogMiB9LCBbMSwgMiwgM11dXG4qIGNvbnNvbGUubG9nKGNsb25lZEFycik7IC8vIFsxLCB7IGE6IDEgfSwgWzEsIDIsIDNdXVxuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIgPT09IGFycik7IC8vIGZhbHNlXG4qXG4qIEBleGFtcGxlXG4qIC8vIENsb25lIGFuIG9iamVjdFxuKiBjb25zdCBvYmogPSB7IGE6IDEsIGI6ICdlcy10b29sa2l0JywgYzogWzEsIDIsIDNdIH07XG4qIGNvbnN0IGNsb25lZE9iaiA9IGNsb25lRGVlcChvYmopO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmopOyAvLyB7IGE6IDEsIGI6ICdlcy10b29sa2l0JywgYzogWzEsIDIsIDNdIH1cbiogY29uc29sZS5sb2coY2xvbmVkT2JqID09PSBvYmopOyAvLyBmYWxzZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBvYmplY3Qgd2l0aCBuZXN0ZWQgb2JqZWN0c1xuKiBjb25zdCBvYmogPSB7IGE6IDEsIGI6IHsgYzogMSB9IH07XG4qIGNvbnN0IGNsb25lZE9iaiA9IGNsb25lRGVlcChvYmopO1xuKiBvYmouYi5jID0gMjtcbiogY29uc29sZS5sb2cob2JqKTsgLy8geyBhOiAxLCBiOiB7IGM6IDIgfSB9XG4qIGNvbnNvbGUubG9nKGNsb25lZE9iaik7IC8vIHsgYTogMSwgYjogeyBjOiAxIH0gfVxuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmogPT09IG9iaik7IC8vIGZhbHNlXG4qL1xuZnVuY3Rpb24gY2xvbmVEZWVwKG9iaikge1xuXHRyZXR1cm4gY2xvbmVEZWVwV2l0aEltcGwob2JqLCB2b2lkIDAsIG9iaiwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSwgdm9pZCAwKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY2xvbmVEZWVwIH07XG4iLCIvLyNyZWdpb24gc3JjL3ByZWRpY2F0ZS9pc1BsYWluT2JqZWN0LnRzXG4vKipcbiogQ2hlY2tzIGlmIGEgZ2l2ZW4gdmFsdWUgaXMgYSBwbGFpbiBvYmplY3QuXG4qXG4qIEBwYXJhbSB2YWx1ZSAtIFRoZSB2YWx1ZSB0byBjaGVjay5cbiogQHJldHVybnMgVHJ1ZSBpZiB0aGUgdmFsdWUgaXMgYSBwbGFpbiBvYmplY3QsIG90aGVyd2lzZSBmYWxzZS5cbipcbiogQGV4YW1wbGVcbiogYGBgdHlwZXNjcmlwdFxuKiAvLyDinIXwn5GHIFRydWVcbipcbiogaXNQbGFpbk9iamVjdCh7IH0pOyAgICAgICAgICAgICAgICAgICAgICAgLy8g4pyFXG4qIGlzUGxhaW5PYmplY3QoeyBrZXk6ICd2YWx1ZScgfSk7ICAgICAgICAgIC8vIOKchVxuKiBpc1BsYWluT2JqZWN0KHsga2V5OiBuZXcgRGF0ZSgpIH0pOyAgICAgICAvLyDinIVcbiogaXNQbGFpbk9iamVjdChuZXcgT2JqZWN0KCkpOyAgICAgICAgICAgICAgLy8g4pyFXG4qIGlzUGxhaW5PYmplY3QoT2JqZWN0LmNyZWF0ZShudWxsKSk7ICAgICAgIC8vIOKchVxuKiBpc1BsYWluT2JqZWN0KHsgbmVzdGVkOiB7IGtleTogdHJ1ZX0gfSk7ICAvLyDinIVcbiogaXNQbGFpbk9iamVjdChuZXcgUHJveHkoe30sIHt9KSk7ICAgICAgICAgLy8g4pyFXG4qIGlzUGxhaW5PYmplY3QoeyBbU3ltYm9sKCd0YWcnKV06ICdBJyB9KTsgIC8vIOKchVxuKlxuKiAvLyDinIXwn5GHIChjcm9zcy1yZWFsbXMsIG5vZGUgY29udGV4dCwgd29ya2VycywgLi4uKVxuKiBjb25zdCBydW5Jbk5ld0NvbnRleHQgPSBhd2FpdCBpbXBvcnQoJ25vZGU6dm0nKS50aGVuKFxuKiAgICAgKG1vZCkgPT4gbW9kLnJ1bkluTmV3Q29udGV4dFxuKiApO1xuKiBpc1BsYWluT2JqZWN0KHJ1bkluTmV3Q29udGV4dCgnKHt9KScpKTsgICAvLyDinIVcbipcbiogLy8g4p2M8J+RhyBGYWxzZVxuKlxuKiBjbGFzcyBUZXN0IHsgfTtcbiogaXNQbGFpbk9iamVjdChuZXcgVGVzdCgpKSAgICAgICAgICAgLy8g4p2MXG4qIGlzUGxhaW5PYmplY3QoMTApOyAgICAgICAgICAgICAgICAgIC8vIOKdjFxuKiBpc1BsYWluT2JqZWN0KG51bGwpOyAgICAgICAgICAgICAgICAvLyDinYxcbiogaXNQbGFpbk9iamVjdCgnaGVsbG8nKTsgICAgICAgICAgICAgLy8g4p2MXG4qIGlzUGxhaW5PYmplY3QoW10pOyAgICAgICAgICAgICAgICAgIC8vIOKdjFxuKiBpc1BsYWluT2JqZWN0KG5ldyBEYXRlKCkpOyAgICAgICAgICAvLyDinYxcbiogaXNQbGFpbk9iamVjdChuZXcgVWludDhBcnJheShbMV0pKTsgLy8g4p2MXG4qIGlzUGxhaW5PYmplY3QoQnVmZmVyLmZyb20oJ0FCQycpKTsgIC8vIOKdjFxuKiBpc1BsYWluT2JqZWN0KFByb21pc2UucmVzb2x2ZSh7fSkpOyAvLyDinYxcbiogaXNQbGFpbk9iamVjdChPYmplY3QuY3JlYXRlKHt9KSk7ICAgLy8g4p2MXG4qIGlzUGxhaW5PYmplY3QobmV3IChjbGFzcyBDbHMge30pKTsgIC8vIOKdjFxuKiBpc1BsYWluT2JqZWN0KGdsb2JhbFRoaXMpOyAgICAgICAgICAvLyDinYwsXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3QodmFsdWUpIHtcblx0aWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09IFwib2JqZWN0XCIpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgcHJvdG8gPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YodmFsdWUpO1xuXHRpZiAoIShwcm90byA9PT0gbnVsbCB8fCBwcm90byA9PT0gT2JqZWN0LnByb3RvdHlwZSB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2YocHJvdG8pID09PSBudWxsKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNQbGFpbk9iamVjdCB9O1xuIiwiLy8jcmVnaW9uIHNyYy9faW50ZXJuYWwvaXNVbnNhZmVQcm9wZXJ0eS50c1xuLyoqXG4qIENoZWNrcyBpZiBhIHByb3BlcnR5IGtleSBpcyB1bnNhZmUgdG8gYWNjZXNzIG9yIGNvcHkgZGlyZWN0bHkuXG4qXG4qIFRoaXMgZnVuY3Rpb24gaXMgdXNlZCBpbiBmdW5jdGlvbnMgbGlrZSBgZ2V0YCwgYHVuc2V0YCwgYW5kIGBtZXJnZWAgdG8gcHJldmVudFxuKiBwcm90b3R5cGUgcG9sbHV0aW9uIGF0dGFja3MgYnkgaWRlbnRpZnlpbmcgYF9fcHJvdG9fX2AsIHdoaWNoIG1vZGlmaWVzIHRoZSBvYmplY3Qnc1xuKiBwcm90b3R5cGUgY2hhaW4uIGBjb25zdHJ1Y3RvcmAgYW5kIGBwcm90b3R5cGVgIHN0YXkgYWNjZXNzaWJsZSBoZXJlIGJlY2F1c2UgbG9kYXNoXG4qIGtlZXBzIHJlYWRzIG9mIHRoZW0gdW5yZXN0cmljdGVkOyB3cml0ZSBwYXRocyB1c2UgYGlzVW5zYWZlVG9Xcml0ZVByb3BlcnR5YCBpbnN0ZWFkLFxuKiB3aGljaCBhbHNvIGJsb2NrcyB0aG9zZSBrZXlzLlxuKlxuKiBAcGFyYW0ga2V5IC0gVGhlIHByb3BlcnR5IGtleSB0byBjaGVja1xuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHByb3BlcnR5IGlzIHVuc2FmZSB0byBhY2Nlc3MgZGlyZWN0bHksIGBmYWxzZWAgb3RoZXJ3aXNlXG4qIEBpbnRlcm5hbFxuKi9cbmZ1bmN0aW9uIGlzVW5zYWZlUHJvcGVydHkoa2V5KSB7XG5cdHJldHVybiBrZXkgPT09IFwiX19wcm90b19fXCI7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzVW5zYWZlUHJvcGVydHkgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvY29tcGF0L3ByZWRpY2F0ZS9pc1BsYWluT2JqZWN0LnRzXG4vKipcbiogQ2hlY2tzIGlmIGEgZ2l2ZW4gdmFsdWUgaXMgYSBwbGFpbiBvYmplY3QuXG4qXG4qIEEgcGxhaW4gb2JqZWN0IGlzIGFuIG9iamVjdCBjcmVhdGVkIGJ5IHRoZSBge31gIGxpdGVyYWwsIGBuZXcgT2JqZWN0KClgLCBvclxuKiBgT2JqZWN0LmNyZWF0ZShudWxsKWAuXG4qXG4qIFRoaXMgZnVuY3Rpb24gYWxzbyBoYW5kbGVzIG9iamVjdHMgd2l0aCBjdXN0b21cbiogYFN5bWJvbC50b1N0cmluZ1RhZ2AgcHJvcGVydGllcy5cbipcbiogYFN5bWJvbC50b1N0cmluZ1RhZ2AgaXMgYSBidWlsdC1pbiBzeW1ib2wgdGhhdCBhIGNvbnN0cnVjdG9yIGNhbiB1c2UgdG8gY3VzdG9taXplIHRoZVxuKiBkZWZhdWx0IHN0cmluZyBkZXNjcmlwdGlvbiBvZiBvYmplY3RzLlxuKlxuKiBAcGFyYW0gW29iamVjdF0gLSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIFRydWUgaWYgdGhlIHZhbHVlIGlzIGEgcGxhaW4gb2JqZWN0LCBvdGhlcndpc2UgZmFsc2UuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnNvbGUubG9nKGlzUGxhaW5PYmplY3Qoe30pKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc1BsYWluT2JqZWN0KFtdKSk7IC8vIGZhbHNlXG4qIGNvbnNvbGUubG9nKGlzUGxhaW5PYmplY3QobnVsbCkpOyAvLyBmYWxzZVxuKiBjb25zb2xlLmxvZyhpc1BsYWluT2JqZWN0KE9iamVjdC5jcmVhdGUobnVsbCkpKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc1BsYWluT2JqZWN0KG5ldyBNYXAoKSkpOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qob2JqZWN0KSB7XG5cdGlmICh0eXBlb2Ygb2JqZWN0ICE9PSBcIm9iamVjdFwiKSByZXR1cm4gZmFsc2U7XG5cdGlmIChvYmplY3QgPT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iamVjdCkgPT09IG51bGwpIHJldHVybiB0cnVlO1xuXHRpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iamVjdCkgIT09IFwiW29iamVjdCBPYmplY3RdXCIpIHtcblx0XHRjb25zdCB0YWcgPSBvYmplY3RbU3ltYm9sLnRvU3RyaW5nVGFnXTtcblx0XHRpZiAodGFnID09IG51bGwpIHJldHVybiBmYWxzZTtcblx0XHRpZiAoIU9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqZWN0LCBTeW1ib2wudG9TdHJpbmdUYWcpPy53cml0YWJsZSkgcmV0dXJuIGZhbHNlO1xuXHRcdHJldHVybiBvYmplY3QudG9TdHJpbmcoKSA9PT0gYFtvYmplY3QgJHt0YWd9XWA7XG5cdH1cblx0bGV0IHByb3RvID0gb2JqZWN0O1xuXHR3aGlsZSAoT2JqZWN0LmdldFByb3RvdHlwZU9mKHByb3RvKSAhPT0gbnVsbCkgcHJvdG8gPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YocHJvdG8pO1xuXHRyZXR1cm4gT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iamVjdCkgPT09IHByb3RvO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc1BsYWluT2JqZWN0IH07XG4iLCIvLyNyZWdpb24gc3JjL2NvbXBhdC91dGlsL2VxLnRzXG4vKipcbiogUGVyZm9ybXMgYSBgU2FtZVZhbHVlWmVyb2AgY29tcGFyaXNvbiBiZXR3ZWVuIHR3byB2YWx1ZXMgdG8gZGV0ZXJtaW5lIGlmIHRoZXkgYXJlIGVxdWl2YWxlbnQuXG4qXG4qIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gY29tcGFyZS5cbiogQHBhcmFtIG90aGVyIFRoZSBvdGhlciB2YWx1ZSB0byBjb21wYXJlLlxuKiBAcmV0dXJucyBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgdmFsdWVzIGFyZSBlcXVpdmFsZW50LCBlbHNlIGBmYWxzZWAuXG4qXG4qIEBleGFtcGxlXG4qIGVxKDEsIDEpOyAvLyB0cnVlXG4qIGVxKDAsIC0wKTsgLy8gdHJ1ZVxuKiBlcShOYU4sIE5hTik7IC8vIHRydWVcbiogZXEoJ2EnLCBPYmplY3QoJ2EnKSk7IC8vIGZhbHNlXG4qL1xuZnVuY3Rpb24gZXEodmFsdWUsIG90aGVyKSB7XG5cdHJldHVybiB2YWx1ZSA9PT0gb3RoZXIgfHwgTnVtYmVyLmlzTmFOKHZhbHVlKSAmJiBOdW1iZXIuaXNOYU4ob3RoZXIpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBlcSB9O1xuIiwiaW1wb3J0IHsgZ2V0U3ltYm9scyB9IGZyb20gXCIuLi9jb21wYXQvX2ludGVybmFsL2dldFN5bWJvbHMubWpzXCI7XG5pbXBvcnQgeyBnZXRUYWcgfSBmcm9tIFwiLi4vY29tcGF0L19pbnRlcm5hbC9nZXRUYWcubWpzXCI7XG5pbXBvcnQgeyBhcnJheUJ1ZmZlclRhZywgYXJyYXlUYWcsIGJpZ0ludDY0QXJyYXlUYWcsIGJpZ1VpbnQ2NEFycmF5VGFnLCBib29sZWFuVGFnLCBkYXRhVmlld1RhZywgZGF0ZVRhZywgZXJyb3JUYWcsIGZsb2F0MzJBcnJheVRhZywgZmxvYXQ2NEFycmF5VGFnLCBmdW5jdGlvblRhZywgaW50MTZBcnJheVRhZywgaW50MzJBcnJheVRhZywgaW50OEFycmF5VGFnLCBtYXBUYWcsIG51bWJlclRhZywgb2JqZWN0VGFnLCByZWdleHBUYWcsIHNldFRhZywgc3RyaW5nVGFnLCBzeW1ib2xUYWcsIHVpbnQxNkFycmF5VGFnLCB1aW50MzJBcnJheVRhZywgdWludDhBcnJheVRhZywgdWludDhDbGFtcGVkQXJyYXlUYWcgfSBmcm9tIFwiLi4vY29tcGF0L19pbnRlcm5hbC90YWdzLm1qc1wiO1xuaW1wb3J0IHsgaXNCdWZmZXIgfSBmcm9tIFwiLi9pc0J1ZmZlci5tanNcIjtcbmltcG9ydCB7IGlzUGxhaW5PYmplY3QgfSBmcm9tIFwiLi9pc1BsYWluT2JqZWN0Lm1qc1wiO1xuaW1wb3J0IHsgZXEgfSBmcm9tIFwiLi4vY29tcGF0L3V0aWwvZXEubWpzXCI7XG4vLyNyZWdpb24gc3JjL3ByZWRpY2F0ZS9pc0VxdWFsV2l0aC50c1xuLyoqXG4qIENvbXBhcmVzIHR3byB2YWx1ZXMgZm9yIGVxdWFsaXR5IHVzaW5nIGEgY3VzdG9tIGNvbXBhcmlzb24gZnVuY3Rpb24uXG4qXG4qIFRoZSBjdXN0b20gZnVuY3Rpb24gYWxsb3dzIGZvciBmaW5lLXR1bmVkIGNvbnRyb2wgb3ZlciB0aGUgY29tcGFyaXNvbiBwcm9jZXNzLiBJZiBpdCByZXR1cm5zIGEgYm9vbGVhbiwgdGhhdCByZXN1bHQgZGV0ZXJtaW5lcyB0aGUgZXF1YWxpdHkuIElmIGl0IHJldHVybnMgdW5kZWZpbmVkLCB0aGUgZnVuY3Rpb24gZmFsbHMgYmFjayB0byB0aGUgZGVmYXVsdCBlcXVhbGl0eSBjb21wYXJpc29uLlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGFsc28gdXNlcyB0aGUgY3VzdG9tIGVxdWFsaXR5IGZ1bmN0aW9uIHRvIGNvbXBhcmUgdmFsdWVzIGluc2lkZSBvYmplY3RzLFxuKiBhcnJheXMsIG1hcHMsIHNldHMsIGFuZCBvdGhlciBjb21wbGV4IHN0cnVjdHVyZXMsIGVuc3VyaW5nIGEgZGVlcCBjb21wYXJpc29uLlxuKlxuKiBUaGlzIGFwcHJvYWNoIHByb3ZpZGVzIGZsZXhpYmlsaXR5IGluIGhhbmRsaW5nIGNvbXBsZXggY29tcGFyaXNvbnMgd2hpbGUgbWFpbnRhaW5pbmcgZWZmaWNpZW50IGRlZmF1bHQgYmVoYXZpb3IgZm9yIHNpbXBsZXIgY2FzZXMuXG4qXG4qIFRoZSBjdXN0b20gY29tcGFyaXNvbiBmdW5jdGlvbiBjYW4gdGFrZSB1cCB0byBzaXggcGFyYW1ldGVyczpcbiogLSBgeGA6IFRoZSB2YWx1ZSBmcm9tIHRoZSBmaXJzdCBvYmplY3QgYGFgLlxuKiAtIGB5YDogVGhlIHZhbHVlIGZyb20gdGhlIHNlY29uZCBvYmplY3QgYGJgLlxuKiAtIGBwcm9wZXJ0eWA6IFRoZSBwcm9wZXJ0eSBrZXkgdXNlZCB0byBnZXQgYHhgIGFuZCBgeWAuXG4qIC0gYHhQYXJlbnRgOiBUaGUgcGFyZW50IG9mIHRoZSBmaXJzdCB2YWx1ZSBgeGAuXG4qIC0gYHlQYXJlbnRgOiBUaGUgcGFyZW50IG9mIHRoZSBzZWNvbmQgdmFsdWUgYHlgLlxuKiAtIGBzdGFja2A6IEFuIGludGVybmFsIHN0YWNrIChNYXApIHRvIGhhbmRsZSBjaXJjdWxhciByZWZlcmVuY2VzLlxuKlxuKiBAcGFyYW0gYSAtIFRoZSBmaXJzdCB2YWx1ZSB0byBjb21wYXJlLlxuKiBAcGFyYW0gYiAtIFRoZSBzZWNvbmQgdmFsdWUgdG8gY29tcGFyZS5cbiogQHBhcmFtIGFyZVZhbHVlc0VxdWFsIC0gQSBmdW5jdGlvbiB0byBjdXN0b21pemUgdGhlIGNvbXBhcmlzb24uXG4qICAgSWYgaXQgcmV0dXJucyBhIGJvb2xlYW4sIHRoYXQgcmVzdWx0IHdpbGwgYmUgdXNlZC4gSWYgaXQgcmV0dXJucyB1bmRlZmluZWQsXG4qICAgdGhlIGRlZmF1bHQgZXF1YWxpdHkgY29tcGFyaXNvbiB3aWxsIGJlIHVzZWQuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgdmFsdWVzIGFyZSBlcXVhbCBhY2NvcmRpbmcgdG8gdGhlIGN1c3RvbWl6ZXIsIG90aGVyd2lzZSBgZmFsc2VgLlxuKlxuKiBAZXhhbXBsZVxuKiBjb25zdCBjdXN0b21pemVyID0gKGEsIGIpID0+IHtcbiogICBpZiAodHlwZW9mIGEgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBiID09PSAnc3RyaW5nJykge1xuKiAgICAgcmV0dXJuIGEudG9Mb3dlckNhc2UoKSA9PT0gYi50b0xvd2VyQ2FzZSgpO1xuKiAgIH1cbiogfTtcbiogaXNFcXVhbFdpdGgoJ0hlbGxvJywgJ2hlbGxvJywgY3VzdG9taXplcik7IC8vIHRydWVcbiogaXNFcXVhbFdpdGgoeyBhOiAnSGVsbG8nIH0sIHsgYTogJ2hlbGxvJyB9LCBjdXN0b21pemVyKTsgLy8gdHJ1ZVxuKiBpc0VxdWFsV2l0aChbMSwgMiwgM10sIFsxLCAyLCAzXSwgY3VzdG9taXplcik7IC8vIHRydWVcbiovXG5mdW5jdGlvbiBpc0VxdWFsV2l0aChhLCBiLCBhcmVWYWx1ZXNFcXVhbCkge1xuXHRyZXR1cm4gaXNFcXVhbFdpdGhJbXBsKGEsIGIsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgYXJlVmFsdWVzRXF1YWwpO1xufVxuZnVuY3Rpb24gaXNFcXVhbFdpdGhJbXBsKGEsIGIsIHByb3BlcnR5LCBhUGFyZW50LCBiUGFyZW50LCBzdGFjaywgYXJlVmFsdWVzRXF1YWwpIHtcblx0Y29uc3QgcmVzdWx0ID0gYXJlVmFsdWVzRXF1YWwoYSwgYiwgcHJvcGVydHksIGFQYXJlbnQsIGJQYXJlbnQsIHN0YWNrKTtcblx0aWYgKHJlc3VsdCAhPT0gdm9pZCAwKSByZXR1cm4gcmVzdWx0O1xuXHRpZiAodHlwZW9mIGEgPT09IHR5cGVvZiBiKSBzd2l0Y2ggKHR5cGVvZiBhKSB7XG5cdFx0Y2FzZSBcImJpZ2ludFwiOlxuXHRcdGNhc2UgXCJzdHJpbmdcIjpcblx0XHRjYXNlIFwiYm9vbGVhblwiOlxuXHRcdGNhc2UgXCJzeW1ib2xcIjpcblx0XHRjYXNlIFwidW5kZWZpbmVkXCI6IHJldHVybiBhID09PSBiO1xuXHRcdGNhc2UgXCJudW1iZXJcIjogcmV0dXJuIGEgPT09IGIgfHwgT2JqZWN0LmlzKGEsIGIpO1xuXHRcdGNhc2UgXCJmdW5jdGlvblwiOiByZXR1cm4gYSA9PT0gYjtcblx0XHRjYXNlIFwib2JqZWN0XCI6IHJldHVybiBhcmVPYmplY3RzRXF1YWwoYSwgYiwgc3RhY2ssIGFyZVZhbHVlc0VxdWFsKTtcblx0fVxuXHRyZXR1cm4gYXJlT2JqZWN0c0VxdWFsKGEsIGIsIHN0YWNrLCBhcmVWYWx1ZXNFcXVhbCk7XG59XG5mdW5jdGlvbiBhcmVPYmplY3RzRXF1YWwoYSwgYiwgc3RhY2ssIGFyZVZhbHVlc0VxdWFsKSB7XG5cdGlmIChPYmplY3QuaXMoYSwgYikpIHJldHVybiB0cnVlO1xuXHRsZXQgYVRhZyA9IGdldFRhZyhhKTtcblx0bGV0IGJUYWcgPSBnZXRUYWcoYik7XG5cdGlmIChhVGFnID09PSBcIltvYmplY3QgQXJndW1lbnRzXVwiKSBhVGFnID0gb2JqZWN0VGFnO1xuXHRpZiAoYlRhZyA9PT0gXCJbb2JqZWN0IEFyZ3VtZW50c11cIikgYlRhZyA9IG9iamVjdFRhZztcblx0aWYgKGFUYWcgIT09IGJUYWcpIHJldHVybiBmYWxzZTtcblx0c3dpdGNoIChhVGFnKSB7XG5cdFx0Y2FzZSBzdHJpbmdUYWc6IHJldHVybiBhLnRvU3RyaW5nKCkgPT09IGIudG9TdHJpbmcoKTtcblx0XHRjYXNlIG51bWJlclRhZzogcmV0dXJuIGVxKGEudmFsdWVPZigpLCBiLnZhbHVlT2YoKSk7XG5cdFx0Y2FzZSBib29sZWFuVGFnOlxuXHRcdGNhc2UgZGF0ZVRhZzpcblx0XHRjYXNlIHN5bWJvbFRhZzogcmV0dXJuIE9iamVjdC5pcyhhLnZhbHVlT2YoKSwgYi52YWx1ZU9mKCkpO1xuXHRcdGNhc2UgcmVnZXhwVGFnOiByZXR1cm4gYS5zb3VyY2UgPT09IGIuc291cmNlICYmIGEuZmxhZ3MgPT09IGIuZmxhZ3M7XG5cdFx0Y2FzZSBmdW5jdGlvblRhZzogcmV0dXJuIGEgPT09IGI7XG5cdH1cblx0c3RhY2sgPSBzdGFjayA/PyAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRjb25zdCBhU3RhY2sgPSBzdGFjay5nZXQoYSk7XG5cdGNvbnN0IGJTdGFjayA9IHN0YWNrLmdldChiKTtcblx0aWYgKGFTdGFjayAhPSBudWxsICYmIGJTdGFjayAhPSBudWxsKSByZXR1cm4gYVN0YWNrID09PSBiO1xuXHRzdGFjay5zZXQoYSwgYik7XG5cdHN0YWNrLnNldChiLCBhKTtcblx0dHJ5IHtcblx0XHRzd2l0Y2ggKGFUYWcpIHtcblx0XHRcdGNhc2UgbWFwVGFnOlxuXHRcdFx0XHRpZiAoYS5zaXplICE9PSBiLnNpemUpIHJldHVybiBmYWxzZTtcblx0XHRcdFx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgYS5lbnRyaWVzKCkpIGlmICghYi5oYXMoa2V5KSB8fCAhaXNFcXVhbFdpdGhJbXBsKHZhbHVlLCBiLmdldChrZXkpLCBrZXksIGEsIGIsIHN0YWNrLCBhcmVWYWx1ZXNFcXVhbCkpIHJldHVybiBmYWxzZTtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHRjYXNlIHNldFRhZzoge1xuXHRcdFx0XHRpZiAoYS5zaXplICE9PSBiLnNpemUpIHJldHVybiBmYWxzZTtcblx0XHRcdFx0Y29uc3QgYVZhbHVlcyA9IEFycmF5LmZyb20oYS52YWx1ZXMoKSk7XG5cdFx0XHRcdGNvbnN0IGJWYWx1ZXMgPSBBcnJheS5mcm9tKGIudmFsdWVzKCkpO1xuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGFWYWx1ZXMubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0XHRjb25zdCBhVmFsdWUgPSBhVmFsdWVzW2ldO1xuXHRcdFx0XHRcdGNvbnN0IGluZGV4ID0gYlZhbHVlcy5maW5kSW5kZXgoKGJWYWx1ZSkgPT4ge1xuXHRcdFx0XHRcdFx0cmV0dXJuIGlzRXF1YWxXaXRoSW1wbChhVmFsdWUsIGJWYWx1ZSwgdm9pZCAwLCBhLCBiLCBzdGFjaywgYXJlVmFsdWVzRXF1YWwpO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGlmIChpbmRleCA9PT0gLTEpIHJldHVybiBmYWxzZTtcblx0XHRcdFx0XHRiVmFsdWVzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0XHRjYXNlIGFycmF5VGFnOlxuXHRcdFx0Y2FzZSB1aW50OEFycmF5VGFnOlxuXHRcdFx0Y2FzZSB1aW50OENsYW1wZWRBcnJheVRhZzpcblx0XHRcdGNhc2UgdWludDE2QXJyYXlUYWc6XG5cdFx0XHRjYXNlIHVpbnQzMkFycmF5VGFnOlxuXHRcdFx0Y2FzZSBiaWdVaW50NjRBcnJheVRhZzpcblx0XHRcdGNhc2UgaW50OEFycmF5VGFnOlxuXHRcdFx0Y2FzZSBpbnQxNkFycmF5VGFnOlxuXHRcdFx0Y2FzZSBpbnQzMkFycmF5VGFnOlxuXHRcdFx0Y2FzZSBiaWdJbnQ2NEFycmF5VGFnOlxuXHRcdFx0Y2FzZSBmbG9hdDMyQXJyYXlUYWc6XG5cdFx0XHRjYXNlIGZsb2F0NjRBcnJheVRhZzpcblx0XHRcdFx0aWYgKGlzQnVmZmVyKGEpICE9PSBpc0J1ZmZlcihiKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRpZiAoYS5sZW5ndGggIT09IGIubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgYS5sZW5ndGg7IGkrKykgaWYgKCFpc0VxdWFsV2l0aEltcGwoYVtpXSwgYltpXSwgaSwgYSwgYiwgc3RhY2ssIGFyZVZhbHVlc0VxdWFsKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdGNhc2UgYXJyYXlCdWZmZXJUYWc6XG5cdFx0XHRcdGlmIChhLmJ5dGVMZW5ndGggIT09IGIuYnl0ZUxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRyZXR1cm4gYXJlT2JqZWN0c0VxdWFsKG5ldyBVaW50OEFycmF5KGEpLCBuZXcgVWludDhBcnJheShiKSwgc3RhY2ssIGFyZVZhbHVlc0VxdWFsKTtcblx0XHRcdGNhc2UgZGF0YVZpZXdUYWc6XG5cdFx0XHRcdGlmIChhLmJ5dGVMZW5ndGggIT09IGIuYnl0ZUxlbmd0aCB8fCBhLmJ5dGVPZmZzZXQgIT09IGIuYnl0ZU9mZnNldCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRyZXR1cm4gYXJlT2JqZWN0c0VxdWFsKG5ldyBVaW50OEFycmF5KGEpLCBuZXcgVWludDhBcnJheShiKSwgc3RhY2ssIGFyZVZhbHVlc0VxdWFsKTtcblx0XHRcdGNhc2UgZXJyb3JUYWc6IHJldHVybiBhLm5hbWUgPT09IGIubmFtZSAmJiBhLm1lc3NhZ2UgPT09IGIubWVzc2FnZTtcblx0XHRcdGNhc2Ugb2JqZWN0VGFnOiB7XG5cdFx0XHRcdGlmICghKGFyZU9iamVjdHNFcXVhbChhLmNvbnN0cnVjdG9yLCBiLmNvbnN0cnVjdG9yLCBzdGFjaywgYXJlVmFsdWVzRXF1YWwpIHx8IGlzUGxhaW5PYmplY3QoYSkgJiYgaXNQbGFpbk9iamVjdChiKSkpIHJldHVybiBmYWxzZTtcblx0XHRcdFx0Y29uc3QgYUtleXMgPSBbLi4uT2JqZWN0LmtleXMoYSksIC4uLmdldFN5bWJvbHMoYSldO1xuXHRcdFx0XHRjb25zdCBiS2V5cyA9IFsuLi5PYmplY3Qua2V5cyhiKSwgLi4uZ2V0U3ltYm9scyhiKV07XG5cdFx0XHRcdGlmIChhS2V5cy5sZW5ndGggIT09IGJLZXlzLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGFLZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdFx0Y29uc3QgcHJvcEtleSA9IGFLZXlzW2ldO1xuXHRcdFx0XHRcdGNvbnN0IGFQcm9wID0gYVtwcm9wS2V5XTtcblx0XHRcdFx0XHRpZiAoIU9iamVjdC5oYXNPd24oYiwgcHJvcEtleSkpIHJldHVybiBmYWxzZTtcblx0XHRcdFx0XHRjb25zdCBiUHJvcCA9IGJbcHJvcEtleV07XG5cdFx0XHRcdFx0aWYgKCFpc0VxdWFsV2l0aEltcGwoYVByb3AsIGJQcm9wLCBwcm9wS2V5LCBhLCBiLCBzdGFjaywgYXJlVmFsdWVzRXF1YWwpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0XHRkZWZhdWx0OiByZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9IGZpbmFsbHkge1xuXHRcdHN0YWNrLmRlbGV0ZShhKTtcblx0XHRzdGFjay5kZWxldGUoYik7XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNFcXVhbFdpdGggfTtcbiIsImltcG9ydCB7IG5vb3AgfSBmcm9tIFwiLi4vZnVuY3Rpb24vbm9vcC5tanNcIjtcbmltcG9ydCB7IGlzRXF1YWxXaXRoIH0gZnJvbSBcIi4vaXNFcXVhbFdpdGgubWpzXCI7XG4vLyNyZWdpb24gc3JjL3ByZWRpY2F0ZS9pc0VxdWFsLnRzXG4vKipcbiogQ2hlY2tzIGlmIHR3byB2YWx1ZXMgYXJlIGVxdWFsLCBpbmNsdWRpbmcgc3VwcG9ydCBmb3IgYERhdGVgLCBgUmVnRXhwYCwgYW5kIGRlZXAgb2JqZWN0IGNvbXBhcmlzb24uXG4qXG4qIEBwYXJhbSBhIC0gVGhlIGZpcnN0IHZhbHVlIHRvIGNvbXBhcmUuXG4qIEBwYXJhbSBiIC0gVGhlIHNlY29uZCB2YWx1ZSB0byBjb21wYXJlLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHZhbHVlcyBhcmUgZXF1YWwsIG90aGVyd2lzZSBgZmFsc2VgLlxuKlxuKiBAZXhhbXBsZVxuKiBpc0VxdWFsKDEsIDEpOyAvLyB0cnVlXG4qIGlzRXF1YWwoeyBhOiAxIH0sIHsgYTogMSB9KTsgLy8gdHJ1ZVxuKiBpc0VxdWFsKC9hYmMvZywgL2FiYy9nKTsgLy8gdHJ1ZVxuKiBpc0VxdWFsKG5ldyBEYXRlKCcyMDIwLTAxLTAxJyksIG5ldyBEYXRlKCcyMDIwLTAxLTAxJykpOyAvLyB0cnVlXG4qIGlzRXF1YWwoWzEsIDIsIDNdLCBbMSwgMiwgM10pOyAvLyB0cnVlXG4qL1xuZnVuY3Rpb24gaXNFcXVhbChhLCBiKSB7XG5cdHJldHVybiBpc0VxdWFsV2l0aChhLCBiLCBub29wKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNFcXVhbCB9O1xuIiwiLy8jcmVnaW9uIHNyYy9wcmVkaWNhdGUvaXNMZW5ndGgudHNcbi8qKlxuKiBDaGVja3MgaWYgYSBnaXZlbiB2YWx1ZSBpcyBhIHZhbGlkIGxlbmd0aC5cbipcbiogQSB2YWxpZCBsZW5ndGggaXMgb2YgdHlwZSBgbnVtYmVyYCwgaXMgYSBub24tbmVnYXRpdmUgaW50ZWdlciwgYW5kIGlzIGxlc3MgdGhhbiBvciBlcXVhbCB0b1xuKiBKYXZhU2NyaXB0J3MgbWF4aW11bSBzYWZlIGludGVnZXIgKGBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUmApLlxuKiBJdCByZXR1cm5zIGB0cnVlYCBpZiB0aGUgdmFsdWUgaXMgYSB2YWxpZCBsZW5ndGgsIGFuZCBgZmFsc2VgIG90aGVyd2lzZS5cbipcbiogVGhpcyBmdW5jdGlvbiBjYW4gYWxzbyBzZXJ2ZSBhcyBhIHR5cGUgcHJlZGljYXRlIGluIFR5cGVTY3JpcHQsIG5hcnJvd2luZyB0aGUgdHlwZSBvZiB0aGVcbiogYXJndW1lbnQgdG8gYSB2YWxpZCBsZW5ndGggKGBudW1iZXJgKS5cbipcbiogQHBhcmFtIHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiogQHJldHVybnMgUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIHZhbGlkIGxlbmd0aCwgZWxzZSBgZmFsc2VgLlxuKlxuKiBAZXhhbXBsZVxuKiBpc0xlbmd0aCgwKTsgLy8gdHJ1ZVxuKiBpc0xlbmd0aCg0Mik7IC8vIHRydWVcbiogaXNMZW5ndGgoLTEpOyAvLyBmYWxzZVxuKiBpc0xlbmd0aCgxLjUpOyAvLyBmYWxzZVxuKiBpc0xlbmd0aChOdW1iZXIuTUFYX1NBRkVfSU5URUdFUik7IC8vIHRydWVcbiogaXNMZW5ndGgoTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVIgKyAxKTsgLy8gZmFsc2VcbiovXG5mdW5jdGlvbiBpc0xlbmd0aCh2YWx1ZSkge1xuXHRyZXR1cm4gTnVtYmVyLmlzU2FmZUludGVnZXIodmFsdWUpICYmIHZhbHVlID49IDA7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzTGVuZ3RoIH07XG4iLCIvLyNyZWdpb24gc3JjL3N0cmluZy9lc2NhcGUudHNcbmNvbnN0IGh0bWxFc2NhcGVzID0ge1xuXHRcIiZcIjogXCImYW1wO1wiLFxuXHRcIjxcIjogXCImbHQ7XCIsXG5cdFwiPlwiOiBcIiZndDtcIixcblx0XCJcXFwiXCI6IFwiJnF1b3Q7XCIsXG5cdFwiJ1wiOiBcIiYjMzk7XCJcbn07XG4vKipcbiogQ29udmVydHMgdGhlIGNoYXJhY3RlcnMgXCImXCIsIFwiPFwiLCBcIj5cIiwgJ1wiJywgYW5kIFwiJ1wiIGluIGBzdHJgIHRvIHRoZWlyIGNvcnJlc3BvbmRpbmcgSFRNTCBlbnRpdGllcy5cbiogRm9yIGV4YW1wbGUsIFwiPFwiIGJlY29tZXMgXCImbHQ7XCIuXG4qXG4qIEBwYXJhbSBzdHIgIFRoZSBzdHJpbmcgdG8gZXNjYXBlLlxuKiBAcmV0dXJucyBSZXR1cm5zIHRoZSBlc2NhcGVkIHN0cmluZy5cbipcbiogQGV4YW1wbGVcbiogZXNjYXBlKCdUaGlzIGlzIGEgPGRpdj4gZWxlbWVudC4nKTsgLy8gcmV0dXJucyAnVGhpcyBpcyBhICZsdDtkaXYmZ3Q7IGVsZW1lbnQuJ1xuKiBlc2NhcGUoJ1RoaXMgaXMgYSBcInF1b3RlXCInKTsgLy8gcmV0dXJucyAnVGhpcyBpcyBhICZxdW90O3F1b3RlJnF1b3Q7J1xuKiBlc2NhcGUoXCJUaGlzIGlzIGEgJ3F1b3RlJ1wiKTsgLy8gcmV0dXJucyAnVGhpcyBpcyBhICYjMzk7cXVvdGUmIzM5OydcbiogZXNjYXBlKCdUaGlzIGlzIGEgJiBzeW1ib2wnKTsgLy8gcmV0dXJucyAnVGhpcyBpcyBhICZhbXA7IHN5bWJvbCdcbiovXG5mdW5jdGlvbiBlc2NhcGUoc3RyKSB7XG5cdHJldHVybiBzdHIucmVwbGFjZSgvWyY8PlwiJ10vZywgKG1hdGNoKSA9PiBodG1sRXNjYXBlc1ttYXRjaF0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBlc2NhcGUgfTtcbiIsImltcG9ydCB7IGlzTGVuZ3RoIH0gZnJvbSBcIi4uLy4uL3ByZWRpY2F0ZS9pc0xlbmd0aC5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvY29tcGF0L3ByZWRpY2F0ZS9pc0FycmF5TGlrZS50c1xuLyoqXG4qIENoZWNrcyBpZiBgdmFsdWVgIGlzIGFycmF5LWxpa2UuXG4qXG4qIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIFJldHVybnMgYHRydWVgIGlmIGB2YWx1ZWAgaXMgYXJyYXktbGlrZSwgZWxzZSBgZmFsc2VgLlxuKlxuKiBAZXhhbXBsZVxuKiBpc0FycmF5TGlrZShbMSwgMiwgM10pOyAvLyB0cnVlXG4qIGlzQXJyYXlMaWtlKCdhYmMnKTsgLy8gdHJ1ZVxuKiBpc0FycmF5TGlrZSh7IDA6ICdhJywgbGVuZ3RoOiAxIH0pOyAvLyB0cnVlXG4qIGlzQXJyYXlMaWtlKHt9KTsgLy8gZmFsc2VcbiogaXNBcnJheUxpa2UobnVsbCk7IC8vIGZhbHNlXG4qIGlzQXJyYXlMaWtlKHVuZGVmaW5lZCk7IC8vIGZhbHNlXG4qL1xuZnVuY3Rpb24gaXNBcnJheUxpa2UodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlICE9IG51bGwgJiYgdHlwZW9mIHZhbHVlICE9PSBcImZ1bmN0aW9uXCIgJiYgaXNMZW5ndGgodmFsdWUubGVuZ3RoKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNBcnJheUxpa2UgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvY29tcGF0L3ByZWRpY2F0ZS9pc1N5bWJvbC50c1xuLyoqXG4qIENoZWNrIHdoZXRoZXIgYSB2YWx1ZSBpcyBhIHN5bWJvbC5cbipcbiogVGhpcyBmdW5jdGlvbiBjYW4gYWxzbyBzZXJ2ZSBhcyBhIHR5cGUgcHJlZGljYXRlIGluIFR5cGVTY3JpcHQsIG5hcnJvd2luZyB0aGUgdHlwZSBvZiB0aGUgYXJndW1lbnQgdG8gYHN5bWJvbGAuXG4qXG4qIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIFJldHVybnMgYHRydWVgIGlmIGB2YWx1ZWAgaXMgYSBzeW1ib2wsIGVsc2UgYGZhbHNlYC5cbiogQGV4YW1wbGVcbiogaXNTeW1ib2woU3ltYm9sLml0ZXJhdG9yKTtcbiogLy8gPT4gdHJ1ZVxuKlxuKiBpc1N5bWJvbCgnYWJjJyk7XG4qIC8vID0+IGZhbHNlXG4qL1xuZnVuY3Rpb24gaXNTeW1ib2wodmFsdWUpIHtcblx0cmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzeW1ib2xcIiB8fCB2YWx1ZSBpbnN0YW5jZW9mIFN5bWJvbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNTeW1ib2wgfTtcbiIsImltcG9ydCB7IGlzU3ltYm9sIH0gZnJvbSBcIi4uL3ByZWRpY2F0ZS9pc1N5bWJvbC5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvY29tcGF0L3V0aWwvdG9TdHJpbmcudHNcbi8qKlxuKiBDb252ZXJ0cyBgdmFsdWVgIHRvIGEgc3RyaW5nLlxuKlxuKiBBbiBlbXB0eSBzdHJpbmcgaXMgcmV0dXJuZWQgZm9yIGBudWxsYCBhbmQgYHVuZGVmaW5lZGAgdmFsdWVzLlxuKiBUaGUgc2lnbiBvZiBgLTBgIGlzIHByZXNlcnZlZC5cbipcbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNvbnZlcnQuXG4qIEByZXR1cm5zIFJldHVybnMgdGhlIGNvbnZlcnRlZCBzdHJpbmcuXG4qXG4qIEBleGFtcGxlXG4qIHRvU3RyaW5nKG51bGwpIC8vIHJldHVybnMgJydcbiogdG9TdHJpbmcodW5kZWZpbmVkKSAvLyByZXR1cm5zICcnXG4qIHRvU3RyaW5nKC0wKSAvLyByZXR1cm5zICctMCdcbiogdG9TdHJpbmcoWzEsIDIsIC0wXSkgLy8gcmV0dXJucyAnMSwyLC0wJ1xuKiB0b1N0cmluZyhbU3ltYm9sKCdhJyksIFN5bWJvbCgnYicpXSkgLy8gcmV0dXJucyAnU3ltYm9sKGEpLFN5bWJvbChiKSdcbiovXG5mdW5jdGlvbiB0b1N0cmluZyh2YWx1ZSkge1xuXHRpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIFwiXCI7XG5cdHJldHVybiBiYXNlVG9TdHJpbmcodmFsdWUpO1xufVxuZnVuY3Rpb24gYmFzZVRvU3RyaW5nKHZhbHVlKSB7XG5cdGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHJldHVybiB2YWx1ZTtcblx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUubWFwKGJhc2VUb1N0cmluZykuam9pbihcIixcIik7XG5cdGlmIChpc1N5bWJvbCh2YWx1ZSkpIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuXHRjb25zdCByZXN1bHQgPSB2YWx1ZSArIFwiXCI7XG5cdGlmIChyZXN1bHQgPT09IFwiMFwiICYmIE9iamVjdC5pcyhOdW1iZXIodmFsdWUpLCAtMCkpIHJldHVybiBcIi0wXCI7XG5cdHJldHVybiByZXN1bHQ7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHRvU3RyaW5nIH07XG4iLCIvLyNyZWdpb24gc3JjL2NvbXBhdC9faW50ZXJuYWwvdG9LZXkudHNcbi8qKlxuKiBDb252ZXJ0cyBgdmFsdWVgIHRvIGEgc3RyaW5nIGtleSBpZiBpdCdzIG5vdCBhIHN0cmluZyBvciBzeW1ib2wuXG4qXG4qIEBwcml2YXRlXG4qIEBwYXJhbSB7dW5rbm93bn0gdmFsdWUgVGhlIHZhbHVlIHRvIGluc3BlY3QuXG4qIEByZXR1cm5zIHtzdHJpbmd8c3ltYm9sfSBSZXR1cm5zIHRoZSBrZXkuXG4qL1xuZnVuY3Rpb24gdG9LZXkodmFsdWUpIHtcblx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdmFsdWUgPT09IFwic3ltYm9sXCIpIHJldHVybiB2YWx1ZTtcblx0aWYgKE9iamVjdC5pcyh2YWx1ZT8udmFsdWVPZj8uKCksIC0wKSkgcmV0dXJuIFwiLTBcIjtcblx0cmV0dXJuIFN0cmluZyh2YWx1ZSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHRvS2V5IH07XG4iLCJpbXBvcnQgeyB0b0tleSB9IGZyb20gXCIuLi9faW50ZXJuYWwvdG9LZXkubWpzXCI7XG5pbXBvcnQgeyB0b1N0cmluZyB9IGZyb20gXCIuL3RvU3RyaW5nLm1qc1wiO1xuLy8jcmVnaW9uIHNyYy9jb21wYXQvdXRpbC90b1BhdGgudHNcbi8qKlxuKiBDb252ZXJ0cyBhIGRlZXAga2V5IHN0cmluZyBpbnRvIGFuIGFycmF5IG9mIHBhdGggc2VnbWVudHMuXG4qXG4qIFRoaXMgZnVuY3Rpb24gdGFrZXMgYSBzdHJpbmcgcmVwcmVzZW50aW5nIGEgZGVlcCBrZXkgKGUuZy4sICdhLmIuYycgb3IgJ2FbYl1bY10nKSBhbmQgYnJlYWtzIGl0IGRvd24gaW50byBhbiBhcnJheSBvZiBzdHJpbmdzLCBlYWNoIHJlcHJlc2VudGluZyBhIHNlZ21lbnQgb2YgdGhlIHBhdGguXG4qXG4qIEBwYXJhbSBkZWVwS2V5IC0gVGhlIGRlZXAga2V5IHN0cmluZyB0byBjb252ZXJ0LlxuKiBAcmV0dXJucyBBbiBhcnJheSBvZiBzdHJpbmdzLCBlYWNoIHJlcHJlc2VudGluZyBhIHNlZ21lbnQgb2YgdGhlIHBhdGguXG4qXG4qIEV4YW1wbGVzOlxuKlxuKiB0b1BhdGgoJ2EuYi5jJykgLy8gUmV0dXJucyBbJ2EnLCAnYicsICdjJ11cbiogdG9QYXRoKCdhW2JdW2NdJykgLy8gUmV0dXJucyBbJ2EnLCAnYicsICdjJ11cbiogdG9QYXRoKCcuYS5iLmMnKSAvLyBSZXR1cm5zIFsnJywgJ2EnLCAnYicsICdjJ11cbiogdG9QYXRoKCdhW1wiYi5jXCJdLmQnKSAvLyBSZXR1cm5zIFsnYScsICdiLmMnLCAnZCddXG4qIHRvUGF0aCgnJykgLy8gUmV0dXJucyBbXVxuKiB0b1BhdGgoJy5hW2JdLmMuZFtlXVtcImYuZ1wiXS5oJykgLy8gUmV0dXJucyBbJycsICdhJywgJ2InLCAnYycsICdkJywgJ2UnLCAnZi5nJywgJ2gnXVxuKi9cbmZ1bmN0aW9uIHRvUGF0aChkZWVwS2V5KSB7XG5cdGlmIChBcnJheS5pc0FycmF5KGRlZXBLZXkpKSByZXR1cm4gZGVlcEtleS5tYXAodG9LZXkpO1xuXHRpZiAodHlwZW9mIGRlZXBLZXkgPT09IFwic3ltYm9sXCIpIHJldHVybiBbZGVlcEtleV07XG5cdGRlZXBLZXkgPSB0b1N0cmluZyhkZWVwS2V5KTtcblx0Y29uc3QgcmVzdWx0ID0gW107XG5cdGNvbnN0IGxlbmd0aCA9IGRlZXBLZXkubGVuZ3RoO1xuXHRpZiAobGVuZ3RoID09PSAwKSByZXR1cm4gcmVzdWx0O1xuXHRsZXQgaW5kZXggPSAwO1xuXHRsZXQga2V5ID0gXCJcIjtcblx0bGV0IHF1b3RlQ2hhciA9IFwiXCI7XG5cdGxldCBicmFja2V0ID0gZmFsc2U7XG5cdGxldCBicmFja2V0SGFkUXVvdGUgPSBmYWxzZTtcblx0Y29uc3QgYnJhY2tldE51bWJlclJlZ2V4ID0gL14tP1xcZCsoPzpcXC5cXGQrKT8kLztcblx0aWYgKGRlZXBLZXkuY2hhckNvZGVBdCgwKSA9PT0gNDYpIHJlc3VsdC5wdXNoKFwiXCIpO1xuXHR3aGlsZSAoaW5kZXggPCBsZW5ndGgpIHtcblx0XHRjb25zdCBjaGFyID0gZGVlcEtleVtpbmRleF07XG5cdFx0aWYgKHF1b3RlQ2hhcikgaWYgKGNoYXIgPT09IFwiXFxcXFwiICYmIGluZGV4ICsgMSA8IGxlbmd0aCkge1xuXHRcdFx0aW5kZXgrKztcblx0XHRcdGtleSArPSBkZWVwS2V5W2luZGV4XTtcblx0XHR9IGVsc2UgaWYgKGNoYXIgPT09IHF1b3RlQ2hhcikgcXVvdGVDaGFyID0gXCJcIjtcblx0XHRlbHNlIGtleSArPSBjaGFyO1xuXHRcdGVsc2UgaWYgKGJyYWNrZXQpIGlmIChjaGFyID09PSBcIlxcXCJcIiB8fCBjaGFyID09PSBcIidcIikge1xuXHRcdFx0cXVvdGVDaGFyID0gY2hhcjtcblx0XHRcdGJyYWNrZXRIYWRRdW90ZSA9IHRydWU7XG5cdFx0fSBlbHNlIGlmIChjaGFyID09PSBcIl1cIikge1xuXHRcdFx0YnJhY2tldCA9IGZhbHNlO1xuXHRcdFx0aWYgKCFicmFja2V0SGFkUXVvdGUgJiYga2V5LmluY2x1ZGVzKFwiLlwiKSAmJiAhYnJhY2tldE51bWJlclJlZ2V4LnRlc3Qoa2V5KSkge1xuXHRcdFx0XHRjb25zdCBzZWdtZW50cyA9IGtleS5zcGxpdChcIi5cIik7XG5cdFx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgc2VnbWVudHMubGVuZ3RoOyBpKyspIGlmIChzZWdtZW50c1tpXSAhPT0gXCJcIikgcmVzdWx0LnB1c2goc2VnbWVudHNbaV0pO1xuXHRcdFx0fSBlbHNlIHJlc3VsdC5wdXNoKGtleSk7XG5cdFx0XHRrZXkgPSBcIlwiO1xuXHRcdH0gZWxzZSBrZXkgKz0gY2hhcjtcblx0XHRlbHNlIGlmIChjaGFyID09PSBcIltcIikge1xuXHRcdFx0YnJhY2tldCA9IHRydWU7XG5cdFx0XHRicmFja2V0SGFkUXVvdGUgPSBmYWxzZTtcblx0XHRcdGlmIChrZXkpIHtcblx0XHRcdFx0cmVzdWx0LnB1c2goa2V5KTtcblx0XHRcdFx0a2V5ID0gXCJcIjtcblx0XHRcdH1cblx0XHR9IGVsc2UgaWYgKGNoYXIgPT09IFwiLlwiKSB7XG5cdFx0XHRpZiAoa2V5KSB7XG5cdFx0XHRcdHJlc3VsdC5wdXNoKGtleSk7XG5cdFx0XHRcdGtleSA9IFwiXCI7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBuZXh0ID0gZGVlcEtleVtpbmRleCArIDFdO1xuXHRcdFx0aWYgKG5leHQgPT09IHZvaWQgMCB8fCBuZXh0ID09PSBcIi5cIikgcmVzdWx0LnB1c2goXCJcIik7XG5cdFx0fSBlbHNlIGtleSArPSBjaGFyO1xuXHRcdGluZGV4Kys7XG5cdH1cblx0aWYgKGtleSkgcmVzdWx0LnB1c2goa2V5KTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdG9QYXRoIH07XG4iLCIvLyNyZWdpb24gc3JjL2NvbXBhdC9faW50ZXJuYWwvaXNEZWVwS2V5LnRzXG4vKiogTWF0Y2hlcyBhbnkgZGVlcCBwcm9wZXJ0eSBwYXRoLiBFeGFtcGxlczogYGEuYmAsIGBhWzBdYCwgYGFbXCJiXCJdYCAqL1xuY29uc3QgcmVnZXhJc0RlZXBQcm9wID0gL1xcLnwoXFxbKD86W15bXFxdXSp8KFtcIiddKSg/Oig/IVxcMilbXlxcXFxdfFxcXFwuKSo/XFwyKVxcXSkvO1xuLyoqXG4qIENoZWNrcyBpZiBhIGdpdmVuIGtleSBpcyBhIGRlZXAga2V5LlxuKlxuKiBBIGRlZXAga2V5IGlzIGEgc3RyaW5nIHRoYXQgY29udGFpbnMgYSBkb3QgKC4pIG9yIHNxdWFyZSBicmFja2V0cyB3aXRoIGEgcHJvcGVydHkgYWNjZXNzb3IuXG4qXG4qIEBwYXJhbSB7UHJvcGVydHlLZXl9IGtleSAtIFRoZSBrZXkgdG8gY2hlY2suXG4qIEByZXR1cm5zIHtib29sZWFufSAtIFJldHVybnMgdHJ1ZSBpZiB0aGUga2V5IGlzIGEgZGVlcCBrZXksIG90aGVyd2lzZSBmYWxzZS5cbipcbiogRXhhbXBsZXM6XG4qXG4qIGlzRGVlcEtleSgnYS5iJykgLy8gdHJ1ZVxuKiBpc0RlZXBLZXkoJ2FbYl0nKSAvLyB0cnVlXG4qIGlzRGVlcEtleSgnYScpIC8vIGZhbHNlXG4qIGlzRGVlcEtleSgxMjMpIC8vIGZhbHNlXG4qIGlzRGVlcEtleSgnYS5iLmMnKSAvLyB0cnVlXG4qIGlzRGVlcEtleSgnYVtiXVtjXScpIC8vIHRydWVcbiogaXNEZWVwS2V5KCdhLicpIC8vIGZhbHNlXG4qIGlzRGVlcEtleSgnLmEnKSAvLyBmYWxzZVxuKiBpc0RlZXBLZXkoJ2FbYicpIC8vIGZhbHNlXG4qIGlzRGVlcEtleSgnYV1iXScpIC8vIGZhbHNlXG4qIGlzRGVlcEtleSgnYV1bYicpIC8vIGZhbHNlXG4qIGlzRGVlcEtleSgnJykgLy8gZmFsc2VcbiogaXNEZWVwS2V5KCdhWzBdJykgLy8gdHJ1ZVxuKlxuKi9cbmZ1bmN0aW9uIGlzRGVlcEtleShrZXkpIHtcblx0c3dpdGNoICh0eXBlb2Yga2V5KSB7XG5cdFx0Y2FzZSBcIm51bWJlclwiOlxuXHRcdGNhc2UgXCJzeW1ib2xcIjogcmV0dXJuIGZhbHNlO1xuXHRcdGNhc2UgXCJzdHJpbmdcIjpcblx0XHRcdGlmIChrZXkgPT09IFwiXCIgfHwga2V5LnN0YXJ0c1dpdGgoXCIuXCIpIHx8IGtleS5lbmRzV2l0aChcIi5cIikpIHJldHVybiBmYWxzZTtcblx0XHRcdHJldHVybiByZWdleElzRGVlcFByb3AudGVzdChrZXkpO1xuXHRcdGRlZmF1bHQ6IHJldHVybiBmYWxzZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc0RlZXBLZXkgfTtcbiIsImltcG9ydCB7IGlzVW5zYWZlUHJvcGVydHkgfSBmcm9tIFwiLi4vLi4vX2ludGVybmFsL2lzVW5zYWZlUHJvcGVydHkubWpzXCI7XG5pbXBvcnQgeyBpc0RlZXBLZXkgfSBmcm9tIFwiLi4vX2ludGVybmFsL2lzRGVlcEtleS5tanNcIjtcbmltcG9ydCB7IHRvS2V5IH0gZnJvbSBcIi4uL19pbnRlcm5hbC90b0tleS5tanNcIjtcbmltcG9ydCB7IHRvUGF0aCB9IGZyb20gXCIuLi91dGlsL3RvUGF0aC5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvY29tcGF0L29iamVjdC9nZXQudHNcbi8qKlxuKiBSZXRyaWV2ZXMgdGhlIHZhbHVlIGF0IGEgZ2l2ZW4gcGF0aCBmcm9tIGFuIG9iamVjdC4gSWYgdGhlIHJlc29sdmVkIHZhbHVlIGlzIHVuZGVmaW5lZCwgdGhlIGRlZmF1bHRWYWx1ZSBpcyByZXR1cm5lZCBpbnN0ZWFkLlxuKlxuKiBAcGFyYW0gb2JqZWN0IC0gVGhlIG9iamVjdCB0byBxdWVyeS5cbiogQHBhcmFtIHBhdGggLSBUaGUgcGF0aCBvZiB0aGUgcHJvcGVydHkgdG8gZ2V0LlxuKiBAcGFyYW0gW2RlZmF1bHRWYWx1ZV0gLSBUaGUgdmFsdWUgcmV0dXJuZWQgaWYgdGhlIHJlc29sdmVkIHZhbHVlIGlzIHVuZGVmaW5lZC5cbiogQHJldHVybnMgUmV0dXJucyB0aGUgcmVzb2x2ZWQgdmFsdWUuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnN0IG9iamVjdCA9IHsgYTogeyBiOiB7IGM6IDEgfSB9IH07XG4qIGdldChvYmplY3QsICdhLmIuYycpO1xuKiAvLyA9PiAxXG4qXG4qIGdldChvYmplY3QsIFsnYScsICdiJywgJ2MnXSk7XG4qIC8vID0+IDFcbipcbiogZ2V0KG9iamVjdCwgJ2EuYi5kJywgJ2RlZmF1bHQnKTtcbiogLy8gPT4gJ2RlZmF1bHQnXG4qL1xuZnVuY3Rpb24gZ2V0KG9iamVjdCwgcGF0aCwgZGVmYXVsdFZhbHVlKSB7XG5cdGlmIChvYmplY3QgPT0gbnVsbCkgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcblx0c3dpdGNoICh0eXBlb2YgcGF0aCkge1xuXHRcdGNhc2UgXCJzdHJpbmdcIjoge1xuXHRcdFx0aWYgKGlzVW5zYWZlUHJvcGVydHkocGF0aCkpIHJldHVybiBkZWZhdWx0VmFsdWU7XG5cdFx0XHRjb25zdCByZXN1bHQgPSBvYmplY3RbcGF0aF07XG5cdFx0XHRpZiAocmVzdWx0ID09PSB2b2lkIDApIGlmIChpc0RlZXBLZXkocGF0aCkgJiYgIU9iamVjdC5oYXNPd24ob2JqZWN0LCBwYXRoKSkgcmV0dXJuIGdldChvYmplY3QsIHRvUGF0aChwYXRoKSwgZGVmYXVsdFZhbHVlKTtcblx0XHRcdGVsc2UgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fVxuXHRcdGNhc2UgXCJudW1iZXJcIjpcblx0XHRjYXNlIFwic3ltYm9sXCI6IHtcblx0XHRcdGlmICh0eXBlb2YgcGF0aCA9PT0gXCJudW1iZXJcIikgcGF0aCA9IHRvS2V5KHBhdGgpO1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gb2JqZWN0W3BhdGhdO1xuXHRcdFx0aWYgKHJlc3VsdCA9PT0gdm9pZCAwKSByZXR1cm4gZGVmYXVsdFZhbHVlO1xuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9XG5cdFx0ZGVmYXVsdDoge1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkocGF0aCkpIHJldHVybiBnZXRXaXRoUGF0aChvYmplY3QsIHBhdGgsIGRlZmF1bHRWYWx1ZSk7XG5cdFx0XHRpZiAoT2JqZWN0LmlzKHBhdGg/LnZhbHVlT2YoKSwgLTApKSBwYXRoID0gXCItMFwiO1xuXHRcdFx0ZWxzZSBwYXRoID0gU3RyaW5nKHBhdGgpO1xuXHRcdFx0aWYgKGlzVW5zYWZlUHJvcGVydHkocGF0aCkpIHJldHVybiBkZWZhdWx0VmFsdWU7XG5cdFx0XHRjb25zdCByZXN1bHQgPSBvYmplY3RbcGF0aF07XG5cdFx0XHRpZiAocmVzdWx0ID09PSB2b2lkIDApIHJldHVybiBkZWZhdWx0VmFsdWU7XG5cdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gZ2V0V2l0aFBhdGgob2JqZWN0LCBwYXRoLCBkZWZhdWx0VmFsdWUpIHtcblx0aWYgKHBhdGgubGVuZ3RoID09PSAwKSByZXR1cm4gZGVmYXVsdFZhbHVlO1xuXHRsZXQgY3VycmVudCA9IG9iamVjdDtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHBhdGgubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0aWYgKGN1cnJlbnQgPT0gbnVsbCkgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcblx0XHRpZiAoaXNVbnNhZmVQcm9wZXJ0eShwYXRoW2luZGV4XSkpIHJldHVybiBkZWZhdWx0VmFsdWU7XG5cdFx0Y3VycmVudCA9IGN1cnJlbnRbcGF0aFtpbmRleF1dO1xuXHR9XG5cdGlmIChjdXJyZW50ID09PSB2b2lkIDApIHJldHVybiBkZWZhdWx0VmFsdWU7XG5cdHJldHVybiBjdXJyZW50O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBnZXQgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvY29tcGF0L3ByZWRpY2F0ZS9pc09iamVjdC50c1xuLyoqXG4qIENoZWNrcyBpZiB0aGUgZ2l2ZW4gdmFsdWUgaXMgYW4gb2JqZWN0LiBBbiBvYmplY3QgaXMgYSB2YWx1ZSB0aGF0IGlzXG4qIG5vdCBhIHByaW1pdGl2ZSB0eXBlIChzdHJpbmcsIG51bWJlciwgYm9vbGVhbiwgc3ltYm9sLCBudWxsLCBvciB1bmRlZmluZWQpLlxuKlxuKiBUaGlzIGZ1bmN0aW9uIHRlc3RzIHdoZXRoZXIgdGhlIHByb3ZpZGVkIHZhbHVlIGlzIGFuIG9iamVjdCBvciBub3QuXG4qIEl0IHJldHVybnMgYHRydWVgIGlmIHRoZSB2YWx1ZSBpcyBhbiBvYmplY3QsIGFuZCBgZmFsc2VgIG90aGVyd2lzZS5cbipcbiogVGhpcyBmdW5jdGlvbiBjYW4gYWxzbyBzZXJ2ZSBhcyBhIHR5cGUgcHJlZGljYXRlIGluIFR5cGVTY3JpcHQsIG5hcnJvd2luZyB0aGUgdHlwZSBvZiB0aGUgYXJndW1lbnQgdG8gYW4gb2JqZWN0IHZhbHVlLlxuKlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gY2hlY2sgaWYgaXQgaXMgYW4gb2JqZWN0LlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHZhbHVlIGlzIGFuIG9iamVjdCwgYGZhbHNlYCBvdGhlcndpc2UuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnN0IHZhbHVlMSA9IHt9O1xuKiBjb25zdCB2YWx1ZTIgPSBbMSwgMiwgM107XG4qIGNvbnN0IHZhbHVlMyA9ICgpID0+IHt9O1xuKiBjb25zdCB2YWx1ZTQgPSBudWxsO1xuKlxuKiBjb25zb2xlLmxvZyhpc09iamVjdCh2YWx1ZTEpKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc09iamVjdCh2YWx1ZTIpKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc09iamVjdCh2YWx1ZTMpKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc09iamVjdCh2YWx1ZTQpKTsgLy8gZmFsc2VcbiovXG5mdW5jdGlvbiBpc09iamVjdCh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUgIT09IG51bGwgJiYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIik7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzT2JqZWN0IH07XG4iLCJpbXBvcnQgeyBnZXRUYWcgfSBmcm9tIFwiLi4vX2ludGVybmFsL2dldFRhZy5tanNcIjtcbmltcG9ydCB7IGFyZ3VtZW50c1RhZywgYm9vbGVhblRhZywgbnVtYmVyVGFnLCBzdHJpbmdUYWcgfSBmcm9tIFwiLi4vX2ludGVybmFsL3RhZ3MubWpzXCI7XG5pbXBvcnQgeyBjbG9uZURlZXBXaXRoIGFzIGNsb25lRGVlcFdpdGgkMSwgY29weVByb3BlcnRpZXMgfSBmcm9tIFwiLi4vLi4vb2JqZWN0L2Nsb25lRGVlcFdpdGgubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9vYmplY3QvY2xvbmVEZWVwV2l0aC50c1xuLyoqXG4qIENyZWF0ZXMgYSBkZWVwIGNsb25lIG9mIHRoZSBnaXZlbiBvYmplY3QgdXNpbmcgYSBjdXN0b21pemVyIGZ1bmN0aW9uLlxuKlxuKiBAdGVtcGxhdGUgVCAtIFRoZSB0eXBlIG9mIHRoZSBvYmplY3QuXG4qIEBwYXJhbSBvYmogLSBUaGUgb2JqZWN0IHRvIGNsb25lLlxuKiBAcGFyYW0gW2Nsb25lVmFsdWVdIC0gQSBmdW5jdGlvbiB0byBjdXN0b21pemUgdGhlIGNsb25pbmcgcHJvY2Vzcy5cbiogQHJldHVybnMgQSBkZWVwIGNsb25lIG9mIHRoZSBnaXZlbiBvYmplY3QuXG4qXG4qIEBleGFtcGxlXG4qIC8vIENsb25lIGEgcHJpbWl0aXZlIHZhbHVlXG4qIGNvbnN0IG51bSA9IDI5O1xuKiBjb25zdCBjbG9uZWROdW0gPSBjbG9uZURlZXBXaXRoKG51bSk7XG4qIGNvbnNvbGUubG9nKGNsb25lZE51bSk7IC8vIDI5XG4qIGNvbnNvbGUubG9nKGNsb25lZE51bSA9PT0gbnVtKTsgLy8gdHJ1ZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBvYmplY3Qgd2l0aCBhIGN1c3RvbWl6ZXJcbiogY29uc3Qgb2JqID0geyBhOiAxLCBiOiAyIH07XG4qIGNvbnN0IGNsb25lZE9iaiA9IGNsb25lRGVlcFdpdGgob2JqLCAodmFsdWUpID0+IHtcbiogICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuKiAgICAgcmV0dXJuIHZhbHVlICogMjsgLy8gRG91YmxlIHRoZSBudW1iZXJcbiogICB9XG4qIH0pO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmopOyAvLyB7IGE6IDIsIGI6IDQgfVxuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmogPT09IG9iaik7IC8vIGZhbHNlXG4qXG4qIEBleGFtcGxlXG4qIC8vIENsb25lIGFuIGFycmF5IHdpdGggYSBjdXN0b21pemVyXG4qIGNvbnN0IGFyciA9IFsxLCAyLCAzXTtcbiogY29uc3QgY2xvbmVkQXJyID0gY2xvbmVEZWVwV2l0aChhcnIsICh2YWx1ZSkgPT4ge1xuKiAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4qICAgICByZXR1cm4gdmFsdWUgKyAxOyAvLyBJbmNyZW1lbnQgZWFjaCBudW1iZXJcbiogICB9XG4qIH0pO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIpOyAvLyBbMiwgMywgNF1cbiogY29uc29sZS5sb2coY2xvbmVkQXJyID09PSBhcnIpOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGNsb25lRGVlcFdpdGgob2JqLCBjdXN0b21pemVyKSB7XG5cdHJldHVybiBjbG9uZURlZXBXaXRoJDEob2JqLCAodmFsdWUsIGtleSwgb2JqZWN0LCBzdGFjaykgPT4ge1xuXHRcdGNvbnN0IGNsb25lZCA9IGN1c3RvbWl6ZXI/Lih2YWx1ZSwga2V5LCBvYmplY3QsIHN0YWNrKTtcblx0XHRpZiAoY2xvbmVkICE9PSB2b2lkIDApIHJldHVybiBjbG9uZWQ7XG5cdFx0aWYgKHR5cGVvZiBvYmogIT09IFwib2JqZWN0XCIpIHJldHVybjtcblx0XHRpZiAoZ2V0VGFnKG9iaikgPT09IFwiW29iamVjdCBPYmplY3RdXCIgJiYgdHlwZW9mIG9iai5jb25zdHJ1Y3RvciAhPT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHRjb25zdCByZXN1bHQgPSB7fTtcblx0XHRcdHN0YWNrLnNldChvYmosIHJlc3VsdCk7XG5cdFx0XHRjb3B5UHJvcGVydGllcyhyZXN1bHQsIG9iaiwgb2JqZWN0LCBzdGFjayk7XG5cdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH1cblx0XHRzd2l0Y2ggKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopKSB7XG5cdFx0XHRjYXNlIG51bWJlclRhZzpcblx0XHRcdGNhc2Ugc3RyaW5nVGFnOlxuXHRcdFx0Y2FzZSBib29sZWFuVGFnOiB7XG5cdFx0XHRcdGNvbnN0IHJlc3VsdCA9IG5ldyBvYmouY29uc3RydWN0b3Iob2JqPy52YWx1ZU9mKCkpO1xuXHRcdFx0XHRjb3B5UHJvcGVydGllcyhyZXN1bHQsIG9iaik7XG5cdFx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0XHR9XG5cdFx0XHRjYXNlIGFyZ3VtZW50c1RhZzoge1xuXHRcdFx0XHRjb25zdCByZXN1bHQgPSB7fTtcblx0XHRcdFx0Y29weVByb3BlcnRpZXMocmVzdWx0LCBvYmopO1xuXHRcdFx0XHRyZXN1bHQubGVuZ3RoID0gb2JqLmxlbmd0aDtcblx0XHRcdFx0cmVzdWx0W1N5bWJvbC5pdGVyYXRvcl0gPSBvYmpbU3ltYm9sLml0ZXJhdG9yXTtcblx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdH1cblx0XHRcdGRlZmF1bHQ6IHJldHVybjtcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjbG9uZURlZXBXaXRoIH07XG4iLCJpbXBvcnQgeyBjbG9uZURlZXBXaXRoIH0gZnJvbSBcIi4vY2xvbmVEZWVwV2l0aC5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvY29tcGF0L29iamVjdC9jbG9uZURlZXAudHNcbi8qKlxuKiBDcmVhdGVzIGEgZGVlcCBjbG9uZSBvZiB0aGUgZ2l2ZW4gb2JqZWN0LlxuKlxuKiBAdGVtcGxhdGUgVCAtIFRoZSB0eXBlIG9mIHRoZSBvYmplY3QuXG4qIEBwYXJhbSBvYmogLSBUaGUgb2JqZWN0IHRvIGNsb25lLlxuKiBAcmV0dXJucyBBIGRlZXAgY2xvbmUgb2YgdGhlIGdpdmVuIG9iamVjdC5cbipcbiogQGV4YW1wbGVcbiogLy8gQ2xvbmUgYSBwcmltaXRpdmUgdmFsdWVcbiogY29uc3QgbnVtID0gMjk7XG4qIGNvbnN0IGNsb25lZE51bSA9IGNsb25lKG51bSk7XG4qIGNvbnNvbGUubG9nKGNsb25lZE51bSk7IC8vIDI5XG4qIGNvbnNvbGUubG9nKGNsb25lZE51bSA9PT0gbnVtKTsgLy8gdHJ1ZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBhcnJheVxuKiBjb25zdCBhcnIgPSBbMSwgMiwgM107XG4qIGNvbnN0IGNsb25lZEFyciA9IGNsb25lRGVlcChhcnIpO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIpOyAvLyBbMSwgMiwgM11cbiogY29uc29sZS5sb2coY2xvbmVkQXJyID09PSBhcnIpOyAvLyBmYWxzZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBhcnJheSB3aXRoIG5lc3RlZCBvYmplY3RzXG4qIGNvbnN0IGFyciA9IFsxLCB7IGE6IDEgfSwgWzEsIDIsIDNdXTtcbiogY29uc3QgY2xvbmVkQXJyID0gY2xvbmVEZWVwKGFycik7XG4qIGFyclsxXS5hID0gMjtcbiogY29uc29sZS5sb2coYXJyKTsgLy8gWzEsIHsgYTogMiB9LCBbMSwgMiwgM11dXG4qIGNvbnNvbGUubG9nKGNsb25lZEFycik7IC8vIFsxLCB7IGE6IDEgfSwgWzEsIDIsIDNdXVxuKiBjb25zb2xlLmxvZyhjbG9uZWRBcnIgPT09IGFycik7IC8vIGZhbHNlXG4qXG4qIEBleGFtcGxlXG4qIC8vIENsb25lIGFuIG9iamVjdFxuKiBjb25zdCBvYmogPSB7IGE6IDEsIGI6ICdlcy10b29sa2l0JywgYzogWzEsIDIsIDNdIH07XG4qIGNvbnN0IGNsb25lZE9iaiA9IGNsb25lRGVlcChvYmopO1xuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmopOyAvLyB7IGE6IDEsIGI6ICdlcy10b29sa2l0JywgYzogWzEsIDIsIDNdIH1cbiogY29uc29sZS5sb2coY2xvbmVkT2JqID09PSBvYmopOyAvLyBmYWxzZVxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDbG9uZSBhbiBvYmplY3Qgd2l0aCBuZXN0ZWQgb2JqZWN0c1xuKiBjb25zdCBvYmogPSB7IGE6IDEsIGI6IHsgYzogMSB9IH07XG4qIGNvbnN0IGNsb25lZE9iaiA9IGNsb25lRGVlcChvYmopO1xuKiBvYmouYi5jID0gMjtcbiogY29uc29sZS5sb2cob2JqKTsgLy8geyBhOiAxLCBiOiB7IGM6IDIgfSB9XG4qIGNvbnNvbGUubG9nKGNsb25lZE9iaik7IC8vIHsgYTogMSwgYjogeyBjOiAxIH0gfVxuKiBjb25zb2xlLmxvZyhjbG9uZWRPYmogPT09IG9iaik7IC8vIGZhbHNlXG4qL1xuZnVuY3Rpb24gY2xvbmVEZWVwKG9iaikge1xuXHRyZXR1cm4gY2xvbmVEZWVwV2l0aChvYmopO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjbG9uZURlZXAgfTtcbiIsImltcG9ydCB7IGdldFRhZyB9IGZyb20gXCIuLi9faW50ZXJuYWwvZ2V0VGFnLm1qc1wiO1xuLy8jcmVnaW9uIHNyYy9jb21wYXQvcHJlZGljYXRlL2lzQXJndW1lbnRzLnRzXG4vKipcbiogQ2hlY2tzIGlmIHRoZSBnaXZlbiB2YWx1ZSBpcyBhbiBhcmd1bWVudHMgb2JqZWN0LlxuKlxuKiBUaGlzIGZ1bmN0aW9uIHRlc3RzIHdoZXRoZXIgdGhlIHByb3ZpZGVkIHZhbHVlIGlzIGFuIGFyZ3VtZW50cyBvYmplY3Qgb3Igbm90LlxuKiBJdCByZXR1cm5zIGB0cnVlYCBpZiB0aGUgdmFsdWUgaXMgYW4gYXJndW1lbnRzIG9iamVjdCwgYW5kIGBmYWxzZWAgb3RoZXJ3aXNlLlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGNhbiBhbHNvIHNlcnZlIGFzIGEgdHlwZSBwcmVkaWNhdGUgaW4gVHlwZVNjcmlwdCwgbmFycm93aW5nIHRoZSB0eXBlIG9mIHRoZSBhcmd1bWVudCB0byBhbiBhcmd1bWVudHMgb2JqZWN0LlxuKlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gdGVzdCBpZiBpdCBpcyBhbiBhcmd1bWVudHMgb2JqZWN0LlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHZhbHVlIGlzIGFuIGFyZ3VtZW50cywgYGZhbHNlYCBvdGhlcndpc2UuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnN0IGFyZ3MgPSAoZnVuY3Rpb24oKSB7IHJldHVybiBhcmd1bWVudHM7IH0pKCk7XG4qIGNvbnN0IHN0cmljdEFyZ3MgPSAoZnVuY3Rpb24oKSB7ICd1c2Ugc3RyaWN0JzsgcmV0dXJuIGFyZ3VtZW50czsgfSkoKTtcbiogY29uc3QgdmFsdWUgPSBbMSwgMiwgM107XG4qXG4qIGNvbnNvbGUubG9nKGlzQXJndW1lbnRzKGFyZ3MpKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc0FyZ3VtZW50cyhzdHJpY3RBcmdzKSk7IC8vIHRydWVcbiogY29uc29sZS5sb2coaXNBcmd1bWVudHModmFsdWUpKTsgLy8gZmFsc2VcbiovXG5mdW5jdGlvbiBpc0FyZ3VtZW50cyh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUgIT09IG51bGwgJiYgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIGdldFRhZyh2YWx1ZSkgPT09IFwiW29iamVjdCBBcmd1bWVudHNdXCI7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzQXJndW1lbnRzIH07XG4iLCIvLyNyZWdpb24gc3JjL2NvbXBhdC9faW50ZXJuYWwvaXNJbmRleC50c1xuY29uc3QgSVNfVU5TSUdORURfSU5URUdFUiA9IC9eKD86MHxbMS05XVxcZCopJC87XG5mdW5jdGlvbiBpc0luZGV4KHZhbHVlLCBsZW5ndGggPSBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUikge1xuXHRzd2l0Y2ggKHR5cGVvZiB2YWx1ZSkge1xuXHRcdGNhc2UgXCJudW1iZXJcIjogcmV0dXJuIE51bWJlci5pc0ludGVnZXIodmFsdWUpICYmIHZhbHVlID49IDAgJiYgdmFsdWUgPCBsZW5ndGg7XG5cdFx0Y2FzZSBcInN5bWJvbFwiOiByZXR1cm4gZmFsc2U7XG5cdFx0Y2FzZSBcInN0cmluZ1wiOiByZXR1cm4gSVNfVU5TSUdORURfSU5URUdFUi50ZXN0KHZhbHVlKTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc0luZGV4IH07XG4iLCJpbXBvcnQgeyBpc0RlZXBLZXkgfSBmcm9tIFwiLi4vX2ludGVybmFsL2lzRGVlcEtleS5tanNcIjtcbmltcG9ydCB7IHRvS2V5IH0gZnJvbSBcIi4uL19pbnRlcm5hbC90b0tleS5tanNcIjtcbmltcG9ydCB7IHRvUGF0aCB9IGZyb20gXCIuLi91dGlsL3RvUGF0aC5tanNcIjtcbmltcG9ydCB7IGlzSW5kZXggfSBmcm9tIFwiLi4vX2ludGVybmFsL2lzSW5kZXgubWpzXCI7XG5pbXBvcnQgeyBpc0FyZ3VtZW50cyB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNBcmd1bWVudHMubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9vYmplY3QvaGFzLnRzXG4vKipcbiogQ2hlY2tzIGlmIGEgZ2l2ZW4gcGF0aCBleGlzdHMgd2l0aGluIGFuIG9iamVjdC5cbipcbiogWW91IGNhbiBwcm92aWRlIHRoZSBwYXRoIGFzIGEgc2luZ2xlIHByb3BlcnR5IGtleSwgYW4gYXJyYXkgb2YgcHJvcGVydHkga2V5cyxcbiogb3IgYSBzdHJpbmcgcmVwcmVzZW50aW5nIGEgZGVlcCBwYXRoLlxuKlxuKiBJZiB0aGUgcGF0aCBpcyBhbiBpbmRleCBhbmQgdGhlIG9iamVjdCBpcyBhbiBhcnJheSBvciBhbiBhcmd1bWVudHMgb2JqZWN0LCB0aGUgZnVuY3Rpb24gd2lsbCB2ZXJpZnlcbiogaWYgdGhlIGluZGV4IGlzIHZhbGlkIGFuZCB3aXRoaW4gdGhlIGJvdW5kcyBvZiB0aGUgYXJyYXkgb3IgYXJndW1lbnRzIG9iamVjdCwgZXZlbiBpZiB0aGUgYXJyYXkgb3JcbiogYXJndW1lbnRzIG9iamVjdCBpcyBzcGFyc2UgKGkuZS4sIG5vdCBhbGwgaW5kZXhlcyBhcmUgZGVmaW5lZCkuXG4qXG4qIEBwYXJhbSBvYmplY3QgLSBUaGUgb2JqZWN0IHRvIHF1ZXJ5LlxuKiBAcGFyYW0gcGF0aCAtIFRoZSBwYXRoIHRvIGNoZWNrLiBUaGlzIGNhbiBiZSBhIHNpbmdsZSBwcm9wZXJ0eSBrZXksXG4qICAgICAgICBhbiBhcnJheSBvZiBwcm9wZXJ0eSBrZXlzLCBvciBhIHN0cmluZyByZXByZXNlbnRpbmcgYSBkZWVwIHBhdGguXG4qIEByZXR1cm5zIFJldHVybnMgYHRydWVgIGlmIHRoZSBwYXRoIGV4aXN0cyBpbiB0aGUgb2JqZWN0LCBgZmFsc2VgIG90aGVyd2lzZS5cbipcbiogQGV4YW1wbGVcbipcbiogY29uc3Qgb2JqID0geyBhOiB7IGI6IHsgYzogMyB9IH0gfTtcbipcbiogaGFzKG9iaiwgJ2EnKTsgLy8gdHJ1ZVxuKiBoYXMob2JqLCBbJ2EnLCAnYiddKTsgLy8gdHJ1ZVxuKiBoYXMob2JqLCBbJ2EnLCAnYicsICdjJ10pOyAvLyB0cnVlXG4qIGhhcyhvYmosICdhLmIuYycpOyAvLyB0cnVlXG4qIGhhcyhvYmosICdhLmIuZCcpOyAvLyBmYWxzZVxuKiBoYXMob2JqLCBbJ2EnLCAnYicsICdjJywgJ2QnXSk7IC8vIGZhbHNlXG4qIGhhcyhbXSwgMCk7IC8vIGZhbHNlXG4qIGhhcyhbMSwgMiwgM10sIDIpOyAvLyB0cnVlXG4qIGhhcyhbMSwgMiwgM10sIDUpOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGhhcyhvYmplY3QsIHBhdGgpIHtcblx0bGV0IHJlc29sdmVkUGF0aDtcblx0aWYgKEFycmF5LmlzQXJyYXkocGF0aCkpIHJlc29sdmVkUGF0aCA9IHBhdGg7XG5cdGVsc2UgaWYgKHR5cGVvZiBwYXRoID09PSBcInN0cmluZ1wiICYmIGlzRGVlcEtleShwYXRoKSAmJiAhKHBhdGggaW4gT2JqZWN0KG9iamVjdCkpKSByZXNvbHZlZFBhdGggPSB0b1BhdGgocGF0aCk7XG5cdGVsc2UgcmVzb2x2ZWRQYXRoID0gW3BhdGhdO1xuXHRpZiAocmVzb2x2ZWRQYXRoLmxlbmd0aCA9PT0gMCkgcmV0dXJuIGZhbHNlO1xuXHRsZXQgY3VycmVudCA9IG9iamVjdDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCByZXNvbHZlZFBhdGgubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBrZXkgPSB0b0tleShyZXNvbHZlZFBhdGhbaV0pO1xuXHRcdGlmIChjdXJyZW50ID09IG51bGwgfHwgIU9iamVjdC5oYXNPd24oY3VycmVudCwga2V5KSkge1xuXHRcdFx0aWYgKCEoKEFycmF5LmlzQXJyYXkoY3VycmVudCkgfHwgaXNBcmd1bWVudHMoY3VycmVudCkpICYmIGlzSW5kZXgoa2V5KSAmJiBOdW1iZXIoa2V5KSA8IGN1cnJlbnQubGVuZ3RoKSkgcmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRjdXJyZW50ID0gY3VycmVudFtrZXldO1xuXHR9XG5cdHJldHVybiB0cnVlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBoYXMgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvY29tcGF0L3ByZWRpY2F0ZS9pc09iamVjdExpa2UudHNcbi8qKlxuKiBDaGVja3MgaWYgdGhlIGdpdmVuIHZhbHVlIGlzIG9iamVjdC1saWtlLlxuKlxuKiBBIHZhbHVlIGlzIG9iamVjdC1saWtlIGlmIGl0cyB0eXBlIGlzIG9iamVjdCBhbmQgaXQgaXMgbm90IG51bGwuXG4qXG4qIFRoaXMgZnVuY3Rpb24gY2FuIGFsc28gc2VydmUgYXMgYSB0eXBlIHByZWRpY2F0ZSBpbiBUeXBlU2NyaXB0LCBuYXJyb3dpbmcgdGhlIHR5cGUgb2YgdGhlIGFyZ3VtZW50IHRvIGFuIG9iamVjdC1saWtlIHZhbHVlLlxuKlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gdGVzdCBpZiBpdCBpcyBhbiBvYmplY3QtbGlrZS5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSB2YWx1ZSBpcyBhbiBvYmplY3QtbGlrZSwgYGZhbHNlYCBvdGhlcndpc2UuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnN0IHZhbHVlMSA9IHsgYTogMSB9O1xuKiBjb25zdCB2YWx1ZTIgPSBbMSwgMiwgM107XG4qIGNvbnN0IHZhbHVlMyA9ICdhYmMnO1xuKiBjb25zdCB2YWx1ZTQgPSAoKSA9PiB7fTtcbiogY29uc3QgdmFsdWU1ID0gbnVsbDtcbipcbiogY29uc29sZS5sb2coaXNPYmplY3RMaWtlKHZhbHVlMSkpOyAvLyB0cnVlXG4qIGNvbnNvbGUubG9nKGlzT2JqZWN0TGlrZSh2YWx1ZTIpKTsgLy8gdHJ1ZVxuKiBjb25zb2xlLmxvZyhpc09iamVjdExpa2UodmFsdWUzKSk7IC8vIGZhbHNlXG4qIGNvbnNvbGUubG9nKGlzT2JqZWN0TGlrZSh2YWx1ZTQpKTsgLy8gZmFsc2VcbiogY29uc29sZS5sb2coaXNPYmplY3RMaWtlKHZhbHVlNSkpOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGlzT2JqZWN0TGlrZSh2YWx1ZSkge1xuXHRyZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc09iamVjdExpa2UgfTtcbiIsImltcG9ydCB7IGlzQXJyYXlMaWtlIH0gZnJvbSBcIi4vaXNBcnJheUxpa2UubWpzXCI7XG5pbXBvcnQgeyBpc09iamVjdExpa2UgfSBmcm9tIFwiLi9pc09iamVjdExpa2UubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9wcmVkaWNhdGUvaXNBcnJheUxpa2VPYmplY3QudHNcbi8qKlxuKiBDaGVja3MgaWYgdGhlIGdpdmVuIHZhbHVlIGlzIGEgbm9uLXByaW1pdGl2ZSwgYXJyYXktbGlrZSBvYmplY3QuXG4qXG4qIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgdmFsdWUgaXMgYSBub24tcHJpbWl0aXZlLCBhcnJheS1saWtlIG9iamVjdCwgYGZhbHNlYCBvdGhlcndpc2UuXG4qXG4qIEBleGFtcGxlXG4qIGlzQXJyYXlMaWtlT2JqZWN0KFsxLCAyLCAzXSk7IC8vIHRydWVcbiogaXNBcnJheUxpa2VPYmplY3QoeyAwOiAnYScsIGxlbmd0aDogMSB9KTsgLy8gdHJ1ZVxuKiBpc0FycmF5TGlrZU9iamVjdCgnYWJjJyk7IC8vIGZhbHNlXG4qIGlzQXJyYXlMaWtlT2JqZWN0KCgpPT57fSk7IC8vIGZhbHNlXG4qL1xuZnVuY3Rpb24gaXNBcnJheUxpa2VPYmplY3QodmFsdWUpIHtcblx0cmV0dXJuIGlzT2JqZWN0TGlrZSh2YWx1ZSkgJiYgaXNBcnJheUxpa2UodmFsdWUpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc0FycmF5TGlrZU9iamVjdCB9O1xuIiwiaW1wb3J0IHsgaXNTeW1ib2wgfSBmcm9tIFwiLi4vcHJlZGljYXRlL2lzU3ltYm9sLm1qc1wiO1xuLy8jcmVnaW9uIHNyYy9jb21wYXQvX2ludGVybmFsL2lzS2V5LnRzXG4vKiogIE1hdGNoZXMgYW55IGRlZXAgcHJvcGVydHkgcGF0aC4gKGUuZy4gYGEuYlswXS5jYCkqL1xuY29uc3QgcmVnZXhJc0RlZXBQcm9wID0gL1xcLnxcXFsoPzpbXltcXF1dKnwoW1wiJ10pKD86KD8hXFwxKVteXFxcXF18XFxcXC4pKj9cXDEpXFxdLztcbi8qKiAgTWF0Y2hlcyBhbnkgd29yZCBjaGFyYWN0ZXIgKGFscGhhbnVtZXJpYyAmIHVuZGVyc2NvcmUpLiovXG5jb25zdCByZWdleElzUGxhaW5Qcm9wID0gL15cXHcqJC87XG4vKipcbiogQ2hlY2tzIGlmIGB2YWx1ZWAgaXMgYSBwcm9wZXJ0eSBuYW1lIGFuZCBub3QgYSBwcm9wZXJ0eSBwYXRoLiAoSXQncyBvayB0aGF0IHRoZSBgdmFsdWVgIGlzIG5vdCBpbiB0aGUga2V5cyBvZiB0aGUgYG9iamVjdGApXG4qIEBwYXJhbSB7dW5rbm93bn0gdmFsdWUgVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcGFyYW0ge3Vua25vd259IG9iamVjdCBUaGUgb2JqZWN0IHRvIHF1ZXJ5LlxuKiBAcmV0dXJucyB7Ym9vbGVhbn0gUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIHByb3BlcnR5IG5hbWUsIGVsc2UgYGZhbHNlYC5cbipcbiogQGV4YW1wbGVcbiogaXNLZXkoJ2EnLCB7IGE6IDEgfSk7XG4qIC8vID0+IHRydWVcbipcbiogaXNLZXkoJ2EuYicsIHsgYTogeyBiOiAyIH0gfSk7XG4qIC8vID0+IGZhbHNlXG4qL1xuZnVuY3Rpb24gaXNLZXkodmFsdWUsIG9iamVjdCkge1xuXHRpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBmYWxzZTtcblx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiB8fCB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiIHx8IHZhbHVlID09IG51bGwgfHwgaXNTeW1ib2wodmFsdWUpKSByZXR1cm4gdHJ1ZTtcblx0cmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiAmJiAocmVnZXhJc1BsYWluUHJvcC50ZXN0KHZhbHVlKSB8fCAhcmVnZXhJc0RlZXBQcm9wLnRlc3QodmFsdWUpKSB8fCBvYmplY3QgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duKG9iamVjdCwgdmFsdWUpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc0tleSB9O1xuIiwiaW1wb3J0IHsgaXNUeXBlZEFycmF5IGFzIGlzVHlwZWRBcnJheSQxIH0gZnJvbSBcIi4uLy4uL3ByZWRpY2F0ZS9pc1R5cGVkQXJyYXkubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9wcmVkaWNhdGUvaXNUeXBlZEFycmF5LnRzXG4vKipcbiogQ2hlY2tzIGlmIGEgdmFsdWUgaXMgYSBUeXBlZEFycmF5LlxuKiBAcGFyYW0geCBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIFJldHVybnMgdHJ1ZSBpZiBgeGAgaXMgYSBUeXBlZEFycmF5LCBmYWxzZSBvdGhlcndpc2UuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnN0IGFyciA9IG5ldyBVaW50OEFycmF5KFsxLCAyLCAzXSk7XG4qIGlzVHlwZWRBcnJheShhcnIpOyAvLyB0cnVlXG4qXG4qIGNvbnN0IHJlZ3VsYXJBcnJheSA9IFsxLCAyLCAzXTtcbiogaXNUeXBlZEFycmF5KHJlZ3VsYXJBcnJheSk7IC8vIGZhbHNlXG4qXG4qIGNvbnN0IGJ1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcigxNik7XG4qIGlzVHlwZWRBcnJheShidWZmZXIpOyAvLyBmYWxzZVxuKi9cbmZ1bmN0aW9uIGlzVHlwZWRBcnJheSh4KSB7XG5cdHJldHVybiBpc1R5cGVkQXJyYXkkMSh4KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNUeXBlZEFycmF5IH07XG4iLCJpbXBvcnQgeyBlcSB9IGZyb20gXCIuLi91dGlsL2VxLm1qc1wiO1xuLy8jcmVnaW9uIHNyYy9jb21wYXQvX2ludGVybmFsL2Fzc2lnblZhbHVlLnRzXG5jb25zdCBhc3NpZ25WYWx1ZSA9IChvYmplY3QsIGtleSwgdmFsdWUpID0+IHtcblx0Y29uc3Qgb2JqVmFsdWUgPSBvYmplY3Rba2V5XTtcblx0aWYgKCEoT2JqZWN0Lmhhc093bihvYmplY3QsIGtleSkgJiYgZXEob2JqVmFsdWUsIHZhbHVlKSkgfHwgdmFsdWUgPT09IHZvaWQgMCAmJiAhKGtleSBpbiBvYmplY3QpKSBvYmplY3Rba2V5XSA9IHZhbHVlO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYXNzaWduVmFsdWUgfTtcbiIsIi8vI3JlZ2lvbiBzcmMvX2ludGVybmFsL2lzVW5zYWZlVG9Xcml0ZVByb3BlcnR5LnRzXG4vKipcbiogQ2hlY2tzIGlmIGEgcHJvcGVydHkga2V5IGlzIHVuc2FmZSB0byB3cml0ZSB0by5cbipcbiogV3JpdGluZyB0aHJvdWdoIGBfX3Byb3RvX19gLCBgY29uc3RydWN0b3JgLCBvciBgcHJvdG90eXBlYCBjYW4gcmVhY2hcbiogYE9iamVjdC5wcm90b3R5cGVgIGFuZCBwb2xsdXRlIGV2ZXJ5IG9iamVjdCwgc28gd3JpdGUgcGF0aHMgbGlrZSBgc2V0YCxcbiogYHVwZGF0ZWAsIGFuZCBgemlwT2JqZWN0RGVlcGAgYWJvcnQgd2hlbiBhIHBhdGggc2VnbWVudCBtYXRjaGVzIG9uZSBvZlxuKiB0aGVzZSBrZXlzLCBtYXRjaGluZyBsb2Rhc2gncyBiZWhhdmlvci5cbipcbiogUmVhZCBwYXRocyBsaWtlIGBnZXRgIGFuZCBgdW5zZXRgIHVzZSBgaXNVbnNhZmVQcm9wZXJ0eWAgaW5zdGVhZCwgd2hpY2hcbiogb25seSBibG9ja3MgYF9fcHJvdG9fX2A7IGxvZGFzaCBrZWVwcyByZWFkcyBvZiBgY29uc3RydWN0b3JgIGFuZFxuKiBgcHJvdG90eXBlYCB1bnJlc3RyaWN0ZWQuXG4qXG4qIEBwYXJhbSBrZXkgLSBUaGUgcHJvcGVydHkga2V5IHRvIGNoZWNrXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcHJvcGVydHkgaXMgdW5zYWZlIHRvIHdyaXRlIHRvLCBgZmFsc2VgIG90aGVyd2lzZVxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiBpc1Vuc2FmZVRvV3JpdGVQcm9wZXJ0eShrZXkpIHtcblx0cmV0dXJuIGtleSA9PT0gXCJfX3Byb3RvX19cIiB8fCBrZXkgPT09IFwiY29uc3RydWN0b3JcIiB8fCBrZXkgPT09IFwicHJvdG90eXBlXCI7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzVW5zYWZlVG9Xcml0ZVByb3BlcnR5IH07XG4iLCJpbXBvcnQgeyB0b0tleSB9IGZyb20gXCIuLi9faW50ZXJuYWwvdG9LZXkubWpzXCI7XG5pbXBvcnQgeyB0b1BhdGggfSBmcm9tIFwiLi4vdXRpbC90b1BhdGgubWpzXCI7XG5pbXBvcnQgeyBnZXQgfSBmcm9tIFwiLi9nZXQubWpzXCI7XG5pbXBvcnQgeyBpc09iamVjdCB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNPYmplY3QubWpzXCI7XG5pbXBvcnQgeyBpc0luZGV4IH0gZnJvbSBcIi4uL19pbnRlcm5hbC9pc0luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgaXNLZXkgfSBmcm9tIFwiLi4vX2ludGVybmFsL2lzS2V5Lm1qc1wiO1xuaW1wb3J0IHsgYXNzaWduVmFsdWUgfSBmcm9tIFwiLi4vX2ludGVybmFsL2Fzc2lnblZhbHVlLm1qc1wiO1xuaW1wb3J0IHsgaXNVbnNhZmVUb1dyaXRlUHJvcGVydHkgfSBmcm9tIFwiLi4vLi4vX2ludGVybmFsL2lzVW5zYWZlVG9Xcml0ZVByb3BlcnR5Lm1qc1wiO1xuLy8jcmVnaW9uIHNyYy9jb21wYXQvb2JqZWN0L3VwZGF0ZVdpdGgudHNcbi8qKlxuKiBVcGRhdGVzIHRoZSB2YWx1ZSBhdCB0aGUgc3BlY2lmaWVkIHBhdGggb2YgdGhlIGdpdmVuIG9iamVjdCB1c2luZyBhbiB1cGRhdGVyIGZ1bmN0aW9uIGFuZCBhIGN1c3RvbWl6ZXIuXG4qIElmIGFueSBwYXJ0IG9mIHRoZSBwYXRoIGRvZXMgbm90IGV4aXN0LCBpdCB3aWxsIGJlIGNyZWF0ZWQuXG4qXG4qIEB0ZW1wbGF0ZSBUIC0gVGhlIHR5cGUgb2YgdGhlIG9iamVjdC5cbiogQHRlbXBsYXRlIFIgLSBUaGUgdHlwZSBvZiB0aGUgcmV0dXJuIHZhbHVlLlxuKiBAcGFyYW0gb2JqIC0gVGhlIG9iamVjdCB0byBtb2RpZnkuXG4qIEBwYXJhbSBwYXRoIC0gVGhlIHBhdGggb2YgdGhlIHByb3BlcnR5IHRvIHVwZGF0ZS5cbiogQHBhcmFtIHVwZGF0ZXIgLSBUaGUgZnVuY3Rpb24gdG8gcHJvZHVjZSB0aGUgdXBkYXRlZCB2YWx1ZS5cbiogQHBhcmFtIGN1c3RvbWl6ZXIgLSBUaGUgZnVuY3Rpb24gdG8gY3VzdG9taXplIHRoZSB1cGRhdGUgcHJvY2Vzcy5cbiogQHJldHVybnMgVGhlIG1vZGlmaWVkIG9iamVjdC5cbipcbiogQGV4YW1wbGVcbiogY29uc3Qgb2JqZWN0ID0geyAnYSc6IFt7ICdiJzogeyAnYyc6IDMgfSB9XSB9O1xuKiB1cGRhdGVXaXRoKG9iamVjdCwgJ2FbMF0uYi5jJywgKG4pID0+IG4gKiBuKTtcbiogLy8gPT4geyAnYSc6IFt7ICdiJzogeyAnYyc6IDkgfSB9XSB9XG4qL1xuZnVuY3Rpb24gdXBkYXRlV2l0aChvYmosIHBhdGgsIHVwZGF0ZXIsIGN1c3RvbWl6ZXIpIHtcblx0aWYgKG9iaiA9PSBudWxsICYmICFpc09iamVjdChvYmopKSByZXR1cm4gb2JqO1xuXHRsZXQgcmVzb2x2ZWRQYXRoO1xuXHRpZiAoaXNLZXkocGF0aCwgb2JqKSkgcmVzb2x2ZWRQYXRoID0gW3BhdGhdO1xuXHRlbHNlIGlmIChBcnJheS5pc0FycmF5KHBhdGgpKSByZXNvbHZlZFBhdGggPSBwYXRoO1xuXHRlbHNlIHJlc29sdmVkUGF0aCA9IHRvUGF0aChwYXRoKTtcblx0Y29uc3QgdXBkYXRlVmFsdWUgPSB1cGRhdGVyKGdldChvYmosIHJlc29sdmVkUGF0aCkpO1xuXHRsZXQgY3VycmVudCA9IG9iajtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCByZXNvbHZlZFBhdGgubGVuZ3RoICYmIGN1cnJlbnQgIT0gbnVsbDsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gdG9LZXkocmVzb2x2ZWRQYXRoW2ldKTtcblx0XHRpZiAoaXNVbnNhZmVUb1dyaXRlUHJvcGVydHkoa2V5KSkgcmV0dXJuIG9iajtcblx0XHRsZXQgbmV3VmFsdWU7XG5cdFx0aWYgKGkgPT09IHJlc29sdmVkUGF0aC5sZW5ndGggLSAxKSBuZXdWYWx1ZSA9IHVwZGF0ZVZhbHVlO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3Qgb2JqVmFsdWUgPSBjdXJyZW50W2tleV07XG5cdFx0XHRjb25zdCBjdXN0b21pemVyUmVzdWx0ID0gY3VzdG9taXplcj8uKG9ialZhbHVlLCBrZXksIG9iaik7XG5cdFx0XHRuZXdWYWx1ZSA9IGN1c3RvbWl6ZXJSZXN1bHQgIT09IHZvaWQgMCA/IGN1c3RvbWl6ZXJSZXN1bHQgOiBpc09iamVjdChvYmpWYWx1ZSkgPyBvYmpWYWx1ZSA6IGlzSW5kZXgocmVzb2x2ZWRQYXRoW2kgKyAxXSkgPyBbXSA6IHt9O1xuXHRcdH1cblx0XHRhc3NpZ25WYWx1ZShjdXJyZW50LCBrZXksIG5ld1ZhbHVlKTtcblx0XHRjdXJyZW50ID0gY3VycmVudFtrZXldO1xuXHR9XG5cdHJldHVybiBvYmo7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVwZGF0ZVdpdGggfTtcbiIsImltcG9ydCB7IHVwZGF0ZVdpdGggfSBmcm9tIFwiLi91cGRhdGVXaXRoLm1qc1wiO1xuLy8jcmVnaW9uIHNyYy9jb21wYXQvb2JqZWN0L3NldC50c1xuLyoqXG4qIFNldHMgdGhlIHZhbHVlIGF0IHRoZSBzcGVjaWZpZWQgcGF0aCBvZiB0aGUgZ2l2ZW4gb2JqZWN0LiBJZiBhbnkgcGFydCBvZiB0aGUgcGF0aCBkb2VzIG5vdCBleGlzdCwgaXQgd2lsbCBiZSBjcmVhdGVkLlxuKlxuKiBAdGVtcGxhdGUgVCAtIFRoZSB0eXBlIG9mIHRoZSBvYmplY3QuXG4qIEBwYXJhbSBvYmogLSBUaGUgb2JqZWN0IHRvIG1vZGlmeS5cbiogQHBhcmFtIHBhdGggLSBUaGUgcGF0aCBvZiB0aGUgcHJvcGVydHkgdG8gc2V0LlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gc2V0LlxuKiBAcmV0dXJucyBUaGUgbW9kaWZpZWQgb2JqZWN0LlxuKlxuKiBAZXhhbXBsZVxuKiAvLyBTZXQgYSB2YWx1ZSBpbiBhIG5lc3RlZCBvYmplY3RcbiogY29uc3Qgb2JqID0geyBhOiB7IGI6IHsgYzogMyB9IH0gfTtcbiogc2V0KG9iaiwgJ2EuYi5jJywgNCk7XG4qIGNvbnNvbGUubG9nKG9iai5hLmIuYyk7IC8vIDRcbipcbiogQGV4YW1wbGVcbiogLy8gU2V0IGEgdmFsdWUgaW4gYW4gYXJyYXlcbiogY29uc3QgYXJyID0gWzEsIDIsIDNdO1xuKiBzZXQoYXJyLCAxLCA0KTtcbiogY29uc29sZS5sb2coYXJyWzFdKTsgLy8gNFxuKlxuKiBAZXhhbXBsZVxuKiAvLyBDcmVhdGUgbm9uLWV4aXN0ZW50IHBhdGggYW5kIHNldCB2YWx1ZVxuKiBjb25zdCBvYmogPSB7fTtcbiogc2V0KG9iaiwgJ2EuYi5jJywgNCk7XG4qIGNvbnNvbGUubG9nKG9iaik7IC8vIHsgYTogeyBiOiB7IGM6IDQgfSB9IH1cbiovXG5mdW5jdGlvbiBzZXQob2JqLCBwYXRoLCB2YWx1ZSkge1xuXHRyZXR1cm4gdXBkYXRlV2l0aChvYmosIHBhdGgsICgpID0+IHZhbHVlLCAoKSA9PiB2b2lkIDApO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBzZXQgfTtcbiIsImltcG9ydCB7IGRlYm91bmNlIGFzIGRlYm91bmNlJDEgfSBmcm9tIFwiLi4vLi4vZnVuY3Rpb24vZGVib3VuY2UubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9mdW5jdGlvbi9kZWJvdW5jZS50c1xuZnVuY3Rpb24gZGVib3VuY2UoZnVuYywgZGVib3VuY2VNcyA9IDAsIG9wdGlvbnMgPSB7fSkge1xuXHRpZiAodHlwZW9mIG9wdGlvbnMgIT09IFwib2JqZWN0XCIpIG9wdGlvbnMgPSB7fTtcblx0Y29uc3QgeyBsZWFkaW5nID0gZmFsc2UsIHRyYWlsaW5nID0gdHJ1ZSwgbWF4V2FpdCB9ID0gb3B0aW9ucztcblx0Y29uc3QgZWRnZXMgPSBBcnJheSgyKTtcblx0aWYgKGxlYWRpbmcpIGVkZ2VzWzBdID0gXCJsZWFkaW5nXCI7XG5cdGlmICh0cmFpbGluZykgZWRnZXNbMV0gPSBcInRyYWlsaW5nXCI7XG5cdGxldCByZXN1bHQgPSB2b2lkIDA7XG5cdGxldCBwZW5kaW5nQXQgPSBudWxsO1xuXHRjb25zdCBfZGVib3VuY2VkID0gZGVib3VuY2UkMShmdW5jdGlvbiguLi5hcmdzKSB7XG5cdFx0cmVzdWx0ID0gZnVuYy5hcHBseSh0aGlzLCBhcmdzKTtcblx0XHRwZW5kaW5nQXQgPSBudWxsO1xuXHR9LCBkZWJvdW5jZU1zLCB7IGVkZ2VzIH0pO1xuXHRjb25zdCBkZWJvdW5jZWQgPSBmdW5jdGlvbiguLi5hcmdzKSB7XG5cdFx0aWYgKG1heFdhaXQgIT0gbnVsbCkge1xuXHRcdFx0aWYgKHBlbmRpbmdBdCA9PT0gbnVsbCkgcGVuZGluZ0F0ID0gRGF0ZS5ub3coKTtcblx0XHRcdGlmIChEYXRlLm5vdygpIC0gcGVuZGluZ0F0ID49IG1heFdhaXQpIHtcblx0XHRcdFx0aWYgKGxlYWRpbmcgfHwgdHJhaWxpbmcpIHJlc3VsdCA9IGZ1bmMuYXBwbHkodGhpcywgYXJncyk7XG5cdFx0XHRcdHBlbmRpbmdBdCA9IERhdGUubm93KCk7XG5cdFx0XHRcdF9kZWJvdW5jZWQuY2FuY2VsKCk7XG5cdFx0XHRcdF9kZWJvdW5jZWQuc2NoZWR1bGUoKTtcblx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdH1cblx0XHR9XG5cdFx0X2RlYm91bmNlZC5hcHBseSh0aGlzLCBhcmdzKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9O1xuXHRjb25zdCBmbHVzaCA9ICgpID0+IHtcblx0XHRfZGVib3VuY2VkLmZsdXNoKCk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fTtcblx0ZGVib3VuY2VkLmNhbmNlbCA9IF9kZWJvdW5jZWQuY2FuY2VsO1xuXHRkZWJvdW5jZWQuZmx1c2ggPSBmbHVzaDtcblx0cmV0dXJuIGRlYm91bmNlZDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVib3VuY2UgfTtcbiIsImltcG9ydCB7IGlzUHJpbWl0aXZlIH0gZnJvbSBcIi4uLy4uL3ByZWRpY2F0ZS9pc1ByaW1pdGl2ZS5tanNcIjtcbmltcG9ydCB7IGNsb25lIH0gZnJvbSBcIi4uLy4uL29iamVjdC9jbG9uZS5tanNcIjtcbmltcG9ydCB7IGdldFN5bWJvbHMgfSBmcm9tIFwiLi4vX2ludGVybmFsL2dldFN5bWJvbHMubWpzXCI7XG5pbXBvcnQgeyBpc0J1ZmZlciB9IGZyb20gXCIuLi8uLi9wcmVkaWNhdGUvaXNCdWZmZXIubWpzXCI7XG5pbXBvcnQgeyBpc1Vuc2FmZVByb3BlcnR5IH0gZnJvbSBcIi4uLy4uL19pbnRlcm5hbC9pc1Vuc2FmZVByb3BlcnR5Lm1qc1wiO1xuaW1wb3J0IHsgaXNQbGFpbk9iamVjdCB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNQbGFpbk9iamVjdC5tanNcIjtcbmltcG9ydCB7IGNsb25lRGVlcCB9IGZyb20gXCIuL2Nsb25lRGVlcC5tanNcIjtcbmltcG9ydCB7IGlzQXJndW1lbnRzIH0gZnJvbSBcIi4uL3ByZWRpY2F0ZS9pc0FyZ3VtZW50cy5tanNcIjtcbmltcG9ydCB7IGlzT2JqZWN0TGlrZSB9IGZyb20gXCIuLi9wcmVkaWNhdGUvaXNPYmplY3RMaWtlLm1qc1wiO1xuaW1wb3J0IHsgaXNBcnJheUxpa2VPYmplY3QgfSBmcm9tIFwiLi4vcHJlZGljYXRlL2lzQXJyYXlMaWtlT2JqZWN0Lm1qc1wiO1xuaW1wb3J0IHsgaXNUeXBlZEFycmF5IH0gZnJvbSBcIi4uL3ByZWRpY2F0ZS9pc1R5cGVkQXJyYXkubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9vYmplY3QvbWVyZ2VXaXRoLnRzXG4vKipcbiogTWVyZ2VzIHRoZSBwcm9wZXJ0aWVzIG9mIG9uZSBvciBtb3JlIHNvdXJjZSBvYmplY3RzIGludG8gdGhlIHRhcmdldCBvYmplY3QgdXNpbmcgYSBjdXN0b21pemVyIGZ1bmN0aW9uLlxuKlxuKiBUaGlzIGZ1bmN0aW9uIHBlcmZvcm1zIGEgZGVlcCBtZXJnZSwgcmVjdXJzaXZlbHkgbWVyZ2luZyBuZXN0ZWQgb2JqZWN0cyBhbmQgYXJyYXlzLlxuKiBJZiBhIHByb3BlcnR5IGluIHRoZSBzb3VyY2Ugb2JqZWN0IGlzIGFuIGFycmF5IG9yIG9iamVjdCBhbmQgdGhlIGNvcnJlc3BvbmRpbmcgcHJvcGVydHkgaW4gdGhlIHRhcmdldCBvYmplY3QgaXMgYWxzbyBhbiBhcnJheSBvciBvYmplY3QsIHRoZXkgd2lsbCBiZSBtZXJnZWQuXG4qIElmIGEgcHJvcGVydHkgaW4gdGhlIHNvdXJjZSBvYmplY3QgaXMgYHVuZGVmaW5lZGAsIGl0IHdpbGwgbm90IG92ZXJ3cml0ZSBhIGRlZmluZWQgcHJvcGVydHkgaW4gdGhlIHRhcmdldCBvYmplY3QuXG4qXG4qIFlvdSBjYW4gcHJvdmlkZSBhIGN1c3RvbSBgbWVyZ2VgIGZ1bmN0aW9uIHRvIGNvbnRyb2wgaG93IHByb3BlcnRpZXMgYXJlIG1lcmdlZC4gVGhlIGBtZXJnZWAgZnVuY3Rpb24gaXMgY2FsbGVkIGZvciBlYWNoIHByb3BlcnR5IHRoYXQgaXMgYmVpbmcgbWVyZ2VkIGFuZCByZWNlaXZlcyB0aGUgZm9sbG93aW5nIGFyZ3VtZW50czpcbipcbiogLSBgdGFyZ2V0VmFsdWVgOiBUaGUgY3VycmVudCB2YWx1ZSBvZiB0aGUgcHJvcGVydHkgaW4gdGhlIHRhcmdldCBvYmplY3QuXG4qIC0gYHNvdXJjZVZhbHVlYDogVGhlIHZhbHVlIG9mIHRoZSBwcm9wZXJ0eSBpbiB0aGUgc291cmNlIG9iamVjdC5cbiogLSBga2V5YDogVGhlIGtleSBvZiB0aGUgcHJvcGVydHkgYmVpbmcgbWVyZ2VkLlxuKiAtIGB0YXJnZXRgOiBUaGUgdGFyZ2V0IG9iamVjdC5cbiogLSBgc291cmNlYDogVGhlIHNvdXJjZSBvYmplY3QuXG4qIC0gYHN0YWNrYDogQSBgTWFwYCB1c2VkIHRvIGtlZXAgdHJhY2sgb2Ygb2JqZWN0cyB0aGF0IGhhdmUgYWxyZWFkeSBiZWVuIHByb2Nlc3NlZCB0byBoYW5kbGUgY2lyY3VsYXIgcmVmZXJlbmNlcy5cbipcbiogVGhlIGBtZXJnZWAgZnVuY3Rpb24gc2hvdWxkIHJldHVybiB0aGUgdmFsdWUgdG8gYmUgc2V0IGluIHRoZSB0YXJnZXQgb2JqZWN0LiBJZiBpdCByZXR1cm5zIGB1bmRlZmluZWRgLCBhIGRlZmF1bHQgZGVlcCBtZXJnZSB3aWxsIGJlIGFwcGxpZWQgZm9yIGFycmF5cyBhbmQgb2JqZWN0cy5cbipcbiogVGhlIGZ1bmN0aW9uIGNhbiBoYW5kbGUgbXVsdGlwbGUgc291cmNlIG9iamVjdHMgYW5kIHdpbGwgbWVyZ2UgdGhlbSBhbGwgaW50byB0aGUgdGFyZ2V0IG9iamVjdC5cbipcbiogQHBhcmFtIG9iamVjdCAtIFRoZSB0YXJnZXQgb2JqZWN0IGludG8gd2hpY2ggdGhlIHNvdXJjZSBvYmplY3QgcHJvcGVydGllcyB3aWxsIGJlIG1lcmdlZC4gVGhpcyBvYmplY3QgaXMgbW9kaWZpZWQgaW4gcGxhY2UuXG4qIEBwYXJhbSBvdGhlckFyZ3MgLSBBZGRpdGlvbmFsIHNvdXJjZSBvYmplY3RzIHRvIG1lcmdlIGludG8gdGhlIHRhcmdldCBvYmplY3QsIGluY2x1ZGluZyB0aGUgY3VzdG9tIGBtZXJnZWAgZnVuY3Rpb24uXG4qIEByZXR1cm5zIFRoZSB1cGRhdGVkIHRhcmdldCBvYmplY3Qgd2l0aCBwcm9wZXJ0aWVzIGZyb20gdGhlIHNvdXJjZSBvYmplY3QocykgbWVyZ2VkIGluLlxuKlxuKiBAZXhhbXBsZVxuKiBjb25zdCB0YXJnZXQgPSB7IGE6IDEsIGI6IDIgfTtcbiogY29uc3Qgc291cmNlID0geyBiOiAzLCBjOiA0IH07XG4qXG4qIG1lcmdlV2l0aCh0YXJnZXQsIHNvdXJjZSwgKHRhcmdldFZhbHVlLCBzb3VyY2VWYWx1ZSkgPT4ge1xuKiAgIGlmICh0eXBlb2YgdGFyZ2V0VmFsdWUgPT09ICdudW1iZXInICYmIHR5cGVvZiBzb3VyY2VWYWx1ZSA9PT0gJ251bWJlcicpIHtcbiogICAgIHJldHVybiB0YXJnZXRWYWx1ZSArIHNvdXJjZVZhbHVlO1xuKiAgIH1cbiogfSk7XG4qIC8vIFJldHVybnMgeyBhOiAxLCBiOiA1LCBjOiA0IH1cbiogQGV4YW1wbGVcbiogY29uc3QgdGFyZ2V0ID0geyBhOiBbMV0sIGI6IFsyXSB9O1xuKiBjb25zdCBzb3VyY2UgPSB7IGE6IFszXSwgYjogWzRdIH07XG4qXG4qIGNvbnN0IHJlc3VsdCA9IG1lcmdlV2l0aCh0YXJnZXQsIHNvdXJjZSwgKG9ialZhbHVlLCBzcmNWYWx1ZSkgPT4ge1xuKiAgIGlmIChBcnJheS5pc0FycmF5KG9ialZhbHVlKSkge1xuKiAgICAgcmV0dXJuIG9ialZhbHVlLmNvbmNhdChzcmNWYWx1ZSk7XG4qICAgfVxuKiB9KTtcbipcbiogZXhwZWN0KHJlc3VsdCkudG9FcXVhbCh7IGE6IFsxLCAzXSwgYjogWzIsIDRdIH0pO1xuKi9cbmZ1bmN0aW9uIG1lcmdlV2l0aChvYmplY3QsIC4uLm90aGVyQXJncykge1xuXHRjb25zdCBzb3VyY2VzID0gb3RoZXJBcmdzLnNsaWNlKDAsIC0xKTtcblx0Y29uc3QgbWVyZ2UgPSBvdGhlckFyZ3Nbb3RoZXJBcmdzLmxlbmd0aCAtIDFdO1xuXHRsZXQgcmVzdWx0ID0gb2JqZWN0O1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHNvdXJjZXMubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBzb3VyY2UgPSBzb3VyY2VzW2ldO1xuXHRcdHJlc3VsdCA9IG1lcmdlV2l0aERlZXAocmVzdWx0LCBzb3VyY2UsIG1lcmdlLCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gbWVyZ2VXaXRoRGVlcCh0YXJnZXQsIHNvdXJjZSwgbWVyZ2UsIHN0YWNrKSB7XG5cdGlmIChpc1ByaW1pdGl2ZSh0YXJnZXQpKSB0YXJnZXQgPSBPYmplY3QodGFyZ2V0KTtcblx0aWYgKHNvdXJjZSA9PSBudWxsIHx8IHR5cGVvZiBzb3VyY2UgIT09IFwib2JqZWN0XCIpIHJldHVybiB0YXJnZXQ7XG5cdGlmIChzdGFjay5oYXMoc291cmNlKSkgcmV0dXJuIGNsb25lKHN0YWNrLmdldChzb3VyY2UpKTtcblx0c3RhY2suc2V0KHNvdXJjZSwgdGFyZ2V0KTtcblx0aWYgKEFycmF5LmlzQXJyYXkoc291cmNlKSkge1xuXHRcdHNvdXJjZSA9IHNvdXJjZS5zbGljZSgpO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlLmxlbmd0aDsgaSsrKSBpZiAoIShpIGluIHNvdXJjZSkpIHNvdXJjZVtpXSA9IHZvaWQgMDtcblx0fVxuXHRjb25zdCBzb3VyY2VLZXlzID0gWy4uLk9iamVjdC5rZXlzKHNvdXJjZSksIC4uLmdldFN5bWJvbHMoc291cmNlKV07XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlS2V5cy5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IHNvdXJjZUtleXNbaV07XG5cdFx0aWYgKGlzVW5zYWZlUHJvcGVydHkoa2V5KSkgY29udGludWU7XG5cdFx0bGV0IHNvdXJjZVZhbHVlID0gc291cmNlW2tleV07XG5cdFx0bGV0IHRhcmdldFZhbHVlID0gdGFyZ2V0W2tleV07XG5cdFx0aWYgKGlzQXJndW1lbnRzKHNvdXJjZVZhbHVlKSkgc291cmNlVmFsdWUgPSB7IC4uLnNvdXJjZVZhbHVlIH07XG5cdFx0aWYgKGlzQXJndW1lbnRzKHRhcmdldFZhbHVlKSkgdGFyZ2V0VmFsdWUgPSB7IC4uLnRhcmdldFZhbHVlIH07XG5cdFx0aWYgKGlzQnVmZmVyKHNvdXJjZVZhbHVlKSkgc291cmNlVmFsdWUgPSBjbG9uZURlZXAoc291cmNlVmFsdWUpO1xuXHRcdGlmIChBcnJheS5pc0FycmF5KHNvdXJjZVZhbHVlKSkgaWYgKEFycmF5LmlzQXJyYXkodGFyZ2V0VmFsdWUpKSB7XG5cdFx0XHRjb25zdCBjbG9uZWQgPSBbXTtcblx0XHRcdGNvbnN0IHRhcmdldEtleXMgPSBSZWZsZWN0Lm93bktleXModGFyZ2V0VmFsdWUpO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCB0YXJnZXRLZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IHRhcmdldEtleSA9IHRhcmdldEtleXNbaV07XG5cdFx0XHRcdGNsb25lZFt0YXJnZXRLZXldID0gdGFyZ2V0VmFsdWVbdGFyZ2V0S2V5XTtcblx0XHRcdH1cblx0XHRcdHRhcmdldFZhbHVlID0gY2xvbmVkO1xuXHRcdH0gZWxzZSBpZiAoaXNBcnJheUxpa2VPYmplY3QodGFyZ2V0VmFsdWUpKSB7XG5cdFx0XHRjb25zdCBjbG9uZWQgPSBbXTtcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgdGFyZ2V0VmFsdWUubGVuZ3RoOyBpKyspIGNsb25lZFtpXSA9IHRhcmdldFZhbHVlW2ldO1xuXHRcdFx0dGFyZ2V0VmFsdWUgPSBjbG9uZWQ7XG5cdFx0fSBlbHNlIHRhcmdldFZhbHVlID0gW107XG5cdFx0Y29uc3QgbWVyZ2VkID0gbWVyZ2UodGFyZ2V0VmFsdWUsIHNvdXJjZVZhbHVlLCBrZXksIHRhcmdldCwgc291cmNlLCBzdGFjayk7XG5cdFx0aWYgKG1lcmdlZCAhPT0gdm9pZCAwKSB0YXJnZXRba2V5XSA9IG1lcmdlZDtcblx0XHRlbHNlIGlmIChBcnJheS5pc0FycmF5KHNvdXJjZVZhbHVlKSkgdGFyZ2V0W2tleV0gPSBtZXJnZVdpdGhEZWVwKHRhcmdldFZhbHVlLCBzb3VyY2VWYWx1ZSwgbWVyZ2UsIHN0YWNrKTtcblx0XHRlbHNlIGlmIChpc09iamVjdExpa2UodGFyZ2V0VmFsdWUpICYmIGlzT2JqZWN0TGlrZShzb3VyY2VWYWx1ZSkgJiYgKGlzUGxhaW5PYmplY3QodGFyZ2V0VmFsdWUpIHx8IGlzUGxhaW5PYmplY3Qoc291cmNlVmFsdWUpIHx8IGlzVHlwZWRBcnJheSh0YXJnZXRWYWx1ZSkgfHwgaXNUeXBlZEFycmF5KHNvdXJjZVZhbHVlKSkpIHRhcmdldFtrZXldID0gbWVyZ2VXaXRoRGVlcCh0YXJnZXRWYWx1ZSwgc291cmNlVmFsdWUsIG1lcmdlLCBzdGFjayk7XG5cdFx0ZWxzZSBpZiAodGFyZ2V0VmFsdWUgPT0gbnVsbCAmJiBpc1BsYWluT2JqZWN0KHNvdXJjZVZhbHVlKSkgdGFyZ2V0W2tleV0gPSBtZXJnZVdpdGhEZWVwKHt9LCBzb3VyY2VWYWx1ZSwgbWVyZ2UsIHN0YWNrKTtcblx0XHRlbHNlIGlmICh0YXJnZXRWYWx1ZSA9PSBudWxsICYmIGlzVHlwZWRBcnJheShzb3VyY2VWYWx1ZSkpIHRhcmdldFtrZXldID0gY2xvbmVEZWVwKHNvdXJjZVZhbHVlKTtcblx0XHRlbHNlIGlmICh0YXJnZXRWYWx1ZSA9PT0gdm9pZCAwIHx8IHNvdXJjZVZhbHVlICE9PSB2b2lkIDApIHRhcmdldFtrZXldID0gc291cmNlVmFsdWU7XG5cdH1cblx0cmV0dXJuIHRhcmdldDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbWVyZ2VXaXRoIH07XG4iLCJpbXBvcnQgeyBub29wIH0gZnJvbSBcIi4uLy4uL2Z1bmN0aW9uL25vb3AubWpzXCI7XG5pbXBvcnQgeyBtZXJnZVdpdGggfSBmcm9tIFwiLi9tZXJnZVdpdGgubWpzXCI7XG4vLyNyZWdpb24gc3JjL2NvbXBhdC9vYmplY3QvbWVyZ2UudHNcbi8qKlxuKiBNZXJnZXMgdGhlIHByb3BlcnRpZXMgb2Ygb25lIG9yIG1vcmUgc291cmNlIG9iamVjdHMgaW50byB0aGUgdGFyZ2V0IG9iamVjdC5cbipcbiogVGhpcyBmdW5jdGlvbiBwZXJmb3JtcyBhIGRlZXAgbWVyZ2UsIHJlY3Vyc2l2ZWx5IG1lcmdpbmcgbmVzdGVkIG9iamVjdHMgYW5kIGFycmF5cy5cbiogSWYgYSBwcm9wZXJ0eSBpbiB0aGUgc291cmNlIG9iamVjdCBpcyBhbiBhcnJheSBvciBvYmplY3QgYW5kIHRoZSBjb3JyZXNwb25kaW5nIHByb3BlcnR5IGluIHRoZSB0YXJnZXQgb2JqZWN0IGlzIGFsc28gYW4gYXJyYXkgb3Igb2JqZWN0LCB0aGV5IHdpbGwgYmUgbWVyZ2VkLlxuKiBJZiBhIHByb3BlcnR5IGluIHRoZSBzb3VyY2Ugb2JqZWN0IGlzIGB1bmRlZmluZWRgLCBpdCB3aWxsIG5vdCBvdmVyd3JpdGUgYSBkZWZpbmVkIHByb3BlcnR5IGluIHRoZSB0YXJnZXQgb2JqZWN0LlxuKlxuKiBUaGUgZnVuY3Rpb24gY2FuIGhhbmRsZSBtdWx0aXBsZSBzb3VyY2Ugb2JqZWN0cyBhbmQgd2lsbCBtZXJnZSB0aGVtIGFsbCBpbnRvIHRoZSB0YXJnZXQgb2JqZWN0LlxuKlxuKiBAcGFyYW0gb2JqZWN0IC0gVGhlIHRhcmdldCBvYmplY3QgaW50byB3aGljaCB0aGUgc291cmNlIG9iamVjdCBwcm9wZXJ0aWVzIHdpbGwgYmUgbWVyZ2VkLiBUaGlzIG9iamVjdCBpcyBtb2RpZmllZCBpbiBwbGFjZS5cbiogQHBhcmFtIHNvdXJjZXMgLSBUaGUgc291cmNlIG9iamVjdHMgd2hvc2UgcHJvcGVydGllcyB3aWxsIGJlIG1lcmdlZCBpbnRvIHRoZSB0YXJnZXQgb2JqZWN0LlxuKiBAcmV0dXJucyBUaGUgdXBkYXRlZCB0YXJnZXQgb2JqZWN0IHdpdGggcHJvcGVydGllcyBmcm9tIHRoZSBzb3VyY2Ugb2JqZWN0KHMpIG1lcmdlZCBpbi5cbipcbiogQGV4YW1wbGVcbiogY29uc3QgdGFyZ2V0ID0geyBhOiAxLCBiOiB7IHg6IDEsIHk6IDIgfSB9O1xuKiBjb25zdCBzb3VyY2UgPSB7IGI6IHsgeTogMywgejogNCB9LCBjOiA1IH07XG4qXG4qIGNvbnN0IHJlc3VsdCA9IG1lcmdlKHRhcmdldCwgc291cmNlKTtcbiogY29uc29sZS5sb2cocmVzdWx0KTtcbiogLy8gT3V0cHV0OiB7IGE6IDEsIGI6IHsgeDogMSwgeTogMywgejogNCB9LCBjOiA1IH1cbipcbiogQGV4YW1wbGVcbiogY29uc3QgdGFyZ2V0ID0geyBhOiBbMSwgMl0sIGI6IHsgeDogMSB9IH07XG4qIGNvbnN0IHNvdXJjZSA9IHsgYTogWzNdLCBiOiB7IHk6IDIgfSB9O1xuKlxuKiBjb25zdCByZXN1bHQgPSBtZXJnZSh0YXJnZXQsIHNvdXJjZSk7XG4qIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4qIC8vIE91dHB1dDogeyBhOiBbM10sIGI6IHsgeDogMSwgeTogMiB9IH1cbipcbiogQGV4YW1wbGVcbiogY29uc3QgdGFyZ2V0ID0geyBhOiBudWxsIH07XG4qIGNvbnN0IHNvdXJjZSA9IHsgYTogWzEsIDIsIDNdIH07XG4qXG4qIGNvbnN0IHJlc3VsdCA9IG1lcmdlKHRhcmdldCwgc291cmNlKTtcbiogY29uc29sZS5sb2cocmVzdWx0KTtcbiogLy8gT3V0cHV0OiB7IGE6IFsxLCAyLCAzXSB9XG4qL1xuZnVuY3Rpb24gbWVyZ2Uob2JqZWN0LCAuLi5zb3VyY2VzKSB7XG5cdHJldHVybiBtZXJnZVdpdGgob2JqZWN0LCAuLi5zb3VyY2VzLCBub29wKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbWVyZ2UgfTtcbiIsImltcG9ydCB7IGVzY2FwZSBhcyBlc2NhcGUkMSB9IGZyb20gXCIuLi8uLi9zdHJpbmcvZXNjYXBlLm1qc1wiO1xuaW1wb3J0IHsgdG9TdHJpbmcgfSBmcm9tIFwiLi4vdXRpbC90b1N0cmluZy5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvY29tcGF0L3N0cmluZy9lc2NhcGUudHNcbi8qKlxuKiBDb252ZXJ0cyB0aGUgY2hhcmFjdGVycyBcIiZcIiwgXCI8XCIsIFwiPlwiLCAnXCInLCBhbmQgXCInXCIgaW4gYHN0cmAgdG8gdGhlaXIgY29ycmVzcG9uZGluZyBIVE1MIGVudGl0aWVzLlxuKiBGb3IgZXhhbXBsZSwgXCI8XCIgYmVjb21lcyBcIiZsdDtcIi5cbipcbiogQHBhcmFtIHN0ciAgVGhlIHN0cmluZyB0byBlc2NhcGUuXG4qIEByZXR1cm5zIFJldHVybnMgdGhlIGVzY2FwZWQgc3RyaW5nLlxuKlxuKiBAZXhhbXBsZVxuKiBlc2NhcGUoJ1RoaXMgaXMgYSA8ZGl2PiBlbGVtZW50LicpOyAvLyByZXR1cm5zICdUaGlzIGlzIGEgJmx0O2RpdiZndDsgZWxlbWVudC4nXG4qIGVzY2FwZSgnVGhpcyBpcyBhIFwicXVvdGVcIicpOyAvLyByZXR1cm5zICdUaGlzIGlzIGEgJnF1b3Q7cXVvdGUmcXVvdDsnXG4qIGVzY2FwZShcIlRoaXMgaXMgYSAncXVvdGUnXCIpOyAvLyByZXR1cm5zICdUaGlzIGlzIGEgJiMzOTtxdW90ZSYjMzk7J1xuKiBlc2NhcGUoJ1RoaXMgaXMgYSAmIHN5bWJvbCcpOyAvLyByZXR1cm5zICdUaGlzIGlzIGEgJmFtcDsgc3ltYm9sJ1xuKi9cbmZ1bmN0aW9uIGVzY2FwZShzdHJpbmcpIHtcblx0cmV0dXJuIGVzY2FwZSQxKHRvU3RyaW5nKHN0cmluZykpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBlc2NhcGUgfTtcbiIsIi8qKlxuICogRGV0ZXJtaW5lIGlmIHRoZSB2YWx1ZSBpcyBhIGZpbGUuXG4gKi9cbmV4cG9ydCBjb25zdCBpc0ZpbGUgPSAodmFsdWUpID0+ICh0eXBlb2YgRmlsZSAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgaW5zdGFuY2VvZiBGaWxlKVxuICAgIHx8IHZhbHVlIGluc3RhbmNlb2YgQmxvYlxuICAgIHx8ICh0eXBlb2YgRmlsZUxpc3QgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgRmlsZUxpc3QgJiYgdmFsdWUubGVuZ3RoID4gMCk7XG4vKipcbiAqIERldGVybWluZSBpZiB0aGUgcGF5bG9hZCBoYXMgYW55IGZpbGVzLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2luZXJ0aWFqcy9pbmVydGlhL2Jsb2IvbWFzdGVyL3BhY2thZ2VzL2NvcmUvc3JjL2ZpbGVzLnRzXG4gKi9cbmV4cG9ydCBjb25zdCBoYXNGaWxlcyA9IChkYXRhKSA9PiB7XG4gICAgaWYgKGRhdGEgaW5zdGFuY2VvZiBGb3JtRGF0YSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGlzRmlsZShkYXRhKVxuICAgICAgICB8fCAodHlwZW9mIGRhdGEgPT09ICdvYmplY3QnICYmIGRhdGEgIT09IG51bGwgJiYgT2JqZWN0LnZhbHVlcyhkYXRhKS5zb21lKCh2YWx1ZSkgPT4gaGFzRmlsZXModmFsdWUpKSk7XG59O1xuIiwiLyoqXG4gKiBFcnJvciB0aHJvd24gd2hlbiB0aGUgc2VydmVyIHJlc3BvbmRzIHdpdGggYSA0eHggb3IgNXh4IHN0YXR1cyBjb2RlLlxuICovXG5leHBvcnQgY2xhc3MgSHR0cFJlc3BvbnNlRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgcmVzcG9uc2U7XG4gICAgY29uc3RydWN0b3IocmVzcG9uc2UpIHtcbiAgICAgICAgc3VwZXIoYEhUVFAgZXJyb3IgJHtyZXNwb25zZS5zdGF0dXN9YCk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdIdHRwUmVzcG9uc2VFcnJvcic7XG4gICAgICAgIHRoaXMucmVzcG9uc2UgPSByZXNwb25zZTtcbiAgICB9XG59XG4vKipcbiAqIEVycm9yIHRocm93biB3aGVuIGEgcmVxdWVzdCBpcyBjYW5jZWxsZWQvYWJvcnRlZC5cbiAqL1xuZXhwb3J0IGNsYXNzIEh0dHBDYW5jZWxsZWRFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlID0gJ1JlcXVlc3Qgd2FzIGNhbmNlbGxlZCcpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdIdHRwQ2FuY2VsbGVkRXJyb3InO1xuICAgIH1cbn1cbi8qKlxuICogRXJyb3IgdGhyb3duIHdoZW4gYSBuZXR3b3JrIGVycm9yIG9jY3VycyAoZS5nLiwgbm8gY29ubmVjdGlvbikuXG4gKi9cbmV4cG9ydCBjbGFzcyBIdHRwTmV0d29ya0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKG1lc3NhZ2UgPSAnTmV0d29yayBlcnJvcicpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdIdHRwTmV0d29ya0Vycm9yJztcbiAgICB9XG59XG4iLCIvKipcbiAqIEJ1aWxkIGEgcXVlcnkgc3RyaW5nIGZyb20gcGFyYW1zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRRdWVyeVN0cmluZyhwYXJhbXMpIHtcbiAgICBjb25zdCBzZWFyY2hQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XG4gICAgT2JqZWN0LmVudHJpZXMocGFyYW1zKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHZhbHVlLmZvckVhY2goKGl0ZW0pID0+IHNlYXJjaFBhcmFtcy5hcHBlbmQoYCR7a2V5fVtdYCwgU3RyaW5nKGl0ZW0pKSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgc2VhcmNoUGFyYW1zLmFwcGVuZChrZXksIEpTT04uc3RyaW5naWZ5KHZhbHVlKSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZWFyY2hQYXJhbXMuYXBwZW5kKGtleSwgU3RyaW5nKHZhbHVlKSk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gc2VhcmNoUGFyYW1zLnRvU3RyaW5nKCk7XG59XG4vKipcbiAqIEJ1aWxkIHRoZSBmdWxsIFVSTCB3aXRoIGJhc2UgVVJMIGFuZCBxdWVyeSBwYXJhbXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZFVybCh1cmwsIGJhc2VVUkwsIHBhcmFtcykge1xuICAgIGlmIChiYXNlVVJMICYmICF1cmwuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmICF1cmwuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKSkge1xuICAgICAgICB1cmwgPSBiYXNlVVJMLnJlcGxhY2UoL1xcLyQvLCAnJykgKyAnLycgKyB1cmwucmVwbGFjZSgvXlxcLy8sICcnKTtcbiAgICB9XG4gICAgaWYgKHBhcmFtcyAmJiBPYmplY3Qua2V5cyhwYXJhbXMpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3QgcXVlcnlTdHJpbmcgPSBidWlsZFF1ZXJ5U3RyaW5nKHBhcmFtcyk7XG4gICAgICAgIGlmIChxdWVyeVN0cmluZykge1xuICAgICAgICAgICAgdXJsICs9ICh1cmwuaW5jbHVkZXMoJz8nKSA/ICcmJyA6ICc/JykgKyBxdWVyeVN0cmluZztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdXJsO1xufVxuIiwiaW1wb3J0IHsgSHR0cFJlc3BvbnNlRXJyb3IsIEh0dHBDYW5jZWxsZWRFcnJvciwgSHR0cE5ldHdvcmtFcnJvciB9IGZyb20gJy4vZXJyb3JzLmpzJztcbmltcG9ydCB7IGJ1aWxkVXJsIH0gZnJvbSAnLi91cmwuanMnO1xuaW1wb3J0IHsgaGFzRmlsZXMgfSBmcm9tICcuLi9mb3JtLmpzJztcbi8qKlxuICogR2V0IHRoZSBYLVJlcXVlc3RlZC1XaXRoIGhlYWRlciBmcm9tIExhcmF2ZWwncyBib290c3RyYXAgY29uZmlnIGlmIGF2YWlsYWJsZS5cbiAqL1xuZnVuY3Rpb24gZ2V0QWpheEhlYWRlcigpIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB3aW5kb3cuYXhpb3M/LmRlZmF1bHRzPy5oZWFkZXJzPy5jb21tb24/LlsnWC1SZXF1ZXN0ZWQtV2l0aCddID8/IG51bGw7XG59XG4vKipcbiAqIENvbnZlcnQgZGF0YSB0byBGb3JtRGF0YSByZWN1cnNpdmVseS5cbiAqL1xuZnVuY3Rpb24gdG9Gb3JtRGF0YShkYXRhLCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpLCBwYXJlbnRLZXkgPSBudWxsKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGRhdGEsIGtleSkpIHtcbiAgICAgICAgICAgIGFwcGVuZFRvRm9ybURhdGEoZm9ybURhdGEsIHBhcmVudEtleSA/IGAke3BhcmVudEtleX1bJHtrZXl9XWAgOiBrZXksIGRhdGFba2V5XSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZvcm1EYXRhO1xufVxuZnVuY3Rpb24gYXBwZW5kVG9Gb3JtRGF0YShmb3JtRGF0YSwga2V5LCB2YWx1ZSkge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gdmFsdWUuZm9yRWFjaCgodmFsLCBpbmRleCkgPT4gYXBwZW5kVG9Gb3JtRGF0YShmb3JtRGF0YSwgYCR7a2V5fVske2luZGV4fV1gLCB2YWwpKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgICAgIHJldHVybiBmb3JtRGF0YS5hcHBlbmQoa2V5LCB2YWx1ZS50b0lTT1N0cmluZygpKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIEZpbGUgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgRmlsZSkge1xuICAgICAgICByZXR1cm4gZm9ybURhdGEuYXBwZW5kKGtleSwgdmFsdWUsIHZhbHVlLm5hbWUpO1xuICAgIH1cbiAgICBlbHNlIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEJsb2IpIHtcbiAgICAgICAgcmV0dXJuIGZvcm1EYXRhLmFwcGVuZChrZXksIHZhbHVlKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIGZvcm1EYXRhLmFwcGVuZChrZXksIHZhbHVlID8gJzEnIDogJzAnKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgICByZXR1cm4gZm9ybURhdGEuYXBwZW5kKGtleSwgdmFsdWUpO1xuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHJldHVybiBmb3JtRGF0YS5hcHBlbmQoa2V5LCBgJHt2YWx1ZX1gKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gZm9ybURhdGEuYXBwZW5kKGtleSwgJycpO1xuICAgIH1cbiAgICB0b0Zvcm1EYXRhKHZhbHVlLCBmb3JtRGF0YSwga2V5KTtcbn1cbi8qKlxuICogUHJlcGFyZSB0aGUgcmVxdWVzdCBib2R5LlxuICovXG5mdW5jdGlvbiBwcmVwYXJlQm9keShkYXRhLCBoZWFkZXJzKSB7XG4gICAgaWYgKGRhdGEgPT09IHVuZGVmaW5lZCB8fCBkYXRhID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChkYXRhIGluc3RhbmNlb2YgRm9ybURhdGEpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZGF0YSA9PT0gJ29iamVjdCcgJiYgaGFzRmlsZXMoZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIHRvRm9ybURhdGEoZGF0YSk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZGF0YSA9PT0gJ29iamVjdCcgfHwgaGVhZGVyc1snQ29udGVudC1UeXBlJ10/LmluY2x1ZGVzKCdhcHBsaWNhdGlvbi9qc29uJykpIHtcbiAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KGRhdGEpO1xuICAgIH1cbiAgICByZXR1cm4gU3RyaW5nKGRhdGEpO1xufVxuLyoqXG4gKiBQYXJzZSByZXNwb25zZSBoZWFkZXJzIGludG8gYSBwbGFpbiBvYmplY3QuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlSGVhZGVycyhoZWFkZXJzKSB7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgaGVhZGVycy5mb3JFYWNoKCh2YWx1ZSwga2V5KSA9PiB7XG4gICAgICAgIHJlc3VsdFtrZXkudG9Mb3dlckNhc2UoKV0gPSB2YWx1ZTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4gKiBDcmVhdGUgYSBmZXRjaC1iYXNlZCBIVFRQIGNsaWVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUZldGNoQ2xpZW50KG9wdGlvbnMgPSB7fSkge1xuICAgIGxldCB4c3JmQ29va2llTmFtZSA9IG9wdGlvbnMueHNyZkNvb2tpZU5hbWUgPz8gJ1hTUkYtVE9LRU4nO1xuICAgIGxldCB4c3JmSGVhZGVyTmFtZSA9IG9wdGlvbnMueHNyZkhlYWRlck5hbWUgPz8gJ1gtWFNSRi1UT0tFTic7XG4gICAgZnVuY3Rpb24gZ2V0WHNyZlRva2VuKCkge1xuICAgICAgICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWF0Y2ggPSBkb2N1bWVudC5jb29raWUubWF0Y2gobmV3IFJlZ0V4cCgnKF58O1xcXFxzKiknICsgeHNyZkNvb2tpZU5hbWUgKyAnPShbXjtdKiknKSk7XG4gICAgICAgIHJldHVybiBtYXRjaCA/IGRlY29kZVVSSUNvbXBvbmVudChtYXRjaFsyXSkgOiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBzZXRYc3JmQ29va2llTmFtZShuYW1lKSB7XG4gICAgICAgICAgICB4c3JmQ29va2llTmFtZSA9IG5hbWU7XG4gICAgICAgIH0sXG4gICAgICAgIHNldFhzcmZIZWFkZXJOYW1lKG5hbWUpIHtcbiAgICAgICAgICAgIHhzcmZIZWFkZXJOYW1lID0gbmFtZTtcbiAgICAgICAgfSxcbiAgICAgICAgYXN5bmMgcmVxdWVzdChjb25maWcpIHtcbiAgICAgICAgICAgIGNvbnN0IHVybCA9IGJ1aWxkVXJsKGNvbmZpZy51cmwsIGNvbmZpZy5iYXNlVVJMLCBjb25maWcucGFyYW1zKTtcbiAgICAgICAgICAgIGNvbnN0IG1ldGhvZCA9IGNvbmZpZy5tZXRob2QudG9VcHBlckNhc2UoKTtcbiAgICAgICAgICAgIGNvbnN0IGhlYWRlcnMgPSB7fTtcbiAgICAgICAgICAgIC8vIEluaGVyaXQgWC1SZXF1ZXN0ZWQtV2l0aCBmcm9tIExhcmF2ZWwncyBib290c3RyYXAgY29uZmlnIGlmIGF2YWlsYWJsZVxuICAgICAgICAgICAgY29uc3QgYWpheEhlYWRlciA9IGdldEFqYXhIZWFkZXIoKTtcbiAgICAgICAgICAgIGlmIChhamF4SGVhZGVyKSB7XG4gICAgICAgICAgICAgICAgaGVhZGVyc1snWC1SZXF1ZXN0ZWQtV2l0aCddID0gYWpheEhlYWRlcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFNldCBkZWZhdWx0IENvbnRlbnQtVHlwZSBmb3Igbm9uLUdFVC9ERUxFVEUgcmVxdWVzdHMgd2l0aCBkYXRhXG4gICAgICAgICAgICBpZiAoY29uZmlnLmRhdGEgIT09IHVuZGVmaW5lZCAmJiAhWydHRVQnLCAnREVMRVRFJ10uaW5jbHVkZXMobWV0aG9kKSkge1xuICAgICAgICAgICAgICAgIGlmICghKGNvbmZpZy5kYXRhIGluc3RhbmNlb2YgRm9ybURhdGEpICYmICFoYXNGaWxlcyhjb25maWcuZGF0YSkpIHtcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSAnYXBwbGljYXRpb24vanNvbic7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gQ29weSB1c2VyIGhlYWRlcnNcbiAgICAgICAgICAgIGlmIChjb25maWcuaGVhZGVycykge1xuICAgICAgICAgICAgICAgIE9iamVjdC5lbnRyaWVzKGNvbmZpZy5oZWFkZXJzKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnNba2V5XSA9IFN0cmluZyh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIEFkZCBYU1JGIHRva2VuXG4gICAgICAgICAgICBjb25zdCB4c3JmVG9rZW4gPSBnZXRYc3JmVG9rZW4oKTtcbiAgICAgICAgICAgIGlmICh4c3JmVG9rZW4gJiYgIVsnR0VUJywgJ0hFQUQnLCAnT1BUSU9OUyddLmluY2x1ZGVzKG1ldGhvZCkpIHtcbiAgICAgICAgICAgICAgICBoZWFkZXJzW3hzcmZIZWFkZXJOYW1lXSA9IHhzcmZUb2tlbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIEhhbmRsZSB0aW1lb3V0XG4gICAgICAgICAgICBsZXQgc2lnbmFsID0gY29uZmlnLnNpZ25hbDtcbiAgICAgICAgICAgIGxldCB0aW1lb3V0SWQ7XG4gICAgICAgICAgICBjb25zdCB0aW1lb3V0ID0gY29uZmlnLnRpbWVvdXQgPz8gMzAwMDA7XG4gICAgICAgICAgICBpZiAodGltZW91dCA+IDAgJiYgIXNpZ25hbCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgICAgICAgICAgc2lnbmFsID0gY29udHJvbGxlci5zaWduYWw7XG4gICAgICAgICAgICAgICAgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIHRpbWVvdXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gUHJlcGFyZSBib2R5IChvbmx5IGZvciBub24tR0VUL0RFTEVURSByZXF1ZXN0cylcbiAgICAgICAgICAgIGNvbnN0IGJvZHkgPSBbJ0dFVCcsICdERUxFVEUnXS5pbmNsdWRlcyhtZXRob2QpXG4gICAgICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICA6IHByZXBhcmVCb2R5KGNvbmZpZy5kYXRhLCBoZWFkZXJzKTtcbiAgICAgICAgICAgIGlmIChib2R5IGluc3RhbmNlb2YgRm9ybURhdGEpIHtcbiAgICAgICAgICAgICAgICBkZWxldGUgaGVhZGVyc1snQ29udGVudC1UeXBlJ107XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICAgICAgICAgICAgc2lnbmFsLFxuICAgICAgICAgICAgICAgICAgICBjcmVkZW50aWFsczogY29uZmlnLmNyZWRlbnRpYWxzID8/ICdzYW1lLW9yaWdpbicsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKHRpbWVvdXRJZCkge1xuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IGRhdGE7XG4gICAgICAgICAgICAgICAgY29uc3QgY29udGVudFR5cGUgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJyk7XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRUeXBlPy5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpKSB7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkYXRhID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBodHRwUmVzcG9uc2UgPSB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiBwYXJzZUhlYWRlcnMocmVzcG9uc2UuaGVhZGVycyksXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBIdHRwUmVzcG9uc2VFcnJvcihodHRwUmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gaHR0cFJlc3BvbnNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRpbWVvdXRJZCkge1xuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgSHR0cFJlc3BvbnNlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIERPTUV4Y2VwdGlvbiAmJiBlcnJvci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEh0dHBDYW5jZWxsZWRFcnJvcigpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBUeXBlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEh0dHBOZXR3b3JrRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH07XG59XG4vKipcbiAqIERlZmF1bHQgZmV0Y2ggSFRUUCBjbGllbnQgaW5zdGFuY2UuXG4gKi9cbmV4cG9ydCBjb25zdCBmZXRjaEh0dHBDbGllbnQgPSBjcmVhdGVGZXRjaENsaWVudCgpO1xuIiwiaW1wb3J0IHsgbWVyZ2UgfSBmcm9tICdlcy10b29sa2l0L2NvbXBhdCc7XG5pbXBvcnQgeyBoYXNGaWxlcyB9IGZyb20gJy4vZm9ybS5qcyc7XG5pbXBvcnQgeyBIdHRwUmVzcG9uc2VFcnJvciB9IGZyb20gJy4vaHR0cC9lcnJvcnMuanMnO1xuaW1wb3J0IHsgZmV0Y2hIdHRwQ2xpZW50IH0gZnJvbSAnLi9odHRwL2ZldGNoQ2xpZW50LmpzJztcbi8qKlxuICogVGhlIGNvbmZpZ3VyZWQgSFRUUCBjbGllbnQuXG4gKi9cbmxldCBodHRwQ2xpZW50ID0gZmV0Y2hIdHRwQ2xpZW50O1xuLyoqXG4gKiBUaGUgY29uZmlndXJlZCBiYXNlIFVSTC5cbiAqL1xubGV0IGJhc2VVUkwgPSB1bmRlZmluZWQ7XG4vKipcbiAqIFRoZSBjb25maWd1cmVkIGRlZmF1bHQgdGltZW91dC5cbiAqL1xubGV0IHRpbWVvdXQgPSB1bmRlZmluZWQ7XG4vKipcbiAqIFRoZSBjb25maWd1cmVkIGNyZWRlbnRpYWxzIG1vZGUuXG4gKi9cbmxldCBjcmVkZW50aWFscyA9ICdzYW1lLW9yaWdpbic7XG4vKipcbiAqIFRoZSByZXF1ZXN0IGZpbmdlcnByaW50IHJlc29sdmVyLlxuICovXG5sZXQgcmVxdWVzdEZpbmdlcnByaW50UmVzb2x2ZXIgPSAoY29uZmlnKSA9PiBgJHtjb25maWcubWV0aG9kfToke2NvbmZpZy5iYXNlVVJMID8/IGJhc2VVUkwgPz8gJyd9JHtjb25maWcudXJsfWA7XG4vKipcbiAqIFRoZSBwcmVjb2duaXRpb24gc3VjY2VzcyByZXNvbHZlci5cbiAqL1xubGV0IHN1Y2Nlc3NSZXNvbHZlciA9IChyZXNwb25zZSkgPT4gcmVzcG9uc2Uuc3RhdHVzID09PSAyMDQgJiYgcmVzcG9uc2UuaGVhZGVyc1sncHJlY29nbml0aW9uLXN1Y2Nlc3MnXSA9PT0gJ3RydWUnO1xuLyoqXG4gKiBUaGUgYWJvcnQgY29udHJvbGxlciBjYWNoZS5cbiAqL1xuY29uc3QgYWJvcnRDb250cm9sbGVycyA9IHt9O1xuLyoqXG4gKiBUaGUgcHJlY29nbml0aXZlIEhUVFAgY2xpZW50IGluc3RhbmNlLlxuICovXG5leHBvcnQgY29uc3QgY2xpZW50ID0ge1xuICAgIGdldDogKHVybCwgZGF0YSA9IHt9LCBjb25maWcgPSB7fSkgPT4gcmVxdWVzdChtZXJnZUNvbmZpZygnZ2V0JywgdXJsLCBkYXRhLCBjb25maWcpKSxcbiAgICBwb3N0OiAodXJsLCBkYXRhID0ge30sIGNvbmZpZyA9IHt9KSA9PiByZXF1ZXN0KG1lcmdlQ29uZmlnKCdwb3N0JywgdXJsLCBkYXRhLCBjb25maWcpKSxcbiAgICBwYXRjaDogKHVybCwgZGF0YSA9IHt9LCBjb25maWcgPSB7fSkgPT4gcmVxdWVzdChtZXJnZUNvbmZpZygncGF0Y2gnLCB1cmwsIGRhdGEsIGNvbmZpZykpLFxuICAgIHB1dDogKHVybCwgZGF0YSA9IHt9LCBjb25maWcgPSB7fSkgPT4gcmVxdWVzdChtZXJnZUNvbmZpZygncHV0JywgdXJsLCBkYXRhLCBjb25maWcpKSxcbiAgICBkZWxldGU6ICh1cmwsIGRhdGEgPSB7fSwgY29uZmlnID0ge30pID0+IHJlcXVlc3QobWVyZ2VDb25maWcoJ2RlbGV0ZScsIHVybCwgZGF0YSwgY29uZmlnKSksXG4gICAgdXNlSHR0cENsaWVudChuZXdIdHRwQ2xpZW50KSB7XG4gICAgICAgIGh0dHBDbGllbnQgPSBuZXdIdHRwQ2xpZW50O1xuICAgICAgICByZXR1cm4gY2xpZW50O1xuICAgIH0sXG4gICAgd2l0aEJhc2VVUkwodXJsKSB7XG4gICAgICAgIGJhc2VVUkwgPSB1cmw7XG4gICAgICAgIHJldHVybiBjbGllbnQ7XG4gICAgfSxcbiAgICB3aXRoVGltZW91dChkdXJhdGlvbikge1xuICAgICAgICB0aW1lb3V0ID0gZHVyYXRpb247XG4gICAgICAgIHJldHVybiBjbGllbnQ7XG4gICAgfSxcbiAgICB3aXRoQ3JlZGVudGlhbHModmFsdWUpIHtcbiAgICAgICAgY3JlZGVudGlhbHMgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnID8gdmFsdWUgOiAodmFsdWUgPyAnaW5jbHVkZScgOiAnb21pdCcpO1xuICAgICAgICByZXR1cm4gY2xpZW50O1xuICAgIH0sXG4gICAgZmluZ2VycHJpbnRSZXF1ZXN0c1VzaW5nKGNhbGxiYWNrKSB7XG4gICAgICAgIHJlcXVlc3RGaW5nZXJwcmludFJlc29sdmVyID0gY2FsbGJhY2sgPT09IG51bGxcbiAgICAgICAgICAgID8gKCkgPT4gbnVsbFxuICAgICAgICAgICAgOiBjYWxsYmFjaztcbiAgICAgICAgcmV0dXJuIGNsaWVudDtcbiAgICB9LFxuICAgIGRldGVybWluZVN1Y2Nlc3NVc2luZyhjYWxsYmFjaykge1xuICAgICAgICBzdWNjZXNzUmVzb2x2ZXIgPSBjYWxsYmFjaztcbiAgICAgICAgcmV0dXJuIGNsaWVudDtcbiAgICB9LFxuICAgIHdpdGhYc3JmQ29va2llTmFtZShuYW1lKSB7XG4gICAgICAgIGZldGNoSHR0cENsaWVudC5zZXRYc3JmQ29va2llTmFtZShuYW1lKTtcbiAgICAgICAgcmV0dXJuIGNsaWVudDtcbiAgICB9LFxuICAgIHdpdGhYc3JmSGVhZGVyTmFtZShuYW1lKSB7XG4gICAgICAgIGZldGNoSHR0cENsaWVudC5zZXRYc3JmSGVhZGVyTmFtZShuYW1lKTtcbiAgICAgICAgcmV0dXJuIGNsaWVudDtcbiAgICB9LFxufTtcbi8qKlxuICogTWVyZ2UgdGhlIGNsaWVudCBzcGVjaWZpZWQgYXJndW1lbnRzIHdpdGggdGhlIHByb3ZpZGVkIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmNvbnN0IG1lcmdlQ29uZmlnID0gKG1ldGhvZCwgdXJsLCBkYXRhLCBjb25maWcpID0+ICh7XG4gICAgdXJsLFxuICAgIG1ldGhvZCxcbiAgICAuLi5jb25maWcsXG4gICAgLi4uKFsnZ2V0JywgJ2RlbGV0ZSddLmluY2x1ZGVzKG1ldGhvZCkgPyB7XG4gICAgICAgIHBhcmFtczogbWVyZ2Uoe30sIGRhdGEsIGNvbmZpZz8ucGFyYW1zKSxcbiAgICB9IDoge1xuICAgICAgICBkYXRhOiBtZXJnZSh7fSwgZGF0YSwgY29uZmlnPy5kYXRhKSxcbiAgICB9KSxcbn0pO1xuLyoqXG4gKiBTZW5kIGFuZCBoYW5kbGUgYSBuZXcgcmVxdWVzdC5cbiAqL1xuY29uc3QgcmVxdWVzdCA9ICh1c2VyQ29uZmlnID0ge30pID0+IHtcbiAgICBjb25zdCBjb25maWcgPSBbXG4gICAgICAgIHJlc29sdmVDb25maWcsXG4gICAgICAgIGFib3J0TWF0Y2hpbmdSZXF1ZXN0cyxcbiAgICAgICAgcmVmcmVzaEFib3J0Q29udHJvbGxlcixcbiAgICBdLnJlZHVjZSgoY29uZmlnLCBjYWxsYmFjaykgPT4gY2FsbGJhY2soY29uZmlnKSwgdXNlckNvbmZpZyk7XG4gICAgaWYgKChjb25maWcub25CZWZvcmUgPz8gKCgpID0+IHRydWUpKSgpID09PSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKG51bGwpO1xuICAgIH1cbiAgICAoY29uZmlnLm9uU3RhcnQgPz8gKCgpID0+IG51bGwpKSgpO1xuICAgIHJldHVybiBodHRwQ2xpZW50LnJlcXVlc3Qoe1xuICAgICAgICBtZXRob2Q6IGNvbmZpZy5tZXRob2QsXG4gICAgICAgIHVybDogY29uZmlnLnVybCxcbiAgICAgICAgYmFzZVVSTDogY29uZmlnLmJhc2VVUkwgPz8gYmFzZVVSTCxcbiAgICAgICAgZGF0YTogY29uZmlnLmRhdGEsXG4gICAgICAgIHBhcmFtczogY29uZmlnLnBhcmFtcyxcbiAgICAgICAgaGVhZGVyczogY29uZmlnLmhlYWRlcnMsXG4gICAgICAgIHNpZ25hbDogY29uZmlnLnNpZ25hbCxcbiAgICAgICAgdGltZW91dDogY29uZmlnLnRpbWVvdXQsXG4gICAgICAgIGNyZWRlbnRpYWxzLFxuICAgIH0pLnRoZW4oYXN5bmMgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGlmIChjb25maWcucHJlY29nbml0aXZlKSB7XG4gICAgICAgICAgICB2YWxpZGF0ZVByZWNvZ25pdGlvblJlc3BvbnNlKHJlc3BvbnNlKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdGF0dXMgPSByZXNwb25zZS5zdGF0dXM7XG4gICAgICAgIGxldCBwYXlsb2FkID0gcmVzcG9uc2U7XG4gICAgICAgIGlmIChjb25maWcucHJlY29nbml0aXZlICYmIGNvbmZpZy5vblByZWNvZ25pdGlvblN1Y2Nlc3MgJiYgc3VjY2Vzc1Jlc29sdmVyKHJlc3BvbnNlKSkge1xuICAgICAgICAgICAgcGF5bG9hZCA9IGF3YWl0IFByb21pc2UucmVzb2x2ZShjb25maWcub25QcmVjb2duaXRpb25TdWNjZXNzKHJlc3BvbnNlKSA/PyBwYXlsb2FkKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29uZmlnLm9uU3VjY2VzcyAmJiBpc1N1Y2Nlc3Moc3RhdHVzKSkge1xuICAgICAgICAgICAgcGF5bG9hZCA9IGF3YWl0IFByb21pc2UucmVzb2x2ZShjb25maWcub25TdWNjZXNzKHBheWxvYWQpID8/IHBheWxvYWQpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHN0YXR1c0hhbmRsZXIgPSByZXNvbHZlU3RhdHVzSGFuZGxlcihjb25maWcsIHN0YXR1cylcbiAgICAgICAgICAgID8/ICgocmVzcG9uc2UpID0+IHJlc3BvbnNlKTtcbiAgICAgICAgcmV0dXJuIHN0YXR1c0hhbmRsZXIocGF5bG9hZCkgPz8gcGF5bG9hZDtcbiAgICB9LCAoZXJyb3IpID0+IHtcbiAgICAgICAgaWYgKGlzTm90U2VydmVyR2VuZXJhdGVkRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGh0dHBFcnJvciA9IGVycm9yO1xuICAgICAgICBpZiAoY29uZmlnLnByZWNvZ25pdGl2ZSkge1xuICAgICAgICAgICAgdmFsaWRhdGVQcmVjb2duaXRpb25SZXNwb25zZShodHRwRXJyb3IucmVzcG9uc2UpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHN0YXR1c0hhbmRsZXIgPSByZXNvbHZlU3RhdHVzSGFuZGxlcihjb25maWcsIGh0dHBFcnJvci5yZXNwb25zZS5zdGF0dXMpXG4gICAgICAgICAgICA/PyAoKF8sIGVycm9yKSA9PiBQcm9taXNlLnJlamVjdChlcnJvcikpO1xuICAgICAgICByZXR1cm4gc3RhdHVzSGFuZGxlcihodHRwRXJyb3IucmVzcG9uc2UsIGh0dHBFcnJvcik7XG4gICAgfSkuZmluYWxseShjb25maWcub25GaW5pc2ggPz8gKCgpID0+IG51bGwpKTtcbn07XG4vKipcbiAqIFJlc29sdmUgdGhlIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmNvbnN0IHJlc29sdmVDb25maWcgPSAoY29uZmlnKSA9PiB7XG4gICAgY29uc3Qgb25seSA9IGNvbmZpZy5vbmx5ID8/IGNvbmZpZy52YWxpZGF0ZTtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5jb25maWcsXG4gICAgICAgIHRpbWVvdXQ6IGNvbmZpZy50aW1lb3V0ID8/IHRpbWVvdXQsXG4gICAgICAgIHByZWNvZ25pdGl2ZTogY29uZmlnLnByZWNvZ25pdGl2ZSAhPT0gZmFsc2UsXG4gICAgICAgIGZpbmdlcnByaW50OiB0eXBlb2YgY29uZmlnLmZpbmdlcnByaW50ID09PSAndW5kZWZpbmVkJ1xuICAgICAgICAgICAgPyByZXF1ZXN0RmluZ2VycHJpbnRSZXNvbHZlcihjb25maWcsIGh0dHBDbGllbnQpXG4gICAgICAgICAgICA6IGNvbmZpZy5maW5nZXJwcmludCxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgLi4uY29uZmlnLmhlYWRlcnMsXG4gICAgICAgICAgICAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6IHJlc29sdmVDb250ZW50VHlwZShjb25maWcpLFxuICAgICAgICAgICAgLi4uY29uZmlnLnByZWNvZ25pdGl2ZSAhPT0gZmFsc2UgPyB7XG4gICAgICAgICAgICAgICAgUHJlY29nbml0aW9uOiB0cnVlLFxuICAgICAgICAgICAgfSA6IHt9LFxuICAgICAgICAgICAgLi4ub25seSA/IHtcbiAgICAgICAgICAgICAgICAnUHJlY29nbml0aW9uLVZhbGlkYXRlLU9ubHknOiBBcnJheS5mcm9tKG9ubHkpLmpvaW4oKSxcbiAgICAgICAgICAgIH0gOiB7fSxcbiAgICAgICAgfSxcbiAgICB9O1xufTtcbi8qKlxuICogRGV0ZXJtaW5lIGlmIHRoZSBzdGF0dXMgaXMgc3VjY2Vzc2Z1bC5cbiAqL1xuY29uc3QgaXNTdWNjZXNzID0gKHN0YXR1cykgPT4gc3RhdHVzID49IDIwMCAmJiBzdGF0dXMgPCAzMDA7XG4vKipcbiAqIEFib3J0IGFuIGV4aXN0aW5nIHJlcXVlc3Qgd2l0aCB0aGUgc2FtZSBjb25maWd1cmVkIGZpbmdlcnByaW50LlxuICovXG5jb25zdCBhYm9ydE1hdGNoaW5nUmVxdWVzdHMgPSAoY29uZmlnKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBjb25maWcuZmluZ2VycHJpbnQgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiBjb25maWc7XG4gICAgfVxuICAgIGFib3J0Q29udHJvbGxlcnNbY29uZmlnLmZpbmdlcnByaW50XT8uYWJvcnQoKTtcbiAgICBkZWxldGUgYWJvcnRDb250cm9sbGVyc1tjb25maWcuZmluZ2VycHJpbnRdO1xuICAgIHJldHVybiBjb25maWc7XG59O1xuLyoqXG4gKiBDcmVhdGUgYW5kIGNvbmZpZ3VyZSB0aGUgYWJvcnQgY29udHJvbGxlciBmb3IgYSBuZXcgcmVxdWVzdC5cbiAqL1xuY29uc3QgcmVmcmVzaEFib3J0Q29udHJvbGxlciA9IChjb25maWcpID0+IHtcbiAgICBpZiAodHlwZW9mIGNvbmZpZy5maW5nZXJwcmludCAhPT0gJ3N0cmluZydcbiAgICAgICAgfHwgY29uZmlnLnNpZ25hbFxuICAgICAgICB8fCAhY29uZmlnLnByZWNvZ25pdGl2ZSkge1xuICAgICAgICByZXR1cm4gY29uZmlnO1xuICAgIH1cbiAgICBhYm9ydENvbnRyb2xsZXJzW2NvbmZpZy5maW5nZXJwcmludF0gPSBuZXcgQWJvcnRDb250cm9sbGVyO1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLmNvbmZpZyxcbiAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXJzW2NvbmZpZy5maW5nZXJwcmludF0uc2lnbmFsLFxuICAgIH07XG59O1xuLyoqXG4gKiBFbnN1cmUgdGhhdCB0aGUgcmVzcG9uc2UgaXMgYSBQcmVjb2duaXRpb24gcmVzcG9uc2UuXG4gKi9cbmNvbnN0IHZhbGlkYXRlUHJlY29nbml0aW9uUmVzcG9uc2UgPSAocmVzcG9uc2UpID0+IHtcbiAgICBpZiAocmVzcG9uc2UuaGVhZGVycz8ucHJlY29nbml0aW9uICE9PSAndHJ1ZScpIHtcbiAgICAgICAgdGhyb3cgRXJyb3IoJ0RpZCBub3QgcmVjZWl2ZSBhIFByZWNvZ25pdGlvbiByZXNwb25zZS4gRW5zdXJlIHlvdSBoYXZlIHRoZSBQcmVjb2duaXRpb24gbWlkZGxld2FyZSBpbiBwbGFjZSBmb3IgdGhlIHJvdXRlLicpO1xuICAgIH1cbn07XG4vKipcbiAqIERldGVybWluZSBpZiB0aGUgZXJyb3Igd2FzIG5vdCB0cmlnZ2VyZWQgYnkgYSBzZXJ2ZXIgcmVzcG9uc2UuXG4gKi9cbmNvbnN0IGlzTm90U2VydmVyR2VuZXJhdGVkRXJyb3IgPSAoZXJyb3IpID0+IHtcbiAgICByZXR1cm4gIShlcnJvciBpbnN0YW5jZW9mIEh0dHBSZXNwb25zZUVycm9yKSB8fCB0eXBlb2YgZXJyb3IucmVzcG9uc2U/LnN0YXR1cyAhPT0gJ251bWJlcic7XG59O1xuLyoqXG4gKiBSZXNvbHZlIHRoZSBoYW5kbGVyIGZvciB0aGUgZ2l2ZW4gSFRUUCByZXNwb25zZSBzdGF0dXMuXG4gKi9cbmNvbnN0IHJlc29sdmVTdGF0dXNIYW5kbGVyID0gKGNvbmZpZywgY29kZSkgPT4gKHtcbiAgICA0MDE6IGNvbmZpZy5vblVuYXV0aG9yaXplZCxcbiAgICA0MDM6IGNvbmZpZy5vbkZvcmJpZGRlbixcbiAgICA0MDQ6IGNvbmZpZy5vbk5vdEZvdW5kLFxuICAgIDQwOTogY29uZmlnLm9uQ29uZmxpY3QsXG4gICAgNDIyOiBjb25maWcub25WYWxpZGF0aW9uRXJyb3IsXG4gICAgNDIzOiBjb25maWcub25Mb2NrZWQsXG59W2NvZGVdKTtcbi8qKlxuICogUmVzb2x2ZSB0aGUgcmVxdWVzdCdzIFwiQ29udGVudC1UeXBlXCIgaGVhZGVyLlxuICovXG5jb25zdCByZXNvbHZlQ29udGVudFR5cGUgPSAoY29uZmlnKSA9PiAoY29uZmlnLmhlYWRlcnM/LlsnQ29udGVudC1UeXBlJ11cbiAgICA/PyBjb25maWcuaGVhZGVycz8uWydDb250ZW50LXR5cGUnXVxuICAgID8/IGNvbmZpZy5oZWFkZXJzPy5bJ2NvbnRlbnQtdHlwZSddXG4gICAgPz8gKGhhc0ZpbGVzKGNvbmZpZy5kYXRhKSA/ICdtdWx0aXBhcnQvZm9ybS1kYXRhJyA6ICdhcHBsaWNhdGlvbi9qc29uJykpO1xuLyoqXG4gKiBSZXNvbHZlIHRoZSB1cmwgZnJvbSBhIHBvdGVudGlhbCBjYWxsYmFjay5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlc29sdmVVcmwgPSAodXJsKSA9PiB0eXBlb2YgdXJsID09PSAnc3RyaW5nJ1xuICAgID8gdXJsXG4gICAgOiB1cmwoKTtcbi8qKlxuICogUmVzb2x2ZSB0aGUgbWV0aG9kIGZyb20gYSBwb3RlbnRpYWwgY2FsbGJhY2suXG4gKi9cbmV4cG9ydCBjb25zdCByZXNvbHZlTWV0aG9kID0gKG1ldGhvZCkgPT4gdHlwZW9mIG1ldGhvZCA9PT0gJ3N0cmluZydcbiAgICA/IG1ldGhvZC50b0xvd2VyQ2FzZSgpXG4gICAgOiBtZXRob2QoKTtcbiIsImltcG9ydCB7IGlzRXF1YWwgfSBmcm9tICdlcy10b29sa2l0JztcbmltcG9ydCB7IGRlYm91bmNlLCBnZXQsIHNldCwgbWVyZ2UgfSBmcm9tICdlcy10b29sa2l0L2NvbXBhdCc7XG5pbXBvcnQgeyBIdHRwUmVzcG9uc2VFcnJvciwgSHR0cENhbmNlbGxlZEVycm9yIH0gZnJvbSAnLi9odHRwL2Vycm9ycy5qcyc7XG5pbXBvcnQgeyBpc0ZpbGUgfSBmcm9tICcuL2Zvcm0uanMnO1xuaW1wb3J0IHsgY2xpZW50IH0gZnJvbSAnLi9jbGllbnQuanMnO1xuLyoqXG4gKiBFeHBhbmQgYSB3aWxkY2FyZCBwYXRoIHRvIGNvbmNyZXRlIHBhdGhzIHVzaW5nIHRoZSBnaXZlbiBkYXRhLlxuICpcbiAqIEV4YW1wbGVzOlxuICogLSAndXNlcnMuKicgd2l0aCB7dXNlcnM6IFt7bmFtZTogJ0EnfSwge25hbWU6ICdCJ31dfSA9PiBbJ3VzZXJzLjAnLCAndXNlcnMuMSddXG4gKiAtICd1c2Vycy4qLm5hbWUnIHdpdGgge3VzZXJzOiBbe25hbWU6ICdBJ30sIHtuYW1lOiAnQid9XX0gPT4gWyd1c2Vycy4wLm5hbWUnLCAndXNlcnMuMS5uYW1lJ11cbiAqIC0gJ2F1dGhvci4qJyB3aXRoIHthdXRob3I6IHtuYW1lOiAnSm9obicsIGJpbzogJ0Rldid9fSA9PiBbJ2F1dGhvci5uYW1lJywgJ2F1dGhvci5iaW8nXVxuICovXG5leHBvcnQgY29uc3QgZXhwYW5kV2lsZGNhcmRQYXRocyA9IChwYXR0ZXJuLCBkYXRhKSA9PiB7XG4gICAgaWYgKCFwYXR0ZXJuLmluY2x1ZGVzKCcqJykpIHtcbiAgICAgICAgcmV0dXJuIFtwYXR0ZXJuXTtcbiAgICB9XG4gICAgY29uc3QgcGFydHMgPSBwYXR0ZXJuLnNwbGl0KCcuJyk7XG4gICAgbGV0IHBhdGhzID0gWycnXTtcbiAgICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICAgICAgaWYgKHBhcnQgPT09ICcqJykge1xuICAgICAgICAgICAgY29uc3QgZXhwYW5kZWQgPSBbXTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcGF0aCBvZiBwYXRocykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gcGF0aCA/IGdldChkYXRhLCBwYXRoKSA6IGRhdGE7XG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEV4cGFuZCBhcnJheSBpbmRpY2VzLi4uXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB2YWx1ZS5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGFuZGVkLnB1c2gocGF0aCA/IGAke3BhdGh9LiR7aW5kZXh9YCA6IFN0cmluZyhpbmRleCkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHZhbHVlICE9PSBudWxsICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRXhwYW5kIG9iamVjdCBrZXlzLi4uXG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXhwYW5kZWQucHVzaChwYXRoID8gYCR7cGF0aH0uJHtrZXl9YCA6IGtleSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gSWYgdmFsdWUgaXMgbnVsbCwgdW5kZWZpbmVkLCBvciBwcmltaXRpdmUsIHdpbGRjYXJkIG1hdGNoZXMgbm90aGluZy5cbiAgICAgICAgICAgICAgICAvLyBlLmcuLCAndXNlcnMuKicgd2l0aCB7dXNlcnM6IG51bGx9ID0+IFtdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwYXRocyA9IGV4cGFuZGVkO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gQXBwZW5kIHRoZSBsaXRlcmFsIHBhcnQgdG8gYWxsIGN1cnJlbnQgcGF0aHNcbiAgICAgICAgICAgIHBhdGhzID0gcGF0aHMubWFwKChwYXRoKSA9PiBwYXRoID8gYCR7cGF0aH0uJHtwYXJ0fWAgOiBwYXJ0KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcGF0aHM7XG59O1xuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSBrZXkgbWF0Y2hlcyB0aGUgZ2l2ZW4gcGF0dGVybi5cbiAqL1xuY29uc3Qga2V5TWF0Y2hlc1BhdHRlcm4gPSAoa2V5LCBwYXR0ZXJuKSA9PiB7XG4gICAgaWYgKCFwYXR0ZXJuLmluY2x1ZGVzKCcqJykpIHtcbiAgICAgICAgcmV0dXJuIGtleSA9PT0gcGF0dGVybjtcbiAgICB9XG4gICAgY29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKCdeJyArIHBhdHRlcm4ucmVwbGFjZSgvXFwuL2csICdcXFxcLicpLnJlcGxhY2UoL1xcKi9nLCAnW14uXSsnKSArICckJyk7XG4gICAgcmV0dXJuIHJlZ2V4LnRlc3Qoa2V5KTtcbn07XG4vKipcbiAqIE9taXQgZW50cmllcyBmcm9tIGFuIG9iamVjdCB3aG9zZSBrZXlzIG1hdGNoIHRoZSBnaXZlbiBwYXR0ZXJucy5cbiAqL1xuY29uc3Qgb21pdEJ5UGF0dGVybiA9IChvYmosIHBhdHRlcm5zKSA9PiB7XG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhvYmopLmZpbHRlcigoW2tleV0pID0+IHtcbiAgICAgICAgcmV0dXJuICFwYXR0ZXJucy5zb21lKChwYXR0ZXJuKSA9PiBrZXlNYXRjaGVzUGF0dGVybihrZXksIHBhdHRlcm4pKTtcbiAgICB9KSk7XG59O1xuZXhwb3J0IGNvbnN0IGNyZWF0ZVZhbGlkYXRvciA9IChjYWxsYmFjaywgaW5pdGlhbERhdGEgPSB7fSkgPT4ge1xuICAgIC8qKlxuICAgICAqIEV2ZW50IGxpc3RlbmVyIHN0YXRlLlxuICAgICAqL1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IHtcbiAgICAgICAgZXJyb3JzQ2hhbmdlZDogW10sXG4gICAgICAgIHRvdWNoZWRDaGFuZ2VkOiBbXSxcbiAgICAgICAgdmFsaWRhdGluZ0NoYW5nZWQ6IFtdLFxuICAgICAgICB2YWxpZGF0ZWRDaGFuZ2VkOiBbXSxcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFZhbGlkYXRlIGZpbGVzIHN0YXRlLlxuICAgICAqL1xuICAgIGxldCB2YWxpZGF0ZUZpbGVzID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogUHJvY2Vzc2luZyB2YWxpZGF0aW9uIHN0YXRlLlxuICAgICAqL1xuICAgIGxldCB2YWxpZGF0aW5nID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogU2V0IHRoZSB2YWxpZGF0aW5nIGlucHV0cy5cbiAgICAgKlxuICAgICAqIFJldHVybnMgYW4gYXJyYXkgb2YgbGlzdGVuZXJzIHRoYXQgc2hvdWxkIGJlIGludm9rZWQgb25jZSBhbGwgc3RhdGVcbiAgICAgKiBjaGFuZ2VzIGhhdmUgdGFrZW4gcGxhY2UuXG4gICAgICovXG4gICAgY29uc3Qgc2V0VmFsaWRhdGluZyA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAodmFsdWUgIT09IHZhbGlkYXRpbmcpIHtcbiAgICAgICAgICAgIHZhbGlkYXRpbmcgPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiBsaXN0ZW5lcnMudmFsaWRhdGluZ0NoYW5nZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogSW5wdXRzIHRoYXQgaGF2ZSBiZWVuIHZhbGlkYXRlZC5cbiAgICAgKi9cbiAgICBsZXQgdmFsaWRhdGVkID0gW107XG4gICAgLyoqXG4gICAgICogU2V0IHRoZSB2YWxpZGF0ZWQgaW5wdXRzLlxuICAgICAqXG4gICAgICogUmV0dXJucyBhbiBhcnJheSBvZiBsaXN0ZW5lcnMgdGhhdCBzaG91bGQgYmUgaW52b2tlZCBvbmNlIGFsbCBzdGF0ZVxuICAgICAqIGNoYW5nZXMgaGF2ZSB0YWtlbiBwbGFjZS5cbiAgICAgKi9cbiAgICBjb25zdCBzZXRWYWxpZGF0ZWQgPSAodmFsdWUpID0+IHtcbiAgICAgICAgY29uc3QgdW5pcXVlTmFtZXMgPSBbLi4ubmV3IFNldCh2YWx1ZSldO1xuICAgICAgICBpZiAodmFsaWRhdGVkLmxlbmd0aCAhPT0gdW5pcXVlTmFtZXMubGVuZ3RoIHx8ICF1bmlxdWVOYW1lcy5ldmVyeSgobmFtZSkgPT4gdmFsaWRhdGVkLmluY2x1ZGVzKG5hbWUpKSkge1xuICAgICAgICAgICAgdmFsaWRhdGVkID0gdW5pcXVlTmFtZXM7XG4gICAgICAgICAgICByZXR1cm4gbGlzdGVuZXJzLnZhbGlkYXRlZENoYW5nZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogVmFsaWQgdmFsaWRhdGlvbiBzdGF0ZS5cbiAgICAgKi9cbiAgICBjb25zdCB2YWxpZCA9ICgpID0+IHZhbGlkYXRlZC5maWx0ZXIoKG5hbWUpID0+IHR5cGVvZiBlcnJvcnNbbmFtZV0gPT09ICd1bmRlZmluZWQnKTtcbiAgICAvKipcbiAgICAgKiBUb3VjaGVkIGlucHV0IHN0YXRlLlxuICAgICAqL1xuICAgIGxldCB0b3VjaGVkID0gW107XG4gICAgLyoqXG4gICAgICogU2V0IHRoZSB0b3VjaGVkIGlucHV0cy5cbiAgICAgKlxuICAgICAqIFJldHVybnMgYW4gYXJyYXkgb2YgbGlzdGVuZXJzIHRoYXQgc2hvdWxkIGJlIGludm9rZWQgb25jZSBhbGwgc3RhdGVcbiAgICAgKiBjaGFuZ2VzIGhhdmUgdGFrZW4gcGxhY2UuXG4gICAgICovXG4gICAgY29uc3Qgc2V0VG91Y2hlZCA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBjb25zdCB1bmlxdWVOYW1lcyA9IFsuLi5uZXcgU2V0KHZhbHVlKV07XG4gICAgICAgIGlmICh0b3VjaGVkLmxlbmd0aCAhPT0gdW5pcXVlTmFtZXMubGVuZ3RoIHx8ICF1bmlxdWVOYW1lcy5ldmVyeSgobmFtZSkgPT4gdG91Y2hlZC5pbmNsdWRlcyhuYW1lKSkpIHtcbiAgICAgICAgICAgIHRvdWNoZWQgPSB1bmlxdWVOYW1lcztcbiAgICAgICAgICAgIHJldHVybiBsaXN0ZW5lcnMudG91Y2hlZENoYW5nZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogVmFsaWRhdGlvbiBlcnJvcnMgc3RhdGUuXG4gICAgICovXG4gICAgbGV0IGVycm9ycyA9IHt9O1xuICAgIC8qKlxuICAgICAqIFNldCB0aGUgaW5wdXQgZXJyb3JzLlxuICAgICAqXG4gICAgICogUmV0dXJucyBhbiBhcnJheSBvZiBsaXN0ZW5lcnMgdGhhdCBzaG91bGQgYmUgaW52b2tlZCBvbmNlIGFsbCBzdGF0ZVxuICAgICAqIGNoYW5nZXMgaGF2ZSB0YWtlbiBwbGFjZS5cbiAgICAgKi9cbiAgICBjb25zdCBzZXRFcnJvcnMgPSAodmFsdWUpID0+IHtcbiAgICAgICAgY29uc3QgcHJlcGFyZWQgPSB0b1ZhbGlkYXRpb25FcnJvcnModmFsdWUpO1xuICAgICAgICBpZiAoIWlzRXF1YWwoZXJyb3JzLCBwcmVwYXJlZCkpIHtcbiAgICAgICAgICAgIGVycm9ycyA9IHByZXBhcmVkO1xuICAgICAgICAgICAgcmV0dXJuIGxpc3RlbmVycy5lcnJvcnNDaGFuZ2VkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEZvcmdldCB0aGUgZ2l2ZW4gaW5wdXQncyBlcnJvcnMuXG4gICAgICpcbiAgICAgKiBSZXR1cm5zIGFuIGFycmF5IG9mIGxpc3RlbmVycyB0aGF0IHNob3VsZCBiZSBpbnZva2VkIG9uY2UgYWxsIHN0YXRlXG4gICAgICogY2hhbmdlcyBoYXZlIHRha2VuIHBsYWNlLlxuICAgICAqL1xuICAgIGNvbnN0IGZvcmdldEVycm9yID0gKG5hbWUpID0+IHtcbiAgICAgICAgY29uc3QgbmV3RXJyb3JzID0geyAuLi5lcnJvcnMgfTtcbiAgICAgICAgZGVsZXRlIG5ld0Vycm9yc1tyZXNvbHZlTmFtZShuYW1lKV07XG4gICAgICAgIHJldHVybiBzZXRFcnJvcnMobmV3RXJyb3JzKTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEhhcyBlcnJvcnMgc3RhdGUuXG4gICAgICovXG4gICAgY29uc3QgaGFzRXJyb3JzID0gKCkgPT4gT2JqZWN0LmtleXMoZXJyb3JzKS5sZW5ndGggPiAwO1xuICAgIC8qKlxuICAgICAqIERlYm91bmNpbmcgdGltZW91dCBzdGF0ZS5cbiAgICAgKi9cbiAgICBsZXQgZGVib3VuY2VUaW1lb3V0RHVyYXRpb24gPSAxNTAwO1xuICAgIGNvbnN0IHNldERlYm91bmNlVGltZW91dCA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBkZWJvdW5jZVRpbWVvdXREdXJhdGlvbiA9IHZhbHVlO1xuICAgICAgICB2YWxpZGF0b3IuY2FuY2VsKCk7XG4gICAgICAgIHZhbGlkYXRvciA9IGNyZWF0ZVZhbGlkYXRvcigpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogVGhlIG9sZCBkYXRhLlxuICAgICAqL1xuICAgIGxldCBvbGREYXRhID0gaW5pdGlhbERhdGE7XG4gICAgLyoqXG4gICAgICogVGhlIGRhdGEgY3VycmVudGx5IGJlaW5nIHZhbGlkYXRlZC5cbiAgICAgKi9cbiAgICBsZXQgdmFsaWRhdGluZ0RhdGEgPSBudWxsO1xuICAgIC8qKlxuICAgICAqIFRoZSBvbGQgdG91Y2hlZC5cbiAgICAgKi9cbiAgICBsZXQgb2xkVG91Y2hlZCA9IFtdO1xuICAgIC8qKlxuICAgICAqIFRoZSB0b3VjaGVkIGN1cnJlbnRseSBiZWluZyB2YWxpZGF0ZWQuXG4gICAgICovXG4gICAgbGV0IHZhbGlkYXRpbmdUb3VjaGVkID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiBDcmVhdGUgYSBkZWJvdW5jZWQgdmFsaWRhdGlvbiBjYWxsYmFjay5cbiAgICAgKi9cbiAgICBjb25zdCBjcmVhdGVWYWxpZGF0b3IgPSAoKSA9PiBkZWJvdW5jZSgoaW5zdGFuY2VDb25maWcpID0+IHtcbiAgICAgICAgY2FsbGJhY2soe1xuICAgICAgICAgICAgZ2V0OiAodXJsLCBkYXRhID0ge30sIGdsb2JhbENvbmZpZyA9IHt9KSA9PiBjbGllbnQuZ2V0KHVybCwgcGFyc2VEYXRhKGRhdGEpLCByZXNvbHZlQ29uZmlnKGdsb2JhbENvbmZpZywgaW5zdGFuY2VDb25maWcsIGRhdGEpKSxcbiAgICAgICAgICAgIHBvc3Q6ICh1cmwsIGRhdGEgPSB7fSwgZ2xvYmFsQ29uZmlnID0ge30pID0+IGNsaWVudC5wb3N0KHVybCwgcGFyc2VEYXRhKGRhdGEpLCByZXNvbHZlQ29uZmlnKGdsb2JhbENvbmZpZywgaW5zdGFuY2VDb25maWcsIGRhdGEpKSxcbiAgICAgICAgICAgIHBhdGNoOiAodXJsLCBkYXRhID0ge30sIGdsb2JhbENvbmZpZyA9IHt9KSA9PiBjbGllbnQucGF0Y2godXJsLCBwYXJzZURhdGEoZGF0YSksIHJlc29sdmVDb25maWcoZ2xvYmFsQ29uZmlnLCBpbnN0YW5jZUNvbmZpZywgZGF0YSkpLFxuICAgICAgICAgICAgcHV0OiAodXJsLCBkYXRhID0ge30sIGdsb2JhbENvbmZpZyA9IHt9KSA9PiBjbGllbnQucHV0KHVybCwgcGFyc2VEYXRhKGRhdGEpLCByZXNvbHZlQ29uZmlnKGdsb2JhbENvbmZpZywgaW5zdGFuY2VDb25maWcsIGRhdGEpKSxcbiAgICAgICAgICAgIGRlbGV0ZTogKHVybCwgZGF0YSA9IHt9LCBnbG9iYWxDb25maWcgPSB7fSkgPT4gY2xpZW50LmRlbGV0ZSh1cmwsIHBhcnNlRGF0YShkYXRhKSwgcmVzb2x2ZUNvbmZpZyhnbG9iYWxDb25maWcsIGluc3RhbmNlQ29uZmlnLCBkYXRhKSksXG4gICAgICAgIH0pLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICAgICAgLy8gUHJlY29nbml0aW9uIGNhbiBvZnRlbiBjYW5jZWwgaW4tZmxpZ2h0IHJlcXVlc3RzLiBJbnN0ZWFkIG9mXG4gICAgICAgICAgICAvLyB0aHJvd2luZyBhbiBleGNlcHRpb24gZm9yIHRoaXMgZXhwZWN0ZWQgYmVoYXZpb3VyLCB3ZSBzaWxlbnRseVxuICAgICAgICAgICAgLy8gZGlzY2FyZCBjYW5jZWxsZWQgcmVxdWVzdCBlcnJvcnMgdG8gbm90IGZsb29kIHRoZSBjb25zb2xlIHdpdGhcbiAgICAgICAgICAgIC8vIGV4cGVjdGVkIGVycm9ycy5cbiAgICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEh0dHBDYW5jZWxsZWRFcnJvcikge1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gVW5saWtlIG90aGVyIHN0YXR1cyBjb2RlcywgNDIyIHJlc3BvbnNlcyBhcmUgZXhwZWN0ZWQgYW5kXG4gICAgICAgICAgICAvLyByZWd1bGFybHkgb2NjdXIgd2l0aCBQcmVjb2duaXRpb24gcmVxdWVzdHMuIFdlIHNpbGVudGx5IGlnbm9yZVxuICAgICAgICAgICAgLy8gdGhlc2Ugc28gd2UgZG8gbm90IGZsb29kIHRoZSBjb25zb2xlIHdpdGggZXhwZWN0ZWQgZXJyb3JzLiBJZlxuICAgICAgICAgICAgLy8gbmVlZGVkLCB0aGV5IGNhbiBiZSBpbnRlcmNlcHRlZCBieSB0aGUgYG9uVmFsaWRhdGlvbkVycm9yYFxuICAgICAgICAgICAgLy8gY29uZmlnIG9wdGlvbiBpbnN0ZWFkLlxuICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgSHR0cFJlc3BvbnNlRXJyb3IgJiYgZXJyb3IucmVzcG9uc2U/LnN0YXR1cyA9PT0gNDIyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICB9KTtcbiAgICB9LCBkZWJvdW5jZVRpbWVvdXREdXJhdGlvbiwgeyBsZWFkaW5nOiB0cnVlLCB0cmFpbGluZzogdHJ1ZSB9KTtcbiAgICAvKipcbiAgICAgKiBWYWxpZGF0b3Igc3RhdGUuXG4gICAgICovXG4gICAgbGV0IHZhbGlkYXRvciA9IGNyZWF0ZVZhbGlkYXRvcigpO1xuICAgIC8qKlxuICAgICAqIFJlc29sdmUgdGhlIGNvbmZpZ3VyYXRpb24uXG4gICAgICovXG4gICAgY29uc3QgcmVzb2x2ZUNvbmZpZyA9IChnbG9iYWxDb25maWcsIGluc3RhbmNlQ29uZmlnLCBkYXRhID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgY29uZmlnID0ge1xuICAgICAgICAgICAgLi4uZ2xvYmFsQ29uZmlnLFxuICAgICAgICAgICAgLi4uaW5zdGFuY2VDb25maWcsXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IG9ubHkgPSBBcnJheS5mcm9tKGNvbmZpZy5vbmx5ID8/IGNvbmZpZy52YWxpZGF0ZSA/PyB0b3VjaGVkKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLmluc3RhbmNlQ29uZmlnLFxuICAgICAgICAgICAgLi4ubWVyZ2Uoe30sIGdsb2JhbENvbmZpZywgaW5zdGFuY2VDb25maWcpLFxuICAgICAgICAgICAgb25seSxcbiAgICAgICAgICAgIHRpbWVvdXQ6IGNvbmZpZy50aW1lb3V0ID8/IDUwMDAsXG4gICAgICAgICAgICBvblZhbGlkYXRpb25FcnJvcjogKHJlc3BvbnNlLCBlcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgLi4uc2V0VmFsaWRhdGVkKFsuLi52YWxpZGF0ZWQsIC4uLm9ubHldKSxcbiAgICAgICAgICAgICAgICAgICAgLi4uc2V0RXJyb3JzKG1lcmdlKG9taXRCeVBhdHRlcm4oeyAuLi5lcnJvcnMgfSwgb25seSksIHJlc3BvbnNlLmRhdGEuZXJyb3JzKSksXG4gICAgICAgICAgICAgICAgXS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbmZpZy5vblZhbGlkYXRpb25FcnJvclxuICAgICAgICAgICAgICAgICAgICA/IGNvbmZpZy5vblZhbGlkYXRpb25FcnJvcihyZXNwb25zZSwgZXJyb3IpXG4gICAgICAgICAgICAgICAgICAgIDogUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uU3VjY2VzczogKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0VmFsaWRhdGVkKFsuLi52YWxpZGF0ZWQsIC4uLm9ubHldKS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbmZpZy5vblN1Y2Nlc3NcbiAgICAgICAgICAgICAgICAgICAgPyBjb25maWcub25TdWNjZXNzKHJlc3BvbnNlKVxuICAgICAgICAgICAgICAgICAgICA6IHJlc3BvbnNlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uUHJlY29nbml0aW9uU3VjY2VzczogKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAuLi5zZXRWYWxpZGF0ZWQoWy4uLnZhbGlkYXRlZCwgLi4ub25seV0pLFxuICAgICAgICAgICAgICAgICAgICAuLi5zZXRFcnJvcnMob21pdEJ5UGF0dGVybih7IC4uLmVycm9ycyB9LCBvbmx5KSksXG4gICAgICAgICAgICAgICAgXS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbmZpZy5vblByZWNvZ25pdGlvblN1Y2Nlc3NcbiAgICAgICAgICAgICAgICAgICAgPyBjb25maWcub25QcmVjb2duaXRpb25TdWNjZXNzKHJlc3BvbnNlKVxuICAgICAgICAgICAgICAgICAgICA6IHJlc3BvbnNlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uQmVmb3JlOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gV2lsZGNhcmRzIGFyZSBleHBhbmRlZCB0byBjb25jcmV0ZSBwYXRocyB1c2luZyB0aGUgY3VycmVudFxuICAgICAgICAgICAgICAgIC8vIGZvcm0gZGF0YSBzbyB0aGF0IGVhY2ggZmllbGQgaXMgaW5kaXZpZHVhbGx5IHRyYWNrZWQuXG4gICAgICAgICAgICAgICAgY29uc3QgaGFzV2lsZGNhcmRzID0gdG91Y2hlZC5zb21lKChuYW1lKSA9PiBuYW1lLmluY2x1ZGVzKCcqJykpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGV4cGFuZGVkVG91Y2hlZCA9IGhhc1dpbGRjYXJkc1xuICAgICAgICAgICAgICAgICAgICA/IFsuLi5uZXcgU2V0KHRvdWNoZWQuZmxhdE1hcCgobmFtZSkgPT4gZXhwYW5kV2lsZGNhcmRQYXRocyhuYW1lLCBkYXRhKSkpXVxuICAgICAgICAgICAgICAgICAgICA6IHRvdWNoZWQ7XG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5vbkJlZm9yZVZhbGlkYXRpb24gJiYgY29uZmlnLm9uQmVmb3JlVmFsaWRhdGlvbih7IGRhdGEsIHRvdWNoZWQ6IGV4cGFuZGVkVG91Y2hlZCB9LCB7IGRhdGE6IG9sZERhdGEsIHRvdWNoZWQ6IG9sZFRvdWNoZWQgfSkgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgYmVmb3JlUmVzdWx0ID0gKGNvbmZpZy5vbkJlZm9yZSB8fCAoKCkgPT4gdHJ1ZSkpKCk7XG4gICAgICAgICAgICAgICAgaWYgKGJlZm9yZVJlc3VsdCA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoaGFzV2lsZGNhcmRzKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldFRvdWNoZWQoZXhwYW5kZWRUb3VjaGVkKS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZhbGlkYXRpbmdUb3VjaGVkID0gdG91Y2hlZDtcbiAgICAgICAgICAgICAgICB2YWxpZGF0aW5nRGF0YSA9IGRhdGE7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25TdGFydDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFZhbGlkYXRpbmcodHJ1ZSkuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyKCkpO1xuICAgICAgICAgICAgICAgIChjb25maWcub25TdGFydCA/PyAoKCkgPT4gbnVsbCkpKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25GaW5pc2g6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRWYWxpZGF0aW5nKGZhbHNlKS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICAgICAgb2xkVG91Y2hlZCA9IHZhbGlkYXRpbmdUb3VjaGVkO1xuICAgICAgICAgICAgICAgIG9sZERhdGEgPSB2YWxpZGF0aW5nRGF0YTtcbiAgICAgICAgICAgICAgICB2YWxpZGF0aW5nVG91Y2hlZCA9IHZhbGlkYXRpbmdEYXRhID0gbnVsbDtcbiAgICAgICAgICAgICAgICAoY29uZmlnLm9uRmluaXNoID8/ICgoKSA9PiBudWxsKSkoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBWYWxpZGF0ZSB0aGUgZ2l2ZW4gaW5wdXQuXG4gICAgICovXG4gICAgY29uc3QgdmFsaWRhdGUgPSAobmFtZSwgdmFsdWUsIGNvbmZpZykgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIG5hbWUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBjb25zdCBvbmx5ID0gQXJyYXkuZnJvbShjb25maWc/Lm9ubHkgPz8gY29uZmlnPy52YWxpZGF0ZSA/PyBbXSk7XG4gICAgICAgICAgICBzZXRUb3VjaGVkKFsuLi50b3VjaGVkLCAuLi5vbmx5XSkuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyKCkpO1xuICAgICAgICAgICAgdmFsaWRhdG9yKGNvbmZpZyA/PyB7fSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRmlsZSh2YWx1ZSkgJiYgIXZhbGlkYXRlRmlsZXMpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignUHJlY29nbml0aW9uIGZpbGUgdmFsaWRhdGlvbiBpcyBub3QgYWN0aXZlLiBDYWxsIHRoZSBcInZhbGlkYXRlRmlsZXNcIiBmdW5jdGlvbiBvbiB5b3VyIGZvcm0gdG8gZW5hYmxlIGl0LicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG5hbWUgPSByZXNvbHZlTmFtZShuYW1lKTtcbiAgICAgICAgaWYgKG5hbWUuaW5jbHVkZXMoJyonKSB8fCBnZXQob2xkRGF0YSwgbmFtZSkgIT09IHZhbHVlKSB7XG4gICAgICAgICAgICBzZXRUb3VjaGVkKFtuYW1lLCAuLi50b3VjaGVkXSkuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyKCkpO1xuICAgICAgICAgICAgdmFsaWRhdG9yKGNvbmZpZyA/PyB7fSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFBhcnNlIHRoZSB2YWxpZGF0ZWQgZGF0YS5cbiAgICAgKi9cbiAgICBjb25zdCBwYXJzZURhdGEgPSAoZGF0YSkgPT4gdmFsaWRhdGVGaWxlcyA9PT0gZmFsc2VcbiAgICAgICAgPyBmb3JnZXRGaWxlcyhkYXRhKVxuICAgICAgICA6IGRhdGE7XG4gICAgLyoqXG4gICAgICogVGhlIGZvcm0gdmFsaWRhdG9yIGluc3RhbmNlLlxuICAgICAqL1xuICAgIGNvbnN0IGZvcm0gPSB7XG4gICAgICAgIHRvdWNoZWQ6ICgpID0+IHRvdWNoZWQsXG4gICAgICAgIHZhbGlkYXRlKG5hbWUsIHZhbHVlLCBjb25maWcpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbmFtZSA9PT0gJ29iamVjdCcgJiYgISgndGFyZ2V0JyBpbiBuYW1lKSkge1xuICAgICAgICAgICAgICAgIGNvbmZpZyA9IG5hbWU7XG4gICAgICAgICAgICAgICAgbmFtZSA9IHZhbHVlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFsaWRhdGUobmFtZSwgdmFsdWUsIGNvbmZpZyk7XG4gICAgICAgICAgICByZXR1cm4gZm9ybTtcbiAgICAgICAgfSxcbiAgICAgICAgdG91Y2goaW5wdXQpIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0cyA9IEFycmF5LmlzQXJyYXkoaW5wdXQpXG4gICAgICAgICAgICAgICAgPyBpbnB1dFxuICAgICAgICAgICAgICAgIDogW3Jlc29sdmVOYW1lKGlucHV0KV07XG4gICAgICAgICAgICBzZXRUb3VjaGVkKFsuLi50b3VjaGVkLCAuLi5pbnB1dHNdKS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICByZXR1cm4gZm9ybTtcbiAgICAgICAgfSxcbiAgICAgICAgdmFsaWRhdGluZzogKCkgPT4gdmFsaWRhdGluZyxcbiAgICAgICAgdmFsaWQsXG4gICAgICAgIGVycm9yczogKCkgPT4gZXJyb3JzLFxuICAgICAgICBoYXNFcnJvcnMsXG4gICAgICAgIHNldEVycm9ycyh2YWx1ZSkge1xuICAgICAgICAgICAgc2V0RXJyb3JzKHZhbHVlKS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIoKSk7XG4gICAgICAgICAgICByZXR1cm4gZm9ybTtcbiAgICAgICAgfSxcbiAgICAgICAgZm9yZ2V0RXJyb3IobmFtZSkge1xuICAgICAgICAgICAgZm9yZ2V0RXJyb3IobmFtZSkuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyKCkpO1xuICAgICAgICAgICAgcmV0dXJuIGZvcm07XG4gICAgICAgIH0sXG4gICAgICAgIGRlZmF1bHRzKGRhdGEpIHtcbiAgICAgICAgICAgIGluaXRpYWxEYXRhID0gZGF0YTtcbiAgICAgICAgICAgIG9sZERhdGEgPSBkYXRhO1xuICAgICAgICAgICAgcmV0dXJuIGZvcm07XG4gICAgICAgIH0sXG4gICAgICAgIHJlc2V0KC4uLm5hbWVzKSB7XG4gICAgICAgICAgICBpZiAobmFtZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgc2V0VG91Y2hlZChbXSkuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3VG91Y2hlZCA9IFsuLi50b3VjaGVkXTtcbiAgICAgICAgICAgICAgICBuYW1lcy5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChuZXdUb3VjaGVkLmluY2x1ZGVzKG5hbWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdUb3VjaGVkLnNwbGljZShuZXdUb3VjaGVkLmluZGV4T2YobmFtZSksIDEpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHNldChvbGREYXRhLCBuYW1lLCBnZXQoaW5pdGlhbERhdGEsIG5hbWUpKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBzZXRUb3VjaGVkKG5ld1RvdWNoZWQpLmZvckVhY2goKGxpc3RlbmVyKSA9PiBsaXN0ZW5lcigpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmb3JtO1xuICAgICAgICB9LFxuICAgICAgICBzZXRUaW1lb3V0KHZhbHVlKSB7XG4gICAgICAgICAgICBzZXREZWJvdW5jZVRpbWVvdXQodmFsdWUpO1xuICAgICAgICAgICAgcmV0dXJuIGZvcm07XG4gICAgICAgIH0sXG4gICAgICAgIG9uKGV2ZW50LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgbGlzdGVuZXJzW2V2ZW50XS5wdXNoKGNhbGxiYWNrKTtcbiAgICAgICAgICAgIHJldHVybiBmb3JtO1xuICAgICAgICB9LFxuICAgICAgICB2YWxpZGF0ZUZpbGVzKCkge1xuICAgICAgICAgICAgdmFsaWRhdGVGaWxlcyA9IHRydWU7XG4gICAgICAgICAgICByZXR1cm4gZm9ybTtcbiAgICAgICAgfSxcbiAgICAgICAgd2l0aG91dEZpbGVWYWxpZGF0aW9uKCkge1xuICAgICAgICAgICAgdmFsaWRhdGVGaWxlcyA9IGZhbHNlO1xuICAgICAgICAgICAgcmV0dXJuIGZvcm07XG4gICAgICAgIH0sXG4gICAgfTtcbiAgICByZXR1cm4gZm9ybTtcbn07XG4vKipcbiAqIE5vcm1hbGlzZSB0aGUgdmFsaWRhdGlvbiBlcnJvcnMgYXMgSW5lcnRpYSBmb3JtYXR0ZWQgZXJyb3JzLlxuICovXG5leHBvcnQgY29uc3QgdG9TaW1wbGVWYWxpZGF0aW9uRXJyb3JzID0gKGVycm9ycykgPT4ge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJvcnMpLnJlZHVjZSgoY2FycnksIGtleSkgPT4gKHtcbiAgICAgICAgLi4uY2FycnksXG4gICAgICAgIFtrZXldOiBBcnJheS5pc0FycmF5KGVycm9yc1trZXldKVxuICAgICAgICAgICAgPyBlcnJvcnNba2V5XVswXVxuICAgICAgICAgICAgOiBlcnJvcnNba2V5XSxcbiAgICB9KSwge30pO1xufTtcbi8qKlxuICogTm9ybWFsaXNlIHRoZSB2YWxpZGF0aW9uIGVycm9ycyBhcyBMYXJhdmVsIGZvcm1hdHRlZCBlcnJvcnMuXG4gKi9cbmV4cG9ydCBjb25zdCB0b1ZhbGlkYXRpb25FcnJvcnMgPSAoZXJyb3JzKSA9PiB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGVycm9ycykucmVkdWNlKChjYXJyeSwga2V5KSA9PiAoe1xuICAgICAgICAuLi5jYXJyeSxcbiAgICAgICAgW2tleV06IHR5cGVvZiBlcnJvcnNba2V5XSA9PT0gJ3N0cmluZycgPyBbZXJyb3JzW2tleV1dIDogZXJyb3JzW2tleV0sXG4gICAgfSksIHt9KTtcbn07XG4vKipcbiAqIFJlc29sdmUgdGhlIGlucHV0J3MgXCJuYW1lXCIgYXR0cmlidXRlLlxuICovXG5leHBvcnQgY29uc3QgcmVzb2x2ZU5hbWUgPSAobmFtZSkgPT4ge1xuICAgIHJldHVybiB0eXBlb2YgbmFtZSAhPT0gJ3N0cmluZydcbiAgICAgICAgPyBuYW1lLnRhcmdldC5uYW1lXG4gICAgICAgIDogbmFtZTtcbn07XG4vKipcbiAqIEZvcmdldCBhbnkgZmlsZXMgZnJvbSB0aGUgcGF5bG9hZC5cbiAqL1xuY29uc3QgZm9yZ2V0RmlsZXMgPSAoZGF0YSkgPT4ge1xuICAgIGNvbnN0IG5ld0RhdGEgPSB7IC4uLmRhdGEgfTtcbiAgICBPYmplY3Qua2V5cyhuZXdEYXRhKS5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gbmV3RGF0YVtuYW1lXTtcbiAgICAgICAgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRmlsZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGRlbGV0ZSBuZXdEYXRhW25hbWVdO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICAgICAgbmV3RGF0YVtuYW1lXSA9IE9iamVjdC52YWx1ZXMoZm9yZ2V0RmlsZXMoeyAuLi52YWx1ZSB9KSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgIG5ld0RhdGFbbmFtZV0gPSBmb3JnZXRGaWxlcyhuZXdEYXRhW25hbWVdKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBuZXdEYXRhO1xufTtcbiIsIi8vIHNyYy9yb3V0ZXIudHNcbmltcG9ydCB7IGNsb25lRGVlcCBhcyBjbG9uZURlZXA0LCBpc0VxdWFsIGFzIGlzRXF1YWwzIH0gZnJvbSBcImVzLXRvb2xraXRcIjtcbmltcG9ydCB7IGdldCBhcyBnZXQ3LCBzZXQgYXMgc2V0NSB9IGZyb20gXCJlcy10b29sa2l0L2NvbXBhdFwiO1xuXG4vLyBzcmMvY29uZmlnLnRzXG5pbXBvcnQgeyBnZXQsIGhhcywgc2V0IH0gZnJvbSBcImVzLXRvb2xraXQvY29tcGF0XCI7XG52YXIgQ29uZmlnID0gY2xhc3Mge1xuICBjb25maWcgPSB7fTtcbiAgZGVmYXVsdHM7XG4gIGNvbnN0cnVjdG9yKGRlZmF1bHRzKSB7XG4gICAgdGhpcy5kZWZhdWx0cyA9IGRlZmF1bHRzO1xuICB9XG4gIGV4dGVuZChkZWZhdWx0cykge1xuICAgIGlmIChkZWZhdWx0cykge1xuICAgICAgdGhpcy5kZWZhdWx0cyA9IHsgLi4udGhpcy5kZWZhdWx0cywgLi4uZGVmYXVsdHMgfTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgcmVwbGFjZShuZXdDb25maWcpIHtcbiAgICB0aGlzLmNvbmZpZyA9IG5ld0NvbmZpZztcbiAgfVxuICBnZXQoa2V5KSB7XG4gICAgcmV0dXJuIGhhcyh0aGlzLmNvbmZpZywga2V5KSA/IGdldCh0aGlzLmNvbmZpZywga2V5KSA6IGdldCh0aGlzLmRlZmF1bHRzLCBrZXkpO1xuICB9XG4gIHNldChrZXlPclZhbHVlcywgdmFsdWUpIHtcbiAgICBpZiAodHlwZW9mIGtleU9yVmFsdWVzID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBzZXQodGhpcy5jb25maWcsIGtleU9yVmFsdWVzLCB2YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIE9iamVjdC5lbnRyaWVzKGtleU9yVmFsdWVzKS5mb3JFYWNoKChba2V5LCB2YWxdKSA9PiB7XG4gICAgICAgIHNldCh0aGlzLmNvbmZpZywga2V5LCB2YWwpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG59O1xudmFyIGNvbmZpZyA9IG5ldyBDb25maWcoe1xuICBmb3JtOiB7XG4gICAgcmVjZW50bHlTdWNjZXNzZnVsRHVyYXRpb246IDJlMyxcbiAgICBmb3JjZUluZGljZXNBcnJheUZvcm1hdEluRm9ybURhdGE6IHRydWUsXG4gICAgd2l0aEFsbEVycm9yczogZmFsc2VcbiAgfSxcbiAgcHJlZmV0Y2g6IHtcbiAgICBjYWNoZUZvcjogM2U0LFxuICAgIGhvdmVyRGVsYXk6IDc1XG4gIH1cbn0pO1xuXG4vLyBzcmMvZXZlbnRIYW5kbGVyLnRzXG5pbXBvcnQgeyBnZXQgYXMgZ2V0NCB9IGZyb20gXCJlcy10b29sa2l0L2NvbXBhdFwiO1xuXG4vLyBzcmMvZGVib3VuY2UudHNcbmZ1bmN0aW9uIGRlYm91bmNlKGZuLCBkZWxheSkge1xuICBsZXQgdGltZW91dElEO1xuICByZXR1cm4gZnVuY3Rpb24oLi4uYXJncykge1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SUQpO1xuICAgIHRpbWVvdXRJRCA9IHNldFRpbWVvdXQoKCkgPT4gZm4uYXBwbHkodGhpcywgYXJncyksIGRlbGF5KTtcbiAgfTtcbn1cblxuLy8gc3JjL2V2ZW50cy50c1xuZnVuY3Rpb24gZmlyZUV2ZW50KG5hbWUsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KGBpbmVydGlhOiR7bmFtZX1gLCBvcHRpb25zKSk7XG59XG52YXIgZmlyZUJlZm9yZUV2ZW50ID0gKHZpc2l0KSA9PiB7XG4gIHJldHVybiBmaXJlRXZlbnQoXCJiZWZvcmVcIiwgeyBjYW5jZWxhYmxlOiB0cnVlLCBkZXRhaWw6IHsgdmlzaXQgfSB9KTtcbn07XG52YXIgZmlyZUVycm9yRXZlbnQgPSAoZXJyb3JzLCB7IHBhZ2U6IHBhZ2UyLCB2aXNpdElkIH0gPSB7fSkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwiZXJyb3JcIiwgeyBkZXRhaWw6IHsgZXJyb3JzLCBwYWdlOiBwYWdlMiwgdmlzaXRJZCB9IH0pO1xufTtcbnZhciBmaXJlTmV0d29ya0Vycm9yRXZlbnQgPSAoZXJyb3IpID0+IHtcbiAgcmV0dXJuIGZpcmVFdmVudChcIm5ldHdvcmtFcnJvclwiLCB7IGNhbmNlbGFibGU6IHRydWUsIGRldGFpbDogeyBlcnJvciB9IH0pO1xufTtcbnZhciBmaXJlRmluaXNoRXZlbnQgPSAodmlzaXQpID0+IHtcbiAgcmV0dXJuIGZpcmVFdmVudChcImZpbmlzaFwiLCB7IGRldGFpbDogeyB2aXNpdCB9IH0pO1xufTtcbnZhciBmaXJlSHR0cEV4Y2VwdGlvbkV2ZW50ID0gKHJlc3BvbnNlKSA9PiB7XG4gIHJldHVybiBmaXJlRXZlbnQoXCJodHRwRXhjZXB0aW9uXCIsIHsgY2FuY2VsYWJsZTogdHJ1ZSwgZGV0YWlsOiB7IHJlc3BvbnNlIH0gfSk7XG59O1xudmFyIGZpcmVCZWZvcmVVcGRhdGVFdmVudCA9IChwYWdlMikgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwiYmVmb3JlVXBkYXRlXCIsIHsgZGV0YWlsOiB7IHBhZ2U6IHBhZ2UyIH0gfSk7XG59O1xudmFyIGZpcmVOYXZpZ2F0ZUV2ZW50ID0gKHBhZ2UyLCB7IGNhY2hlZCA9IGZhbHNlLCB2aXNpdElkIH0gPSB7fSkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwibmF2aWdhdGVcIiwgeyBkZXRhaWw6IHsgcGFnZTogcGFnZTIsIGNhY2hlZCwgdmlzaXRJZCB9IH0pO1xufTtcbnZhciBmaXJlQ2xpZW50VmlzaXRFdmVudCA9IChwYWdlMiwgeyByZXBsYWNlLCB2aXNpdElkIH0pID0+IHtcbiAgcmV0dXJuIGZpcmVFdmVudChcImNsaWVudFZpc2l0XCIsIHsgZGV0YWlsOiB7IHBhZ2U6IHBhZ2UyLCByZXBsYWNlLCB2aXNpdElkIH0gfSk7XG59O1xudmFyIGZpcmVQcm9ncmVzc0V2ZW50ID0gKHByb2dyZXNzMykgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwicHJvZ3Jlc3NcIiwgeyBkZXRhaWw6IHsgcHJvZ3Jlc3M6IHByb2dyZXNzMyB9IH0pO1xufTtcbnZhciBmaXJlU3RhcnRFdmVudCA9ICh2aXNpdCkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwic3RhcnRcIiwgeyBkZXRhaWw6IHsgdmlzaXQgfSB9KTtcbn07XG52YXIgZmlyZVN1Y2Nlc3NFdmVudCA9IChwYWdlMiwgeyB2aXNpdElkIH0gPSB7fSkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwic3VjY2Vzc1wiLCB7IGRldGFpbDogeyBwYWdlOiBwYWdlMiwgdmlzaXRJZCB9IH0pO1xufTtcbnZhciBmaXJlUHJlZmV0Y2hlZEV2ZW50ID0gKHJlc3BvbnNlLCB2aXNpdCkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwicHJlZmV0Y2hlZFwiLCB7IGRldGFpbDogeyBmZXRjaGVkQXQ6IERhdGUubm93KCksIHJlc3BvbnNlLCB2aXNpdCB9IH0pO1xufTtcbnZhciBmaXJlUHJlZmV0Y2hpbmdFdmVudCA9ICh2aXNpdCkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwicHJlZmV0Y2hpbmdcIiwgeyBkZXRhaWw6IHsgdmlzaXQgfSB9KTtcbn07XG52YXIgZmlyZUZsYXNoRXZlbnQgPSAoZmxhc2gpID0+IHtcbiAgcmV0dXJuIGZpcmVFdmVudChcImZsYXNoXCIsIHsgZGV0YWlsOiB7IGZsYXNoIH0gfSk7XG59O1xudmFyIGZpcmVMb2NhdGlvbkV2ZW50ID0gKHVybCwgdmVyc2lvbkNoYW5nZSkgPT4ge1xuICByZXR1cm4gZmlyZUV2ZW50KFwibG9jYXRpb25cIiwgeyBjYW5jZWxhYmxlOiB0cnVlLCBkZXRhaWw6IHsgdXJsLCB2ZXJzaW9uQ2hhbmdlIH0gfSk7XG59O1xuXG4vLyBzcmMvaGlzdG9yeS50c1xuaW1wb3J0IHsgY2xvbmVEZWVwIGFzIGNsb25lRGVlcDMsIGlzRXF1YWwgfSBmcm9tIFwiZXMtdG9vbGtpdFwiO1xuXG4vLyBzcmMvc2Vzc2lvblN0b3JhZ2UudHNcbnZhciBTZXNzaW9uU3RvcmFnZSA9IGNsYXNzIHtcbiAgc3RhdGljIGxvY2F0aW9uVmlzaXRLZXkgPSBcImluZXJ0aWFMb2NhdGlvblZpc2l0XCI7XG4gIHN0YXRpYyBzZXQoa2V5LCB2YWx1ZSkge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB3aW5kb3cuc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KHZhbHVlKSk7XG4gICAgfVxuICB9XG4gIHN0YXRpYyBnZXQoa2V5KSB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5nZXRJdGVtKGtleSkgfHwgXCJudWxsXCIpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgbWVyZ2Uoa2V5LCB2YWx1ZSkge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gdGhpcy5nZXQoa2V5KTtcbiAgICBpZiAoZXhpc3RpbmcgPT09IG51bGwpIHtcbiAgICAgIHRoaXMuc2V0KGtleSwgdmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNldChrZXksIHsgLi4uZXhpc3RpbmcsIC4uLnZhbHVlIH0pO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgcmVtb3ZlKGtleSkge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB3aW5kb3cuc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbShrZXkpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgcmVtb3ZlTmVzdGVkKGtleSwgbmVzdGVkS2V5KSB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSB0aGlzLmdldChrZXkpO1xuICAgIGlmIChleGlzdGluZyAhPT0gbnVsbCkge1xuICAgICAgZGVsZXRlIGV4aXN0aW5nW25lc3RlZEtleV07XG4gICAgICB0aGlzLnNldChrZXksIGV4aXN0aW5nKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIGV4aXN0cyhrZXkpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0KGtleSkgIT09IG51bGw7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIGNsZWFyKCkge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuY2xlYXIoKTtcbiAgICB9XG4gIH1cbn07XG5cbi8vIHNyYy9lbmNyeXB0aW9uLnRzXG52YXIgZW5jcnlwdEhpc3RvcnkgPSBhc3luYyAoZGF0YSkgPT4ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYWJsZSB0byBlbmNyeXB0IGhpc3RvcnlcIik7XG4gIH1cbiAgY29uc3QgaXYgPSBnZXRJdigpO1xuICBjb25zdCBzdG9yZWRLZXkgPSBhd2FpdCBnZXRLZXlGcm9tU2Vzc2lvblN0b3JhZ2UoKTtcbiAgY29uc3Qga2V5ID0gYXdhaXQgZ2V0T3JDcmVhdGVLZXkoc3RvcmVkS2V5KTtcbiAgaWYgKCFrZXkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmFibGUgdG8gZW5jcnlwdCBoaXN0b3J5XCIpO1xuICB9XG4gIGNvbnN0IGVuY3J5cHRlZCA9IGF3YWl0IGVuY3J5cHREYXRhKGl2LCBrZXksIGRhdGEpO1xuICByZXR1cm4gZW5jcnlwdGVkO1xufTtcbnZhciBoaXN0b3J5U2Vzc2lvblN0b3JhZ2VLZXlzID0ge1xuICBrZXk6IFwiaGlzdG9yeUtleVwiLFxuICBpdjogXCJoaXN0b3J5SXZcIlxufTtcbnZhciBkZWNyeXB0SGlzdG9yeSA9IGFzeW5jIChkYXRhKSA9PiB7XG4gIGNvbnN0IGl2ID0gZ2V0SXYoKTtcbiAgY29uc3Qgc3RvcmVkS2V5ID0gYXdhaXQgZ2V0S2V5RnJvbVNlc3Npb25TdG9yYWdlKCk7XG4gIGlmICghc3RvcmVkS2V5KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiVW5hYmxlIHRvIGRlY3J5cHQgaGlzdG9yeVwiKTtcbiAgfVxuICByZXR1cm4gYXdhaXQgZGVjcnlwdERhdGEoaXYsIHN0b3JlZEtleSwgZGF0YSk7XG59O1xudmFyIGVuY3J5cHREYXRhID0gYXN5bmMgKGl2LCBrZXksIGRhdGEpID0+IHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmFibGUgdG8gZW5jcnlwdCBoaXN0b3J5XCIpO1xuICB9XG4gIGlmICh0eXBlb2Ygd2luZG93LmNyeXB0by5zdWJ0bGUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBjb25zb2xlLndhcm4oXCJFbmNyeXB0aW9uIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudC4gU1NMIGlzIHJlcXVpcmVkLlwiKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGRhdGEpO1xuICB9XG4gIGNvbnN0IHRleHRFbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG4gIGNvbnN0IHN0ciA9IEpTT04uc3RyaW5naWZ5KGRhdGEpO1xuICBjb25zdCBlbmNvZGVkID0gbmV3IFVpbnQ4QXJyYXkoc3RyLmxlbmd0aCAqIDMpO1xuICBjb25zdCByZXN1bHQgPSB0ZXh0RW5jb2Rlci5lbmNvZGVJbnRvKHN0ciwgZW5jb2RlZCk7XG4gIHJldHVybiB3aW5kb3cuY3J5cHRvLnN1YnRsZS5lbmNyeXB0KFxuICAgIHtcbiAgICAgIG5hbWU6IFwiQUVTLUdDTVwiLFxuICAgICAgaXZcbiAgICB9LFxuICAgIGtleSxcbiAgICBlbmNvZGVkLnN1YmFycmF5KDAsIHJlc3VsdC53cml0dGVuKVxuICApO1xufTtcbnZhciBkZWNyeXB0RGF0YSA9IGFzeW5jIChpdiwga2V5LCBkYXRhKSA9PiB7XG4gIGlmICh0eXBlb2Ygd2luZG93LmNyeXB0by5zdWJ0bGUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBjb25zb2xlLndhcm4oXCJEZWNyeXB0aW9uIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudC4gU1NMIGlzIHJlcXVpcmVkLlwiKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGRhdGEpO1xuICB9XG4gIGNvbnN0IGRlY3J5cHRlZCA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmRlY3J5cHQoXG4gICAge1xuICAgICAgbmFtZTogXCJBRVMtR0NNXCIsXG4gICAgICBpdlxuICAgIH0sXG4gICAga2V5LFxuICAgIGRhdGFcbiAgKTtcbiAgcmV0dXJuIEpTT04ucGFyc2UobmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGRlY3J5cHRlZCkpO1xufTtcbnZhciBnZXRJdiA9ICgpID0+IHtcbiAgY29uc3QgaXZTdHJpbmcgPSBTZXNzaW9uU3RvcmFnZS5nZXQoaGlzdG9yeVNlc3Npb25TdG9yYWdlS2V5cy5pdik7XG4gIGlmIChpdlN0cmluZykge1xuICAgIHJldHVybiBuZXcgVWludDhBcnJheShpdlN0cmluZyk7XG4gIH1cbiAgY29uc3QgaXYgPSB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBTZXNzaW9uU3RvcmFnZS5zZXQoaGlzdG9yeVNlc3Npb25TdG9yYWdlS2V5cy5pdiwgQXJyYXkuZnJvbShpdikpO1xuICByZXR1cm4gaXY7XG59O1xudmFyIGNyZWF0ZUtleSA9IGFzeW5jICgpID0+IHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cuY3J5cHRvLnN1YnRsZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGNvbnNvbGUud2FybihcIkVuY3J5cHRpb24gaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50LiBTU0wgaXMgcmVxdWlyZWQuXCIpO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUobnVsbCk7XG4gIH1cbiAgcmV0dXJuIHdpbmRvdy5jcnlwdG8uc3VidGxlLmdlbmVyYXRlS2V5KFxuICAgIHtcbiAgICAgIG5hbWU6IFwiQUVTLUdDTVwiLFxuICAgICAgbGVuZ3RoOiAyNTZcbiAgICB9LFxuICAgIHRydWUsXG4gICAgW1wiZW5jcnlwdFwiLCBcImRlY3J5cHRcIl1cbiAgKTtcbn07XG52YXIgc2F2ZUtleSA9IGFzeW5jIChrZXkpID0+IHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cuY3J5cHRvLnN1YnRsZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGNvbnNvbGUud2FybihcIkVuY3J5cHRpb24gaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50LiBTU0wgaXMgcmVxdWlyZWQuXCIpO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgfVxuICBjb25zdCBrZXlEYXRhID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZXhwb3J0S2V5KFwicmF3XCIsIGtleSk7XG4gIFNlc3Npb25TdG9yYWdlLnNldChoaXN0b3J5U2Vzc2lvblN0b3JhZ2VLZXlzLmtleSwgQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShrZXlEYXRhKSkpO1xufTtcbnZhciBnZXRPckNyZWF0ZUtleSA9IGFzeW5jIChrZXkpID0+IHtcbiAgaWYgKGtleSkge1xuICAgIHJldHVybiBrZXk7XG4gIH1cbiAgY29uc3QgbmV3S2V5ID0gYXdhaXQgY3JlYXRlS2V5KCk7XG4gIGlmICghbmV3S2V5KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgYXdhaXQgc2F2ZUtleShuZXdLZXkpO1xuICByZXR1cm4gbmV3S2V5O1xufTtcbnZhciBnZXRLZXlGcm9tU2Vzc2lvblN0b3JhZ2UgPSBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IHN0cmluZ0tleSA9IFNlc3Npb25TdG9yYWdlLmdldChoaXN0b3J5U2Vzc2lvblN0b3JhZ2VLZXlzLmtleSk7XG4gIGlmICghc3RyaW5nS2V5KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3Qga2V5ID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KFxuICAgIFwicmF3XCIsXG4gICAgbmV3IFVpbnQ4QXJyYXkoc3RyaW5nS2V5KSxcbiAgICB7XG4gICAgICBuYW1lOiBcIkFFUy1HQ01cIixcbiAgICAgIGxlbmd0aDogMjU2XG4gICAgfSxcbiAgICB0cnVlLFxuICAgIFtcImVuY3J5cHRcIiwgXCJkZWNyeXB0XCJdXG4gICk7XG4gIHJldHVybiBrZXk7XG59O1xuXG4vLyBzcmMvcGFnZS50c1xuaW1wb3J0IHsgY2xvbmVEZWVwIGFzIGNsb25lRGVlcDIgfSBmcm9tIFwiZXMtdG9vbGtpdFwiO1xuaW1wb3J0IHsgZ2V0IGFzIGdldDMsIHNldCBhcyBzZXQzIH0gZnJvbSBcImVzLXRvb2xraXQvY29tcGF0XCI7XG5cbi8vIHNyYy9wcmVmZXRjaGVkLnRzXG5pbXBvcnQgeyBjbG9uZURlZXAgfSBmcm9tIFwiZXMtdG9vbGtpdFwiO1xuaW1wb3J0IHsgZ2V0IGFzIGdldDIgfSBmcm9tIFwiZXMtdG9vbGtpdC9jb21wYXRcIjtcblxuLy8gc3JjL29iamVjdFV0aWxzLnRzXG5pbXBvcnQgeyB0b1BhdGggfSBmcm9tIFwiZXMtdG9vbGtpdC9jb21wYXRcIjtcbnZhciBzdHJpcFRvcExldmVsVW5kZWZpbmVkID0gKG9iaikgPT4ge1xuICBjb25zdCByZXN1bHQgPSB7fTtcbiAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob2JqKSkge1xuICAgIGlmIChvYmpba2V5XSAhPT0gdm9pZCAwKSB7XG4gICAgICByZXN1bHRba2V5XSA9IG9ialtrZXldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufTtcbnZhciBvYmplY3RzQXJlRXF1YWwgPSAob2JqMSwgb2JqMiwgZXhjbHVkZUtleXMpID0+IHtcbiAgaWYgKG9iajEgPT09IG9iajIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBmb3IgKGNvbnN0IGtleSBpbiBvYmoxKSB7XG4gICAgaWYgKGV4Y2x1ZGVLZXlzLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAob2JqMVtrZXldID09PSBvYmoyW2tleV0pIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoIWNvbXBhcmVWYWx1ZXMob2JqMVtrZXldLCBvYmoyW2tleV0pKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIGZvciAoY29uc3Qga2V5IGluIG9iajIpIHtcbiAgICBpZiAoZXhjbHVkZUtleXMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghKGtleSBpbiBvYmoxKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn07XG52YXIgY29tcGFyZVZhbHVlcyA9ICh2YWx1ZTEsIHZhbHVlMikgPT4ge1xuICBzd2l0Y2ggKHR5cGVvZiB2YWx1ZTEpIHtcbiAgICBjYXNlIFwib2JqZWN0XCI6XG4gICAgICByZXR1cm4gb2JqZWN0c0FyZUVxdWFsKHZhbHVlMSwgdmFsdWUyLCBbXSk7XG4gICAgY2FzZSBcImZ1bmN0aW9uXCI6XG4gICAgICByZXR1cm4gdmFsdWUxLnRvU3RyaW5nKCkgPT09IHZhbHVlMi50b1N0cmluZygpO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gdmFsdWUxID09PSB2YWx1ZTI7XG4gIH1cbn07XG52YXIgc2V0UGF0aFByZXNlcnZpbmdJZGVudGl0eSA9ICh0YXJnZXQsIHBhdGgsIHZhbHVlKSA9PiB7XG4gIGNvbnN0IGtleXMgPSB0b1BhdGgocGF0aCk7XG4gIGlmIChrZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgY29uc3QgY29weUFsb25nUGF0aCA9IChub2RlLCBkZXB0aCkgPT4ge1xuICAgIGlmIChkZXB0aCA9PT0ga2V5cy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgY29uc3Qga2V5ID0ga2V5c1tkZXB0aF07XG4gICAgY29uc3QgY29weSA9IEFycmF5LmlzQXJyYXkobm9kZSkgPyBbLi4ubm9kZV0gOiBub2RlICYmIHR5cGVvZiBub2RlID09PSBcIm9iamVjdFwiID8geyAuLi5ub2RlIH0gOiAvXig/OjB8WzEtOV1cXGQqKSQvLnRlc3Qoa2V5KSA/IFtdIDoge307XG4gICAgY29weVtrZXldID0gY29weUFsb25nUGF0aChub2RlPy5ba2V5XSwgZGVwdGggKyAxKTtcbiAgICByZXR1cm4gY29weTtcbiAgfTtcbiAgcmV0dXJuIGNvcHlBbG9uZ1BhdGgodGFyZ2V0LCAwKTtcbn07XG5cbi8vIHNyYy90aW1lLnRzXG52YXIgY29udmVyc2lvbk1hcCA9IHtcbiAgbXM6IDEsXG4gIHM6IDFlMyxcbiAgbTogMWUzICogNjAsXG4gIGg6IDFlMyAqIDYwICogNjAsXG4gIGQ6IDFlMyAqIDYwICogNjAgKiAyNFxufTtcbnZhciB0aW1lVG9NcyA9ICh0aW1lKSA9PiB7XG4gIGlmICh0eXBlb2YgdGltZSA9PT0gXCJudW1iZXJcIikge1xuICAgIHJldHVybiB0aW1lO1xuICB9XG4gIGZvciAoY29uc3QgW3VuaXQsIGNvbnZlcnNpb25dIG9mIE9iamVjdC5lbnRyaWVzKGNvbnZlcnNpb25NYXApKSB7XG4gICAgaWYgKHRpbWUuZW5kc1dpdGgodW5pdCkpIHtcbiAgICAgIHJldHVybiBwYXJzZUZsb2F0KHRpbWUpICogY29udmVyc2lvbjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHBhcnNlSW50KHRpbWUpO1xufTtcblxuLy8gc3JjL3ByZWZldGNoZWQudHNcbnZhciBQcmVmZXRjaGVkUmVxdWVzdHMgPSBjbGFzcyB7XG4gIGNhY2hlZCA9IFtdO1xuICBpbkZsaWdodFJlcXVlc3RzID0gW107XG4gIHJlbW92YWxUaW1lcnMgPSBbXTtcbiAgY3VycmVudFVzZUlkID0gbnVsbDtcbiAgYWRkKHBhcmFtcywgc2VuZEZ1bmMsIHsgY2FjaGVGb3IsIGNhY2hlVGFncyB9KSB7XG4gICAgY29uc3QgaW5GbGlnaHQgPSB0aGlzLmZpbmRJbkZsaWdodChwYXJhbXMpO1xuICAgIGlmIChpbkZsaWdodCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBjb25zdCBleGlzdGluZyA9IHRoaXMuZmluZENhY2hlZChwYXJhbXMpO1xuICAgIGlmICghcGFyYW1zLmZyZXNoICYmIGV4aXN0aW5nICYmIGV4aXN0aW5nLnN0YWxlVGltZXN0YW1wID4gRGF0ZS5ub3coKSkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBjb25zdCBbc3RhbGUsIHByZWZldGNoRXhwaXJlc0luXSA9IHRoaXMuZXh0cmFjdFN0YWxlVmFsdWVzKGNhY2hlRm9yKTtcbiAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgc2VuZEZ1bmMoe1xuICAgICAgICAuLi5wYXJhbXMsXG4gICAgICAgIG9uQ2FuY2VsOiAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZW1vdmUocGFyYW1zKTtcbiAgICAgICAgICBwYXJhbXMub25DYW5jZWwoKTtcbiAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgfSxcbiAgICAgICAgb25FcnJvcjogKGVycm9yKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZW1vdmUocGFyYW1zKTtcbiAgICAgICAgICBwYXJhbXMub25FcnJvcihlcnJvcik7XG4gICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uUHJlZmV0Y2hpbmcodmlzaXRQYXJhbXMpIHtcbiAgICAgICAgICBwYXJhbXMub25QcmVmZXRjaGluZyh2aXNpdFBhcmFtcyk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uUHJlZmV0Y2hlZChyZXNwb25zZSwgdmlzaXQpIHtcbiAgICAgICAgICBwYXJhbXMub25QcmVmZXRjaGVkKHJlc3BvbnNlLCB2aXNpdCk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uUHJlZmV0Y2hSZXNwb25zZShyZXNwb25zZSkge1xuICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICB9LFxuICAgICAgICBvblByZWZldGNoRXJyb3IoZXJyb3IpIHtcbiAgICAgICAgICBwcmVmZXRjaGVkUmVxdWVzdHMucmVtb3ZlRnJvbUluRmxpZ2h0KHBhcmFtcyk7XG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSkudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgIHRoaXMucmVtb3ZlKHBhcmFtcyk7XG4gICAgICBjb25zdCBwYWdlUmVzcG9uc2UgPSByZXNwb25zZS5nZXRQYWdlUmVzcG9uc2UoKTtcbiAgICAgIHBhZ2UubWVyZ2VPbmNlUHJvcHNJbnRvUmVzcG9uc2UocGFnZVJlc3BvbnNlKTtcbiAgICAgIHRoaXMuY2FjaGVkLnB1c2goe1xuICAgICAgICBwYXJhbXM6IHsgLi4ucGFyYW1zIH0sXG4gICAgICAgIHN0YWxlVGltZXN0YW1wOiBEYXRlLm5vdygpICsgc3RhbGUsXG4gICAgICAgIGV4cGlyZXNBdDogRGF0ZS5ub3coKSArIHByZWZldGNoRXhwaXJlc0luLFxuICAgICAgICByZXNwb25zZTogcHJvbWlzZSxcbiAgICAgICAgc2luZ2xlVXNlOiBwcmVmZXRjaEV4cGlyZXNJbiA9PT0gMCxcbiAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICBpbkZsaWdodDogZmFsc2UsXG4gICAgICAgIHRhZ3M6IEFycmF5LmlzQXJyYXkoY2FjaGVUYWdzKSA/IGNhY2hlVGFncyA6IFtjYWNoZVRhZ3NdXG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG9uY2VQcm9wRXhwaXJlc0luID0gdGhpcy5nZXRTaG9ydGVzdE9uY2VQcm9wVHRsKHBhZ2VSZXNwb25zZSk7XG4gICAgICB0aGlzLnNjaGVkdWxlRm9yUmVtb3ZhbChcbiAgICAgICAgcGFyYW1zLFxuICAgICAgICBvbmNlUHJvcEV4cGlyZXNJbiA/IE1hdGgubWluKHByZWZldGNoRXhwaXJlc0luLCBvbmNlUHJvcEV4cGlyZXNJbikgOiBwcmVmZXRjaEV4cGlyZXNJblxuICAgICAgKTtcbiAgICAgIHRoaXMucmVtb3ZlRnJvbUluRmxpZ2h0KHBhcmFtcyk7XG4gICAgICByZXNwb25zZS5oYW5kbGVQcmVmZXRjaCgpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0pO1xuICAgIHRoaXMuaW5GbGlnaHRSZXF1ZXN0cy5wdXNoKHtcbiAgICAgIHBhcmFtczogeyAuLi5wYXJhbXMgfSxcbiAgICAgIHJlc3BvbnNlOiBwcm9taXNlLFxuICAgICAgc3RhbGVUaW1lc3RhbXA6IG51bGwsXG4gICAgICBpbkZsaWdodDogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG4gIHJlbW92ZUFsbCgpIHtcbiAgICB0aGlzLmNhY2hlZCA9IFtdO1xuICAgIHRoaXMucmVtb3ZhbFRpbWVycy5mb3JFYWNoKChyZW1vdmFsVGltZXIpID0+IHtcbiAgICAgIGNsZWFyVGltZW91dChyZW1vdmFsVGltZXIudGltZXIpO1xuICAgIH0pO1xuICAgIHRoaXMucmVtb3ZhbFRpbWVycyA9IFtdO1xuICB9XG4gIHJlbW92ZUJ5VGFncyh0YWdzKSB7XG4gICAgdGhpcy5jYWNoZWQgPSB0aGlzLmNhY2hlZC5maWx0ZXIoKHByZWZldGNoZWQpID0+IHtcbiAgICAgIHJldHVybiAhcHJlZmV0Y2hlZC50YWdzLnNvbWUoKHRhZykgPT4gdGFncy5pbmNsdWRlcyh0YWcpKTtcbiAgICB9KTtcbiAgfVxuICByZW1vdmUocGFyYW1zKSB7XG4gICAgdGhpcy5jYWNoZWQgPSB0aGlzLmNhY2hlZC5maWx0ZXIoKHByZWZldGNoZWQpID0+IHtcbiAgICAgIHJldHVybiAhdGhpcy5wYXJhbXNBcmVFcXVhbChwcmVmZXRjaGVkLnBhcmFtcywgcGFyYW1zKTtcbiAgICB9KTtcbiAgICB0aGlzLmNsZWFyVGltZXIocGFyYW1zKTtcbiAgfVxuICByZW1vdmVGcm9tSW5GbGlnaHQocGFyYW1zKSB7XG4gICAgdGhpcy5pbkZsaWdodFJlcXVlc3RzID0gdGhpcy5pbkZsaWdodFJlcXVlc3RzLmZpbHRlcigocHJlZmV0Y2hpbmcpID0+IHtcbiAgICAgIHJldHVybiAhdGhpcy5wYXJhbXNBcmVFcXVhbChwcmVmZXRjaGluZy5wYXJhbXMsIHBhcmFtcyk7XG4gICAgfSk7XG4gIH1cbiAgZXh0cmFjdFN0YWxlVmFsdWVzKGNhY2hlRm9yKSB7XG4gICAgY29uc3QgW3N0YWxlLCBleHBpcmVzXSA9IHRoaXMuY2FjaGVGb3JUb1N0YWxlQW5kRXhwaXJlcyhjYWNoZUZvcik7XG4gICAgcmV0dXJuIFt0aW1lVG9NcyhzdGFsZSksIHRpbWVUb01zKGV4cGlyZXMpXTtcbiAgfVxuICBjYWNoZUZvclRvU3RhbGVBbmRFeHBpcmVzKGNhY2hlRm9yKSB7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGNhY2hlRm9yKSkge1xuICAgICAgcmV0dXJuIFtjYWNoZUZvciwgY2FjaGVGb3JdO1xuICAgIH1cbiAgICBzd2l0Y2ggKGNhY2hlRm9yLmxlbmd0aCkge1xuICAgICAgY2FzZSAwOlxuICAgICAgICByZXR1cm4gWzAsIDBdO1xuICAgICAgY2FzZSAxOlxuICAgICAgICByZXR1cm4gW2NhY2hlRm9yWzBdLCBjYWNoZUZvclswXV07XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gW2NhY2hlRm9yWzBdLCBjYWNoZUZvclsxXV07XG4gICAgfVxuICB9XG4gIGNsZWFyVGltZXIocGFyYW1zKSB7XG4gICAgY29uc3QgdGltZXIgPSB0aGlzLnJlbW92YWxUaW1lcnMuZmluZCgocmVtb3ZhbFRpbWVyKSA9PiB7XG4gICAgICByZXR1cm4gdGhpcy5wYXJhbXNBcmVFcXVhbChyZW1vdmFsVGltZXIucGFyYW1zLCBwYXJhbXMpO1xuICAgIH0pO1xuICAgIGlmICh0aW1lcikge1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyLnRpbWVyKTtcbiAgICAgIHRoaXMucmVtb3ZhbFRpbWVycyA9IHRoaXMucmVtb3ZhbFRpbWVycy5maWx0ZXIoKHJlbW92YWxUaW1lcikgPT4gcmVtb3ZhbFRpbWVyICE9PSB0aW1lcik7XG4gICAgfVxuICB9XG4gIHNjaGVkdWxlRm9yUmVtb3ZhbChwYXJhbXMsIGV4cGlyZXNJbikge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuY2xlYXJUaW1lcihwYXJhbXMpO1xuICAgIGlmIChleHBpcmVzSW4gPiAwKSB7XG4gICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHRoaXMucmVtb3ZlKHBhcmFtcyksIGV4cGlyZXNJbik7XG4gICAgICB0aGlzLnJlbW92YWxUaW1lcnMucHVzaCh7XG4gICAgICAgIHBhcmFtcyxcbiAgICAgICAgdGltZXJcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBnZXQocGFyYW1zKSB7XG4gICAgcmV0dXJuIHRoaXMuZmluZENhY2hlZChwYXJhbXMpIHx8IHRoaXMuZmluZEluRmxpZ2h0KHBhcmFtcyk7XG4gIH1cbiAgdXNlKHByZWZldGNoZWQsIHBhcmFtcykge1xuICAgIGNvbnN0IGlkID0gYCR7cGFyYW1zLnVybC5wYXRobmFtZX0tJHtEYXRlLm5vdygpfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZyg3KX1gO1xuICAgIHRoaXMuY3VycmVudFVzZUlkID0gaWQ7XG4gICAgY29uc3QgY29uc3VtZWRQYXJhbXMgPSB7XG4gICAgICAuLi5wYXJhbXMsXG4gICAgICBjYWNoZWQ6IHRydWVcbiAgICB9O1xuICAgIHJldHVybiBwcmVmZXRjaGVkLnJlc3BvbnNlLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICBpZiAodGhpcy5jdXJyZW50VXNlSWQgIT09IGlkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJlc3BvbnNlLm1lcmdlUGFyYW1zKHsgLi4uY29uc3VtZWRQYXJhbXMsIG9uUHJlZmV0Y2hlZDogKCkgPT4ge1xuICAgICAgfSB9KTtcbiAgICAgIHRoaXMucmVtb3ZlU2luZ2xlVXNlSXRlbXMocGFyYW1zKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5oYW5kbGUoKTtcbiAgICB9KTtcbiAgfVxuICByZW1vdmVTaW5nbGVVc2VJdGVtcyhwYXJhbXMpIHtcbiAgICB0aGlzLmNhY2hlZCA9IHRoaXMuY2FjaGVkLmZpbHRlcigocHJlZmV0Y2hlZCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLnBhcmFtc0FyZUVxdWFsKHByZWZldGNoZWQucGFyYW1zLCBwYXJhbXMpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuICFwcmVmZXRjaGVkLnNpbmdsZVVzZTtcbiAgICB9KTtcbiAgfVxuICBmaW5kQ2FjaGVkKHBhcmFtcykge1xuICAgIHJldHVybiB0aGlzLmNhY2hlZC5maW5kKChwcmVmZXRjaGVkKSA9PiB7XG4gICAgICByZXR1cm4gdGhpcy5wYXJhbXNBcmVFcXVhbChwcmVmZXRjaGVkLnBhcmFtcywgcGFyYW1zKTtcbiAgICB9KSB8fCBudWxsO1xuICB9XG4gIGZpbmRJbkZsaWdodChwYXJhbXMpIHtcbiAgICByZXR1cm4gdGhpcy5pbkZsaWdodFJlcXVlc3RzLmZpbmQoKHByZWZldGNoZWQpID0+IHtcbiAgICAgIHJldHVybiB0aGlzLnBhcmFtc0FyZUVxdWFsKHByZWZldGNoZWQucGFyYW1zLCBwYXJhbXMpO1xuICAgIH0pIHx8IG51bGw7XG4gIH1cbiAgd2l0aG91dFB1cnBvc2VQcmVmZXRjaEhlYWRlcihwYXJhbXMpIHtcbiAgICBjb25zdCBuZXdQYXJhbXMgPSBjbG9uZURlZXAocGFyYW1zKTtcbiAgICBpZiAobmV3UGFyYW1zLmhlYWRlcnNbXCJQdXJwb3NlXCJdID09PSBcInByZWZldGNoXCIpIHtcbiAgICAgIGRlbGV0ZSBuZXdQYXJhbXMuaGVhZGVyc1tcIlB1cnBvc2VcIl07XG4gICAgfVxuICAgIHJldHVybiBuZXdQYXJhbXM7XG4gIH1cbiAgcGFyYW1zQXJlRXF1YWwocGFyYW1zMSwgcGFyYW1zMikge1xuICAgIHJldHVybiBvYmplY3RzQXJlRXF1YWwoXG4gICAgICB0aGlzLndpdGhvdXRQdXJwb3NlUHJlZmV0Y2hIZWFkZXIocGFyYW1zMSksXG4gICAgICB0aGlzLndpdGhvdXRQdXJwb3NlUHJlZmV0Y2hIZWFkZXIocGFyYW1zMiksXG4gICAgICBbXG4gICAgICAgIFwiaWRcIixcbiAgICAgICAgXCJzaG93UHJvZ3Jlc3NcIixcbiAgICAgICAgXCJyZXBsYWNlXCIsXG4gICAgICAgIFwicHJlZmV0Y2hcIixcbiAgICAgICAgXCJwcmVzZXJ2ZVNjcm9sbFwiLFxuICAgICAgICBcInByZXNlcnZlU3RhdGVcIixcbiAgICAgICAgXCJvbkJlZm9yZVwiLFxuICAgICAgICBcIm9uQmVmb3JlVXBkYXRlXCIsXG4gICAgICAgIFwib25TdGFydFwiLFxuICAgICAgICBcIm9uUHJvZ3Jlc3NcIixcbiAgICAgICAgXCJvbkZpbmlzaFwiLFxuICAgICAgICBcIm9uQ2FuY2VsXCIsXG4gICAgICAgIFwib25TdWNjZXNzXCIsXG4gICAgICAgIFwib25FcnJvclwiLFxuICAgICAgICBcIm9uRmxhc2hcIixcbiAgICAgICAgXCJvblByZWZldGNoZWRcIixcbiAgICAgICAgXCJvbkNhbmNlbFRva2VuXCIsXG4gICAgICAgIFwib25QcmVmZXRjaGluZ1wiLFxuICAgICAgICBcImFzeW5jXCIsXG4gICAgICAgIFwidmlld1RyYW5zaXRpb25cIixcbiAgICAgICAgXCJvcHRpbWlzdGljXCIsXG4gICAgICAgIFwiY29tcG9uZW50XCIsXG4gICAgICAgIFwicGFnZVByb3BzXCIsXG4gICAgICAgIFwiY2FjaGVkXCJcbiAgICAgIF1cbiAgICApO1xuICB9XG4gIHVwZGF0ZUNhY2hlZE9uY2VQcm9wc0Zyb21DdXJyZW50UGFnZSgpIHtcbiAgICB0aGlzLmNhY2hlZC5mb3JFYWNoKChwcmVmZXRjaGVkKSA9PiB7XG4gICAgICBwcmVmZXRjaGVkLnJlc3BvbnNlLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGNvbnN0IHBhZ2VSZXNwb25zZSA9IHJlc3BvbnNlLmdldFBhZ2VSZXNwb25zZSgpO1xuICAgICAgICBwYWdlLm1lcmdlT25jZVByb3BzSW50b1Jlc3BvbnNlKHBhZ2VSZXNwb25zZSwgeyBmb3JjZTogdHJ1ZSB9KTtcbiAgICAgICAgZm9yIChjb25zdCBbZ3JvdXAsIGRlZmVycmVkUHJvcHNdIG9mIE9iamVjdC5lbnRyaWVzKHBhZ2VSZXNwb25zZS5kZWZlcnJlZFByb3BzID8/IHt9KSkge1xuICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IGRlZmVycmVkUHJvcHMuZmlsdGVyKChwcm9wKSA9PiBnZXQyKHBhZ2VSZXNwb25zZS5wcm9wcywgcHJvcCkgPT09IHZvaWQgMCk7XG4gICAgICAgICAgaWYgKHJlbWFpbmluZy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBwYWdlUmVzcG9uc2UuZGVmZXJyZWRQcm9wc1tncm91cF0gPSByZW1haW5pbmc7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRlbGV0ZSBwYWdlUmVzcG9uc2UuZGVmZXJyZWRQcm9wc1tncm91cF07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG9uY2VQcm9wRXhwaXJlc0luID0gdGhpcy5nZXRTaG9ydGVzdE9uY2VQcm9wVHRsKHBhZ2VSZXNwb25zZSk7XG4gICAgICAgIGlmIChvbmNlUHJvcEV4cGlyZXNJbiA9PT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmVmZXRjaEV4cGlyZXNJbiA9IHByZWZldGNoZWQuZXhwaXJlc0F0IC0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3QgZXhwaXJlc0luID0gTWF0aC5taW4ocHJlZmV0Y2hFeHBpcmVzSW4sIG9uY2VQcm9wRXhwaXJlc0luKTtcbiAgICAgICAgaWYgKGV4cGlyZXNJbiA+IDApIHtcbiAgICAgICAgICB0aGlzLnNjaGVkdWxlRm9yUmVtb3ZhbChwcmVmZXRjaGVkLnBhcmFtcywgZXhwaXJlc0luKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnJlbW92ZShwcmVmZXRjaGVkLnBhcmFtcyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGdldFNob3J0ZXN0T25jZVByb3BUdGwocGFnZTIpIHtcbiAgICBjb25zdCBleHBpcnlUaW1lc3RhbXBzID0gT2JqZWN0LnZhbHVlcyhwYWdlMi5vbmNlUHJvcHMgPz8ge30pLm1hcCgob25jZVByb3ApID0+IG9uY2VQcm9wLmV4cGlyZXNBdCkuZmlsdGVyKChleHBpcmVzQXQpID0+ICEhZXhwaXJlc0F0KTtcbiAgICBpZiAoZXhwaXJ5VGltZXN0YW1wcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gTWF0aC5taW4oLi4uZXhwaXJ5VGltZXN0YW1wcykgLSBEYXRlLm5vdygpO1xuICB9XG59O1xudmFyIHByZWZldGNoZWRSZXF1ZXN0cyA9IG5ldyBQcmVmZXRjaGVkUmVxdWVzdHMoKTtcblxuLy8gc3JjL2RvbVV0aWxzLnRzXG52YXIgZWxlbWVudEluVmlld3BvcnQgPSAoZWwpID0+IHtcbiAgaWYgKGVsLm9mZnNldFBhcmVudCA9PT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGNvbnN0IHZlcnRpY2FsbHlWaXNpYmxlID0gcmVjdC50b3AgPCB3aW5kb3cuaW5uZXJIZWlnaHQgJiYgcmVjdC5ib3R0b20gPj0gMDtcbiAgY29uc3QgaG9yaXpvbnRhbGx5VmlzaWJsZSA9IHJlY3QubGVmdCA8IHdpbmRvdy5pbm5lcldpZHRoICYmIHJlY3QucmlnaHQgPj0gMDtcbiAgcmV0dXJuIHZlcnRpY2FsbHlWaXNpYmxlICYmIGhvcml6b250YWxseVZpc2libGU7XG59O1xudmFyIGdldFNjcm9sbGFibGVQYXJlbnQgPSAoZWxlbWVudCkgPT4ge1xuICBjb25zdCBhbGxvd3NWZXJ0aWNhbFNjcm9sbCA9IChlbCkgPT4ge1xuICAgIGNvbnN0IGNvbXB1dGVkU3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gICAgaWYgKGNvbXB1dGVkU3R5bGUub3ZlcmZsb3dZID09PSBcInNjcm9sbFwiKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGNvbXB1dGVkU3R5bGUub3ZlcmZsb3dZICE9PSBcImF1dG9cIikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoW1widmlzaWJsZVwiLCBcImNsaXBcIl0uaW5jbHVkZXMoY29tcHV0ZWRTdHlsZS5vdmVyZmxvd1gpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGhhc0RpbWVuc2lvbkNvbnN0cmFpbnQoY29tcHV0ZWRTdHlsZS5tYXhIZWlnaHQsIGVsLnN0eWxlLmhlaWdodCkgfHwgaXNDb25zdHJhaW5lZEJ5TGF5b3V0KGVsLCBcImhlaWdodFwiKTtcbiAgfTtcbiAgY29uc3QgYWxsb3dzSG9yaXpvbnRhbFNjcm9sbCA9IChlbCkgPT4ge1xuICAgIGNvbnN0IGNvbXB1dGVkU3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gICAgaWYgKGNvbXB1dGVkU3R5bGUub3ZlcmZsb3dYID09PSBcInNjcm9sbFwiKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGNvbXB1dGVkU3R5bGUub3ZlcmZsb3dYICE9PSBcImF1dG9cIikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoW1widmlzaWJsZVwiLCBcImNsaXBcIl0uaW5jbHVkZXMoY29tcHV0ZWRTdHlsZS5vdmVyZmxvd1kpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGhhc0RpbWVuc2lvbkNvbnN0cmFpbnQoY29tcHV0ZWRTdHlsZS5tYXhXaWR0aCwgZWwuc3R5bGUud2lkdGgpIHx8IGlzQ29uc3RyYWluZWRCeUxheW91dChlbCwgXCJ3aWR0aFwiKTtcbiAgfTtcbiAgY29uc3QgaGFzRGltZW5zaW9uQ29uc3RyYWludCA9IChjb21wdXRlZE1heERpbWVuc2lvbiwgaW5saW5lU3R5bGVEaW1lbnNpb24pID0+IHtcbiAgICBpZiAoY29tcHV0ZWRNYXhEaW1lbnNpb24gJiYgY29tcHV0ZWRNYXhEaW1lbnNpb24gIT09IFwibm9uZVwiICYmIGNvbXB1dGVkTWF4RGltZW5zaW9uICE9PSBcIjBweFwiKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGlubGluZVN0eWxlRGltZW5zaW9uICYmIGlubGluZVN0eWxlRGltZW5zaW9uICE9PSBcImF1dG9cIiAmJiBpbmxpbmVTdHlsZURpbWVuc2lvbiAhPT0gXCIwXCIpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH07XG4gIGNvbnN0IGlzQ29uc3RyYWluZWRCeUxheW91dCA9IChlbCwgZGltZW5zaW9uKSA9PiB7XG4gICAgY29uc3QgcGFyZW50MiA9IGVsLnBhcmVudEVsZW1lbnQ7XG4gICAgaWYgKCFwYXJlbnQyKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHBhcmVudFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUocGFyZW50Mik7XG4gICAgaWYgKFtcImZsZXhcIiwgXCJpbmxpbmUtZmxleFwiXS5pbmNsdWRlcyhwYXJlbnRTdHlsZS5kaXNwbGF5KSkge1xuICAgICAgY29uc3QgaXNDb2x1bW5MYXlvdXQgPSBbXCJjb2x1bW5cIiwgXCJjb2x1bW4tcmV2ZXJzZVwiXS5pbmNsdWRlcyhwYXJlbnRTdHlsZS5mbGV4RGlyZWN0aW9uKTtcbiAgICAgIHJldHVybiBkaW1lbnNpb24gPT09IFwiaGVpZ2h0XCIgPyBpc0NvbHVtbkxheW91dCA6ICFpc0NvbHVtbkxheW91dDtcbiAgICB9XG4gICAgcmV0dXJuIFtcImdyaWRcIiwgXCJpbmxpbmUtZ3JpZFwiXS5pbmNsdWRlcyhwYXJlbnRTdHlsZS5kaXNwbGF5KTtcbiAgfTtcbiAgbGV0IHBhcmVudCA9IGVsZW1lbnQ/LnBhcmVudEVsZW1lbnQ7XG4gIHdoaWxlIChwYXJlbnQpIHtcbiAgICBjb25zdCBhbGxvd3NTY3JvbGwgPSBhbGxvd3NWZXJ0aWNhbFNjcm9sbChwYXJlbnQpIHx8IGFsbG93c0hvcml6b250YWxTY3JvbGwocGFyZW50KTtcbiAgICBpZiAod2luZG93LmdldENvbXB1dGVkU3R5bGUocGFyZW50KS5kaXNwbGF5ICE9PSBcImNvbnRlbnRzXCIgJiYgYWxsb3dzU2Nyb2xsKSB7XG4gICAgICByZXR1cm4gcGFyZW50O1xuICAgIH1cbiAgICBwYXJlbnQgPSBwYXJlbnQucGFyZW50RWxlbWVudDtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn07XG52YXIgZ2V0RWxlbWVudHNJblZpZXdwb3J0RnJvbUNvbGxlY3Rpb24gPSAoZWxlbWVudHMsIHJlZmVyZW5jZUVsZW1lbnQpID0+IHtcbiAgaWYgKCFyZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgcmV0dXJuIGVsZW1lbnRzLmZpbHRlcigoZWxlbWVudCkgPT4gZWxlbWVudEluVmlld3BvcnQoZWxlbWVudCkpO1xuICB9XG4gIGNvbnN0IHJlZmVyZW5jZUluZGV4ID0gZWxlbWVudHMuaW5kZXhPZihyZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3QgdXB3YXJkRWxlbWVudHMgPSBbXTtcbiAgY29uc3QgZG93bndhcmRFbGVtZW50cyA9IFtdO1xuICBmb3IgKGxldCBpID0gcmVmZXJlbmNlSW5kZXg7IGkgPj0gMDsgaS0tKSB7XG4gICAgY29uc3QgZWxlbWVudCA9IGVsZW1lbnRzW2ldO1xuICAgIGlmIChlbGVtZW50SW5WaWV3cG9ydChlbGVtZW50KSkge1xuICAgICAgdXB3YXJkRWxlbWVudHMucHVzaChlbGVtZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIGZvciAobGV0IGkgPSByZWZlcmVuY2VJbmRleCArIDE7IGkgPCBlbGVtZW50cy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGVsZW1lbnQgPSBlbGVtZW50c1tpXTtcbiAgICBpZiAoZWxlbWVudEluVmlld3BvcnQoZWxlbWVudCkpIHtcbiAgICAgIGRvd253YXJkRWxlbWVudHMucHVzaChlbGVtZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiBbLi4udXB3YXJkRWxlbWVudHMucmV2ZXJzZSgpLCAuLi5kb3dud2FyZEVsZW1lbnRzXTtcbn07XG52YXIgcmVxdWVzdEFuaW1hdGlvbkZyYW1lID0gKGNiLCB0aW1lcyA9IDEpID0+IHtcbiAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgaWYgKHRpbWVzID4gMSkge1xuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGNiLCB0aW1lcyAtIDEpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYigpO1xuICAgIH1cbiAgfSk7XG59O1xudmFyIGdldEluaXRpYWxQYWdlRnJvbURPTSA9IChpZCkgPT4ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHNjcmlwdEVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihgc2NyaXB0W2RhdGEtcGFnZT1cIiR7aWR9XCJdW3R5cGU9XCJhcHBsaWNhdGlvbi9qc29uXCJdYCk7XG4gIGlmIChzY3JpcHRFbD8udGV4dENvbnRlbnQpIHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZShzY3JpcHRFbC50ZXh0Q29udGVudCk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59O1xuXG4vLyBzcmMvc2Nyb2xsLnRzXG52YXIgaXNTZXJ2ZXIgPSB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiO1xudmFyIGlzRmlyZWZveCA9ICFpc1NlcnZlciAmJiAvRmlyZWZveC9pLnRlc3Qod2luZG93Lm5hdmlnYXRvci51c2VyQWdlbnQpO1xudmFyIFNjcm9sbCA9IGNsYXNzIHtcbiAgc3RhdGljIHNhdmUoKSB7XG4gICAgaGlzdG9yeS5zYXZlU2Nyb2xsUG9zaXRpb25zKHRoaXMuZ2V0U2Nyb2xsUmVnaW9ucygpKTtcbiAgfVxuICBzdGF0aWMgZ2V0U2Nyb2xsUmVnaW9ucygpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh0aGlzLnJlZ2lvbnMoKSkubWFwKChyZWdpb24pID0+ICh7XG4gICAgICB0b3A6IHJlZ2lvbi5zY3JvbGxUb3AsXG4gICAgICBsZWZ0OiByZWdpb24uc2Nyb2xsTGVmdFxuICAgIH0pKTtcbiAgfVxuICBzdGF0aWMgcmVnaW9ucygpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIltzY3JvbGwtcmVnaW9uXVwiKTtcbiAgfVxuICBzdGF0aWMgc2Nyb2xsVG9Ub3AoKSB7XG4gICAgaWYgKGlzRmlyZWZveCAmJiBnZXRDb21wdXRlZFN0eWxlKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuc2Nyb2xsQmVoYXZpb3IgPT09IFwic21vb3RoXCIpIHtcbiAgICAgIHJldHVybiByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gd2luZG93LnNjcm9sbFRvKDAsIDApLCAyKTtcbiAgICB9XG4gICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xuICB9XG4gIHN0YXRpYyByZXNldCgpIHtcbiAgICBjb25zdCBhbmNob3JIYXNoID0gaXNTZXJ2ZXIgPyBudWxsIDogd2luZG93LmxvY2F0aW9uLmhhc2g7XG4gICAgaWYgKCFhbmNob3JIYXNoKSB7XG4gICAgICB0aGlzLnNjcm9sbFRvVG9wKCk7XG4gICAgfVxuICAgIHRoaXMucmVnaW9ucygpLmZvckVhY2goKHJlZ2lvbikgPT4ge1xuICAgICAgaWYgKHR5cGVvZiByZWdpb24uc2Nyb2xsVG8gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZWdpb24uc2Nyb2xsVG8oMCwgMCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZWdpb24uc2Nyb2xsVG9wID0gMDtcbiAgICAgICAgcmVnaW9uLnNjcm9sbExlZnQgPSAwO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMuc2F2ZSgpO1xuICAgIHRoaXMuc2Nyb2xsVG9BbmNob3IoKTtcbiAgfVxuICBzdGF0aWMgc2Nyb2xsVG9BbmNob3IoKSB7XG4gICAgY29uc3QgYW5jaG9ySGFzaCA9IGlzU2VydmVyID8gbnVsbCA6IHdpbmRvdy5sb2NhdGlvbi5oYXNoO1xuICAgIGlmIChhbmNob3JIYXNoKSB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgY29uc3QgYW5jaG9yRWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGFuY2hvckhhc2guc2xpY2UoMSkpO1xuICAgICAgICBhbmNob3JFbGVtZW50ID8gYW5jaG9yRWxlbWVudC5zY3JvbGxJbnRvVmlldygpIDogdGhpcy5zY3JvbGxUb1RvcCgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHN0YXRpYyByZXN0b3JlKHNjcm9sbFJlZ2lvbnMpIHtcbiAgICBpZiAoaXNTZXJ2ZXIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICB0aGlzLnJlc3RvcmVEb2N1bWVudCgpO1xuICAgICAgdGhpcy5yZXN0b3JlU2Nyb2xsUmVnaW9ucyhzY3JvbGxSZWdpb25zKTtcbiAgICB9KTtcbiAgfVxuICBzdGF0aWMgcmVzdG9yZVNjcm9sbFJlZ2lvbnMoc2Nyb2xsUmVnaW9ucykge1xuICAgIGlmIChpc1NlcnZlcikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnJlZ2lvbnMoKS5mb3JFYWNoKChyZWdpb24sIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBzY3JvbGxQb3NpdGlvbiA9IHNjcm9sbFJlZ2lvbnNbaW5kZXhdO1xuICAgICAgaWYgKCFzY3JvbGxQb3NpdGlvbikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHJlZ2lvbi5zY3JvbGxUbyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJlZ2lvbi5zY3JvbGxUbyhzY3JvbGxQb3NpdGlvbi5sZWZ0LCBzY3JvbGxQb3NpdGlvbi50b3ApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVnaW9uLnNjcm9sbFRvcCA9IHNjcm9sbFBvc2l0aW9uLnRvcDtcbiAgICAgICAgcmVnaW9uLnNjcm9sbExlZnQgPSBzY3JvbGxQb3NpdGlvbi5sZWZ0O1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHN0YXRpYyByZXN0b3JlRG9jdW1lbnQoKSB7XG4gICAgY29uc3Qgc2Nyb2xsUG9zaXRpb24gPSBoaXN0b3J5LmdldERvY3VtZW50U2Nyb2xsUG9zaXRpb24oKTtcbiAgICB3aW5kb3cuc2Nyb2xsVG8oc2Nyb2xsUG9zaXRpb24ubGVmdCwgc2Nyb2xsUG9zaXRpb24udG9wKTtcbiAgfVxuICBzdGF0aWMgb25TY3JvbGwoZXZlbnQpIHtcbiAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgaWYgKHR5cGVvZiB0YXJnZXQuaGFzQXR0cmlidXRlID09PSBcImZ1bmN0aW9uXCIgJiYgdGFyZ2V0Lmhhc0F0dHJpYnV0ZShcInNjcm9sbC1yZWdpb25cIikpIHtcbiAgICAgIHRoaXMuc2F2ZSgpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgb25XaW5kb3dTY3JvbGwoKSB7XG4gICAgaGlzdG9yeS5zYXZlRG9jdW1lbnRTY3JvbGxQb3NpdGlvbih7XG4gICAgICB0b3A6IHdpbmRvdy5zY3JvbGxZLFxuICAgICAgbGVmdDogd2luZG93LnNjcm9sbFhcbiAgICB9KTtcbiAgfVxufTtcblxuLy8gc3JjL2ZpbGVzLnRzXG52YXIgaXNGaWxlID0gKHZhbHVlKSA9PiB0eXBlb2YgRmlsZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGUgfHwgdmFsdWUgaW5zdGFuY2VvZiBCbG9iIHx8IHR5cGVvZiBGaWxlTGlzdCAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGVMaXN0ICYmIHZhbHVlLmxlbmd0aCA+IDA7XG5mdW5jdGlvbiBoYXNGaWxlcyhkYXRhKSB7XG4gIHJldHVybiBpc0ZpbGUoZGF0YSkgfHwgZGF0YSBpbnN0YW5jZW9mIEZvcm1EYXRhICYmIEFycmF5LmZyb20oZGF0YS52YWx1ZXMoKSkuc29tZSgodmFsdWUpID0+IGhhc0ZpbGVzKHZhbHVlKSkgfHwgdHlwZW9mIGRhdGEgPT09IFwib2JqZWN0XCIgJiYgZGF0YSAhPT0gbnVsbCAmJiBPYmplY3QudmFsdWVzKGRhdGEpLnNvbWUoKHZhbHVlKSA9PiBoYXNGaWxlcyh2YWx1ZSkpO1xufVxuXG4vLyBzcmMvZm9ybURhdGEudHNcbnZhciBpc0Zvcm1EYXRhID0gKHZhbHVlKSA9PiB2YWx1ZSBpbnN0YW5jZW9mIEZvcm1EYXRhO1xuZnVuY3Rpb24gb2JqZWN0VG9Gb3JtRGF0YShzb3VyY2UsIGZvcm0gPSBuZXcgRm9ybURhdGEoKSwgcGFyZW50S2V5ID0gbnVsbCwgcXVlcnlTdHJpbmdBcnJheUZvcm1hdCA9IFwiYnJhY2tldHNcIikge1xuICBzb3VyY2UgPSBzb3VyY2UgfHwge307XG4gIGZvciAoY29uc3Qga2V5IGluIHNvdXJjZSkge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc291cmNlLCBrZXkpKSB7XG4gICAgICBhcHBlbmQoZm9ybSwgY29tcG9zZUtleShwYXJlbnRLZXksIGtleSwgXCJpbmRpY2VzXCIpLCBzb3VyY2Vba2V5XSwgcXVlcnlTdHJpbmdBcnJheUZvcm1hdCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBmb3JtO1xufVxuZnVuY3Rpb24gY29tcG9zZUtleShwYXJlbnQsIGtleSwgZm9ybWF0KSB7XG4gIGlmICghcGFyZW50KSB7XG4gICAgcmV0dXJuIGtleTtcbiAgfVxuICByZXR1cm4gZm9ybWF0ID09PSBcImJyYWNrZXRzXCIgPyBgJHtwYXJlbnR9W11gIDogYCR7cGFyZW50fVske2tleX1dYDtcbn1cbmZ1bmN0aW9uIGFwcGVuZChmb3JtLCBrZXksIHZhbHVlLCBmb3JtYXQpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIEFycmF5LmZyb20odmFsdWUua2V5cygpKS5mb3JFYWNoKFxuICAgICAgKGluZGV4KSA9PiBhcHBlbmQoZm9ybSwgY29tcG9zZUtleShrZXksIGluZGV4LnRvU3RyaW5nKCksIGZvcm1hdCksIHZhbHVlW2luZGV4XSwgZm9ybWF0KVxuICAgICk7XG4gIH0gZWxzZSBpZiAodmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgcmV0dXJuIGZvcm0uYXBwZW5kKGtleSwgdmFsdWUudG9JU09TdHJpbmcoKSk7XG4gIH0gZWxzZSBpZiAodmFsdWUgaW5zdGFuY2VvZiBGaWxlKSB7XG4gICAgcmV0dXJuIGZvcm0uYXBwZW5kKGtleSwgdmFsdWUsIHZhbHVlLm5hbWUpO1xuICB9IGVsc2UgaWYgKHZhbHVlIGluc3RhbmNlb2YgQmxvYikge1xuICAgIHJldHVybiBmb3JtLmFwcGVuZChrZXksIHZhbHVlKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgcmV0dXJuIGZvcm0uYXBwZW5kKGtleSwgdmFsdWUgPyBcIjFcIiA6IFwiMFwiKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICByZXR1cm4gZm9ybS5hcHBlbmQoa2V5LCB2YWx1ZSk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKSB7XG4gICAgcmV0dXJuIGZvcm0uYXBwZW5kKGtleSwgYCR7dmFsdWV9YCk7XG4gIH0gZWxzZSBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHZvaWQgMCkge1xuICAgIHJldHVybiBmb3JtLmFwcGVuZChrZXksIFwiXCIpO1xuICB9XG4gIG9iamVjdFRvRm9ybURhdGEodmFsdWUsIGZvcm0sIGtleSwgZm9ybWF0KTtcbn1cblxuLy8gc3JjL3F1ZXJ5U3RyaW5nLnRzXG5mdW5jdGlvbiBoYXNJbmRpY2VzKHVybCkge1xuICByZXR1cm4gL1xcW1xcZCtcXF0vLnRlc3QoZGVjb2RlVVJJQ29tcG9uZW50KHVybC5zZWFyY2gpKTtcbn1cbmZ1bmN0aW9uIHBhcnNlKHF1ZXJ5KSB7XG4gIGlmICghcXVlcnkgfHwgcXVlcnkgPT09IFwiP1wiKSB7XG4gICAgcmV0dXJuIHt9O1xuICB9XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICBxdWVyeS5yZXBsYWNlKC9eXFw/LywgXCJcIikuc3BsaXQoXCImXCIpLmZpbHRlcihCb29sZWFuKS5mb3JFYWNoKChzZWdtZW50KSA9PiB7XG4gICAgY29uc3QgW3Jhd0tleSwgcmF3VmFsdWVdID0gc3BsaXRQYWlyKHNlZ21lbnQpO1xuICAgIHNldDIocmVzdWx0LCBkZWNvZGUocmF3S2V5KSwgZGVjb2RlKHJhd1ZhbHVlKSk7XG4gIH0pO1xuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gc3RyaW5naWZ5KGRhdGEsIGFycmF5Rm9ybWF0KSB7XG4gIGNvbnN0IHBhaXJzID0gW107XG4gIGJ1aWxkKGRhdGEsIFwiXCIsIHBhaXJzLCBhcnJheUZvcm1hdCk7XG4gIHJldHVybiBwYWlycy5sZW5ndGggPyBcIj9cIiArIHBhaXJzLmpvaW4oXCImXCIpIDogXCJcIjtcbn1cbmZ1bmN0aW9uIHNwbGl0UGFpcihwYWlyKSB7XG4gIGNvbnN0IGluZGV4ID0gcGFpci5pbmRleE9mKFwiPVwiKTtcbiAgcmV0dXJuIGluZGV4ID09PSAtMSA/IFtwYWlyLCBcIlwiXSA6IFtwYWlyLnN1YnN0cmluZygwLCBpbmRleCksIHBhaXIuc3Vic3RyaW5nKGluZGV4ICsgMSldO1xufVxuZnVuY3Rpb24gZGVjb2RlKHZhbHVlKSB7XG4gIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQodmFsdWUucmVwbGFjZSgvXFwrL2csIFwiIFwiKSk7XG59XG5mdW5jdGlvbiBzZXQyKHRhcmdldCwga2V5LCB2YWx1ZSkge1xuICBjb25zdCBrZXlzID0gcGFyc2VLZXkoa2V5KTtcbiAgaWYgKGtleXMuc29tZSgoaykgPT4gayA9PT0gXCJfX3Byb3RvX19cIikpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgbGV0IGN1cnJlbnQgPSB0YXJnZXQ7XG4gIHdoaWxlIChrZXlzLmxlbmd0aCA+IDEpIHtcbiAgICBjb25zdCBzZWdtZW50ID0ga2V5cy5zaGlmdCgpO1xuICAgIGNvbnN0IG5leHRJc0FycmF5UHVzaCA9IGtleXNbMF0gPT09IFwiXCI7XG4gICAgaWYgKHR5cGVvZiBjdXJyZW50W3NlZ21lbnRdICE9PSBcIm9iamVjdFwiIHx8IGN1cnJlbnRbc2VnbWVudF0gPT09IG51bGwpIHtcbiAgICAgIGN1cnJlbnRbc2VnbWVudF0gPSBuZXh0SXNBcnJheVB1c2ggPyBbXSA6IHt9O1xuICAgIH1cbiAgICBjdXJyZW50ID0gY3VycmVudFtzZWdtZW50XTtcbiAgfVxuICBjb25zdCBmaW5hbCA9IGtleXMuc2hpZnQoKTtcbiAgaWYgKGZpbmFsID09PSBcIlwiICYmIEFycmF5LmlzQXJyYXkoY3VycmVudCkpIHtcbiAgICBjdXJyZW50LnB1c2godmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIGN1cnJlbnRbZmluYWxdID0gdmFsdWU7XG4gIH1cbn1cbmZ1bmN0aW9uIHBhcnNlS2V5KGtleSkge1xuICBjb25zdCBzZWdtZW50cyA9IFtdO1xuICBjb25zdCBiYXNlID0ga2V5LnNwbGl0KFwiW1wiKVswXTtcbiAgaWYgKGJhc2UpIHtcbiAgICBzZWdtZW50cy5wdXNoKGJhc2UpO1xuICB9XG4gIGxldCBtYXRjaDtcbiAgY29uc3QgcGF0dGVybiA9IC9cXFsoW15cXF1dKilcXF0vZztcbiAgd2hpbGUgKChtYXRjaCA9IHBhdHRlcm4uZXhlYyhrZXkpKSAhPT0gbnVsbCkge1xuICAgIHNlZ21lbnRzLnB1c2gobWF0Y2hbMV0pO1xuICB9XG4gIHJldHVybiBzZWdtZW50cztcbn1cbmZ1bmN0aW9uIGJ1aWxkKHZhbHVlLCBwcmVmaXgsIHBhaXJzLCBhcnJheUZvcm1hdCkge1xuICBpZiAodmFsdWUgPT09IHZvaWQgMCkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodmFsdWUgPT09IG51bGwpIHtcbiAgICBwYWlycy5wdXNoKGAke3ByZWZpeH09YCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgIHZhbHVlLmZvckVhY2goKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSBhcnJheUZvcm1hdCA9PT0gXCJpbmRpY2VzXCIgPyBgJHtwcmVmaXh9WyR7aW5kZXh9XWAgOiBgJHtwcmVmaXh9W11gO1xuICAgICAgYnVpbGQoaXRlbSwga2V5LCBwYWlycywgYXJyYXlGb3JtYXQpO1xuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiKSB7XG4gICAgT2JqZWN0LmtleXModmFsdWUpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgYnVpbGQodmFsdWVba2V5XSwgcHJlZml4ID8gYCR7cHJlZml4fVske2tleX1dYCA6IGtleSwgcGFpcnMsIGFycmF5Rm9ybWF0KTtcbiAgICB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgcGFpcnMucHVzaChgJHtwcmVmaXh9PSR7ZW5jb2RlVVJJQ29tcG9uZW50KFN0cmluZyh2YWx1ZSkpfWApO1xufVxuXG4vLyBzcmMvdXJsLnRzXG5mdW5jdGlvbiBocmVmVG9VcmwoaHJlZikge1xuICByZXR1cm4gbmV3IFVSTChocmVmLnRvU3RyaW5nKCksIHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIgPyB2b2lkIDAgOiB3aW5kb3cubG9jYXRpb24udG9TdHJpbmcoKSk7XG59XG52YXIgdHJhbnNmb3JtVXJsQW5kRGF0YSA9IChocmVmLCBkYXRhLCBtZXRob2QsIGZvcmNlRm9ybURhdGEsIHF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXQpID0+IHtcbiAgbGV0IHVybCA9IHR5cGVvZiBocmVmID09PSBcInN0cmluZ1wiID8gaHJlZlRvVXJsKGhyZWYpIDogaHJlZjtcbiAgaWYgKChoYXNGaWxlcyhkYXRhKSB8fCBmb3JjZUZvcm1EYXRhKSAmJiAhaXNGb3JtRGF0YShkYXRhKSkge1xuICAgIGlmIChjb25maWcuZ2V0KFwiZm9ybS5mb3JjZUluZGljZXNBcnJheUZvcm1hdEluRm9ybURhdGFcIikpIHtcbiAgICAgIHF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXQgPSBcImluZGljZXNcIjtcbiAgICB9XG4gICAgZGF0YSA9IG9iamVjdFRvRm9ybURhdGEoZGF0YSwgbmV3IEZvcm1EYXRhKCksIG51bGwsIHF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXQpO1xuICB9XG4gIGlmIChpc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgcmV0dXJuIFt1cmwsIGRhdGFdO1xuICB9XG4gIGNvbnN0IFtfaHJlZiwgX2RhdGFdID0gbWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nKG1ldGhvZCwgdXJsLCBkYXRhLCBxdWVyeVN0cmluZ0FycmF5Rm9ybWF0KTtcbiAgcmV0dXJuIFtocmVmVG9VcmwoX2hyZWYpLCBfZGF0YV07XG59O1xuZnVuY3Rpb24gbWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nKG1ldGhvZCwgaHJlZiwgZGF0YSwgcXNBcnJheUZvcm1hdCA9IFwiYnJhY2tldHNcIikge1xuICBjb25zdCBoYXNEYXRhRm9yUXVlcnlTdHJpbmcgPSBtZXRob2QgPT09IFwiZ2V0XCIgJiYgIWlzRm9ybURhdGEoZGF0YSkgJiYgT2JqZWN0LmtleXMoZGF0YSkubGVuZ3RoID4gMDtcbiAgY29uc3QgaGFzSG9zdCA9IHVybEhhc1Byb3RvY29sKGhyZWYudG9TdHJpbmcoKSk7XG4gIGNvbnN0IGhhc0Fic29sdXRlUGF0aCA9IGhhc0hvc3QgfHwgaHJlZi50b1N0cmluZygpLnN0YXJ0c1dpdGgoXCIvXCIpIHx8IGhyZWYudG9TdHJpbmcoKSA9PT0gXCJcIjtcbiAgY29uc3QgaGFzUmVsYXRpdmVQYXRoID0gIWhhc0Fic29sdXRlUGF0aCAmJiAhaHJlZi50b1N0cmluZygpLnN0YXJ0c1dpdGgoXCIjXCIpICYmICFocmVmLnRvU3RyaW5nKCkuc3RhcnRzV2l0aChcIj9cIik7XG4gIGNvbnN0IGhhc1JlbGF0aXZlUGF0aFdpdGhEb3RQcmVmaXggPSAvXlsuXXsxLDJ9KFsvXXwkKS8udGVzdChocmVmLnRvU3RyaW5nKCkpO1xuICBjb25zdCBoYXNTZWFyY2ggPSBocmVmLnRvU3RyaW5nKCkuaW5jbHVkZXMoXCI/XCIpIHx8IGhhc0RhdGFGb3JRdWVyeVN0cmluZztcbiAgY29uc3QgaGFzSGFzaCA9IGhyZWYudG9TdHJpbmcoKS5pbmNsdWRlcyhcIiNcIik7XG4gIGNvbnN0IHVybCA9IG5ldyBVUkwoaHJlZi50b1N0cmluZygpLCB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiID8gXCJodHRwOi8vbG9jYWxob3N0XCIgOiB3aW5kb3cubG9jYXRpb24udG9TdHJpbmcoKSk7XG4gIGlmIChoYXNEYXRhRm9yUXVlcnlTdHJpbmcpIHtcbiAgICBjb25zdCBhcnJheUZvcm1hdCA9IGhhc0luZGljZXModXJsKSA/IFwiaW5kaWNlc1wiIDogcXNBcnJheUZvcm1hdDtcbiAgICB1cmwuc2VhcmNoID0gc3RyaW5naWZ5KHsgLi4ucGFyc2UodXJsLnNlYXJjaCksIC4uLmRhdGEgfSwgYXJyYXlGb3JtYXQpO1xuICB9XG4gIHJldHVybiBbXG4gICAgW1xuICAgICAgaGFzSG9zdCA/IGAke3VybC5wcm90b2NvbH0vLyR7dXJsLmhvc3R9YCA6IFwiXCIsXG4gICAgICBoYXNBYnNvbHV0ZVBhdGggPyB1cmwucGF0aG5hbWUgOiBcIlwiLFxuICAgICAgaGFzUmVsYXRpdmVQYXRoID8gdXJsLnBhdGhuYW1lLnN1YnN0cmluZyhoYXNSZWxhdGl2ZVBhdGhXaXRoRG90UHJlZml4ID8gMCA6IDEpIDogXCJcIixcbiAgICAgIGhhc1NlYXJjaCA/IHVybC5zZWFyY2ggOiBcIlwiLFxuICAgICAgaGFzSGFzaCA/IHVybC5oYXNoIDogXCJcIlxuICAgIF0uam9pbihcIlwiKSxcbiAgICBoYXNEYXRhRm9yUXVlcnlTdHJpbmcgPyB7fSA6IGRhdGFcbiAgXTtcbn1cbmZ1bmN0aW9uIHVybFdpdGhvdXRIYXNoKHVybCkge1xuICB1cmwgPSBuZXcgVVJMKHVybC5ocmVmKTtcbiAgdXJsLmhhc2ggPSBcIlwiO1xuICByZXR1cm4gdXJsO1xufVxudmFyIHNldEhhc2hJZlNhbWVVcmwgPSAob3JpZ2luVXJsLCBkZXN0aW5hdGlvblVybCkgPT4ge1xuICBpZiAob3JpZ2luVXJsLmhhc2ggJiYgIWRlc3RpbmF0aW9uVXJsLmhhc2ggJiYgdXJsV2l0aG91dEhhc2gob3JpZ2luVXJsKS5ocmVmID09PSBkZXN0aW5hdGlvblVybC5ocmVmKSB7XG4gICAgZGVzdGluYXRpb25VcmwuaGFzaCA9IG9yaWdpblVybC5oYXNoO1xuICB9XG59O1xudmFyIGlzU2FtZVVybFdpdGhvdXRIYXNoID0gKHVybDEsIHVybDIpID0+IHtcbiAgcmV0dXJuIHVybFdpdGhvdXRIYXNoKHVybDEpLmhyZWYgPT09IHVybFdpdGhvdXRIYXNoKHVybDIpLmhyZWY7XG59O1xudmFyIGlzU2FtZVVybFdpdGhvdXRRdWVyeU9ySGFzaCA9ICh1cmwxLCB1cmwyKSA9PiB7XG4gIHJldHVybiB1cmwxLm9yaWdpbiA9PT0gdXJsMi5vcmlnaW4gJiYgdXJsMS5wYXRobmFtZSA9PT0gdXJsMi5wYXRobmFtZTtcbn07XG5mdW5jdGlvbiBpc1VybE1ldGhvZFBhaXIoaHJlZikge1xuICByZXR1cm4gaHJlZiAhPT0gbnVsbCAmJiB0eXBlb2YgaHJlZiA9PT0gXCJvYmplY3RcIiAmJiBocmVmICE9PSB2b2lkIDAgJiYgXCJ1cmxcIiBpbiBocmVmICYmIFwibWV0aG9kXCIgaW4gaHJlZjtcbn1cbmZ1bmN0aW9uIHJlc29sdmVVcmxNZXRob2RQYWlyQ29tcG9uZW50KHBhaXIpIHtcbiAgaWYgKCFwYWlyLmNvbXBvbmVudCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmICh0eXBlb2YgcGFpci5jb21wb25lbnQgIT09IFwic3RyaW5nXCIpIHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgYFRoZSBcImNvbXBvbmVudFwiIHByb3BlcnR5IG9uIHRoZSBVUkwgbWV0aG9kIHBhaXIgcmVjZWl2ZWQgbXVsdGlwbGUgY29tcG9uZW50cyAoJHtPYmplY3Qua2V5cyhwYWlyLmNvbXBvbmVudCkuam9pbihcIiwgXCIpfSksIGJ1dCBvbmx5IGEgc2luZ2xlIGNvbXBvbmVudCBzdHJpbmcgaXMgc3VwcG9ydGVkIGZvciBpbnN0YW50IHZpc2l0cy4gVXNlIHRoZSB3aXRoQ29tcG9uZW50KCkgbWV0aG9kIHRvIHNwZWNpZnkgd2hpY2ggY29tcG9uZW50IHRvIHVzZS5gXG4gICAgKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gcGFpci5jb21wb25lbnQ7XG59XG5mdW5jdGlvbiB1cmxIYXNQcm90b2NvbCh1cmwpIHtcbiAgcmV0dXJuIC9eKFthLXpdW2EtejAtOSsuLV0qOik/XFwvXFwvW14vXS9pLnRlc3QodXJsKTtcbn1cbmZ1bmN0aW9uIHVybFRvU3RyaW5nKHVybCwgYWJzb2x1dGUpIHtcbiAgY29uc3QgdXJsT2JqID0gdHlwZW9mIHVybCA9PT0gXCJzdHJpbmdcIiA/IGhyZWZUb1VybCh1cmwpIDogdXJsO1xuICByZXR1cm4gYWJzb2x1dGUgPyBgJHt1cmxPYmoucHJvdG9jb2x9Ly8ke3VybE9iai5ob3N0fSR7dXJsT2JqLnBhdGhuYW1lfSR7dXJsT2JqLnNlYXJjaH0ke3VybE9iai5oYXNofWAgOiBgJHt1cmxPYmoucGF0aG5hbWV9JHt1cmxPYmouc2VhcmNofSR7dXJsT2JqLmhhc2h9YDtcbn1cblxuLy8gc3JjL3BhZ2UudHNcbnZhciBDdXJyZW50UGFnZSA9IGNsYXNzIHtcbiAgcGFnZTtcbiAgc3dhcENvbXBvbmVudDtcbiAgcmVzb2x2ZUNvbXBvbmVudDtcbiAgb25GbGFzaENhbGxiYWNrO1xuICBjb21wb25lbnRJZCA9IHt9O1xuICBsaXN0ZW5lcnMgPSBbXTtcbiAgaXNGaXJzdFBhZ2VMb2FkID0gdHJ1ZTtcbiAgY2xlYXJlZCA9IGZhbHNlO1xuICBwZW5kaW5nRGVmZXJyZWRQcm9wcyA9IG51bGw7XG4gIGhpc3RvcnlRdW90YUV4Y2VlZGVkID0gZmFsc2U7XG4gIG9wdGltaXN0aWNCYXNlbGluZSA9IHt9O1xuICBwZW5kaW5nT3B0aW1pc3RpY3MgPSBbXTtcbiAgb3B0aW1pc3RpY0NvdW50ZXIgPSAwO1xuICBpbml0KHtcbiAgICBpbml0aWFsUGFnZSxcbiAgICBzd2FwQ29tcG9uZW50LFxuICAgIHJlc29sdmVDb21wb25lbnQsXG4gICAgb25GbGFzaFxuICB9KSB7XG4gICAgdGhpcy5wYWdlID0geyAuLi5pbml0aWFsUGFnZSwgZmxhc2g6IGluaXRpYWxQYWdlLmZsYXNoID8/IHt9LCByZXNjdWVkUHJvcHM6IGluaXRpYWxQYWdlLnJlc2N1ZWRQcm9wcyA/PyBbXSB9O1xuICAgIHRoaXMuc3dhcENvbXBvbmVudCA9IHN3YXBDb21wb25lbnQ7XG4gICAgdGhpcy5yZXNvbHZlQ29tcG9uZW50ID0gcmVzb2x2ZUNvbXBvbmVudDtcbiAgICB0aGlzLm9uRmxhc2hDYWxsYmFjayA9IG9uRmxhc2g7XG4gICAgZXZlbnRIYW5kbGVyLm9uKFwiaGlzdG9yeVF1b3RhRXhjZWVkZWRcIiwgKCkgPT4ge1xuICAgICAgdGhpcy5oaXN0b3J5UXVvdGFFeGNlZWRlZCA9IHRydWU7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgc2V0KHBhZ2UyLCB7XG4gICAgcmVwbGFjZSA9IGZhbHNlLFxuICAgIHByZXNlcnZlU2Nyb2xsID0gZmFsc2UsXG4gICAgcHJlc2VydmVTdGF0ZSA9IGZhbHNlLFxuICAgIHZpZXdUcmFuc2l0aW9uID0gZmFsc2UsXG4gICAgY2FjaGVkID0gZmFsc2UsXG4gICAgaW5pdGlhbFJlbmRlciA9IGZhbHNlLFxuICAgIHZpc2l0SWRcbiAgfSA9IHt9KSB7XG4gICAgaWYgKE9iamVjdC5rZXlzKHBhZ2UyLmRlZmVycmVkUHJvcHMgfHwge30pLmxlbmd0aCkge1xuICAgICAgdGhpcy5wZW5kaW5nRGVmZXJyZWRQcm9wcyA9IHtcbiAgICAgICAgZGVmZXJyZWRQcm9wczogcGFnZTIuZGVmZXJyZWRQcm9wcyxcbiAgICAgICAgY29tcG9uZW50OiBwYWdlMi5jb21wb25lbnQsXG4gICAgICAgIHVybDogcGFnZTIudXJsXG4gICAgICB9O1xuICAgICAgaWYgKHBhZ2UyLmluaXRpYWxEZWZlcnJlZFByb3BzID09PSB2b2lkIDApIHtcbiAgICAgICAgcGFnZTIuaW5pdGlhbERlZmVycmVkUHJvcHMgPSBwYWdlMi5kZWZlcnJlZFByb3BzO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmNvbXBvbmVudElkID0ge307XG4gICAgY29uc3QgY29tcG9uZW50SWQgPSB0aGlzLmNvbXBvbmVudElkO1xuICAgIGlmIChwYWdlMi5jbGVhckhpc3RvcnkpIHtcbiAgICAgIGhpc3RvcnkuY2xlYXIoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmVzb2x2ZShwYWdlMi5jb21wb25lbnQsIHBhZ2UyKS50aGVuKChjb21wb25lbnQpID0+IHtcbiAgICAgIGlmIChjb21wb25lbnRJZCAhPT0gdGhpcy5jb21wb25lbnRJZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwYWdlMi5yZW1lbWJlcmVkU3RhdGUgPz89IHt9O1xuICAgICAgY29uc3QgaXNTZXJ2ZXIzID0gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIjtcbiAgICAgIGNvbnN0IGxvY2F0aW9uID0gIWlzU2VydmVyMyA/IHdpbmRvdy5sb2NhdGlvbiA6IG5ldyBVUkwocGFnZTIudXJsKTtcbiAgICAgIGNvbnN0IHNjcm9sbFJlZ2lvbnMgPSAhaXNTZXJ2ZXIzICYmIHByZXNlcnZlU2Nyb2xsID8gU2Nyb2xsLmdldFNjcm9sbFJlZ2lvbnMoKSA6IFtdO1xuICAgICAgcmVwbGFjZSA9IHJlcGxhY2UgfHwgaXNTYW1lVXJsV2l0aG91dEhhc2goaHJlZlRvVXJsKHBhZ2UyLnVybCksIGxvY2F0aW9uKTtcbiAgICAgIGNvbnN0IHBhZ2VGb3JIaXN0b3J5ID0geyAuLi5wYWdlMiwgZmxhc2g6IHt9IH07XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoXG4gICAgICAgIChyZXNvbHZlKSA9PiByZXBsYWNlID8gaGlzdG9yeS5yZXBsYWNlU3RhdGUocGFnZUZvckhpc3RvcnksIHJlc29sdmUpIDogaGlzdG9yeS5wdXNoU3RhdGUocGFnZUZvckhpc3RvcnksIHJlc29sdmUpXG4gICAgICApLnRoZW4oKCkgPT4ge1xuICAgICAgICBjb25zdCBpc05ld0NvbXBvbmVudCA9ICF0aGlzLmlzVGhlU2FtZShwYWdlMik7XG4gICAgICAgIGlmICghaXNOZXdDb21wb25lbnQgJiYgT2JqZWN0LmtleXMocGFnZTIucHJvcHMuZXJyb3JzIHx8IHt9KS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdmlld1RyYW5zaXRpb24gPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnBhZ2UgPSBwYWdlMjtcbiAgICAgICAgdGhpcy5jbGVhcmVkID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLmhhc09uY2VQcm9wcygpKSB7XG4gICAgICAgICAgcHJlZmV0Y2hlZFJlcXVlc3RzLnVwZGF0ZUNhY2hlZE9uY2VQcm9wc0Zyb21DdXJyZW50UGFnZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc05ld0NvbXBvbmVudCkge1xuICAgICAgICAgIHRoaXMuZmlyZUV2ZW50c0ZvcihcIm5ld0NvbXBvbmVudFwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5pc0ZpcnN0UGFnZUxvYWQpIHtcbiAgICAgICAgICB0aGlzLmZpcmVFdmVudHNGb3IoXCJmaXJzdExvYWRcIik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pc0ZpcnN0UGFnZUxvYWQgPSBmYWxzZTtcbiAgICAgICAgaWYgKHRoaXMuaGlzdG9yeVF1b3RhRXhjZWVkZWQpIHtcbiAgICAgICAgICB0aGlzLmhpc3RvcnlRdW90YUV4Y2VlZGVkID0gZmFsc2U7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnN3YXAoe1xuICAgICAgICAgIGNvbXBvbmVudCxcbiAgICAgICAgICBwYWdlOiBwYWdlMixcbiAgICAgICAgICBwcmVzZXJ2ZVN0YXRlLFxuICAgICAgICAgIHZpZXdUcmFuc2l0aW9uLFxuICAgICAgICAgIGluaXRpYWxSZW5kZXJcbiAgICAgICAgfSkudGhlbigoKSA9PiB7XG4gICAgICAgICAgaWYgKHByZXNlcnZlU2Nyb2xsKSB7XG4gICAgICAgICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IFNjcm9sbC5yZXN0b3JlU2Nyb2xsUmVnaW9ucyhzY3JvbGxSZWdpb25zKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIFNjcm9sbC5yZXNldCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodGhpcy5wZW5kaW5nRGVmZXJyZWRQcm9wcyAmJiB0aGlzLnBlbmRpbmdEZWZlcnJlZFByb3BzLmNvbXBvbmVudCA9PT0gcGFnZTIuY29tcG9uZW50ICYmIHRoaXMucGVuZGluZ0RlZmVycmVkUHJvcHMudXJsID09PSBwYWdlMi51cmwpIHtcbiAgICAgICAgICAgIGV2ZW50SGFuZGxlci5maXJlSW50ZXJuYWxFdmVudChcImxvYWREZWZlcnJlZFByb3BzXCIsIHRoaXMucGVuZGluZ0RlZmVycmVkUHJvcHMuZGVmZXJyZWRQcm9wcyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMucGVuZGluZ0RlZmVycmVkUHJvcHMgPSBudWxsO1xuICAgICAgICAgIGlmICghcmVwbGFjZSkge1xuICAgICAgICAgICAgZmlyZU5hdmlnYXRlRXZlbnQocGFnZTIsIHsgY2FjaGVkLCB2aXNpdElkIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICBzZXRRdWlldGx5KHBhZ2UyLCB7XG4gICAgcHJlc2VydmVTdGF0ZSA9IGZhbHNlXG4gIH0gPSB7fSkge1xuICAgIHJldHVybiB0aGlzLnJlc29sdmUocGFnZTIuY29tcG9uZW50LCBwYWdlMikudGhlbigoY29tcG9uZW50KSA9PiB7XG4gICAgICB0aGlzLnBhZ2UgPSBwYWdlMjtcbiAgICAgIHRoaXMuY2xlYXJlZCA9IGZhbHNlO1xuICAgICAgaGlzdG9yeS5zZXRDdXJyZW50KHBhZ2UyKTtcbiAgICAgIHJldHVybiB0aGlzLnN3YXAoeyBjb21wb25lbnQsIHBhZ2U6IHBhZ2UyLCBwcmVzZXJ2ZVN0YXRlLCB2aWV3VHJhbnNpdGlvbjogZmFsc2UgfSk7XG4gICAgfSk7XG4gIH1cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5jbGVhcmVkID0gdHJ1ZTtcbiAgfVxuICBpc0NsZWFyZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuY2xlYXJlZDtcbiAgfVxuICBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFnZTtcbiAgfVxuICBnZXRXaXRob3V0Rmxhc2hEYXRhKCkge1xuICAgIHJldHVybiB7IC4uLnRoaXMucGFnZSwgZmxhc2g6IHt9IH07XG4gIH1cbiAgaGFzT25jZVByb3BzKCkge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLnBhZ2Uub25jZVByb3BzID8/IHt9KS5sZW5ndGggPiAwO1xuICB9XG4gIG1lcmdlKGRhdGEpIHtcbiAgICB0aGlzLnBhZ2UgPSB7IC4uLnRoaXMucGFnZSwgLi4uZGF0YSB9O1xuICB9XG4gIHNldFByb3BzUXVpZXRseShwcm9wcykge1xuICAgIHRoaXMucGFnZSA9IHsgLi4udGhpcy5wYWdlLCBwcm9wcyB9O1xuICAgIHJldHVybiB0aGlzLnJlc29sdmUodGhpcy5wYWdlLmNvbXBvbmVudCwgdGhpcy5wYWdlKS50aGVuKChjb21wb25lbnQpID0+IHtcbiAgICAgIHJldHVybiB0aGlzLnN3YXAoeyBjb21wb25lbnQsIHBhZ2U6IHRoaXMucGFnZSwgcHJlc2VydmVTdGF0ZTogdHJ1ZSwgdmlld1RyYW5zaXRpb246IGZhbHNlIH0pO1xuICAgIH0pO1xuICB9XG4gIHNldEZsYXNoKGZsYXNoKSB7XG4gICAgdGhpcy5wYWdlID0geyAuLi50aGlzLnBhZ2UsIGZsYXNoIH07XG4gICAgdGhpcy5vbkZsYXNoQ2FsbGJhY2s/LihmbGFzaCk7XG4gIH1cbiAgc2V0VXJsSGFzaChoYXNoKSB7XG4gICAgaWYgKCF0aGlzLnBhZ2UudXJsLmluY2x1ZGVzKGhhc2gpKSB7XG4gICAgICB0aGlzLnBhZ2UudXJsICs9IGhhc2g7XG4gICAgfVxuICB9XG4gIHJlbWVtYmVyKGRhdGEpIHtcbiAgICB0aGlzLnBhZ2UucmVtZW1iZXJlZFN0YXRlID0gZGF0YTtcbiAgfVxuICBzd2FwKHtcbiAgICBjb21wb25lbnQsXG4gICAgcGFnZTogcGFnZTIsXG4gICAgcHJlc2VydmVTdGF0ZSxcbiAgICB2aWV3VHJhbnNpdGlvbixcbiAgICBpbml0aWFsUmVuZGVyID0gZmFsc2VcbiAgfSkge1xuICAgIGNvbnN0IGRvU3dhcCA9ICgpID0+IHRoaXMuc3dhcENvbXBvbmVudCh7IGNvbXBvbmVudCwgcGFnZTogcGFnZTIsIHByZXNlcnZlU3RhdGUsIGluaXRpYWxSZW5kZXIgfSk7XG4gICAgaWYgKCF2aWV3VHJhbnNpdGlvbiB8fCAhZG9jdW1lbnQ/LnN0YXJ0Vmlld1RyYW5zaXRpb24gfHwgZG9jdW1lbnQudmlzaWJpbGl0eVN0YXRlID09PSBcImhpZGRlblwiKSB7XG4gICAgICByZXR1cm4gZG9Td2FwKCk7XG4gICAgfVxuICAgIGNvbnN0IHZpZXdUcmFuc2l0aW9uQ2FsbGJhY2sgPSB0eXBlb2Ygdmlld1RyYW5zaXRpb24gPT09IFwiYm9vbGVhblwiID8gKCkgPT4gbnVsbCA6IHZpZXdUcmFuc2l0aW9uO1xuICAgIGNvbnN0IGlnbm9yZVNraXBwZWRUcmFuc2l0aW9uID0gKHByb21pc2UpID0+IHtcbiAgICAgIHByb21pc2UuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgIGlmICghKGVycm9yIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uKSkge1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgY29uc3QgdHJhbnNpdGlvblJlc3VsdCA9IGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oKCkgPT4gZG9Td2FwKCkudGhlbihyZXNvbHZlKSk7XG4gICAgICBpZ25vcmVTa2lwcGVkVHJhbnNpdGlvbih0cmFuc2l0aW9uUmVzdWx0LnJlYWR5KTtcbiAgICAgIGlnbm9yZVNraXBwZWRUcmFuc2l0aW9uKHRyYW5zaXRpb25SZXN1bHQuZmluaXNoZWQpO1xuICAgICAgaWdub3JlU2tpcHBlZFRyYW5zaXRpb24odHJhbnNpdGlvblJlc3VsdC51cGRhdGVDYWxsYmFja0RvbmUpO1xuICAgICAgdmlld1RyYW5zaXRpb25DYWxsYmFjayh0cmFuc2l0aW9uUmVzdWx0KTtcbiAgICB9KTtcbiAgfVxuICByZXNvbHZlKGNvbXBvbmVudCwgcGFnZTIpIHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMucmVzb2x2ZUNvbXBvbmVudChjb21wb25lbnQsIHBhZ2UyKSk7XG4gIH1cbiAgbmV4dE9wdGltaXN0aWNJZCgpIHtcbiAgICByZXR1cm4gKyt0aGlzLm9wdGltaXN0aWNDb3VudGVyO1xuICB9XG4gIHNldEJhc2VsaW5lKGtleSwgdmFsdWUpIHtcbiAgICBpZiAoIShrZXkgaW4gdGhpcy5vcHRpbWlzdGljQmFzZWxpbmUpKSB7XG4gICAgICB0aGlzLm9wdGltaXN0aWNCYXNlbGluZVtrZXldID0gdmFsdWU7XG4gICAgfVxuICB9XG4gIHVwZGF0ZUJhc2VsaW5lKGtleSwgdmFsdWUpIHtcbiAgICBpZiAoa2V5IGluIHRoaXMub3B0aW1pc3RpY0Jhc2VsaW5lKSB7XG4gICAgICB0aGlzLm9wdGltaXN0aWNCYXNlbGluZVtrZXldID0gdmFsdWU7XG4gICAgfVxuICB9XG4gIGhhc0Jhc2VsaW5lKGtleSkge1xuICAgIHJldHVybiBrZXkgaW4gdGhpcy5vcHRpbWlzdGljQmFzZWxpbmU7XG4gIH1cbiAgcmVnaXN0ZXJPcHRpbWlzdGljKGlkLCBjYWxsYmFjaykge1xuICAgIHRoaXMucGVuZGluZ09wdGltaXN0aWNzLnB1c2goeyBpZCwgY2FsbGJhY2sgfSk7XG4gIH1cbiAgdW5yZWdpc3Rlck9wdGltaXN0aWMoaWQpIHtcbiAgICB0aGlzLnBlbmRpbmdPcHRpbWlzdGljcyA9IHRoaXMucGVuZGluZ09wdGltaXN0aWNzLmZpbHRlcigoZW50cnkpID0+IGVudHJ5LmlkICE9PSBpZCk7XG4gIH1cbiAgcmVwbGF5T3B0aW1pc3RpY3MoKSB7XG4gICAgY29uc3QgYmFzZWxpbmVLZXlzID0gT2JqZWN0LmtleXModGhpcy5vcHRpbWlzdGljQmFzZWxpbmUpO1xuICAgIGlmIChiYXNlbGluZUtleXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICAgIGNvbnN0IHByb3BzID0gY2xvbmVEZWVwMih0aGlzLnBhZ2UucHJvcHMpO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIGJhc2VsaW5lS2V5cykge1xuICAgICAgcHJvcHNba2V5XSA9IGNsb25lRGVlcDIodGhpcy5vcHRpbWlzdGljQmFzZWxpbmVba2V5XSk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgeyBjYWxsYmFjayB9IG9mIHRoaXMucGVuZGluZ09wdGltaXN0aWNzKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBjYWxsYmFjayhjbG9uZURlZXAyKHByb3BzKSk7XG4gICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24ocHJvcHMsIHJlc3VsdCk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHJlcGxheWVkUHJvcHMgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBiYXNlbGluZUtleXMpIHtcbiAgICAgIHJlcGxheWVkUHJvcHNba2V5XSA9IHByb3BzW2tleV07XG4gICAgfVxuICAgIHJldHVybiByZXBsYXllZFByb3BzO1xuICB9XG4gIHBlbmRpbmdPcHRpbWlzdGljQ291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMucGVuZGluZ09wdGltaXN0aWNzLmxlbmd0aDtcbiAgfVxuICBjbGVhck9wdGltaXN0aWNTdGF0ZSgpIHtcbiAgICB0aGlzLm9wdGltaXN0aWNCYXNlbGluZSA9IHt9O1xuICAgIHRoaXMucGVuZGluZ09wdGltaXN0aWNzID0gW107XG4gIH1cbiAgaXNUaGVTYW1lKHBhZ2UyKSB7XG4gICAgcmV0dXJuIHRoaXMucGFnZS5jb21wb25lbnQgPT09IHBhZ2UyLmNvbXBvbmVudDtcbiAgfVxuICBvbihldmVudCwgY2FsbGJhY2spIHtcbiAgICB0aGlzLmxpc3RlbmVycy5wdXNoKHsgZXZlbnQsIGNhbGxiYWNrIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB0aGlzLmxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzLmZpbHRlcigobGlzdGVuZXIpID0+IGxpc3RlbmVyLmV2ZW50ICE9PSBldmVudCAmJiBsaXN0ZW5lci5jYWxsYmFjayAhPT0gY2FsbGJhY2spO1xuICAgIH07XG4gIH1cbiAgZmlyZUV2ZW50c0ZvcihldmVudCkge1xuICAgIHRoaXMubGlzdGVuZXJzLmZpbHRlcigobGlzdGVuZXIpID0+IGxpc3RlbmVyLmV2ZW50ID09PSBldmVudCkuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyLmNhbGxiYWNrKCkpO1xuICB9XG4gIG1lcmdlT25jZVByb3BzSW50b1Jlc3BvbnNlKHJlc3BvbnNlLCB7IGZvcmNlID0gZmFsc2UgfSA9IHt9KSB7XG4gICAgT2JqZWN0LmVudHJpZXMocmVzcG9uc2Uub25jZVByb3BzID8/IHt9KS5mb3JFYWNoKChba2V5LCBvbmNlUHJvcF0pID0+IHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nT25jZVByb3AgPSB0aGlzLnBhZ2Uub25jZVByb3BzPy5ba2V5XTtcbiAgICAgIGlmIChleGlzdGluZ09uY2VQcm9wID09PSB2b2lkIDApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGZvcmNlIHx8IGdldDMocmVzcG9uc2UucHJvcHMsIG9uY2VQcm9wLnByb3ApID09PSB2b2lkIDApIHtcbiAgICAgICAgc2V0MyhyZXNwb25zZS5wcm9wcywgb25jZVByb3AucHJvcCwgZ2V0Myh0aGlzLnBhZ2UucHJvcHMsIGV4aXN0aW5nT25jZVByb3AucHJvcCkpO1xuICAgICAgICByZXNwb25zZS5vbmNlUHJvcHNba2V5XS5leHBpcmVzQXQgPSBleGlzdGluZ09uY2VQcm9wLmV4cGlyZXNBdDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufTtcbnZhciBwYWdlID0gbmV3IEN1cnJlbnRQYWdlKCk7XG5cbi8vIHNyYy9xdWV1ZS50c1xudmFyIFF1ZXVlID0gY2xhc3Mge1xuICBpdGVtcyA9IFtdO1xuICBwcm9jZXNzaW5nUHJvbWlzZSA9IG51bGw7XG4gIGFkZChpdGVtKSB7XG4gICAgdGhpcy5pdGVtcy5wdXNoKGl0ZW0pO1xuICAgIHJldHVybiB0aGlzLnByb2Nlc3MoKTtcbiAgfVxuICBwcm9jZXNzKCkge1xuICAgIHRoaXMucHJvY2Vzc2luZ1Byb21pc2UgPz89IHRoaXMucHJvY2Vzc05leHQoKS5maW5hbGx5KCgpID0+IHtcbiAgICAgIHRoaXMucHJvY2Vzc2luZ1Byb21pc2UgPSBudWxsO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzLnByb2Nlc3NpbmdQcm9taXNlO1xuICB9XG4gIHByb2Nlc3NOZXh0KCkge1xuICAgIGNvbnN0IG5leHQgPSB0aGlzLml0ZW1zLnNoaWZ0KCk7XG4gICAgaWYgKG5leHQpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUobmV4dCgpKS50aGVuKCgpID0+IHRoaXMucHJvY2Vzc05leHQoKSk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgfVxufTtcblxuLy8gc3JjL2hpc3RvcnkudHNcbnZhciBpc1NlcnZlcjIgPSB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiO1xudmFyIHF1ZXVlID0gbmV3IFF1ZXVlKCk7XG52YXIgaXNDaHJvbWVJT1MgPSAhaXNTZXJ2ZXIyICYmIC9DcmlPUy8udGVzdCh3aW5kb3cubmF2aWdhdG9yLnVzZXJBZ2VudCk7XG52YXIgSGlzdG9yeSA9IGNsYXNzIHtcbiAgcmVtZW1iZXJlZFN0YXRlID0gXCJyZW1lbWJlcmVkU3RhdGVcIjtcbiAgc2Nyb2xsUmVnaW9ucyA9IFwic2Nyb2xsUmVnaW9uc1wiO1xuICBwcmVzZXJ2ZVVybCA9IGZhbHNlO1xuICBjdXJyZW50ID0ge307XG4gIC8vIFdlIG5lZWQgaW5pdGlhbFN0YXRlIGZvciBgcmVzdG9yZWBcbiAgaW5pdGlhbFN0YXRlID0gbnVsbDtcbiAgcmVtZW1iZXIoZGF0YSwga2V5KSB7XG4gICAgdGhpcy5yZXBsYWNlU3RhdGUoe1xuICAgICAgLi4ucGFnZS5nZXRXaXRob3V0Rmxhc2hEYXRhKCksXG4gICAgICByZW1lbWJlcmVkU3RhdGU6IHtcbiAgICAgICAgLi4ucGFnZS5nZXQoKT8ucmVtZW1iZXJlZFN0YXRlID8/IHt9LFxuICAgICAgICBba2V5XTogZGF0YVxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHJlc3RvcmUoa2V5KSB7XG4gICAgaWYgKCFpc1NlcnZlcjIpIHtcbiAgICAgIHJldHVybiB0aGlzLmN1cnJlbnRbdGhpcy5yZW1lbWJlcmVkU3RhdGVdPy5ba2V5XSAhPT0gdm9pZCAwID8gdGhpcy5jdXJyZW50W3RoaXMucmVtZW1iZXJlZFN0YXRlXT8uW2tleV0gOiB0aGlzLmluaXRpYWxTdGF0ZT8uW3RoaXMucmVtZW1iZXJlZFN0YXRlXT8uW2tleV07XG4gICAgfVxuICB9XG4gIHB1c2hTdGF0ZShwYWdlMiwgY2IgPSBudWxsKSB7XG4gICAgaWYgKGlzU2VydmVyMikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodGhpcy5wcmVzZXJ2ZVVybCkge1xuICAgICAgY2IgJiYgY2IoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5jdXJyZW50ID0gcGFnZTI7XG4gICAgcXVldWUuYWRkKCgpID0+IHtcbiAgICAgIHJldHVybiB0aGlzLmdldFBhZ2VEYXRhKHBhZ2UyKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgIGNvbnN0IGRvUHVzaCA9ICgpID0+IHRoaXMuZG9QdXNoU3RhdGUoeyBwYWdlOiBkYXRhIH0sIHBhZ2UyLnVybCkudGhlbigoKSA9PiBjYj8uKCkpO1xuICAgICAgICBpZiAoaXNDaHJvbWVJT1MpIHtcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gZG9QdXNoKCkudGhlbihyZXNvbHZlKSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRvUHVzaCgpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgY2xvbmVQYWdlUHJvcHMocGFnZTIpIHtcbiAgICB0cnkge1xuICAgICAgc3RydWN0dXJlZENsb25lKHBhZ2UyLnByb3BzKTtcbiAgICAgIHJldHVybiBwYWdlMjtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnBhZ2UyLFxuICAgICAgICBwcm9wczogY2xvbmVEZWVwMyhwYWdlMi5wcm9wcylcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIGdldFBhZ2VEYXRhKHBhZ2UyKSB7XG4gICAgY29uc3QgcGFnZVdpdGhDbG9uZWRQcm9wcyA9IHRoaXMuY2xvbmVQYWdlUHJvcHMocGFnZTIpO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgcmV0dXJuIHBhZ2UyLmVuY3J5cHRIaXN0b3J5ID8gZW5jcnlwdEhpc3RvcnkocGFnZVdpdGhDbG9uZWRQcm9wcykudGhlbihyZXNvbHZlKSA6IHJlc29sdmUocGFnZVdpdGhDbG9uZWRQcm9wcyk7XG4gICAgfSk7XG4gIH1cbiAgcHJvY2Vzc1F1ZXVlKCkge1xuICAgIHJldHVybiBxdWV1ZS5wcm9jZXNzKCk7XG4gIH1cbiAgZGVjcnlwdChwYWdlMiA9IG51bGwpIHtcbiAgICBpZiAoaXNTZXJ2ZXIyKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHBhZ2UyID8/IHBhZ2UuZ2V0KCkpO1xuICAgIH1cbiAgICBjb25zdCBwYWdlRGF0YSA9IHBhZ2UyID8/IHdpbmRvdy5oaXN0b3J5LnN0YXRlPy5wYWdlO1xuICAgIHJldHVybiB0aGlzLmRlY3J5cHRQYWdlRGF0YShwYWdlRGF0YSkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgaWYgKCFkYXRhKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVuYWJsZSB0byBkZWNyeXB0IGhpc3RvcnlcIik7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5pbml0aWFsU3RhdGUgPT09IG51bGwpIHtcbiAgICAgICAgdGhpcy5pbml0aWFsU3RhdGUgPSBkYXRhID8/IHZvaWQgMDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuY3VycmVudCA9IGRhdGEgPz8ge307XG4gICAgICB9XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9KTtcbiAgfVxuICBkZWNyeXB0UGFnZURhdGEocGFnZURhdGEpIHtcbiAgICByZXR1cm4gcGFnZURhdGEgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciA/IGRlY3J5cHRIaXN0b3J5KHBhZ2VEYXRhKSA6IFByb21pc2UucmVzb2x2ZShwYWdlRGF0YSk7XG4gIH1cbiAgc2F2ZVNjcm9sbFBvc2l0aW9ucyhzY3JvbGxSZWdpb25zKSB7XG4gICAgcXVldWUuYWRkKCgpID0+IHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IHtcbiAgICAgICAgaWYgKCF3aW5kb3cuaGlzdG9yeS5zdGF0ZT8ucGFnZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNFcXVhbCh0aGlzLmdldFNjcm9sbFJlZ2lvbnMoKSwgc2Nyb2xsUmVnaW9ucykpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZG9SZXBsYWNlU3RhdGUoe1xuICAgICAgICAgIHBhZ2U6IHdpbmRvdy5oaXN0b3J5LnN0YXRlLnBhZ2UsXG4gICAgICAgICAgc2Nyb2xsUmVnaW9uc1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIHNhdmVEb2N1bWVudFNjcm9sbFBvc2l0aW9uKHNjcm9sbFJlZ2lvbikge1xuICAgIHF1ZXVlLmFkZCgoKSA9PiB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG4gICAgICAgIGlmICghd2luZG93Lmhpc3Rvcnkuc3RhdGU/LnBhZ2UpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRXF1YWwodGhpcy5nZXREb2N1bWVudFNjcm9sbFBvc2l0aW9uKCksIHNjcm9sbFJlZ2lvbikpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZG9SZXBsYWNlU3RhdGUoe1xuICAgICAgICAgIHBhZ2U6IHdpbmRvdy5oaXN0b3J5LnN0YXRlLnBhZ2UsXG4gICAgICAgICAgZG9jdW1lbnRTY3JvbGxQb3NpdGlvbjogc2Nyb2xsUmVnaW9uXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgZ2V0U2Nyb2xsUmVnaW9ucygpIHtcbiAgICByZXR1cm4gd2luZG93Lmhpc3Rvcnkuc3RhdGU/LnNjcm9sbFJlZ2lvbnMgfHwgW107XG4gIH1cbiAgZ2V0RG9jdW1lbnRTY3JvbGxQb3NpdGlvbigpIHtcbiAgICByZXR1cm4gd2luZG93Lmhpc3Rvcnkuc3RhdGU/LmRvY3VtZW50U2Nyb2xsUG9zaXRpb24gfHwgeyB0b3A6IDAsIGxlZnQ6IDAgfTtcbiAgfVxuICByZXBsYWNlU3RhdGUocGFnZTIsIGNiID0gbnVsbCkge1xuICAgIGlmIChpc0VxdWFsKHRoaXMuY3VycmVudCwgcGFnZTIpKSB7XG4gICAgICBjYiAmJiBjYigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB7IGZsYXNoLCAuLi5wYWdlV2l0aG91dEZsYXNoIH0gPSBwYWdlMjtcbiAgICBwYWdlLm1lcmdlKHBhZ2VXaXRob3V0Rmxhc2gpO1xuICAgIGlmIChpc1NlcnZlcjIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMucHJlc2VydmVVcmwpIHtcbiAgICAgIGNiICYmIGNiKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuY3VycmVudCA9IHBhZ2UyO1xuICAgIHF1ZXVlLmFkZCgoKSA9PiB7XG4gICAgICByZXR1cm4gdGhpcy5nZXRQYWdlRGF0YShwYWdlMikudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICBjb25zdCBkb1JlcGxhY2UgPSAoKSA9PiB0aGlzLmRvUmVwbGFjZVN0YXRlKHsgcGFnZTogZGF0YSB9LCBwYWdlMi51cmwpLnRoZW4oKCkgPT4gY2I/LigpKTtcbiAgICAgICAgaWYgKGlzQ2hyb21lSU9TKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGRvUmVwbGFjZSgpLnRoZW4ocmVzb2x2ZSkpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkb1JlcGxhY2UoKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGlzSGlzdG9yeVRocm90dGxlRXJyb3IoZXJyb3IpIHtcbiAgICByZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnJvci5uYW1lID09PSBcIlNlY3VyaXR5RXJyb3JcIiAmJiAoZXJyb3IubWVzc2FnZS5pbmNsdWRlcyhcImhpc3RvcnkucHVzaFN0YXRlXCIpIHx8IGVycm9yLm1lc3NhZ2UuaW5jbHVkZXMoXCJoaXN0b3J5LnJlcGxhY2VTdGF0ZVwiKSk7XG4gIH1cbiAgaXNRdW90YUV4Y2VlZGVkRXJyb3IoZXJyb3IpIHtcbiAgICByZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnJvci5uYW1lID09PSBcIlF1b3RhRXhjZWVkZWRFcnJvclwiO1xuICB9XG4gIHdpdGhUaHJvdHRsZVByb3RlY3Rpb24oY2IpIHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gY2IoKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmICghdGhpcy5pc0hpc3RvcnlUaHJvdHRsZUVycm9yKGVycm9yKSkge1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgZG9SZXBsYWNlU3RhdGUoZGF0YSwgdXJsKSB7XG4gICAgcmV0dXJuIHRoaXMud2l0aFRocm90dGxlUHJvdGVjdGlvbigoKSA9PiB7XG4gICAgICB3aW5kb3cuaGlzdG9yeS5yZXBsYWNlU3RhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICAuLi5kYXRhLFxuICAgICAgICAgIHNjcm9sbFJlZ2lvbnM6IGRhdGEuc2Nyb2xsUmVnaW9ucyA/PyB3aW5kb3cuaGlzdG9yeS5zdGF0ZT8uc2Nyb2xsUmVnaW9ucyxcbiAgICAgICAgICBkb2N1bWVudFNjcm9sbFBvc2l0aW9uOiBkYXRhLmRvY3VtZW50U2Nyb2xsUG9zaXRpb24gPz8gd2luZG93Lmhpc3Rvcnkuc3RhdGU/LmRvY3VtZW50U2Nyb2xsUG9zaXRpb25cbiAgICAgICAgfSxcbiAgICAgICAgXCJcIixcbiAgICAgICAgdXJsXG4gICAgICApO1xuICAgIH0pO1xuICB9XG4gIGRvUHVzaFN0YXRlKGRhdGEsIHVybCkge1xuICAgIHJldHVybiB0aGlzLndpdGhUaHJvdHRsZVByb3RlY3Rpb24oKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgd2luZG93Lmhpc3RvcnkucHVzaFN0YXRlKGRhdGEsIFwiXCIsIHVybCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoIXRoaXMuaXNRdW90YUV4Y2VlZGVkRXJyb3IoZXJyb3IpKSB7XG4gICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgZXZlbnRIYW5kbGVyLmZpcmVJbnRlcm5hbEV2ZW50KFwiaGlzdG9yeVF1b3RhRXhjZWVkZWRcIiwgdXJsKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBnZXRTdGF0ZShrZXksIGRlZmF1bHRWYWx1ZSkge1xuICAgIHJldHVybiB0aGlzLmN1cnJlbnQ/LltrZXldID8/IGRlZmF1bHRWYWx1ZTtcbiAgfVxuICBkZWxldGVTdGF0ZShrZXkpIHtcbiAgICBpZiAodGhpcy5jdXJyZW50W2tleV0gIT09IHZvaWQgMCkge1xuICAgICAgZGVsZXRlIHRoaXMuY3VycmVudFtrZXldO1xuICAgICAgdGhpcy5yZXBsYWNlU3RhdGUodGhpcy5jdXJyZW50KTtcbiAgICB9XG4gIH1cbiAgY2xlYXJJbml0aWFsU3RhdGUoa2V5KSB7XG4gICAgaWYgKHRoaXMuaW5pdGlhbFN0YXRlICYmIHRoaXMuaW5pdGlhbFN0YXRlW2tleV0gIT09IHZvaWQgMCkge1xuICAgICAgZGVsZXRlIHRoaXMuaW5pdGlhbFN0YXRlW2tleV07XG4gICAgfVxuICB9XG4gIGJyb3dzZXJIYXNIaXN0b3J5RW50cnkoKSB7XG4gICAgcmV0dXJuICFpc1NlcnZlcjIgJiYgISF3aW5kb3cuaGlzdG9yeS5zdGF0ZT8ucGFnZTtcbiAgfVxuICBjbGVhcigpIHtcbiAgICBTZXNzaW9uU3RvcmFnZS5yZW1vdmUoaGlzdG9yeVNlc3Npb25TdG9yYWdlS2V5cy5rZXkpO1xuICAgIFNlc3Npb25TdG9yYWdlLnJlbW92ZShoaXN0b3J5U2Vzc2lvblN0b3JhZ2VLZXlzLml2KTtcbiAgfVxuICBzZXRDdXJyZW50KHBhZ2UyKSB7XG4gICAgdGhpcy5jdXJyZW50ID0gcGFnZTI7XG4gIH1cbiAgaXNWYWxpZFN0YXRlKHN0YXRlKSB7XG4gICAgcmV0dXJuICEhc3RhdGUucGFnZTtcbiAgfVxuICBnZXRBbGxTdGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5jdXJyZW50O1xuICB9XG59O1xuaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSBcIm1hbnVhbFwiO1xufVxudmFyIGhpc3RvcnkgPSBuZXcgSGlzdG9yeSgpO1xuXG4vLyBzcmMvZXZlbnRIYW5kbGVyLnRzXG52YXIgRXZlbnRIYW5kbGVyID0gY2xhc3Mge1xuICBpbnRlcm5hbExpc3RlbmVycyA9IFtdO1xuICBpbml0KCkge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIHRoaXMuaGFuZGxlUG9wc3RhdGVFdmVudC5iaW5kKHRoaXMpKTtcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZXNob3dcIiwgdGhpcy5oYW5kbGVQYWdlc2hvd0V2ZW50LmJpbmQodGhpcykpO1xuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgZGVib3VuY2UoU2Nyb2xsLm9uV2luZG93U2Nyb2xsLmJpbmQoU2Nyb2xsKSwgMTAwKSwgdHJ1ZSk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgZGVib3VuY2UoU2Nyb2xsLm9uU2Nyb2xsLmJpbmQoU2Nyb2xsKSwgMTAwKSwgdHJ1ZSk7XG4gICAgfVxuICB9XG4gIG9uR2xvYmFsRXZlbnQodHlwZSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBsaXN0ZW5lciA9ICgoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gY2FsbGJhY2soZXZlbnQpO1xuICAgICAgaWYgKGV2ZW50LmNhbmNlbGFibGUgJiYgIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgJiYgcmVzcG9uc2UgPT09IGZhbHNlKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXMucmVnaXN0ZXJMaXN0ZW5lcihgaW5lcnRpYToke3R5cGV9YCwgbGlzdGVuZXIpO1xuICB9XG4gIG9uKGV2ZW50LCBjYWxsYmFjaykge1xuICAgIHRoaXMuaW50ZXJuYWxMaXN0ZW5lcnMucHVzaCh7IGV2ZW50LCBsaXN0ZW5lcjogY2FsbGJhY2sgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMuaW50ZXJuYWxMaXN0ZW5lcnMgPSB0aGlzLmludGVybmFsTGlzdGVuZXJzLmZpbHRlcigobGlzdGVuZXIpID0+IGxpc3RlbmVyLmxpc3RlbmVyICE9PSBjYWxsYmFjayk7XG4gICAgfTtcbiAgfVxuICBvbk1pc3NpbmdIaXN0b3J5SXRlbSgpIHtcbiAgICBwYWdlLmNsZWFyKCk7XG4gICAgdGhpcy5maXJlSW50ZXJuYWxFdmVudChcIm1pc3NpbmdIaXN0b3J5SXRlbVwiKTtcbiAgfVxuICBmaXJlSW50ZXJuYWxFdmVudChldmVudCwgLi4uYXJncykge1xuICAgIHRoaXMuaW50ZXJuYWxMaXN0ZW5lcnMuZmlsdGVyKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIuZXZlbnQgPT09IGV2ZW50KS5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIubGlzdGVuZXIoLi4uYXJncykpO1xuICB9XG4gIHJlZ2lzdGVyTGlzdGVuZXIodHlwZSwgbGlzdGVuZXIpIHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyKTtcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcik7XG4gIH1cbiAgLy8gYmZjYWNoZSByZXN0b3JlcyBwYWdlcyB3aXRob3V0IGZpcmluZyBgcG9wc3RhdGVgLCBzbyB3ZSB1c2UgYHBhZ2VzaG93YCB0b1xuICAvLyByZS12YWxpZGF0ZSBlbmNyeXB0ZWQgaGlzdG9yeSBlbnRyaWVzIGFmdGVyIGBjbGVhckhpc3RvcnlgIHJlbW92ZWQgdGhlIGtleXMuXG4gIC8vIGh0dHBzOi8vd2ViLmRldi9hcnRpY2xlcy9iZmNhY2hlXG4gIGhhbmRsZVBhZ2VzaG93RXZlbnQoZXZlbnQpIHtcbiAgICBpZiAoZXZlbnQucGVyc2lzdGVkKSB7XG4gICAgICBoaXN0b3J5LmRlY3J5cHQoKS5jYXRjaCgoKSA9PiB0aGlzLm9uTWlzc2luZ0hpc3RvcnlJdGVtKCkpO1xuICAgIH1cbiAgfVxuICBoYW5kbGVQb3BzdGF0ZUV2ZW50KGV2ZW50KSB7XG4gICAgY29uc3Qgc3RhdGUgPSBldmVudC5zdGF0ZSB8fCBudWxsO1xuICAgIGlmIChzdGF0ZSA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdXJsID0gaHJlZlRvVXJsKHBhZ2UuZ2V0KCkudXJsKTtcbiAgICAgIHVybC5oYXNoID0gd2luZG93LmxvY2F0aW9uLmhhc2g7XG4gICAgICBoaXN0b3J5LnJlcGxhY2VTdGF0ZSh7IC4uLnBhZ2UuZ2V0V2l0aG91dEZsYXNoRGF0YSgpLCB1cmw6IHVybC5ocmVmIH0pO1xuICAgICAgU2Nyb2xsLnJlc2V0KCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghaGlzdG9yeS5pc1ZhbGlkU3RhdGUoc3RhdGUpKSB7XG4gICAgICByZXR1cm4gdGhpcy5vbk1pc3NpbmdIaXN0b3J5SXRlbSgpO1xuICAgIH1cbiAgICBoaXN0b3J5LmRlY3J5cHQoc3RhdGUucGFnZSkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgaWYgKHBhZ2UuZ2V0KCkudmVyc2lvbiAhPT0gZGF0YS52ZXJzaW9uKSB7XG4gICAgICAgIHRoaXMub25NaXNzaW5nSGlzdG9yeUl0ZW0oKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcm91dGVyLmNhbmNlbEFsbCh7IHByZWZldGNoOiBmYWxzZSB9KTtcbiAgICAgIHBhZ2Uuc2V0UXVpZXRseShkYXRhLCB7IHByZXNlcnZlU3RhdGU6IGZhbHNlIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgICBTY3JvbGwucmVzdG9yZShoaXN0b3J5LmdldFNjcm9sbFJlZ2lvbnMoKSk7XG4gICAgICAgIGZpcmVOYXZpZ2F0ZUV2ZW50KHBhZ2UuZ2V0KCkpO1xuICAgICAgICBjb25zdCBwZW5kaW5nRGVmZXJyZWQgPSB7fTtcbiAgICAgICAgY29uc3QgcGFnZVByb3BzID0gcGFnZS5nZXQoKS5wcm9wcztcbiAgICAgICAgZm9yIChjb25zdCBbZ3JvdXAsIHByb3BzXSBvZiBPYmplY3QuZW50cmllcyhkYXRhLmluaXRpYWxEZWZlcnJlZFByb3BzID8/IGRhdGEuZGVmZXJyZWRQcm9wcyA/PyB7fSkpIHtcbiAgICAgICAgICBjb25zdCBtaXNzaW5nID0gcHJvcHMuZmlsdGVyKChwcm9wKSA9PiBnZXQ0KHBhZ2VQcm9wcywgcHJvcCkgPT09IHZvaWQgMCk7XG4gICAgICAgICAgaWYgKG1pc3NpbmcubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgcGVuZGluZ0RlZmVycmVkW2dyb3VwXSA9IG1pc3Npbmc7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhwZW5kaW5nRGVmZXJyZWQpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICB0aGlzLmZpcmVJbnRlcm5hbEV2ZW50KFwibG9hZERlZmVycmVkUHJvcHNcIiwgcGVuZGluZ0RlZmVycmVkKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgdGhpcy5vbk1pc3NpbmdIaXN0b3J5SXRlbSgpO1xuICAgIH0pO1xuICB9XG59O1xudmFyIGV2ZW50SGFuZGxlciA9IG5ldyBFdmVudEhhbmRsZXIoKTtcblxuLy8gc3JjL25hdmlnYXRpb25UeXBlLnRzXG52YXIgTmF2aWdhdGlvblR5cGUgPSBjbGFzcyB7XG4gIHR5cGU7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMudHlwZSA9IHRoaXMucmVzb2x2ZVR5cGUoKTtcbiAgfVxuICByZXNvbHZlVHlwZSgpIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgcmV0dXJuIFwibmF2aWdhdGVcIjtcbiAgICB9XG4gICAgY29uc3QgZW50cnkgPSB3aW5kb3cucGVyZm9ybWFuY2U/LmdldEVudHJpZXNCeVR5cGUoXCJuYXZpZ2F0aW9uXCIpWzBdO1xuICAgIHJldHVybiBlbnRyeT8udHlwZSA/PyBcIm5hdmlnYXRlXCI7XG4gIH1cbiAgZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLnR5cGU7XG4gIH1cbiAgaXNCYWNrRm9yd2FyZCgpIHtcbiAgICByZXR1cm4gdGhpcy50eXBlID09PSBcImJhY2tfZm9yd2FyZFwiO1xuICB9XG4gIGlzUmVsb2FkKCkge1xuICAgIHJldHVybiB0aGlzLnR5cGUgPT09IFwicmVsb2FkXCI7XG4gIH1cbn07XG52YXIgbmF2aWdhdGlvblR5cGUgPSBuZXcgTmF2aWdhdGlvblR5cGUoKTtcblxuLy8gc3JjL3VpZC50c1xuZnVuY3Rpb24gdWlkKCkge1xuICBjb25zdCBjcnlwdG9PYmogPSB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93LmNyeXB0byA6IHZvaWQgMDtcbiAgaWYgKGNyeXB0b09iaj8ucmFuZG9tVVVJRCkge1xuICAgIHJldHVybiBjcnlwdG9PYmoucmFuZG9tVVVJRCgpO1xuICB9XG4gIGNvbnN0IHJhbmRvbUJ5dGUgPSAoKSA9PiBjcnlwdG9PYmo/LmdldFJhbmRvbVZhbHVlcyA/IGNyeXB0b09iai5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMSkpWzBdIDogTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMjU2KTtcbiAgcmV0dXJuIFwiMTAwMDAwMDAtMTAwMC00MDAwLTgwMDAtMTAwMDAwMDAwMDAwXCIucmVwbGFjZShcbiAgICAvWzAxOF0vZyxcbiAgICAoYykgPT4gKCtjIF4gcmFuZG9tQnl0ZSgpICYgMTUgPj4gK2MgLyA0KS50b1N0cmluZygxNilcbiAgKTtcbn1cblxuLy8gc3JjL2luaXRpYWxWaXNpdC50c1xudmFyIEluaXRpYWxWaXNpdCA9IGNsYXNzIHtcbiAgc3RhdGljIGhhbmRsZSgpIHtcbiAgICB0aGlzLmNsZWFyUmVtZW1iZXJlZFN0YXRlT25SZWxvYWQoKTtcbiAgICBjb25zdCBzY2VuYXJpb3MgPSBbdGhpcy5oYW5kbGVCYWNrRm9yd2FyZCwgdGhpcy5oYW5kbGVMb2NhdGlvbiwgdGhpcy5oYW5kbGVEZWZhdWx0XTtcbiAgICBzY2VuYXJpb3MuZmluZCgoaGFuZGxlcikgPT4gaGFuZGxlci5iaW5kKHRoaXMpKCkpO1xuICB9XG4gIHN0YXRpYyBjbGVhclJlbWVtYmVyZWRTdGF0ZU9uUmVsb2FkKCkge1xuICAgIGlmIChuYXZpZ2F0aW9uVHlwZS5pc1JlbG9hZCgpKSB7XG4gICAgICBoaXN0b3J5LmRlbGV0ZVN0YXRlKGhpc3RvcnkucmVtZW1iZXJlZFN0YXRlKTtcbiAgICAgIGhpc3RvcnkuY2xlYXJJbml0aWFsU3RhdGUoaGlzdG9yeS5yZW1lbWJlcmVkU3RhdGUpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgaGFuZGxlQmFja0ZvcndhcmQoKSB7XG4gICAgaWYgKCFuYXZpZ2F0aW9uVHlwZS5pc0JhY2tGb3J3YXJkKCkgfHwgIWhpc3RvcnkuYnJvd3Nlckhhc0hpc3RvcnlFbnRyeSgpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHNjcm9sbFJlZ2lvbnMgPSBoaXN0b3J5LmdldFNjcm9sbFJlZ2lvbnMoKTtcbiAgICBoaXN0b3J5LmRlY3J5cHQoKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBjb25zdCB2aXNpdElkID0gdWlkKCk7XG4gICAgICBwYWdlLnNldChkYXRhLCB7IHByZXNlcnZlU2Nyb2xsOiB0cnVlLCBwcmVzZXJ2ZVN0YXRlOiB0cnVlLCB2aXNpdElkIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgICBTY3JvbGwucmVzdG9yZShzY3JvbGxSZWdpb25zKTtcbiAgICAgICAgZmlyZU5hdmlnYXRlRXZlbnQocGFnZS5nZXQoKSwgeyB2aXNpdElkIH0pO1xuICAgICAgfSk7XG4gICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgZXZlbnRIYW5kbGVyLm9uTWlzc2luZ0hpc3RvcnlJdGVtKCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLyoqXG4gICAqIEBsaW5rIGh0dHBzOi8vaW5lcnRpYWpzLmNvbS9yZWRpcmVjdHMjZXh0ZXJuYWwtcmVkaXJlY3RzXG4gICAqL1xuICBzdGF0aWMgaGFuZGxlTG9jYXRpb24oKSB7XG4gICAgaWYgKCFTZXNzaW9uU3RvcmFnZS5leGlzdHMoU2Vzc2lvblN0b3JhZ2UubG9jYXRpb25WaXNpdEtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgbG9jYXRpb25WaXNpdCA9IFNlc3Npb25TdG9yYWdlLmdldChTZXNzaW9uU3RvcmFnZS5sb2NhdGlvblZpc2l0S2V5KSB8fCB7fTtcbiAgICBTZXNzaW9uU3RvcmFnZS5yZW1vdmUoU2Vzc2lvblN0b3JhZ2UubG9jYXRpb25WaXNpdEtleSk7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHBhZ2Uuc2V0VXJsSGFzaCh3aW5kb3cubG9jYXRpb24uaGFzaCk7XG4gICAgfVxuICAgIGhpc3RvcnkuZGVjcnlwdChwYWdlLmdldCgpKS50aGVuKCgpID0+IHtcbiAgICAgIGNvbnN0IHZpc2l0SWQgPSB1aWQoKTtcbiAgICAgIGNvbnN0IHJlbWVtYmVyZWRTdGF0ZSA9IGhpc3RvcnkuZ2V0U3RhdGUoaGlzdG9yeS5yZW1lbWJlcmVkU3RhdGUsIHt9KTtcbiAgICAgIGNvbnN0IHNjcm9sbFJlZ2lvbnMgPSBoaXN0b3J5LmdldFNjcm9sbFJlZ2lvbnMoKTtcbiAgICAgIHBhZ2UucmVtZW1iZXIocmVtZW1iZXJlZFN0YXRlKTtcbiAgICAgIHBhZ2Uuc2V0KHBhZ2UuZ2V0KCksIHtcbiAgICAgICAgcHJlc2VydmVTY3JvbGw6IGxvY2F0aW9uVmlzaXQucHJlc2VydmVTY3JvbGwsXG4gICAgICAgIHByZXNlcnZlU3RhdGU6IHRydWUsXG4gICAgICAgIGluaXRpYWxSZW5kZXI6IHRydWUsXG4gICAgICAgIHZpc2l0SWRcbiAgICAgIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgICBpZiAobG9jYXRpb25WaXNpdC5wcmVzZXJ2ZVNjcm9sbCkge1xuICAgICAgICAgIFNjcm9sbC5yZXN0b3JlKHNjcm9sbFJlZ2lvbnMpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZmlyZUluaXRpYWxFdmVudHModmlzaXRJZCk7XG4gICAgICB9KTtcbiAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICBldmVudEhhbmRsZXIub25NaXNzaW5nSGlzdG9yeUl0ZW0oKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBzdGF0aWMgaGFuZGxlRGVmYXVsdCgpIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgcGFnZS5zZXRVcmxIYXNoKHdpbmRvdy5sb2NhdGlvbi5oYXNoKTtcbiAgICB9XG4gICAgY29uc3QgdmlzaXRJZCA9IHVpZCgpO1xuICAgIHBhZ2Uuc2V0KHBhZ2UuZ2V0KCksIHsgcHJlc2VydmVTY3JvbGw6IHRydWUsIHByZXNlcnZlU3RhdGU6IHRydWUsIGluaXRpYWxSZW5kZXI6IHRydWUsIHZpc2l0SWQgfSkudGhlbigoKSA9PiB7XG4gICAgICBpZiAobmF2aWdhdGlvblR5cGUuaXNSZWxvYWQoKSkge1xuICAgICAgICBTY3JvbGwucmVzdG9yZShoaXN0b3J5LmdldFNjcm9sbFJlZ2lvbnMoKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBTY3JvbGwuc2Nyb2xsVG9BbmNob3IoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuZmlyZUluaXRpYWxFdmVudHModmlzaXRJZCk7XG4gICAgfSk7XG4gIH1cbiAgc3RhdGljIGZpcmVJbml0aWFsRXZlbnRzKHZpc2l0SWQpIHtcbiAgICBjb25zdCBwYWdlMiA9IHBhZ2UuZ2V0KCk7XG4gICAgZmlyZU5hdmlnYXRlRXZlbnQocGFnZTIsIHsgdmlzaXRJZCB9KTtcbiAgICBpZiAoT2JqZWN0LmtleXMocGFnZTIuZmxhc2gpLmxlbmd0aCA+IDApIHtcbiAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IGZpcmVGbGFzaEV2ZW50KHBhZ2UyLmZsYXNoKSk7XG4gICAgfVxuICB9XG59O1xuXG4vLyBzcmMvcG9sbC50c1xudmFyIFBvbGwgPSBjbGFzcyB7XG4gIGludGVydmFsSWQgPSBudWxsO1xuICB0aW1lb3V0SWQgPSBudWxsO1xuICB0aHJvdHRsZSA9IGZhbHNlO1xuICBrZWVwQWxpdmUgPSBmYWxzZTtcbiAgY2I7XG4gIGludGVydmFsO1xuICBjYkNvdW50ID0gMDtcbiAgbW9kZTtcbiAgaW5GbGlnaHQgPSBmYWxzZTtcbiAgY3VycmVudENhbmNlbCA9IG51bGw7XG4gIHN0b3BwZWQgPSB0cnVlO1xuICBpbnN0YW5jZUlkID0gMDtcbiAgY29uc3RydWN0b3IoaW50ZXJ2YWwsIGNiLCBvcHRpb25zKSB7XG4gICAgdGhpcy5rZWVwQWxpdmUgPSBvcHRpb25zLmtlZXBBbGl2ZSA/PyBmYWxzZTtcbiAgICB0aGlzLm1vZGUgPSBvcHRpb25zLm1vZGUgPz8gXCJvdmVybGFwXCI7XG4gICAgdGhpcy5jYiA9IGNiO1xuICAgIHRoaXMuaW50ZXJ2YWwgPSBpbnRlcnZhbDtcbiAgICBpZiAob3B0aW9ucy5hdXRvU3RhcnQgPz8gdHJ1ZSkge1xuICAgICAgdGhpcy5zdGFydCgpO1xuICAgIH1cbiAgfVxuICBzdG9wKCkge1xuICAgIHRoaXMuc3RvcHBlZCA9IHRydWU7XG4gICAgdGhpcy5pbnN0YW5jZUlkKys7XG4gICAgdGhpcy5pbkZsaWdodCA9IGZhbHNlO1xuICAgIHRoaXMuY3VycmVudENhbmNlbCA9IG51bGw7XG4gICAgaWYgKHRoaXMuaW50ZXJ2YWxJZCkge1xuICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLmludGVydmFsSWQpO1xuICAgICAgdGhpcy5pbnRlcnZhbElkID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKHRoaXMudGltZW91dElkKSB7XG4gICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lb3V0SWQpO1xuICAgICAgdGhpcy50aW1lb3V0SWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICBzdGFydCgpIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnN0b3AoKTtcbiAgICB0aGlzLnN0b3BwZWQgPSBmYWxzZTtcbiAgICBpZiAodGhpcy5tb2RlID09PSBcInJlc3RcIikge1xuICAgICAgdGhpcy5zY2hlZHVsZU5leHQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5pbnRlcnZhbElkID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHRoaXMudGljaygpLCB0aGlzLmludGVydmFsKTtcbiAgfVxuICBpc0luQmFja2dyb3VuZChoaWRkZW4yKSB7XG4gICAgdGhpcy50aHJvdHRsZSA9IHRoaXMua2VlcEFsaXZlID8gZmFsc2UgOiBoaWRkZW4yO1xuICAgIGlmICh0aGlzLnRocm90dGxlKSB7XG4gICAgICB0aGlzLmNiQ291bnQgPSAwO1xuICAgIH1cbiAgfVxuICBzY2hlZHVsZU5leHQoKSB7XG4gICAgaWYgKHRoaXMuc3RvcHBlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnRpbWVvdXRJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMudGltZW91dElkID0gbnVsbDtcbiAgICAgIHRoaXMudGljaygpO1xuICAgIH0sIHRoaXMuaW50ZXJ2YWwpO1xuICB9XG4gIHRpY2soKSB7XG4gICAgaWYgKCF0aGlzLnRocm90dGxlIHx8IHRoaXMuY2JDb3VudCAlIDEwID09PSAwKSB7XG4gICAgICB0aGlzLmZpcmUoKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMubW9kZSA9PT0gXCJyZXN0XCIpIHtcbiAgICAgIHRoaXMuc2NoZWR1bGVOZXh0KCk7XG4gICAgfVxuICAgIGlmICh0aGlzLnRocm90dGxlKSB7XG4gICAgICB0aGlzLmNiQ291bnQrKztcbiAgICB9XG4gIH1cbiAgZmlyZSgpIHtcbiAgICBpZiAodGhpcy5pbkZsaWdodCAmJiB0aGlzLm1vZGUgPT09IFwiY2FuY2VsXCIpIHtcbiAgICAgIHRoaXMuY3VycmVudENhbmNlbD8uKCk7XG4gICAgfVxuICAgIGNvbnN0IGluc3RhbmNlID0gdGhpcy5pbnN0YW5jZUlkO1xuICAgIHRoaXMuY2Ioe1xuICAgICAgb25TdGFydDogKGNhbmNlbCkgPT4ge1xuICAgICAgICBpZiAoaW5zdGFuY2UgIT09IHRoaXMuaW5zdGFuY2VJZCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmluRmxpZ2h0ID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jdXJyZW50Q2FuY2VsID0gY2FuY2VsO1xuICAgICAgfSxcbiAgICAgIG9uRmluaXNoOiAoKSA9PiB7XG4gICAgICAgIGlmIChpbnN0YW5jZSAhPT0gdGhpcy5pbnN0YW5jZUlkKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaW5GbGlnaHQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5jdXJyZW50Q2FuY2VsID0gbnVsbDtcbiAgICAgICAgaWYgKHRoaXMubW9kZSA9PT0gXCJyZXN0XCIpIHtcbiAgICAgICAgICB0aGlzLnNjaGVkdWxlTmV4dCgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn07XG5cbi8vIHNyYy9wb2xscy50c1xudmFyIFBvbGxzID0gY2xhc3Mge1xuICBwb2xscyA9IFtdO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnNldHVwVmlzaWJpbGl0eUxpc3RlbmVyKCk7XG4gIH1cbiAgZ2V0IGNvdW50KCkge1xuICAgIHJldHVybiB0aGlzLnBvbGxzLmxlbmd0aDtcbiAgfVxuICBhZGQoaW50ZXJ2YWwsIGNiLCBvcHRpb25zKSB7XG4gICAgY29uc3QgcG9sbCA9IG5ldyBQb2xsKGludGVydmFsLCBjYiwgb3B0aW9ucyk7XG4gICAgdGhpcy5wb2xscy5wdXNoKHBvbGwpO1xuICAgIHJldHVybiB7XG4gICAgICBzdG9wOiAoKSA9PiBwb2xsLnN0b3AoKSxcbiAgICAgIHN0YXJ0OiAoKSA9PiBwb2xsLnN0YXJ0KCksXG4gICAgICBkZXN0cm95OiAoKSA9PiB7XG4gICAgICAgIHBvbGwuc3RvcCgpO1xuICAgICAgICB0aGlzLnBvbGxzID0gdGhpcy5wb2xscy5maWx0ZXIoKHApID0+IHAgIT09IHBvbGwpO1xuICAgICAgfVxuICAgIH07XG4gIH1cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5wb2xscy5mb3JFYWNoKChwb2xsKSA9PiBwb2xsLnN0b3AoKSk7XG4gICAgdGhpcy5wb2xscyA9IFtdO1xuICB9XG4gIHNldHVwVmlzaWJpbGl0eUxpc3RlbmVyKCkge1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgIFwidmlzaWJpbGl0eWNoYW5nZVwiLFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBvbGxzLmZvckVhY2goKHBvbGwpID0+IHBvbGwuaXNJbkJhY2tncm91bmQoZG9jdW1lbnQuaGlkZGVuKSk7XG4gICAgICB9LFxuICAgICAgZmFsc2VcbiAgICApO1xuICB9XG59O1xudmFyIHBvbGxzID0gbmV3IFBvbGxzKCk7XG5cbi8vIHNyYy9yZXF1ZXN0LnRzXG5pbXBvcnQgeyBnZXQgYXMgZ2V0NiB9IGZyb20gXCJlcy10b29sa2l0L2NvbXBhdFwiO1xuXG4vLyBzcmMvaHR0cC50c1xuaW1wb3J0IHsgY2xpZW50IGFzIHByZWNvZ25pdGlvbkNsaWVudCB9IGZyb20gXCJsYXJhdmVsLXByZWNvZ25pdGlvblwiO1xuXG4vLyBzcmMvaHR0cEhhbmRsZXJzLnRzXG52YXIgSHR0cEhhbmRsZXJzID0gY2xhc3Mge1xuICByZXF1ZXN0SGFuZGxlcnMgPSBbXTtcbiAgcmVzcG9uc2VIYW5kbGVycyA9IFtdO1xuICBlcnJvckhhbmRsZXJzID0gW107XG4gIG9uUmVxdWVzdChoYW5kbGVyKSB7XG4gICAgdGhpcy5yZXF1ZXN0SGFuZGxlcnMucHVzaChoYW5kbGVyKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdGhpcy5yZXF1ZXN0SGFuZGxlcnMgPSB0aGlzLnJlcXVlc3RIYW5kbGVycy5maWx0ZXIoKGgpID0+IGggIT09IGhhbmRsZXIpO1xuICAgIH07XG4gIH1cbiAgb25SZXNwb25zZShoYW5kbGVyKSB7XG4gICAgdGhpcy5yZXNwb25zZUhhbmRsZXJzLnB1c2goaGFuZGxlcik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMucmVzcG9uc2VIYW5kbGVycyA9IHRoaXMucmVzcG9uc2VIYW5kbGVycy5maWx0ZXIoKGgpID0+IGggIT09IGhhbmRsZXIpO1xuICAgIH07XG4gIH1cbiAgb25FcnJvcihoYW5kbGVyKSB7XG4gICAgdGhpcy5lcnJvckhhbmRsZXJzLnB1c2goaGFuZGxlcik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMuZXJyb3JIYW5kbGVycyA9IHRoaXMuZXJyb3JIYW5kbGVycy5maWx0ZXIoKGgpID0+IGggIT09IGhhbmRsZXIpO1xuICAgIH07XG4gIH1cbiAgYXN5bmMgcHJvY2Vzc1JlcXVlc3QoY29uZmlnMikge1xuICAgIGxldCByZXN1bHQgPSBjb25maWcyO1xuICAgIGZvciAoY29uc3QgaGFuZGxlciBvZiB0aGlzLnJlcXVlc3RIYW5kbGVycykge1xuICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlcihyZXN1bHQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGFzeW5jIHByb2Nlc3NSZXNwb25zZShyZXNwb25zZSkge1xuICAgIGxldCByZXN1bHQgPSByZXNwb25zZTtcbiAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2YgdGhpcy5yZXNwb25zZUhhbmRsZXJzKSB7XG4gICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVyKHJlc3VsdCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgYXN5bmMgcHJvY2Vzc0Vycm9yKGVycm9yKSB7XG4gICAgZm9yIChjb25zdCBoYW5kbGVyIG9mIHRoaXMuZXJyb3JIYW5kbGVycykge1xuICAgICAgYXdhaXQgaGFuZGxlcihlcnJvcik7XG4gICAgfVxuICB9XG59O1xudmFyIGh0dHBIYW5kbGVycyA9IG5ldyBIdHRwSGFuZGxlcnMoKTtcblxuLy8gc3JjL2h0dHBFcnJvcnMudHNcbnZhciBIdHRwRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgY29kZTtcbiAgdXJsO1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBjb2RlLCB1cmwpIHtcbiAgICBzdXBlcih1cmwgPyBgJHttZXNzYWdlfSAoJHt1cmx9KWAgOiBtZXNzYWdlKTtcbiAgICB0aGlzLm5hbWUgPSBcIkh0dHBFcnJvclwiO1xuICAgIHRoaXMuY29kZSA9IGNvZGU7XG4gICAgdGhpcy51cmwgPSB1cmw7XG4gIH1cbn07XG52YXIgSHR0cFJlc3BvbnNlRXJyb3IgPSBjbGFzcyBleHRlbmRzIEh0dHBFcnJvciB7XG4gIHJlc3BvbnNlO1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlLCByZXNwb25zZSwgdXJsKSB7XG4gICAgc3VwZXIobWVzc2FnZSwgXCJFUlJfSFRUUF9SRVNQT05TRVwiLCB1cmwpO1xuICAgIHRoaXMubmFtZSA9IFwiSHR0cFJlc3BvbnNlRXJyb3JcIjtcbiAgICB0aGlzLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gIH1cbn07XG52YXIgSHR0cENhbmNlbGxlZEVycm9yID0gY2xhc3MgZXh0ZW5kcyBIdHRwRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlID0gXCJSZXF1ZXN0IHdhcyBjYW5jZWxsZWRcIiwgdXJsKSB7XG4gICAgc3VwZXIobWVzc2FnZSwgXCJFUlJfQ0FOQ0VMTEVEXCIsIHVybCk7XG4gICAgdGhpcy5uYW1lID0gXCJIdHRwQ2FuY2VsbGVkRXJyb3JcIjtcbiAgfVxufTtcbnZhciBIdHRwTmV0d29ya0Vycm9yID0gY2xhc3MgZXh0ZW5kcyBIdHRwRXJyb3Ige1xuICBjYXVzZTtcbiAgY29uc3RydWN0b3IobWVzc2FnZSwgdXJsLCBjYXVzZSkge1xuICAgIHN1cGVyKG1lc3NhZ2UsIFwiRVJSX05FVFdPUktcIiwgdXJsKTtcbiAgICB0aGlzLm5hbWUgPSBcIkh0dHBOZXR3b3JrRXJyb3JcIjtcbiAgICB0aGlzLmNhdXNlID0gY2F1c2U7XG4gIH1cbn07XG5cbi8vIHNyYy94aHJIdHRwQ2xpZW50LnRzXG5mdW5jdGlvbiBnZXRDb29raWUobmFtZSkge1xuICBjb25zdCBtYXRjaCA9IGRvY3VtZW50LmNvb2tpZS5tYXRjaChuZXcgUmVnRXhwKFwiKF58O1xcXFxzKikoXCIgKyBuYW1lICsgXCIpPShbXjtdKilcIikpO1xuICByZXR1cm4gbWF0Y2ggPyBkZWNvZGVVUklDb21wb25lbnQobWF0Y2hbM10pIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHBhcnNlSGVhZGVycyh4aHIpIHtcbiAgY29uc3QgaGVhZGVycyA9IHt9O1xuICB4aHIuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzKCkuc3BsaXQoXCJcXHJcXG5cIikuZm9yRWFjaCgobGluZSkgPT4ge1xuICAgIGNvbnN0IGluZGV4ID0gbGluZS5pbmRleE9mKFwiOlwiKTtcbiAgICBpZiAoaW5kZXggPiAwKSB7XG4gICAgICBoZWFkZXJzW2xpbmUuc2xpY2UoMCwgaW5kZXgpLnRvTG93ZXJDYXNlKCkudHJpbSgpXSA9IGxpbmUuc2xpY2UoaW5kZXggKyAxKS50cmltKCk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGhlYWRlcnM7XG59XG5mdW5jdGlvbiBpc0Zvcm1EYXRhUmVxdWVzdEJvZHkodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiBGb3JtRGF0YSAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZvcm1EYXRhO1xufVxuZnVuY3Rpb24gaXNSYXdSZXF1ZXN0Qm9keSh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IGlzRm9ybURhdGFSZXF1ZXN0Qm9keSh2YWx1ZSkgfHwgdHlwZW9mIEJsb2IgIT09IFwidW5kZWZpbmVkXCIgJiYgdmFsdWUgaW5zdGFuY2VvZiBCbG9iIHx8IHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyIHx8IHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gXCJ1bmRlZmluZWRcIiAmJiBBcnJheUJ1ZmZlci5pc1ZpZXcodmFsdWUpIHx8IHR5cGVvZiBVUkxTZWFyY2hQYXJhbXMgIT09IFwidW5kZWZpbmVkXCIgJiYgdmFsdWUgaW5zdGFuY2VvZiBVUkxTZWFyY2hQYXJhbXM7XG59XG5mdW5jdGlvbiBzZXRIZWFkZXJzKHhociwgY29uZmlnMikge1xuICBpZiAoIWNvbmZpZzIuaGVhZGVycykge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBpc0Zvcm1EYXRhMiA9IGlzRm9ybURhdGFSZXF1ZXN0Qm9keShjb25maWcyLmRhdGEpO1xuICBPYmplY3QuZW50cmllcyhjb25maWcyLmhlYWRlcnMpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgIGlmIChrZXkudG9Mb3dlckNhc2UoKSAhPT0gXCJjb250ZW50LXR5cGVcIiB8fCAhaXNGb3JtRGF0YTIpIHtcbiAgICAgIHhoci5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgU3RyaW5nKHZhbHVlKSk7XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIGJ1aWxkVXJsV2l0aFBhcmFtcyh1cmwsIHBhcmFtcykge1xuICBpZiAoIXBhcmFtcyB8fCBPYmplY3Qua2V5cyhwYXJhbXMpLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB1cmw7XG4gIH1cbiAgY29uc3QgW3VybFdpdGhQYXJhbXNdID0gbWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nKFwiZ2V0XCIsIHVybCwgcGFyYW1zKTtcbiAgcmV0dXJuIHVybFdpdGhQYXJhbXM7XG59XG52YXIgWGhySHR0cENsaWVudCA9IGNsYXNzIHtcbiAgeHNyZkNvb2tpZU5hbWU7XG4gIHhzcmZIZWFkZXJOYW1lO1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLnhzcmZDb29raWVOYW1lID0gb3B0aW9ucy54c3JmQ29va2llTmFtZSA/PyBcIlhTUkYtVE9LRU5cIjtcbiAgICB0aGlzLnhzcmZIZWFkZXJOYW1lID0gb3B0aW9ucy54c3JmSGVhZGVyTmFtZSA/PyBcIlgtWFNSRi1UT0tFTlwiO1xuICB9XG4gIGFzeW5jIHJlcXVlc3QoY29uZmlnMikge1xuICAgIGNvbnN0IHByb2Nlc3NlZENvbmZpZyA9IGF3YWl0IGh0dHBIYW5kbGVycy5wcm9jZXNzUmVxdWVzdChjb25maWcyKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmRvUmVxdWVzdChwcm9jZXNzZWRDb25maWcpO1xuICAgICAgcmV0dXJuIGF3YWl0IGh0dHBIYW5kbGVycy5wcm9jZXNzUmVzcG9uc2UocmVzcG9uc2UpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2VFcnJvciB8fCBlcnJvciBpbnN0YW5jZW9mIEh0dHBOZXR3b3JrRXJyb3IgfHwgZXJyb3IgaW5zdGFuY2VvZiBIdHRwQ2FuY2VsbGVkRXJyb3IpIHtcbiAgICAgICAgYXdhaXQgaHR0cEhhbmRsZXJzLnByb2Nlc3NFcnJvcihlcnJvcik7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cbiAgZG9SZXF1ZXN0KGNvbmZpZzIpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgY29uc3QgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICBjb25zdCB1cmwgPSBidWlsZFVybFdpdGhQYXJhbXMoY29uZmlnMi51cmwsIGNvbmZpZzIucGFyYW1zKTtcbiAgICAgIHhoci5vcGVuKGNvbmZpZzIubWV0aG9kLnRvVXBwZXJDYXNlKCksIHVybCwgdHJ1ZSk7XG4gICAgICBjb25zdCB4c3JmVG9rZW4gPSBnZXRDb29raWUodGhpcy54c3JmQ29va2llTmFtZSk7XG4gICAgICBpZiAoeHNyZlRva2VuKSB7XG4gICAgICAgIHhoci5zZXRSZXF1ZXN0SGVhZGVyKHRoaXMueHNyZkhlYWRlck5hbWUsIHhzcmZUb2tlbik7XG4gICAgICB9XG4gICAgICBjb25zdCBoYXNSZXF1ZXN0ZWRXaXRoSGVhZGVyID0gT2JqZWN0LmtleXMoY29uZmlnMi5oZWFkZXJzID8/IHt9KS5zb21lKFxuICAgICAgICAoa2V5KSA9PiBrZXkudG9Mb3dlckNhc2UoKSA9PT0gXCJ4LXJlcXVlc3RlZC13aXRoXCJcbiAgICAgICk7XG4gICAgICBpZiAoIWhhc1JlcXVlc3RlZFdpdGhIZWFkZXIpIHtcbiAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJYLVJlcXVlc3RlZC1XaXRoXCIsIFwiWE1MSHR0cFJlcXVlc3RcIik7XG4gICAgICB9XG4gICAgICBsZXQgYm9keSA9IG51bGw7XG4gICAgICBpZiAoY29uZmlnMi5kYXRhICE9PSBudWxsICYmIGNvbmZpZzIuZGF0YSAhPT0gdm9pZCAwKSB7XG4gICAgICAgIGlmIChpc1Jhd1JlcXVlc3RCb2R5KGNvbmZpZzIuZGF0YSkpIHtcbiAgICAgICAgICBib2R5ID0gY29uZmlnMi5kYXRhO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBjb25maWcyLmRhdGEgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkoY29uZmlnMi5kYXRhKTtcbiAgICAgICAgICBpZiAoIWNvbmZpZzIuaGVhZGVycz8uW1wiQ29udGVudC1UeXBlXCJdICYmICFjb25maWcyLmhlYWRlcnM/LltcImNvbnRlbnQtdHlwZVwiXSkge1xuICAgICAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBib2R5ID0gU3RyaW5nKGNvbmZpZzIuZGF0YSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHNldEhlYWRlcnMoeGhyLCBjb25maWcyKTtcbiAgICAgIGlmIChjb25maWcyLm9uVXBsb2FkUHJvZ3Jlc3MpIHtcbiAgICAgICAgeGhyLnVwbG9hZC5vbnByb2dyZXNzID0gKGV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgcHJvZ3Jlc3MzID0gZXZlbnQubGVuZ3RoQ29tcHV0YWJsZSA/IGV2ZW50LmxvYWRlZCAvIGV2ZW50LnRvdGFsIDogdm9pZCAwO1xuICAgICAgICAgIGNvbmZpZzIub25VcGxvYWRQcm9ncmVzcyh7XG4gICAgICAgICAgICBwcm9ncmVzczogcHJvZ3Jlc3MzLFxuICAgICAgICAgICAgcGVyY2VudGFnZTogcHJvZ3Jlc3MzID8gTWF0aC5yb3VuZChwcm9ncmVzczMgKiAxMDApIDogMCxcbiAgICAgICAgICAgIGxvYWRlZDogZXZlbnQubG9hZGVkLFxuICAgICAgICAgICAgdG90YWw6IGV2ZW50Lmxlbmd0aENvbXB1dGFibGUgPyBldmVudC50b3RhbCA6IHZvaWQgMFxuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKGNvbmZpZzIuc2lnbmFsKSB7XG4gICAgICAgIGNvbmZpZzIuc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCAoKSA9PiB4aHIuYWJvcnQoKSk7XG4gICAgICB9XG4gICAgICB4aHIub25hYm9ydCA9ICgpID0+IHJlamVjdChuZXcgSHR0cENhbmNlbGxlZEVycm9yKFwiUmVxdWVzdCB3YXMgY2FuY2VsbGVkXCIsIGNvbmZpZzIudXJsKSk7XG4gICAgICB4aHIub25lcnJvciA9ICgpID0+IHJlamVjdChuZXcgSHR0cE5ldHdvcmtFcnJvcihcIk5ldHdvcmsgZXJyb3JcIiwgY29uZmlnMi51cmwpKTtcbiAgICAgIHhoci5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0ge1xuICAgICAgICAgIHN0YXR1czogeGhyLnN0YXR1cyxcbiAgICAgICAgICBkYXRhOiB4aHIucmVzcG9uc2VUZXh0LFxuICAgICAgICAgIGhlYWRlcnM6IHBhcnNlSGVhZGVycyh4aHIpXG4gICAgICAgIH07XG4gICAgICAgIGlmICh4aHIuc3RhdHVzID49IDQwMCkge1xuICAgICAgICAgIHJlamVjdChuZXcgSHR0cFJlc3BvbnNlRXJyb3IoYFJlcXVlc3QgZmFpbGVkIHdpdGggc3RhdHVzICR7eGhyLnN0YXR1c31gLCByZXNwb25zZSwgY29uZmlnMi51cmwpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHhoci5zZW5kKGJvZHkpO1xuICAgIH0pO1xuICB9XG59O1xudmFyIHhockh0dHBDbGllbnQgPSBuZXcgWGhySHR0cENsaWVudCgpO1xuXG4vLyBzcmMvaHR0cC50c1xudmFyIGh0dHBDbGllbnQgPSB4aHJIdHRwQ2xpZW50O1xuZnVuY3Rpb24gaXNIdHRwQ2xpZW50T3B0aW9ucyhjbGllbnQpIHtcbiAgcmV0dXJuICEoXCJyZXF1ZXN0XCIgaW4gY2xpZW50KTtcbn1cbnZhciBodHRwID0ge1xuICAvKipcbiAgICogR2V0IHRoZSBjdXJyZW50IEhUVFAgY2xpZW50XG4gICAqL1xuICBnZXRDbGllbnQoKSB7XG4gICAgcmV0dXJuIGh0dHBDbGllbnQ7XG4gIH0sXG4gIC8qKlxuICAgKiBTZXQgdGhlIEhUVFAgY2xpZW50IHRvIHVzZSBmb3IgYWxsIEluZXJ0aWEgcmVxdWVzdHNcbiAgICovXG4gIHNldENsaWVudChjbGllbnRPck9wdGlvbnMpIHtcbiAgICBpZiAoIWlzSHR0cENsaWVudE9wdGlvbnMoY2xpZW50T3JPcHRpb25zKSkge1xuICAgICAgaHR0cENsaWVudCA9IGNsaWVudE9yT3B0aW9ucztcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaHR0cENsaWVudCA9IG5ldyBYaHJIdHRwQ2xpZW50KGNsaWVudE9yT3B0aW9ucyk7XG4gICAgaWYgKGNsaWVudE9yT3B0aW9ucy54c3JmQ29va2llTmFtZSkge1xuICAgICAgcHJlY29nbml0aW9uQ2xpZW50LndpdGhYc3JmQ29va2llTmFtZShjbGllbnRPck9wdGlvbnMueHNyZkNvb2tpZU5hbWUpO1xuICAgIH1cbiAgICBpZiAoY2xpZW50T3JPcHRpb25zLnhzcmZIZWFkZXJOYW1lKSB7XG4gICAgICBwcmVjb2duaXRpb25DbGllbnQud2l0aFhzcmZIZWFkZXJOYW1lKGNsaWVudE9yT3B0aW9ucy54c3JmSGVhZGVyTmFtZSk7XG4gICAgfVxuICB9LFxuICAvKipcbiAgICogUmVnaXN0ZXIgYSByZXF1ZXN0IGhhbmRsZXIgdGhhdCBydW5zIGJlZm9yZSBlYWNoIHJlcXVlc3RcbiAgICovXG4gIG9uUmVxdWVzdDogaHR0cEhhbmRsZXJzLm9uUmVxdWVzdC5iaW5kKGh0dHBIYW5kbGVycyksXG4gIC8qKlxuICAgKiBSZWdpc3RlciBhIHJlc3BvbnNlIGhhbmRsZXIgdGhhdCBydW5zIGFmdGVyIGVhY2ggc3VjY2Vzc2Z1bCByZXNwb25zZVxuICAgKi9cbiAgb25SZXNwb25zZTogaHR0cEhhbmRsZXJzLm9uUmVzcG9uc2UuYmluZChodHRwSGFuZGxlcnMpLFxuICAvKipcbiAgICogUmVnaXN0ZXIgYW4gZXJyb3IgaGFuZGxlciB0aGF0IHJ1bnMgd2hlbiBhIHJlcXVlc3QgZmFpbHNcbiAgICovXG4gIG9uRXJyb3I6IGh0dHBIYW5kbGVycy5vbkVycm9yLmJpbmQoaHR0cEhhbmRsZXJzKSxcbiAgLyoqXG4gICAqIFByb2Nlc3MgYSByZXF1ZXN0IGNvbmZpZyB0aHJvdWdoIGFsbCByZWdpc3RlcmVkIHJlcXVlc3QgaGFuZGxlcnMuXG4gICAqIEZvciB1c2UgYnkgY3VzdG9tIEh0dHBDbGllbnQgaW1wbGVtZW50YXRpb25zLlxuICAgKi9cbiAgcHJvY2Vzc1JlcXVlc3Q6IGh0dHBIYW5kbGVycy5wcm9jZXNzUmVxdWVzdC5iaW5kKGh0dHBIYW5kbGVycyksXG4gIC8qKlxuICAgKiBQcm9jZXNzIGEgcmVzcG9uc2UgdGhyb3VnaCBhbGwgcmVnaXN0ZXJlZCByZXNwb25zZSBoYW5kbGVycy5cbiAgICogRm9yIHVzZSBieSBjdXN0b20gSHR0cENsaWVudCBpbXBsZW1lbnRhdGlvbnMuXG4gICAqL1xuICBwcm9jZXNzUmVzcG9uc2U6IGh0dHBIYW5kbGVycy5wcm9jZXNzUmVzcG9uc2UuYmluZChodHRwSGFuZGxlcnMpLFxuICAvKipcbiAgICogUHJvY2VzcyBhbiBlcnJvciB0aHJvdWdoIGFsbCByZWdpc3RlcmVkIGVycm9yIGhhbmRsZXJzLlxuICAgKiBGb3IgdXNlIGJ5IGN1c3RvbSBIdHRwQ2xpZW50IGltcGxlbWVudGF0aW9ucy5cbiAgICovXG4gIHByb2Nlc3NFcnJvcjogaHR0cEhhbmRsZXJzLnByb2Nlc3NFcnJvci5iaW5kKGh0dHBIYW5kbGVycylcbn07XG5cbi8vIHNyYy9pbnRlcmNlcHRvcnMudHNcbnZhciBWaXNpdEludGVyY2VwdG9ycyA9IGNsYXNzIHtcbiAgcmVxdWVzdEhhbmRsZXJzID0gW107XG4gIHJlc3BvbnNlSGFuZGxlcnMgPSBbXTtcbiAgb25WaXNpdFJlcXVlc3QoaGFuZGxlcikge1xuICAgIHRoaXMucmVxdWVzdEhhbmRsZXJzLnB1c2goaGFuZGxlcik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMucmVxdWVzdEhhbmRsZXJzID0gdGhpcy5yZXF1ZXN0SGFuZGxlcnMuZmlsdGVyKChoKSA9PiBoICE9PSBoYW5kbGVyKTtcbiAgICB9O1xuICB9XG4gIG9uVmlzaXRSZXNwb25zZShoYW5kbGVyKSB7XG4gICAgdGhpcy5yZXNwb25zZUhhbmRsZXJzLnB1c2goaGFuZGxlcik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMucmVzcG9uc2VIYW5kbGVycyA9IHRoaXMucmVzcG9uc2VIYW5kbGVycy5maWx0ZXIoKGgpID0+IGggIT09IGhhbmRsZXIpO1xuICAgIH07XG4gIH1cbiAgYXN5bmMgcHJvY2Vzc1JlcXVlc3QodmlzaXQsIGNvbmZpZzIpIHtcbiAgICBsZXQgcmVzdWx0ID0gY29uZmlnMjtcbiAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2YgdGhpcy5yZXF1ZXN0SGFuZGxlcnMpIHtcbiAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZXIodmlzaXQsIHJlc3VsdCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgYXN5bmMgcHJvY2Vzc1Jlc3BvbnNlKHZpc2l0LCByZXNwb25zZSkge1xuICAgIGxldCByZXN1bHQgPSByZXNwb25zZTtcbiAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2YgdGhpcy5yZXNwb25zZUhhbmRsZXJzKSB7XG4gICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVyKHZpc2l0LCByZXN1bHQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG59O1xudmFyIGludGVyY2VwdG9ycyA9IG5ldyBWaXNpdEludGVyY2VwdG9ycygpO1xuZnVuY3Rpb24gZXhwb3NlSW50ZXJjZXB0b3JzKCkge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHJldHVybjtcbiAgfVxuICA7XG4gIHdpbmRvdy5fX2luZXJ0aWFfaW50ZXJjZXB0b3JzX18gPSBpbnRlcmNlcHRvcnM7XG59XG5cbi8vIHNyYy9yZXF1ZXN0UGFyYW1zLnRzXG52YXIgUmVxdWVzdFBhcmFtcyA9IGNsYXNzIF9SZXF1ZXN0UGFyYW1zIHtcbiAgY2FsbGJhY2tzID0gW107XG4gIHBhcmFtcztcbiAgY29uc3RydWN0b3IocGFyYW1zKSB7XG4gICAgaWYgKCFwYXJhbXMucHJlZmV0Y2gpIHtcbiAgICAgIHRoaXMucGFyYW1zID0gcGFyYW1zO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB3cmFwcGVkQ2FsbGJhY2tzID0ge1xuICAgICAgICBvbkJlZm9yZTogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uQmVmb3JlXCIpLFxuICAgICAgICBvbkJlZm9yZVVwZGF0ZTogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uQmVmb3JlVXBkYXRlXCIpLFxuICAgICAgICBvblN0YXJ0OiB0aGlzLndyYXBDYWxsYmFjayhwYXJhbXMsIFwib25TdGFydFwiKSxcbiAgICAgICAgb25Qcm9ncmVzczogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uUHJvZ3Jlc3NcIiksXG4gICAgICAgIG9uRmluaXNoOiB0aGlzLndyYXBDYWxsYmFjayhwYXJhbXMsIFwib25GaW5pc2hcIiksXG4gICAgICAgIG9uQ2FuY2VsOiB0aGlzLndyYXBDYWxsYmFjayhwYXJhbXMsIFwib25DYW5jZWxcIiksXG4gICAgICAgIG9uU3VjY2VzczogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uU3VjY2Vzc1wiKSxcbiAgICAgICAgb25FcnJvcjogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uRXJyb3JcIiksXG4gICAgICAgIG9uSHR0cEV4Y2VwdGlvbjogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uSHR0cEV4Y2VwdGlvblwiKSxcbiAgICAgICAgb25OZXR3b3JrRXJyb3I6IHRoaXMud3JhcENhbGxiYWNrKHBhcmFtcywgXCJvbk5ldHdvcmtFcnJvclwiKSxcbiAgICAgICAgb25GbGFzaDogdGhpcy53cmFwQ2FsbGJhY2socGFyYW1zLCBcIm9uRmxhc2hcIiksXG4gICAgICAgIG9uQ2FuY2VsVG9rZW46IHRoaXMud3JhcENhbGxiYWNrKHBhcmFtcywgXCJvbkNhbmNlbFRva2VuXCIpLFxuICAgICAgICBvblByZWZldGNoZWQ6IHRoaXMud3JhcENhbGxiYWNrKHBhcmFtcywgXCJvblByZWZldGNoZWRcIiksXG4gICAgICAgIG9uUHJlZmV0Y2hpbmc6IHRoaXMud3JhcENhbGxiYWNrKHBhcmFtcywgXCJvblByZWZldGNoaW5nXCIpXG4gICAgICB9O1xuICAgICAgdGhpcy5wYXJhbXMgPSB7XG4gICAgICAgIC4uLnBhcmFtcyxcbiAgICAgICAgLi4ud3JhcHBlZENhbGxiYWNrcyxcbiAgICAgICAgb25QcmVmZXRjaFJlc3BvbnNlOiBwYXJhbXMub25QcmVmZXRjaFJlc3BvbnNlIHx8ICgoKSA9PiB7XG4gICAgICAgIH0pLFxuICAgICAgICBvblByZWZldGNoRXJyb3I6IHBhcmFtcy5vblByZWZldGNoRXJyb3IgfHwgKCgpID0+IHtcbiAgICAgICAgfSlcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHN0YXRpYyBjcmVhdGUocGFyYW1zKSB7XG4gICAgcmV0dXJuIG5ldyBfUmVxdWVzdFBhcmFtcyhwYXJhbXMpO1xuICB9XG4gIGRhdGEoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFyYW1zLm1ldGhvZCA9PT0gXCJnZXRcIiA/IG51bGwgOiB0aGlzLnBhcmFtcy5kYXRhO1xuICB9XG4gIHF1ZXJ5UGFyYW1zKCkge1xuICAgIHJldHVybiB0aGlzLnBhcmFtcy5tZXRob2QgPT09IFwiZ2V0XCIgPyB0aGlzLnBhcmFtcy5kYXRhIDoge307XG4gIH1cbiAgaXNQYXJ0aWFsKCkge1xuICAgIHJldHVybiB0aGlzLnBhcmFtcy5vbmx5Lmxlbmd0aCA+IDAgfHwgdGhpcy5wYXJhbXMuZXhjZXB0Lmxlbmd0aCA+IDAgfHwgdGhpcy5wYXJhbXMucmVzZXQubGVuZ3RoID4gMDtcbiAgfVxuICBpc1ByZWZldGNoKCkge1xuICAgIHJldHVybiB0aGlzLnBhcmFtcy5wcmVmZXRjaCA9PT0gdHJ1ZTtcbiAgfVxuICBpc0RlZmVycmVkUHJvcHNSZXF1ZXN0KCkge1xuICAgIHJldHVybiB0aGlzLnBhcmFtcy5kZWZlcnJlZFByb3BzID09PSB0cnVlO1xuICB9XG4gIGlzUG9sbFJlcXVlc3QoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFyYW1zLnBvbGwgPT09IHRydWU7XG4gIH1cbiAgb25DYW5jZWxUb2tlbihjYikge1xuICAgIHRoaXMucGFyYW1zLm9uQ2FuY2VsVG9rZW4oe1xuICAgICAgY2FuY2VsOiBjYlxuICAgIH0pO1xuICB9XG4gIG1hcmtBc0ZpbmlzaGVkKCkge1xuICAgIHRoaXMucGFyYW1zLmNvbXBsZXRlZCA9IHRydWU7XG4gICAgdGhpcy5wYXJhbXMuY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgdGhpcy5wYXJhbXMuaW50ZXJydXB0ZWQgPSBmYWxzZTtcbiAgfVxuICBtYXJrQXNDYW5jZWxsZWQoeyBjYW5jZWxsZWQgPSB0cnVlLCBpbnRlcnJ1cHRlZCA9IGZhbHNlIH0pIHtcbiAgICB0aGlzLnBhcmFtcy5vbkNhbmNlbCgpO1xuICAgIHRoaXMucGFyYW1zLmNvbXBsZXRlZCA9IGZhbHNlO1xuICAgIHRoaXMucGFyYW1zLmNhbmNlbGxlZCA9IGNhbmNlbGxlZDtcbiAgICB0aGlzLnBhcmFtcy5pbnRlcnJ1cHRlZCA9IGludGVycnVwdGVkO1xuICB9XG4gIHdhc0NhbmNlbGxlZEF0QWxsKCkge1xuICAgIHJldHVybiB0aGlzLnBhcmFtcy5jYW5jZWxsZWQgfHwgdGhpcy5wYXJhbXMuaW50ZXJydXB0ZWQ7XG4gIH1cbiAgb25GaW5pc2goKSB7XG4gICAgdGhpcy5wYXJhbXMub25GaW5pc2godGhpcy5wYXJhbXMpO1xuICB9XG4gIG9uU3RhcnQoKSB7XG4gICAgdGhpcy5wYXJhbXMub25TdGFydCh0aGlzLnBhcmFtcyk7XG4gIH1cbiAgb25QcmVmZXRjaGluZygpIHtcbiAgICB0aGlzLnBhcmFtcy5vblByZWZldGNoaW5nKHRoaXMucGFyYW1zKTtcbiAgfVxuICBvblByZWZldGNoUmVzcG9uc2UocmVzcG9uc2UpIHtcbiAgICBpZiAodGhpcy5wYXJhbXMub25QcmVmZXRjaFJlc3BvbnNlKSB7XG4gICAgICB0aGlzLnBhcmFtcy5vblByZWZldGNoUmVzcG9uc2UocmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuICBvblByZWZldGNoRXJyb3IoZXJyb3IpIHtcbiAgICBpZiAodGhpcy5wYXJhbXMub25QcmVmZXRjaEVycm9yKSB7XG4gICAgICB0aGlzLnBhcmFtcy5vblByZWZldGNoRXJyb3IoZXJyb3IpO1xuICAgIH1cbiAgfVxuICBhbGwoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFyYW1zO1xuICB9XG4gIGhlYWRlcnMoKSB7XG4gICAgY29uc3QgaGVhZGVycyA9IHtcbiAgICAgIC4uLnRoaXMucGFyYW1zLmhlYWRlcnNcbiAgICB9O1xuICAgIGlmICh0aGlzLmlzUGFydGlhbCgpKSB7XG4gICAgICBoZWFkZXJzW1wiWC1JbmVydGlhLVBhcnRpYWwtQ29tcG9uZW50XCJdID0gcGFnZS5nZXQoKS5jb21wb25lbnQ7XG4gICAgfVxuICAgIGNvbnN0IG9ubHkgPSB0aGlzLnBhcmFtcy5vbmx5LmNvbmNhdCh0aGlzLnBhcmFtcy5yZXNldCk7XG4gICAgaWYgKG9ubHkubGVuZ3RoID4gMCkge1xuICAgICAgaGVhZGVyc1tcIlgtSW5lcnRpYS1QYXJ0aWFsLURhdGFcIl0gPSBvbmx5LmpvaW4oXCIsXCIpO1xuICAgIH1cbiAgICBpZiAodGhpcy5wYXJhbXMuZXhjZXB0Lmxlbmd0aCA+IDApIHtcbiAgICAgIGhlYWRlcnNbXCJYLUluZXJ0aWEtUGFydGlhbC1FeGNlcHRcIl0gPSB0aGlzLnBhcmFtcy5leGNlcHQuam9pbihcIixcIik7XG4gICAgfVxuICAgIGlmICh0aGlzLnBhcmFtcy5yZXNldC5sZW5ndGggPiAwKSB7XG4gICAgICBoZWFkZXJzW1wiWC1JbmVydGlhLVJlc2V0XCJdID0gdGhpcy5wYXJhbXMucmVzZXQuam9pbihcIixcIik7XG4gICAgfVxuICAgIGlmICh0aGlzLnBhcmFtcy5lcnJvckJhZyAmJiB0aGlzLnBhcmFtcy5lcnJvckJhZy5sZW5ndGggPiAwKSB7XG4gICAgICBoZWFkZXJzW1wiWC1JbmVydGlhLUVycm9yLUJhZ1wiXSA9IHRoaXMucGFyYW1zLmVycm9yQmFnO1xuICAgIH1cbiAgICByZXR1cm4gaGVhZGVycztcbiAgfVxuICBzZXRQcmVzZXJ2ZU9wdGlvbnMocGFnZTIpIHtcbiAgICB0aGlzLnBhcmFtcy5wcmVzZXJ2ZVNjcm9sbCA9IF9SZXF1ZXN0UGFyYW1zLnJlc29sdmVQcmVzZXJ2ZU9wdGlvbih0aGlzLnBhcmFtcy5wcmVzZXJ2ZVNjcm9sbCwgcGFnZTIpO1xuICAgIHRoaXMucGFyYW1zLnByZXNlcnZlU3RhdGUgPSBfUmVxdWVzdFBhcmFtcy5yZXNvbHZlUHJlc2VydmVPcHRpb24odGhpcy5wYXJhbXMucHJlc2VydmVTdGF0ZSwgcGFnZTIpO1xuICB9XG4gIHJ1bkNhbGxiYWNrcygpIHtcbiAgICB0aGlzLmNhbGxiYWNrcy5mb3JFYWNoKCh7IG5hbWUsIGFyZ3MgfSkgPT4ge1xuICAgICAgdGhpcy5wYXJhbXNbbmFtZV0oLi4uYXJncyk7XG4gICAgfSk7XG4gIH1cbiAgbWVyZ2UodG9NZXJnZSkge1xuICAgIHRoaXMucGFyYW1zID0ge1xuICAgICAgLi4udGhpcy5wYXJhbXMsXG4gICAgICAuLi50b01lcmdlXG4gICAgfTtcbiAgfVxuICB3cmFwQ2FsbGJhY2socGFyYW1zLCBuYW1lKSB7XG4gICAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgICB0aGlzLnJlY29yZENhbGxiYWNrKG5hbWUsIGFyZ3MpO1xuICAgICAgcGFyYW1zW25hbWVdKC4uLmFyZ3MpO1xuICAgIH07XG4gIH1cbiAgcmVjb3JkQ2FsbGJhY2sobmFtZSwgYXJncykge1xuICAgIHRoaXMuY2FsbGJhY2tzLnB1c2goeyBuYW1lLCBhcmdzIH0pO1xuICB9XG4gIHN0YXRpYyByZXNvbHZlUHJlc2VydmVPcHRpb24odmFsdWUsIHBhZ2UyKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICByZXR1cm4gdmFsdWUocGFnZTIpO1xuICAgIH1cbiAgICBpZiAodmFsdWUgPT09IFwiZXJyb3JzXCIpIHtcbiAgICAgIHJldHVybiBPYmplY3Qua2V5cyhwYWdlMi5wcm9wcy5lcnJvcnMgfHwge30pLmxlbmd0aCA+IDA7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxufTtcblxuLy8gc3JjL3Jlc3BvbnNlLnRzXG5pbXBvcnQgeyBpc0VxdWFsIGFzIGlzRXF1YWwyIH0gZnJvbSBcImVzLXRvb2xraXRcIjtcbmltcG9ydCB7IGdldCBhcyBnZXQ1LCBzZXQgYXMgc2V0NCB9IGZyb20gXCJlcy10b29sa2l0L2NvbXBhdFwiO1xuXG4vLyBzcmMvZGlhbG9nLnRzXG52YXIgZGlhbG9nX2RlZmF1bHQgPSB7XG4gIGNyZWF0ZUlmcmFtZUFuZFBhZ2UoaHRtbCkge1xuICAgIGlmICh0eXBlb2YgaHRtbCA9PT0gXCJvYmplY3RcIikge1xuICAgICAgaHRtbCA9IGBBbGwgSW5lcnRpYSByZXF1ZXN0cyBtdXN0IHJlY2VpdmUgYSB2YWxpZCBJbmVydGlhIHJlc3BvbnNlLCBob3dldmVyIGEgcGxhaW4gSlNPTiByZXNwb25zZSB3YXMgcmVjZWl2ZWQuPGhyPiR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgIGh0bWxcbiAgICAgICl9YDtcbiAgICB9XG4gICAgY29uc3QgcGFnZTIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaHRtbFwiKTtcbiAgICBwYWdlMi5pbm5lckhUTUwgPSBodG1sO1xuICAgIHBhZ2UyLnF1ZXJ5U2VsZWN0b3JBbGwoXCJhXCIpLmZvckVhY2goKGEpID0+IGEuc2V0QXR0cmlidXRlKFwidGFyZ2V0XCIsIFwiX3RvcFwiKSk7XG4gICAgY29uc3QgaWZyYW1lID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImlmcmFtZVwiKTtcbiAgICBpZnJhbWUuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gXCJ3aGl0ZVwiO1xuICAgIGlmcmFtZS5zdHlsZS5ib3JkZXJSYWRpdXMgPSBcIjVweFwiO1xuICAgIGlmcmFtZS5zdHlsZS53aWR0aCA9IFwiMTAwJVwiO1xuICAgIGlmcmFtZS5zdHlsZS5oZWlnaHQgPSBcIjEwMCVcIjtcbiAgICBpZnJhbWUuc2V0QXR0cmlidXRlKFwic2FuZGJveFwiLCBcImFsbG93LXNjcmlwdHNcIik7XG4gICAgcmV0dXJuIHsgaWZyYW1lLCBwYWdlOiBwYWdlMiB9O1xuICB9LFxuICBzaG93KGh0bWwpIHtcbiAgICBjb25zdCB7IGlmcmFtZSwgcGFnZTogcGFnZTIgfSA9IHRoaXMuY3JlYXRlSWZyYW1lQW5kUGFnZShodG1sKTtcbiAgICBpZnJhbWUuc3R5bGUuYm94U2l6aW5nID0gXCJib3JkZXItYm94XCI7XG4gICAgaWZyYW1lLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgY29uc3QgZGlhbG9nID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpYWxvZ1wiKTtcbiAgICBkaWFsb2cuaWQgPSBcImluZXJ0aWEtZXJyb3ItZGlhbG9nXCI7XG4gICAgT2JqZWN0LmFzc2lnbihkaWFsb2cuc3R5bGUsIHtcbiAgICAgIHdpZHRoOiBcImNhbGMoMTAwdncgLSAxMDBweClcIixcbiAgICAgIGhlaWdodDogXCJjYWxjKDEwMHZoIC0gMTAwcHgpXCIsXG4gICAgICBwYWRkaW5nOiBcIjBcIixcbiAgICAgIG1hcmdpbjogXCJhdXRvXCIsXG4gICAgICBib3JkZXI6IFwibm9uZVwiLFxuICAgICAgYmFja2dyb3VuZENvbG9yOiBcInRyYW5zcGFyZW50XCJcbiAgICB9KTtcbiAgICBjb25zdCBkaWFsb2dTdHlsZUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG4gICAgZGlhbG9nU3R5bGVFbGVtZW50LnRleHRDb250ZW50ID0gYFxuICAgICAgZGlhbG9nI2luZXJ0aWEtZXJyb3ItZGlhbG9nOjpiYWNrZHJvcCB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42KTtcbiAgICAgIH1cblxuICAgICAgZGlhbG9nI2luZXJ0aWEtZXJyb3ItZGlhbG9nOmZvY3VzIHtcbiAgICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgIH1cbiAgICBgO1xuICAgIGNvbnN0IG5vbmNlID0gY29uZmlnLmdldChcIm5vbmNlXCIpO1xuICAgIGlmIChub25jZSkge1xuICAgICAgZGlhbG9nU3R5bGVFbGVtZW50Lm5vbmNlID0gbm9uY2U7XG4gICAgfVxuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoZGlhbG9nU3R5bGVFbGVtZW50KTtcbiAgICBkaWFsb2cuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChldmVudCkgPT4ge1xuICAgICAgaWYgKGV2ZW50LnRhcmdldCA9PT0gZGlhbG9nKSB7XG4gICAgICAgIGRpYWxvZy5jbG9zZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGRpYWxvZy5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgKCkgPT4ge1xuICAgICAgZGlhbG9nU3R5bGVFbGVtZW50LnJlbW92ZSgpO1xuICAgICAgZGlhbG9nLnJlbW92ZSgpO1xuICAgIH0pO1xuICAgIGRpYWxvZy5hcHBlbmRDaGlsZChpZnJhbWUpO1xuICAgIGRvY3VtZW50LmJvZHkucHJlcGVuZChkaWFsb2cpO1xuICAgIGRpYWxvZy5zaG93TW9kYWwoKTtcbiAgICBkaWFsb2cuZm9jdXMoKTtcbiAgICBpZnJhbWUuc3JjZG9jID0gcGFnZTIub3V0ZXJIVE1MO1xuICB9XG59O1xuXG4vLyBzcmMvcGFydGlhbFJlbG9hZC50c1xudmFyIGlzUGF0aE9yU3ViUGF0aCA9IChwYXRoLCBjYW5kaWRhdGUpID0+IHtcbiAgcmV0dXJuIHBhdGggPT09IGNhbmRpZGF0ZSB8fCBwYXRoLnN0YXJ0c1dpdGgoYCR7Y2FuZGlkYXRlfS5gKTtcbn07XG52YXIgcGFydGlhbFJlbG9hZFJlcXVlc3RzUHJvcCA9ICh2aXNpdCwgcHJvcCkgPT4ge1xuICBjb25zdCB7IG9ubHksIGV4Y2VwdCB9ID0gdmlzaXQ7XG4gIGlmIChvbmx5Lmxlbmd0aCA9PT0gMCAmJiBleGNlcHQubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChvbmx5Lmxlbmd0aCA+IDAgJiYgIW9ubHkuc29tZSgoY2FuZGlkYXRlKSA9PiBpc1BhdGhPclN1YlBhdGgocHJvcCwgY2FuZGlkYXRlKSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGV4Y2VwdC5sZW5ndGggPiAwICYmIGV4Y2VwdC5zb21lKChjYW5kaWRhdGUpID0+IGlzUGF0aE9yU3ViUGF0aChwcm9wLCBjYW5kaWRhdGUpKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn07XG52YXIgcGFydGlhbFJlbG9hZFJlcXVlc3RzU29tZVByb3BzID0gKHZpc2l0LCBwcm9wcykgPT4ge1xuICByZXR1cm4gcHJvcHMuc29tZSgocHJvcCkgPT4gcGFydGlhbFJlbG9hZFJlcXVlc3RzUHJvcCh2aXNpdCwgcHJvcCkpO1xufTtcblxuLy8gc3JjL3Jlc3BvbnNlLnRzXG52YXIgcXVldWUyID0gbmV3IFF1ZXVlKCk7XG52YXIgUmVzcG9uc2UgPSBjbGFzcyBfUmVzcG9uc2Uge1xuICBjb25zdHJ1Y3RvcihyZXF1ZXN0UGFyYW1zLCByZXNwb25zZSwgb3JpZ2luYXRpbmdQYWdlKSB7XG4gICAgdGhpcy5yZXF1ZXN0UGFyYW1zID0gcmVxdWVzdFBhcmFtcztcbiAgICB0aGlzLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgdGhpcy5vcmlnaW5hdGluZ1BhZ2UgPSBvcmlnaW5hdGluZ1BhZ2U7XG4gIH1cbiAgcmVxdWVzdFBhcmFtcztcbiAgcmVzcG9uc2U7XG4gIG9yaWdpbmF0aW5nUGFnZTtcbiAgd2FzUHJlZmV0Y2hlZCA9IGZhbHNlO1xuICBwcm9jZXNzZWQgPSBmYWxzZTtcbiAgc3RhdGljIGNyZWF0ZShwYXJhbXMsIHJlc3BvbnNlLCBvcmlnaW5hdGluZ1BhZ2UpIHtcbiAgICByZXR1cm4gbmV3IF9SZXNwb25zZShwYXJhbXMsIHJlc3BvbnNlLCBvcmlnaW5hdGluZ1BhZ2UpO1xuICB9XG4gIGlzUHJvY2Vzc2VkKCkge1xuICAgIHJldHVybiB0aGlzLnByb2Nlc3NlZDtcbiAgfVxuICBhc3luYyBoYW5kbGVQcmVmZXRjaCgpIHtcbiAgICBpZiAoaXNTYW1lVXJsV2l0aG91dEhhc2godGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnVybCwgd2luZG93LmxvY2F0aW9uKSkge1xuICAgICAgdGhpcy5oYW5kbGUoKTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgaGFuZGxlKCkge1xuICAgIHJldHVybiBxdWV1ZTIuYWRkKCgpID0+IHRoaXMucHJvY2VzcygpKTtcbiAgfVxuICBhc3luYyBwcm9jZXNzKCkge1xuICAgIGlmICh0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkucHJlZmV0Y2gpIHtcbiAgICAgIHRoaXMud2FzUHJlZmV0Y2hlZCA9IHRydWU7XG4gICAgICB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkucHJlZmV0Y2ggPSBmYWxzZTtcbiAgICAgIHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5vblByZWZldGNoZWQodGhpcy5yZXNwb25zZSwgdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpKTtcbiAgICAgIGZpcmVQcmVmZXRjaGVkRXZlbnQodGhpcy5yZXNwb25zZSwgdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpKTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgdGhpcy5yZXF1ZXN0UGFyYW1zLnJ1bkNhbGxiYWNrcygpO1xuICAgIHRoaXMucHJvY2Vzc2VkID0gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuaXNJbmVydGlhUmVzcG9uc2UoKSkge1xuICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlTm9uSW5lcnRpYVJlc3BvbnNlKCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmlzSHR0cEV4Y2VwdGlvbigpKSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IHtcbiAgICAgICAgLi4udGhpcy5yZXNwb25zZSxcbiAgICAgICAgZGF0YTogdGhpcy5nZXREYXRhRnJvbVJlc3BvbnNlKHRoaXMucmVzcG9uc2UuZGF0YSlcbiAgICAgIH07XG4gICAgICBpZiAodGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLm9uSHR0cEV4Y2VwdGlvbihyZXNwb25zZSkgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICghZmlyZUh0dHBFeGNlcHRpb25FdmVudChyZXNwb25zZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICBhd2FpdCBoaXN0b3J5LnByb2Nlc3NRdWV1ZSgpO1xuICAgIGhpc3RvcnkucHJlc2VydmVVcmwgPSB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkucHJlc2VydmVVcmw7XG4gICAgYXdhaXQgdGhpcy5zZXRQYWdlKCk7XG4gICAgY29uc3QgeyBmbGFzaCB9ID0gcGFnZS5nZXQoKTtcbiAgICBpZiAoT2JqZWN0LmtleXMoZmxhc2gpLmxlbmd0aCA+IDAgJiYgIXRoaXMucmVxdWVzdFBhcmFtcy5pc0RlZmVycmVkUHJvcHNSZXF1ZXN0KCkpIHtcbiAgICAgIGZpcmVGbGFzaEV2ZW50KGZsYXNoKTtcbiAgICAgIHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5vbkZsYXNoKGZsYXNoKTtcbiAgICB9XG4gICAgY29uc3QgZXJyb3JzID0gcGFnZS5nZXQoKS5wcm9wcy5lcnJvcnMgfHwge307XG4gICAgaWYgKE9iamVjdC5rZXlzKGVycm9ycykubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3Qgc2NvcGVkRXJyb3JzID0gdGhpcy5nZXRTY29wZWRFcnJvcnMoZXJyb3JzKTtcbiAgICAgIGZpcmVFcnJvckV2ZW50KHNjb3BlZEVycm9ycywgeyBwYWdlOiBwYWdlLmdldCgpLCB2aXNpdElkOiB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkuaWQgfSk7XG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLm9uRXJyb3Ioc2NvcGVkRXJyb3JzKTtcbiAgICB9XG4gICAgcm91dGVyLmZsdXNoQnlDYWNoZVRhZ3ModGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLmludmFsaWRhdGVDYWNoZVRhZ3MgfHwgW10pO1xuICAgIGlmICghdGhpcy53YXNQcmVmZXRjaGVkKSB7XG4gICAgICByb3V0ZXIuZmx1c2gocGFnZS5nZXQoKS51cmwpO1xuICAgIH1cbiAgICBmaXJlU3VjY2Vzc0V2ZW50KHBhZ2UuZ2V0KCksIHsgdmlzaXRJZDogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLmlkIH0pO1xuICAgIGF3YWl0IHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5vblN1Y2Nlc3MocGFnZS5nZXQoKSk7XG4gICAgaGlzdG9yeS5wcmVzZXJ2ZVVybCA9IGZhbHNlO1xuICB9XG4gIG1lcmdlUGFyYW1zKHBhcmFtcykge1xuICAgIHRoaXMucmVxdWVzdFBhcmFtcy5tZXJnZShwYXJhbXMpO1xuICB9XG4gIGdldFBhZ2VSZXNwb25zZSgpIHtcbiAgICBjb25zdCBkYXRhID0gdGhpcy5nZXREYXRhRnJvbVJlc3BvbnNlKHRoaXMucmVzcG9uc2UuZGF0YSk7XG4gICAgaWYgKHR5cGVvZiBkYXRhID09PSBcIm9iamVjdFwiKSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXNwb25zZS5kYXRhID0geyAuLi5kYXRhLCBmbGFzaDogZGF0YS5mbGFzaCA/PyB7fSwgcmVzY3VlZFByb3BzOiBkYXRhLnJlc2N1ZWRQcm9wcyA/PyBbXSB9O1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZXNwb25zZS5kYXRhID0gZGF0YTtcbiAgfVxuICBhc3luYyBoYW5kbGVOb25JbmVydGlhUmVzcG9uc2UoKSB7XG4gICAgaWYgKHRoaXMuaXNJbmVydGlhUmVkaXJlY3QoKSkge1xuICAgICAgcm91dGVyLnZpc2l0KHRoaXMuZ2V0SGVhZGVyKFwieC1pbmVydGlhLXJlZGlyZWN0XCIpLCB7XG4gICAgICAgIC4uLnRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKSxcbiAgICAgICAgbWV0aG9kOiBcImdldFwiLFxuICAgICAgICBkYXRhOiB7fVxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aGlzLmlzTG9jYXRpb25WaXNpdCgpKSB7XG4gICAgICBjb25zdCBsb2NhdGlvblVybCA9IGhyZWZUb1VybCh0aGlzLmdldEhlYWRlcihcIngtaW5lcnRpYS1sb2NhdGlvblwiKSk7XG4gICAgICBzZXRIYXNoSWZTYW1lVXJsKHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS51cmwsIGxvY2F0aW9uVXJsKTtcbiAgICAgIHJldHVybiB0aGlzLmxvY2F0aW9uVmlzaXQobG9jYXRpb25VcmwpO1xuICAgIH1cbiAgICBjb25zdCByZXNwb25zZSA9IHtcbiAgICAgIC4uLnRoaXMucmVzcG9uc2UsXG4gICAgICBkYXRhOiB0aGlzLmdldERhdGFGcm9tUmVzcG9uc2UodGhpcy5yZXNwb25zZS5kYXRhKVxuICAgIH07XG4gICAgaWYgKHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5vbkh0dHBFeGNlcHRpb24ocmVzcG9uc2UpID09PSBmYWxzZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoZmlyZUh0dHBFeGNlcHRpb25FdmVudChyZXNwb25zZSkpIHtcbiAgICAgIHJldHVybiBkaWFsb2dfZGVmYXVsdC5zaG93KHJlc3BvbnNlLmRhdGEpO1xuICAgIH1cbiAgfVxuICBpc0luZXJ0aWFSZXNwb25zZSgpIHtcbiAgICByZXR1cm4gdGhpcy5oYXNIZWFkZXIoXCJ4LWluZXJ0aWFcIik7XG4gIH1cbiAgaXNIdHRwRXhjZXB0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnJlc3BvbnNlLnN0YXR1cyA+PSA0MDA7XG4gIH1cbiAgaGFzU3RhdHVzKHN0YXR1czIpIHtcbiAgICByZXR1cm4gdGhpcy5yZXNwb25zZS5zdGF0dXMgPT09IHN0YXR1czI7XG4gIH1cbiAgZ2V0SGVhZGVyKGhlYWRlcikge1xuICAgIHJldHVybiB0aGlzLnJlc3BvbnNlLmhlYWRlcnNbaGVhZGVyXTtcbiAgfVxuICBoYXNIZWFkZXIoaGVhZGVyKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0SGVhZGVyKGhlYWRlcikgIT09IHZvaWQgMDtcbiAgfVxuICBpc0luZXJ0aWFSZWRpcmVjdCgpIHtcbiAgICByZXR1cm4gdGhpcy5oYXNTdGF0dXMoNDA5KSAmJiB0aGlzLmhhc0hlYWRlcihcIngtaW5lcnRpYS1yZWRpcmVjdFwiKTtcbiAgfVxuICBpc0xvY2F0aW9uVmlzaXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuaGFzU3RhdHVzKDQwOSkgJiYgdGhpcy5oYXNIZWFkZXIoXCJ4LWluZXJ0aWEtbG9jYXRpb25cIik7XG4gIH1cbiAgLyoqXG4gICAqIEBsaW5rIGh0dHBzOi8vaW5lcnRpYWpzLmNvbS9yZWRpcmVjdHMjZXh0ZXJuYWwtcmVkaXJlY3RzXG4gICAqL1xuICBsb2NhdGlvblZpc2l0KHVybCkge1xuICAgIHRyeSB7XG4gICAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCByZXNwb25zZVZlcnNpb24gPSB0aGlzLmdldEhlYWRlcihcIngtaW5lcnRpYS12ZXJzaW9uXCIpO1xuICAgICAgY29uc3QgdmVyc2lvbkNoYW5nZSA9ICEhcmVzcG9uc2VWZXJzaW9uICYmIHJlc3BvbnNlVmVyc2lvbiAhPT0gcGFnZS5nZXQoKS52ZXJzaW9uO1xuICAgICAgaWYgKCFmaXJlTG9jYXRpb25FdmVudCh1cmwsIHZlcnNpb25DaGFuZ2UpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICh2ZXJzaW9uQ2hhbmdlICYmIHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5hc3luYykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBTZXNzaW9uU3RvcmFnZS5zZXQoU2Vzc2lvblN0b3JhZ2UubG9jYXRpb25WaXNpdEtleSwge1xuICAgICAgICBwcmVzZXJ2ZVNjcm9sbDogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnByZXNlcnZlU2Nyb2xsID09PSB0cnVlXG4gICAgICB9KTtcbiAgICAgIGlmIChpc1NhbWVVcmxXaXRob3V0SGFzaCh3aW5kb3cubG9jYXRpb24sIHVybCkpIHtcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSB1cmwuaHJlZjtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICBhc3luYyBzZXRQYWdlKCkge1xuICAgIGNvbnN0IHBhZ2VSZXNwb25zZSA9IHRoaXMuZ2V0UGFnZVJlc3BvbnNlKCk7XG4gICAgaWYgKCF0aGlzLnNob3VsZFNldFBhZ2UocGFnZVJlc3BvbnNlKSkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICB0aGlzLnJlc3BvbnNlID0gYXdhaXQgaW50ZXJjZXB0b3JzLnByb2Nlc3NSZXNwb25zZSh0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCksIHRoaXMucmVzcG9uc2UpO1xuICAgIHRoaXMubWVyZ2VQcm9wcyhwYWdlUmVzcG9uc2UpO1xuICAgIHBhZ2UubWVyZ2VPbmNlUHJvcHNJbnRvUmVzcG9uc2UocGFnZVJlc3BvbnNlKTtcbiAgICB0aGlzLnByZXNlcnZlT3B0aW1pc3RpY1Byb3BzKHBhZ2VSZXNwb25zZSk7XG4gICAgdGhpcy5wcmVzZXJ2ZUVxdWFsUHJvcHMocGFnZVJlc3BvbnNlKTtcbiAgICBhd2FpdCB0aGlzLnNldFJlbWVtYmVyZWRTdGF0ZShwYWdlUmVzcG9uc2UpO1xuICAgIHRoaXMucmVxdWVzdFBhcmFtcy5zZXRQcmVzZXJ2ZU9wdGlvbnMocGFnZVJlc3BvbnNlKTtcbiAgICBwYWdlUmVzcG9uc2UudXJsID0gaGlzdG9yeS5wcmVzZXJ2ZVVybCA/IHBhZ2UuZ2V0KCkudXJsIDogdGhpcy5wYWdlVXJsKHBhZ2VSZXNwb25zZSk7XG4gICAgdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLm9uQmVmb3JlVXBkYXRlKHBhZ2VSZXNwb25zZSk7XG4gICAgZmlyZUJlZm9yZVVwZGF0ZUV2ZW50KHBhZ2VSZXNwb25zZSk7XG4gICAgcmV0dXJuIHBhZ2Uuc2V0KHBhZ2VSZXNwb25zZSwge1xuICAgICAgcmVwbGFjZTogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnJlcGxhY2UsXG4gICAgICBwcmVzZXJ2ZVNjcm9sbDogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnByZXNlcnZlU2Nyb2xsLFxuICAgICAgcHJlc2VydmVTdGF0ZTogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnByZXNlcnZlU3RhdGUsXG4gICAgICB2aWV3VHJhbnNpdGlvbjogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnZpZXdUcmFuc2l0aW9uLFxuICAgICAgY2FjaGVkOiB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkuY2FjaGVkLFxuICAgICAgdmlzaXRJZDogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLmlkXG4gICAgfSk7XG4gIH1cbiAgZ2V0RGF0YUZyb21SZXNwb25zZShyZXNwb25zZSkge1xuICAgIGlmICh0eXBlb2YgcmVzcG9uc2UgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlc3BvbnNlKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH1cbiAgfVxuICBzaG91bGRTZXRQYWdlKHBhZ2VSZXNwb25zZSkge1xuICAgIGlmICghdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLmFzeW5jKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMub3JpZ2luYXRpbmdQYWdlLmNvbXBvbmVudCAhPT0gcGFnZVJlc3BvbnNlLmNvbXBvbmVudCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICh0aGlzLm9yaWdpbmF0aW5nUGFnZS5jb21wb25lbnQgIT09IHBhZ2UuZ2V0KCkuY29tcG9uZW50KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IG9yaWdpbmF0aW5nVXJsID0gaHJlZlRvVXJsKHRoaXMub3JpZ2luYXRpbmdQYWdlLnVybCk7XG4gICAgY29uc3QgY3VycmVudFBhZ2VVcmwgPSBocmVmVG9VcmwocGFnZS5nZXQoKS51cmwpO1xuICAgIHJldHVybiBvcmlnaW5hdGluZ1VybC5vcmlnaW4gPT09IGN1cnJlbnRQYWdlVXJsLm9yaWdpbiAmJiBvcmlnaW5hdGluZ1VybC5wYXRobmFtZSA9PT0gY3VycmVudFBhZ2VVcmwucGF0aG5hbWU7XG4gIH1cbiAgcGFnZVVybChwYWdlUmVzcG9uc2UpIHtcbiAgICBjb25zdCByZXNwb25zZVVybCA9IGhyZWZUb1VybChwYWdlUmVzcG9uc2UudXJsKTtcbiAgICBpZiAocGFnZVJlc3BvbnNlLnByZXNlcnZlRnJhZ21lbnQpIHtcbiAgICAgIHJlc3BvbnNlVXJsLmhhc2ggPSB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkudXJsLmhhc2g7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldEhhc2hJZlNhbWVVcmwodGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnVybCwgcmVzcG9uc2VVcmwpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzcG9uc2VVcmwucGF0aG5hbWUgKyByZXNwb25zZVVybC5zZWFyY2ggKyByZXNwb25zZVVybC5oYXNoO1xuICB9XG4gIHByZXNlcnZlT3B0aW1pc3RpY1Byb3BzKHBhZ2VSZXNwb25zZSkge1xuICAgIGlmICghcm91dGVyLmhhc1BlbmRpbmdPcHRpbWlzdGljKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMocGFnZVJlc3BvbnNlLnByb3BzKSkge1xuICAgICAgaWYgKHBhZ2UuaGFzQmFzZWxpbmUoa2V5KSkge1xuICAgICAgICBwYWdlLnVwZGF0ZUJhc2VsaW5lKGtleSwgcGFnZVJlc3BvbnNlLnByb3BzW2tleV0pO1xuICAgICAgICBwYWdlUmVzcG9uc2UucHJvcHNba2V5XSA9IHBhZ2UuZ2V0KCkucHJvcHNba2V5XTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcHJlc2VydmVFcXVhbFByb3BzKHBhZ2VSZXNwb25zZSkge1xuICAgIGlmIChwYWdlUmVzcG9uc2UuY29tcG9uZW50ICE9PSBwYWdlLmdldCgpLmNvbXBvbmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50UGFnZVByb3BzID0gcGFnZS5nZXQoKS5wcm9wcztcbiAgICBPYmplY3QuZW50cmllcyhwYWdlUmVzcG9uc2UucHJvcHMpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgaWYgKGlzRXF1YWwyKHZhbHVlLCBjdXJyZW50UGFnZVByb3BzW2tleV0pKSB7XG4gICAgICAgIHBhZ2VSZXNwb25zZS5wcm9wc1trZXldID0gY3VycmVudFBhZ2VQcm9wc1trZXldO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIG1lcmdlUHJvcHMocGFnZVJlc3BvbnNlKSB7XG4gICAgaWYgKCF0aGlzLnJlcXVlc3RQYXJhbXMuaXNQYXJ0aWFsKCkgfHwgcGFnZVJlc3BvbnNlLmNvbXBvbmVudCAhPT0gcGFnZS5nZXQoKS5jb21wb25lbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcHJvcHNUb0FwcGVuZCA9IHBhZ2VSZXNwb25zZS5tZXJnZVByb3BzIHx8IFtdO1xuICAgIGNvbnN0IHByb3BzVG9QcmVwZW5kID0gcGFnZVJlc3BvbnNlLnByZXBlbmRQcm9wcyB8fCBbXTtcbiAgICBjb25zdCBwcm9wc1RvRGVlcE1lcmdlID0gcGFnZVJlc3BvbnNlLmRlZXBNZXJnZVByb3BzIHx8IFtdO1xuICAgIGNvbnN0IG1hdGNoUHJvcHNPbiA9IHBhZ2VSZXNwb25zZS5tYXRjaFByb3BzT24gfHwgW107XG4gICAgY29uc3QgbWVyZ2VQcm9wID0gKHByb3AsIHNob3VsZEFwcGVuZCkgPT4ge1xuICAgICAgY29uc3QgY3VycmVudFByb3AgPSBnZXQ1KHBhZ2UuZ2V0KCkucHJvcHMsIHByb3ApO1xuICAgICAgY29uc3QgaW5jb21pbmdQcm9wID0gZ2V0NShwYWdlUmVzcG9uc2UucHJvcHMsIHByb3ApO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5jb21pbmdQcm9wKSkge1xuICAgICAgICBjb25zdCBuZXdBcnJheSA9IHRoaXMubWVyZ2VPck1hdGNoSXRlbXMoXG4gICAgICAgICAgY3VycmVudFByb3AgfHwgW10sXG4gICAgICAgICAgaW5jb21pbmdQcm9wLFxuICAgICAgICAgIHByb3AsXG4gICAgICAgICAgbWF0Y2hQcm9wc09uLFxuICAgICAgICAgIHNob3VsZEFwcGVuZFxuICAgICAgICApO1xuICAgICAgICBzZXQ0KHBhZ2VSZXNwb25zZS5wcm9wcywgcHJvcCwgbmV3QXJyYXkpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgaW5jb21pbmdQcm9wID09PSBcIm9iamVjdFwiICYmIGluY29taW5nUHJvcCAhPT0gbnVsbCkge1xuICAgICAgICBjb25zdCBuZXdPYmplY3QgPSB7XG4gICAgICAgICAgLi4uY3VycmVudFByb3AgfHwge30sXG4gICAgICAgICAgLi4uaW5jb21pbmdQcm9wXG4gICAgICAgIH07XG4gICAgICAgIHNldDQocGFnZVJlc3BvbnNlLnByb3BzLCBwcm9wLCBuZXdPYmplY3QpO1xuICAgICAgfVxuICAgIH07XG4gICAgcHJvcHNUb0FwcGVuZC5mb3JFYWNoKChwcm9wKSA9PiBtZXJnZVByb3AocHJvcCwgdHJ1ZSkpO1xuICAgIHByb3BzVG9QcmVwZW5kLmZvckVhY2goKHByb3ApID0+IG1lcmdlUHJvcChwcm9wLCBmYWxzZSkpO1xuICAgIHByb3BzVG9EZWVwTWVyZ2UuZm9yRWFjaCgocHJvcCkgPT4ge1xuICAgICAgY29uc3QgY3VycmVudFByb3AgPSBnZXQ1KHBhZ2UuZ2V0KCkucHJvcHMsIHByb3ApO1xuICAgICAgY29uc3QgaW5jb21pbmdQcm9wID0gZ2V0NShwYWdlUmVzcG9uc2UucHJvcHMsIHByb3ApO1xuICAgICAgY29uc3QgZGVlcE1lcmdlID0gKHRhcmdldCwgc291cmNlLCBtYXRjaFByb3ApID0+IHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoc291cmNlKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLm1lcmdlT3JNYXRjaEl0ZW1zKHRhcmdldCwgc291cmNlLCBtYXRjaFByb3AsIG1hdGNoUHJvcHNPbik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBzb3VyY2UgPT09IFwib2JqZWN0XCIgJiYgc291cmNlICE9PSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKHNvdXJjZSkucmVkdWNlKFxuICAgICAgICAgICAgKGFjYywga2V5KSA9PiB7XG4gICAgICAgICAgICAgIGFjY1trZXldID0gZGVlcE1lcmdlKHRhcmdldCA/IHRhcmdldFtrZXldIDogdm9pZCAwLCBzb3VyY2Vba2V5XSwgYCR7bWF0Y2hQcm9wfS4ke2tleX1gKTtcbiAgICAgICAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7IC4uLnRhcmdldCB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc291cmNlO1xuICAgICAgfTtcbiAgICAgIHNldDQocGFnZVJlc3BvbnNlLnByb3BzLCBwcm9wLCBkZWVwTWVyZ2UoY3VycmVudFByb3AsIGluY29taW5nUHJvcCwgcHJvcCkpO1xuICAgIH0pO1xuICAgIGNvbnN0IG5lc3RlZFRvcEtleXMgPSBuZXcgU2V0KFxuICAgICAgWy4uLnRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5vbmx5LCAuLi50aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkuZXhjZXB0XS5maWx0ZXIoKHByb3ApID0+IHByb3AuaW5jbHVkZXMoXCIuXCIpKS5tYXAoKHByb3ApID0+IHByb3Auc3BsaXQoXCIuXCIpWzBdKVxuICAgICk7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgbmVzdGVkVG9wS2V5cykge1xuICAgICAgY29uc3QgY3VycmVudFZhbHVlID0gcGFnZS5nZXQoKS5wcm9wc1trZXldO1xuICAgICAgaWYgKHRoaXMuaXNPYmplY3QoY3VycmVudFZhbHVlKSAmJiB0aGlzLmlzT2JqZWN0KHBhZ2VSZXNwb25zZS5wcm9wc1trZXldKSkge1xuICAgICAgICBwYWdlUmVzcG9uc2UucHJvcHNba2V5XSA9IHRoaXMuZGVlcE1lcmdlT2JqZWN0cyhjdXJyZW50VmFsdWUsIHBhZ2VSZXNwb25zZS5wcm9wc1trZXldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcGFnZVJlc3BvbnNlLnByb3BzID0geyAuLi5wYWdlLmdldCgpLnByb3BzLCAuLi5wYWdlUmVzcG9uc2UucHJvcHMgfTtcbiAgICBpZiAodGhpcy5zaG91bGRQcmVzZXJ2ZUVycm9ycyhwYWdlUmVzcG9uc2UpKSB7XG4gICAgICBwYWdlUmVzcG9uc2UucHJvcHMuZXJyb3JzID0gcGFnZS5nZXQoKS5wcm9wcy5lcnJvcnM7XG4gICAgfVxuICAgIGlmIChwYWdlLmdldCgpLnNjcm9sbFByb3BzKSB7XG4gICAgICBwYWdlUmVzcG9uc2Uuc2Nyb2xsUHJvcHMgPSB7XG4gICAgICAgIC4uLnBhZ2UuZ2V0KCkuc2Nyb2xsUHJvcHMgfHwge30sXG4gICAgICAgIC4uLnBhZ2VSZXNwb25zZS5zY3JvbGxQcm9wcyB8fCB7fVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHBhZ2UuaGFzT25jZVByb3BzKCkpIHtcbiAgICAgIHBhZ2VSZXNwb25zZS5vbmNlUHJvcHMgPSB7XG4gICAgICAgIC4uLnBhZ2UuZ2V0KCkub25jZVByb3BzIHx8IHt9LFxuICAgICAgICAuLi5wYWdlUmVzcG9uc2Uub25jZVByb3BzIHx8IHt9XG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAodGhpcy5yZXF1ZXN0UGFyYW1zLmlzRGVmZXJyZWRQcm9wc1JlcXVlc3QoKSkge1xuICAgICAgcGFnZVJlc3BvbnNlLmZsYXNoID0geyAuLi5wYWdlLmdldCgpLmZsYXNoIH07XG4gICAgfVxuICAgIGNvbnN0IGN1cnJlbnRPcmlnaW5hbERlZmVycmVkID0gcGFnZS5nZXQoKS5pbml0aWFsRGVmZXJyZWRQcm9wcztcbiAgICBpZiAoY3VycmVudE9yaWdpbmFsRGVmZXJyZWQgJiYgT2JqZWN0LmtleXMoY3VycmVudE9yaWdpbmFsRGVmZXJyZWQpLmxlbmd0aCA+IDApIHtcbiAgICAgIHBhZ2VSZXNwb25zZS5pbml0aWFsRGVmZXJyZWRQcm9wcyA9IGN1cnJlbnRPcmlnaW5hbERlZmVycmVkO1xuICAgIH1cbiAgICBwYWdlUmVzcG9uc2UucmVzY3VlZFByb3BzID0gdGhpcy5tZXJnZVJlc2N1ZWRQcm9wcyhwYWdlUmVzcG9uc2UpO1xuICB9XG4gIG1lcmdlUmVzY3VlZFByb3BzKHBhZ2VSZXNwb25zZSkge1xuICAgIGNvbnN0IGN1cnJlbnRSZXNjdWVkID0gcGFnZS5nZXQoKS5yZXNjdWVkUHJvcHMgPz8gW107XG4gICAgY29uc3QgaW5jb21pbmdSZXNjdWVkID0gcGFnZVJlc3BvbnNlLnJlc2N1ZWRQcm9wcyA/PyBbXTtcbiAgICBjb25zdCBuZXdSZXNjdWVkID0gbmV3IFNldChcbiAgICAgIGN1cnJlbnRSZXNjdWVkLmZpbHRlcigocHJvcCkgPT4gIXBhcnRpYWxSZWxvYWRSZXF1ZXN0c1Byb3AodGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLCBwcm9wKSlcbiAgICApO1xuICAgIGluY29taW5nUmVzY3VlZC5mb3JFYWNoKChwcm9wKSA9PiBuZXdSZXNjdWVkLmFkZChwcm9wKSk7XG4gICAgcmV0dXJuIEFycmF5LmZyb20obmV3UmVzY3VlZCk7XG4gIH1cbiAgLyoqXG4gICAqIEJ5IGRlZmF1bHQsIHRoZSBMYXJhdmVsIGFkYXB0ZXIgc2hhcmVzIHZhbGlkYXRpb24gZXJyb3JzIHZpYSBJbmVydGlhOjphbHdheXMoKSxcbiAgICogc28gcmVzcG9uc2VzIGFsd2F5cyBpbmNsdWRlIGVycm9ycywgZXZlbiB3aGVuIGVtcHR5LiBDb21wb25lbnRzIGxpa2VcbiAgICogSW5maW5pdGVTY3JvbGwgYW5kIFdoZW5WaXNpYmxlLCBhcyB3ZWxsIGFzIGxvYWRpbmcgZGVmZXJyZWQgcHJvcHMsXG4gICAqIHBlcmZvcm0gYXN5bmMgcmVxdWVzdHMgdGhhdCBzaG91bGQgcHJhY3RpY2FsbHkgbmV2ZXIgcmVzZXQgZXJyb3JzLlxuICAgKi9cbiAgc2hvdWxkUHJlc2VydmVFcnJvcnMocGFnZVJlc3BvbnNlKSB7XG4gICAgaWYgKCF0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkucHJlc2VydmVFcnJvcnMpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgY3VycmVudEVycm9ycyA9IHBhZ2UuZ2V0KCkucHJvcHMuZXJyb3JzO1xuICAgIGlmICghY3VycmVudEVycm9ycyB8fCBPYmplY3Qua2V5cyhjdXJyZW50RXJyb3JzKS5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgcmVzcG9uc2VFcnJvcnMgPSBwYWdlUmVzcG9uc2UucHJvcHMuZXJyb3JzO1xuICAgIGlmIChyZXNwb25zZUVycm9ycyAmJiBPYmplY3Qua2V5cyhyZXNwb25zZUVycm9ycykubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpc09iamVjdChpdGVtKSB7XG4gICAgcmV0dXJuIGl0ZW0gJiYgdHlwZW9mIGl0ZW0gPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkoaXRlbSk7XG4gIH1cbiAgZGVlcE1lcmdlT2JqZWN0cyh0YXJnZXQsIHNvdXJjZSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IHsgLi4udGFyZ2V0IH07XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoc291cmNlKSkge1xuICAgICAgY29uc3QgdGFyZ2V0VmFsdWUgPSB0YXJnZXRba2V5XTtcbiAgICAgIGNvbnN0IHNvdXJjZVZhbHVlID0gc291cmNlW2tleV07XG4gICAgICBpZiAodGhpcy5pc09iamVjdCh0YXJnZXRWYWx1ZSkgJiYgdGhpcy5pc09iamVjdChzb3VyY2VWYWx1ZSkpIHtcbiAgICAgICAgcmVzdWx0W2tleV0gPSB0aGlzLmRlZXBNZXJnZU9iamVjdHModGFyZ2V0VmFsdWUsIHNvdXJjZVZhbHVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdFtrZXldID0gc291cmNlVmFsdWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgbWVyZ2VPck1hdGNoSXRlbXMoZXhpc3RpbmdJdGVtcywgbmV3SXRlbXMsIG1hdGNoUHJvcCwgbWF0Y2hQcm9wc09uLCBzaG91bGRBcHBlbmQgPSB0cnVlKSB7XG4gICAgY29uc3QgaXRlbXMgPSBBcnJheS5pc0FycmF5KGV4aXN0aW5nSXRlbXMpID8gZXhpc3RpbmdJdGVtcyA6IFtdO1xuICAgIGNvbnN0IG1hdGNoaW5nS2V5ID0gbWF0Y2hQcm9wc09uLmZpbmQoKGtleSkgPT4ge1xuICAgICAgY29uc3Qga2V5UGF0aCA9IGtleS5zcGxpdChcIi5cIikuc2xpY2UoMCwgLTEpLmpvaW4oXCIuXCIpO1xuICAgICAgcmV0dXJuIGtleVBhdGggPT09IG1hdGNoUHJvcDtcbiAgICB9KTtcbiAgICBpZiAoIW1hdGNoaW5nS2V5KSB7XG4gICAgICByZXR1cm4gc2hvdWxkQXBwZW5kID8gWy4uLml0ZW1zLCAuLi5uZXdJdGVtc10gOiBbLi4ubmV3SXRlbXMsIC4uLml0ZW1zXTtcbiAgICB9XG4gICAgY29uc3QgdW5pcXVlUHJvcGVydHkgPSBtYXRjaGluZ0tleS5zcGxpdChcIi5cIikucG9wKCkgfHwgXCJcIjtcbiAgICBjb25zdCBuZXdJdGVtc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgbmV3SXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xuICAgICAgaWYgKHRoaXMuaGFzVW5pcXVlUHJvcGVydHkoaXRlbSwgdW5pcXVlUHJvcGVydHkpKSB7XG4gICAgICAgIG5ld0l0ZW1zTWFwLnNldChpdGVtW3VuaXF1ZVByb3BlcnR5XSwgaXRlbSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHNob3VsZEFwcGVuZCA/IHRoaXMuYXBwZW5kV2l0aE1hdGNoaW5nKGl0ZW1zLCBuZXdJdGVtcywgbmV3SXRlbXNNYXAsIHVuaXF1ZVByb3BlcnR5KSA6IHRoaXMucHJlcGVuZFdpdGhNYXRjaGluZyhpdGVtcywgbmV3SXRlbXMsIG5ld0l0ZW1zTWFwLCB1bmlxdWVQcm9wZXJ0eSk7XG4gIH1cbiAgYXBwZW5kV2l0aE1hdGNoaW5nKGV4aXN0aW5nSXRlbXMsIG5ld0l0ZW1zLCBuZXdJdGVtc01hcCwgdW5pcXVlUHJvcGVydHkpIHtcbiAgICBjb25zdCB1cGRhdGVkRXhpc3RpbmcgPSBleGlzdGluZ0l0ZW1zLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgaWYgKHRoaXMuaGFzVW5pcXVlUHJvcGVydHkoaXRlbSwgdW5pcXVlUHJvcGVydHkpICYmIG5ld0l0ZW1zTWFwLmhhcyhpdGVtW3VuaXF1ZVByb3BlcnR5XSkpIHtcbiAgICAgICAgcmV0dXJuIG5ld0l0ZW1zTWFwLmdldChpdGVtW3VuaXF1ZVByb3BlcnR5XSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gaXRlbTtcbiAgICB9KTtcbiAgICBjb25zdCBuZXdJdGVtc1RvQWRkID0gbmV3SXRlbXMuZmlsdGVyKChpdGVtKSA9PiB7XG4gICAgICBpZiAoIXRoaXMuaGFzVW5pcXVlUHJvcGVydHkoaXRlbSwgdW5pcXVlUHJvcGVydHkpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuICFleGlzdGluZ0l0ZW1zLnNvbWUoXG4gICAgICAgIChleGlzdGluZykgPT4gdGhpcy5oYXNVbmlxdWVQcm9wZXJ0eShleGlzdGluZywgdW5pcXVlUHJvcGVydHkpICYmIGV4aXN0aW5nW3VuaXF1ZVByb3BlcnR5XSA9PT0gaXRlbVt1bmlxdWVQcm9wZXJ0eV1cbiAgICAgICk7XG4gICAgfSk7XG4gICAgcmV0dXJuIFsuLi51cGRhdGVkRXhpc3RpbmcsIC4uLm5ld0l0ZW1zVG9BZGRdO1xuICB9XG4gIHByZXBlbmRXaXRoTWF0Y2hpbmcoZXhpc3RpbmdJdGVtcywgbmV3SXRlbXMsIG5ld0l0ZW1zTWFwLCB1bmlxdWVQcm9wZXJ0eSkge1xuICAgIGNvbnN0IHVudG91Y2hlZEV4aXN0aW5nID0gZXhpc3RpbmdJdGVtcy5maWx0ZXIoKGl0ZW0pID0+IHtcbiAgICAgIGlmICh0aGlzLmhhc1VuaXF1ZVByb3BlcnR5KGl0ZW0sIHVuaXF1ZVByb3BlcnR5KSkge1xuICAgICAgICByZXR1cm4gIW5ld0l0ZW1zTWFwLmhhcyhpdGVtW3VuaXF1ZVByb3BlcnR5XSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgICByZXR1cm4gWy4uLm5ld0l0ZW1zLCAuLi51bnRvdWNoZWRFeGlzdGluZ107XG4gIH1cbiAgaGFzVW5pcXVlUHJvcGVydHkoaXRlbSwgcHJvcGVydHkpIHtcbiAgICByZXR1cm4gaXRlbSAmJiB0eXBlb2YgaXRlbSA9PT0gXCJvYmplY3RcIiAmJiBwcm9wZXJ0eSBpbiBpdGVtO1xuICB9XG4gIGFzeW5jIHNldFJlbWVtYmVyZWRTdGF0ZShwYWdlUmVzcG9uc2UpIHtcbiAgICBjb25zdCByZW1lbWJlcmVkU3RhdGUgPSBhd2FpdCBoaXN0b3J5LmdldFN0YXRlKGhpc3RvcnkucmVtZW1iZXJlZFN0YXRlLCB7fSk7XG4gICAgaWYgKHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5wcmVzZXJ2ZVN0YXRlICYmIHJlbWVtYmVyZWRTdGF0ZSAmJiBwYWdlUmVzcG9uc2UuY29tcG9uZW50ID09PSBwYWdlLmdldCgpLmNvbXBvbmVudCkge1xuICAgICAgcGFnZVJlc3BvbnNlLnJlbWVtYmVyZWRTdGF0ZSA9IHJlbWVtYmVyZWRTdGF0ZTtcbiAgICB9XG4gIH1cbiAgZ2V0U2NvcGVkRXJyb3JzKGVycm9ycykge1xuICAgIGlmICghdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLmVycm9yQmFnKSB7XG4gICAgICByZXR1cm4gZXJyb3JzO1xuICAgIH1cbiAgICByZXR1cm4gZXJyb3JzW3RoaXMucmVxdWVzdFBhcmFtcy5hbGwoKS5lcnJvckJhZyB8fCBcIlwiXSB8fCB7fTtcbiAgfVxufTtcblxuLy8gc3JjL3JlcXVlc3QudHNcbnZhciBSZXF1ZXN0ID0gY2xhc3MgX1JlcXVlc3Qge1xuICBjb25zdHJ1Y3RvcihwYXJhbXMsIHBhZ2UyLCB7IG9wdGltaXN0aWMgPSBmYWxzZSB9ID0ge30pIHtcbiAgICB0aGlzLnBhZ2UgPSBwYWdlMjtcbiAgICB0aGlzLnJlcXVlc3RQYXJhbXMgPSBSZXF1ZXN0UGFyYW1zLmNyZWF0ZShwYXJhbXMpO1xuICAgIHRoaXMuY2FuY2VsVG9rZW4gPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgdGhpcy5vcHRpbWlzdGljID0gb3B0aW1pc3RpYztcbiAgfVxuICBwYWdlO1xuICByZXNwb25zZTtcbiAgY2FuY2VsVG9rZW47XG4gIHJlcXVlc3RQYXJhbXM7XG4gIHJlcXVlc3RIYXNGaW5pc2hlZCA9IGZhbHNlO1xuICBvcHRpbWlzdGljO1xuICBzdGF0aWMgY3JlYXRlKHBhcmFtcywgcGFnZTIsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gbmV3IF9SZXF1ZXN0KHBhcmFtcywgcGFnZTIsIG9wdGlvbnMpO1xuICB9XG4gIGlzUHJlZmV0Y2goKSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdFBhcmFtcy5pc1ByZWZldGNoKCk7XG4gIH1cbiAgZ2V0VXJsKCkge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkudXJsO1xuICB9XG4gIGlzT3B0aW1pc3RpYygpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpbWlzdGljO1xuICB9XG4gIGlzUGVuZGluZ09wdGltaXN0aWMoKSB7XG4gICAgcmV0dXJuIHRoaXMuaXNPcHRpbWlzdGljKCkgJiYgKCF0aGlzLnJlc3BvbnNlIHx8ICF0aGlzLnJlc3BvbnNlLmlzUHJvY2Vzc2VkKCkpO1xuICB9XG4gIGFzeW5jIHNlbmQoKSB7XG4gICAgdGhpcy5yZXF1ZXN0UGFyYW1zLm9uQ2FuY2VsVG9rZW4oKCkgPT4ge1xuICAgICAgaWYgKHRoaXMucmVzcG9uc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdGhpcy5jYW5jZWwoeyBjYW5jZWxsZWQ6IHRydWUgfSk7XG4gICAgfSk7XG4gICAgZmlyZVN0YXJ0RXZlbnQodGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpKTtcbiAgICB0aGlzLnJlcXVlc3RQYXJhbXMub25TdGFydCgpO1xuICAgIGlmICh0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkucHJlZmV0Y2gpIHtcbiAgICAgIHRoaXMucmVxdWVzdFBhcmFtcy5vblByZWZldGNoaW5nKCk7XG4gICAgICBmaXJlUHJlZmV0Y2hpbmdFdmVudCh0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkpO1xuICAgIH1cbiAgICBjb25zdCBvcmlnaW5hbGx5UHJlZmV0Y2ggPSB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkucHJlZmV0Y2g7XG4gICAgY29uc3QgY29uZmlnMiA9IHtcbiAgICAgIG1ldGhvZDogdGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLm1ldGhvZCxcbiAgICAgIHVybDogdXJsV2l0aG91dEhhc2godGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpLnVybCkuaHJlZixcbiAgICAgIGRhdGE6IHRoaXMucmVxdWVzdFBhcmFtcy5kYXRhKCksXG4gICAgICBzaWduYWw6IHRoaXMuY2FuY2VsVG9rZW4uc2lnbmFsLFxuICAgICAgaGVhZGVyczogdGhpcy5nZXRIZWFkZXJzKCksXG4gICAgICBvblVwbG9hZFByb2dyZXNzOiB0aGlzLm9uUHJvZ3Jlc3MuYmluZCh0aGlzKVxuICAgIH07XG4gICAgY29uc3QgcHJvY2Vzc2VkQ29uZmlnID0gYXdhaXQgaW50ZXJjZXB0b3JzLnByb2Nlc3NSZXF1ZXN0KHRoaXMucmVxdWVzdFBhcmFtcy5hbGwoKSwgY29uZmlnMik7XG4gICAgcmV0dXJuIGh0dHAuZ2V0Q2xpZW50KCkucmVxdWVzdChwcm9jZXNzZWRDb25maWcpLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICB0aGlzLnJlc3BvbnNlID0gUmVzcG9uc2UuY3JlYXRlKHRoaXMucmVxdWVzdFBhcmFtcywgcmVzcG9uc2UsIHRoaXMucGFnZSk7XG4gICAgICByZXR1cm4gdGhpcy5yZXNwb25zZS5oYW5kbGUoKTtcbiAgICB9KS5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEh0dHBSZXNwb25zZUVycm9yKSB7XG4gICAgICAgIHRoaXMucmVzcG9uc2UgPSBSZXNwb25zZS5jcmVhdGUodGhpcy5yZXF1ZXN0UGFyYW1zLCBlcnJvci5yZXNwb25zZSwgdGhpcy5wYWdlKTtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVzcG9uc2UuaGFuZGxlKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH0pLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgSHR0cENhbmNlbGxlZEVycm9yKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkub25OZXR3b3JrRXJyb3IoZXJyb3IpID09PSBmYWxzZSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZmlyZU5ldHdvcmtFcnJvckV2ZW50KGVycm9yKSkge1xuICAgICAgICBpZiAob3JpZ2luYWxseVByZWZldGNoKSB7XG4gICAgICAgICAgdGhpcy5yZXF1ZXN0UGFyYW1zLm9uUHJlZmV0Y2hFcnJvcihlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgIH1cbiAgICB9KS5maW5hbGx5KCgpID0+IHtcbiAgICAgIHRoaXMuZmluaXNoKCk7XG4gICAgICBpZiAob3JpZ2luYWxseVByZWZldGNoICYmIHRoaXMucmVzcG9uc2UpIHtcbiAgICAgICAgdGhpcy5yZXF1ZXN0UGFyYW1zLm9uUHJlZmV0Y2hSZXNwb25zZSh0aGlzLnJlc3BvbnNlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBmaW5pc2goKSB7XG4gICAgaWYgKHRoaXMucmVxdWVzdFBhcmFtcy53YXNDYW5jZWxsZWRBdEFsbCgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMucmVxdWVzdFBhcmFtcy5tYXJrQXNGaW5pc2hlZCgpO1xuICAgIHRoaXMuZmlyZUZpbmlzaEV2ZW50cygpO1xuICB9XG4gIGZpcmVGaW5pc2hFdmVudHMoKSB7XG4gICAgaWYgKHRoaXMucmVxdWVzdEhhc0ZpbmlzaGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMucmVxdWVzdEhhc0ZpbmlzaGVkID0gdHJ1ZTtcbiAgICBmaXJlRmluaXNoRXZlbnQodGhpcy5yZXF1ZXN0UGFyYW1zLmFsbCgpKTtcbiAgICB0aGlzLnJlcXVlc3RQYXJhbXMub25GaW5pc2goKTtcbiAgfVxuICBjYW5jZWwoeyBjYW5jZWxsZWQgPSBmYWxzZSwgaW50ZXJydXB0ZWQgPSBmYWxzZSB9KSB7XG4gICAgaWYgKHRoaXMucmVxdWVzdEhhc0ZpbmlzaGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuY2FuY2VsVG9rZW4uYWJvcnQoKTtcbiAgICB0aGlzLnJlcXVlc3RQYXJhbXMubWFya0FzQ2FuY2VsbGVkKHsgY2FuY2VsbGVkLCBpbnRlcnJ1cHRlZCB9KTtcbiAgICB0aGlzLmZpcmVGaW5pc2hFdmVudHMoKTtcbiAgfVxuICBvblByb2dyZXNzKHByb2dyZXNzMykge1xuICAgIGlmICh0aGlzLnJlcXVlc3RQYXJhbXMuZGF0YSgpIGluc3RhbmNlb2YgRm9ybURhdGEpIHtcbiAgICAgIGZpcmVQcm9ncmVzc0V2ZW50KHByb2dyZXNzMyk7XG4gICAgICB0aGlzLnJlcXVlc3RQYXJhbXMuYWxsKCkub25Qcm9ncmVzcyhwcm9ncmVzczMpO1xuICAgIH1cbiAgfVxuICBnZXRIZWFkZXJzKCkge1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAuLi50aGlzLnJlcXVlc3RQYXJhbXMuaGVhZGVycygpLFxuICAgICAgQWNjZXB0OiBcInRleHQvaHRtbCwgYXBwbGljYXRpb24veGh0bWwreG1sXCIsXG4gICAgICBcIlgtUmVxdWVzdGVkLVdpdGhcIjogXCJYTUxIdHRwUmVxdWVzdFwiLFxuICAgICAgXCJYLUluZXJ0aWFcIjogdHJ1ZVxuICAgIH07XG4gICAgY29uc3QgcGFnZTIgPSBwYWdlLmdldCgpO1xuICAgIGlmIChwYWdlMi52ZXJzaW9uKSB7XG4gICAgICBoZWFkZXJzW1wiWC1JbmVydGlhLVZlcnNpb25cIl0gPSBwYWdlMi52ZXJzaW9uO1xuICAgIH1cbiAgICBjb25zdCBvbmNlUHJvcHMgPSBPYmplY3QuZW50cmllcyhwYWdlMi5vbmNlUHJvcHMgfHwge30pLmZpbHRlcigoWywgb25jZVByb3BdKSA9PiB7XG4gICAgICBpZiAoZ2V0NihwYWdlMi5wcm9wcywgb25jZVByb3AucHJvcCkgPT09IHZvaWQgMCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gIW9uY2VQcm9wLmV4cGlyZXNBdCB8fCBvbmNlUHJvcC5leHBpcmVzQXQgPiBEYXRlLm5vdygpO1xuICAgIH0pLm1hcCgoW2tleV0pID0+IGtleSk7XG4gICAgaWYgKG9uY2VQcm9wcy5sZW5ndGggPiAwKSB7XG4gICAgICBoZWFkZXJzW1wiWC1JbmVydGlhLUV4Y2VwdC1PbmNlLVByb3BzXCJdID0gb25jZVByb3BzLmpvaW4oXCIsXCIpO1xuICAgIH1cbiAgICByZXR1cm4gaGVhZGVycztcbiAgfVxufTtcblxuLy8gc3JjL3JlcXVlc3RTdHJlYW0udHNcbnZhciBSZXF1ZXN0U3RyZWFtID0gY2xhc3Mge1xuICByZXF1ZXN0cyA9IFtdO1xuICBtYXhDb25jdXJyZW50O1xuICBpbnRlcnJ1cHRpYmxlO1xuICBjb25zdHJ1Y3Rvcih7IG1heENvbmN1cnJlbnQsIGludGVycnVwdGlibGUgfSkge1xuICAgIHRoaXMubWF4Q29uY3VycmVudCA9IG1heENvbmN1cnJlbnQ7XG4gICAgdGhpcy5pbnRlcnJ1cHRpYmxlID0gaW50ZXJydXB0aWJsZTtcbiAgfVxuICBzZW5kKHJlcXVlc3QpIHtcbiAgICB0aGlzLnJlcXVlc3RzLnB1c2gocmVxdWVzdCk7XG4gICAgcmVxdWVzdC5zZW5kKCkuZmluYWxseSgoKSA9PiB7XG4gICAgICB0aGlzLnJlcXVlc3RzID0gdGhpcy5yZXF1ZXN0cy5maWx0ZXIoKHIpID0+IHIgIT09IHJlcXVlc3QpO1xuICAgIH0pO1xuICB9XG4gIGludGVycnVwdEluRmxpZ2h0KCkge1xuICAgIHRoaXMuY2FuY2VsKHsgaW50ZXJydXB0ZWQ6IHRydWUgfSwgZmFsc2UpO1xuICB9XG4gIGNhbmNlbEluRmxpZ2h0KG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHNob3VsZENhbmNlbCA9IHR5cGVvZiBvcHRpb25zID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zIDogKHJlcXVlc3QpID0+IHtcbiAgICAgIGNvbnN0IHsgcHJlZmV0Y2ggPSB0cnVlLCBvcHRpbWlzdGljID0gdHJ1ZSB9ID0gb3B0aW9ucztcbiAgICAgIHJldHVybiAocHJlZmV0Y2ggfHwgIXJlcXVlc3QuaXNQcmVmZXRjaCgpKSAmJiAob3B0aW1pc3RpYyB8fCAhcmVxdWVzdC5pc09wdGltaXN0aWMoKSk7XG4gICAgfTtcbiAgICB0aGlzLnJlcXVlc3RzLmZpbHRlcihzaG91bGRDYW5jZWwpLmZvckVhY2goKHJlcXVlc3QpID0+IHJlcXVlc3QuY2FuY2VsKHsgY2FuY2VsbGVkOiB0cnVlIH0pKTtcbiAgfVxuICBjYW5jZWwoeyBjYW5jZWxsZWQgPSBmYWxzZSwgaW50ZXJydXB0ZWQgPSBmYWxzZSB9ID0ge30sIGZvcmNlID0gZmFsc2UpIHtcbiAgICBpZiAoIWZvcmNlICYmICF0aGlzLnNob3VsZENhbmNlbCgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJlcXVlc3QgPSB0aGlzLnJlcXVlc3RzLnNoaWZ0KCk7XG4gICAgcmVxdWVzdD8uY2FuY2VsKHsgY2FuY2VsbGVkLCBpbnRlcnJ1cHRlZCB9KTtcbiAgfVxuICBzaG91bGRDYW5jZWwoKSB7XG4gICAgcmV0dXJuIHRoaXMuaW50ZXJydXB0aWJsZSAmJiB0aGlzLnJlcXVlc3RzLmxlbmd0aCA+PSB0aGlzLm1heENvbmN1cnJlbnQ7XG4gIH1cbiAgaGFzUGVuZGluZ09wdGltaXN0aWMoKSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdHMuc29tZSgocmVxdWVzdCkgPT4gcmVxdWVzdC5pc1BlbmRpbmdPcHRpbWlzdGljKCkpO1xuICB9XG59O1xuXG4vLyBzcmMvcm91dGVyLnRzXG52YXIgbm9vcCA9ICgpID0+IHtcbn07XG52YXIgUm91dGVyID0gY2xhc3Mge1xuICBzeW5jUmVxdWVzdFN0cmVhbSA9IG5ldyBSZXF1ZXN0U3RyZWFtKHtcbiAgICBtYXhDb25jdXJyZW50OiAxLFxuICAgIGludGVycnVwdGlibGU6IHRydWVcbiAgfSk7XG4gIGFzeW5jUmVxdWVzdFN0cmVhbSA9IG5ldyBSZXF1ZXN0U3RyZWFtKHtcbiAgICBtYXhDb25jdXJyZW50OiBJbmZpbml0eSxcbiAgICBpbnRlcnJ1cHRpYmxlOiBmYWxzZVxuICB9KTtcbiAgY2xpZW50VmlzaXRRdWV1ZSA9IG5ldyBRdWV1ZSgpO1xuICBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID0gdm9pZCAwO1xuICBpbml0KHtcbiAgICBpbml0aWFsUGFnZSxcbiAgICByZXNvbHZlQ29tcG9uZW50LFxuICAgIHN3YXBDb21wb25lbnQsXG4gICAgb25GbGFzaFxuICB9KSB7XG4gICAgcGFnZS5pbml0KHtcbiAgICAgIGluaXRpYWxQYWdlLFxuICAgICAgcmVzb2x2ZUNvbXBvbmVudCxcbiAgICAgIHN3YXBDb21wb25lbnQsXG4gICAgICBvbkZsYXNoXG4gICAgfSk7XG4gICAgSW5pdGlhbFZpc2l0LmhhbmRsZSgpO1xuICAgIGV2ZW50SGFuZGxlci5pbml0KCk7XG4gICAgZXZlbnRIYW5kbGVyLm9uKFwibWlzc2luZ0hpc3RvcnlJdGVtXCIsICgpID0+IHtcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIHRoaXMudmlzaXQod2luZG93LmxvY2F0aW9uLmhyZWYsIHsgcHJlc2VydmVTdGF0ZTogdHJ1ZSwgcHJlc2VydmVTY3JvbGw6IHRydWUsIHJlcGxhY2U6IHRydWUgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgZXZlbnRIYW5kbGVyLm9uKFwibG9hZERlZmVycmVkUHJvcHNcIiwgKGRlZmVycmVkUHJvcHMpID0+IHtcbiAgICAgIHRoaXMubG9hZERlZmVycmVkUHJvcHMoZGVmZXJyZWRQcm9wcyk7XG4gICAgfSk7XG4gICAgZXZlbnRIYW5kbGVyLm9uKFwiaGlzdG9yeVF1b3RhRXhjZWVkZWRcIiwgKHVybCkgPT4ge1xuICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSB1cmw7XG4gICAgfSk7XG4gIH1cbiAgb3B0aW1pc3RpYyhjYWxsYmFjaykge1xuICAgIHRoaXMucGVuZGluZ09wdGltaXN0aWNDYWxsYmFjayA9IGNhbGxiYWNrO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGdldCh1cmwsIGRhdGEgPSB7fSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMudmlzaXQodXJsLCB7IC4uLm9wdGlvbnMsIG1ldGhvZDogXCJnZXRcIiwgZGF0YSB9KTtcbiAgfVxuICBwb3N0KHVybCwgZGF0YSA9IHt9LCBvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gdGhpcy52aXNpdCh1cmwsIHsgcHJlc2VydmVTdGF0ZTogdHJ1ZSwgLi4ub3B0aW9ucywgbWV0aG9kOiBcInBvc3RcIiwgZGF0YSB9KTtcbiAgfVxuICBwdXQodXJsLCBkYXRhID0ge30sIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLnZpc2l0KHVybCwgeyBwcmVzZXJ2ZVN0YXRlOiB0cnVlLCAuLi5vcHRpb25zLCBtZXRob2Q6IFwicHV0XCIsIGRhdGEgfSk7XG4gIH1cbiAgcGF0Y2godXJsLCBkYXRhID0ge30sIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLnZpc2l0KHVybCwgeyBwcmVzZXJ2ZVN0YXRlOiB0cnVlLCAuLi5vcHRpb25zLCBtZXRob2Q6IFwicGF0Y2hcIiwgZGF0YSB9KTtcbiAgfVxuICBkZWxldGUodXJsLCBvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gdGhpcy52aXNpdCh1cmwsIHsgcHJlc2VydmVTdGF0ZTogdHJ1ZSwgLi4ub3B0aW9ucywgbWV0aG9kOiBcImRlbGV0ZVwiIH0pO1xuICB9XG4gIHJlbG9hZChvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gdGhpcy5kb1JlbG9hZChvcHRpb25zKTtcbiAgfVxuICBkb1JlbG9hZChvcHRpb25zID0ge30pIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy52aXNpdCh3aW5kb3cubG9jYXRpb24uaHJlZiwge1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHByZXNlcnZlU2Nyb2xsOiB0cnVlLFxuICAgICAgcHJlc2VydmVTdGF0ZTogdHJ1ZSxcbiAgICAgIGFzeW5jOiB0cnVlLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi5vcHRpb25zLmhlYWRlcnMgfHwge30sXG4gICAgICAgIFwiQ2FjaGUtQ29udHJvbFwiOiBcIm5vLWNhY2hlXCJcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZW1lbWJlcihkYXRhLCBrZXkgPSBcImRlZmF1bHRcIikge1xuICAgIGhpc3RvcnkucmVtZW1iZXIoZGF0YSwga2V5KTtcbiAgfVxuICByZXN0b3JlKGtleSA9IFwiZGVmYXVsdFwiKSB7XG4gICAgcmV0dXJuIGhpc3RvcnkucmVzdG9yZShrZXkpO1xuICB9XG4gIG9uKHR5cGUsIGNhbGxiYWNrKSB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gZXZlbnRIYW5kbGVyLm9uR2xvYmFsRXZlbnQodHlwZSwgY2FsbGJhY2spO1xuICB9XG4gIG9uY2UodHlwZSwgY2FsbGJhY2spIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IHJlbW92ZTIgPSB0aGlzLm9uKHR5cGUsIChldmVudCkgPT4ge1xuICAgICAgcmVtb3ZlMigpO1xuICAgICAgcmV0dXJuIGNhbGxiYWNrKGV2ZW50KTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVtb3ZlMjtcbiAgfVxuICBoYXNQZW5kaW5nT3B0aW1pc3RpYygpIHtcbiAgICByZXR1cm4gdGhpcy5hc3luY1JlcXVlc3RTdHJlYW0uaGFzUGVuZGluZ09wdGltaXN0aWMoKTtcbiAgfVxuICBnZXQgYWN0aXZlUG9sbHMoKSB7XG4gICAgcmV0dXJuIHBvbGxzLmNvdW50O1xuICB9XG4gIGNhbmNlbEFsbCh7IGFzeW5jID0gdHJ1ZSwgcHJlZmV0Y2ggPSB0cnVlLCBzeW5jID0gdHJ1ZSB9ID0ge30pIHtcbiAgICBpZiAoYXN5bmMpIHtcbiAgICAgIHRoaXMuYXN5bmNSZXF1ZXN0U3RyZWFtLmNhbmNlbEluRmxpZ2h0KHsgcHJlZmV0Y2ggfSk7XG4gICAgfVxuICAgIGlmIChzeW5jKSB7XG4gICAgICB0aGlzLnN5bmNSZXF1ZXN0U3RyZWFtLmNhbmNlbEluRmxpZ2h0KCk7XG4gICAgfVxuICB9XG4gIHBvbGwoaW50ZXJ2YWwsIHJlcXVlc3RPcHRpb25zID0ge30sIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiBwb2xscy5hZGQoXG4gICAgICBpbnRlcnZhbCxcbiAgICAgICh7IG9uU3RhcnQsIG9uRmluaXNoIH0pID0+IHtcbiAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSB0eXBlb2YgcmVxdWVzdE9wdGlvbnMgPT09IFwiZnVuY3Rpb25cIiA/IHJlcXVlc3RPcHRpb25zKCkgOiByZXF1ZXN0T3B0aW9ucztcbiAgICAgICAgdGhpcy5kb1JlbG9hZCh7XG4gICAgICAgICAgcG9sbDogdHJ1ZSxcbiAgICAgICAgICBwcmVzZXJ2ZUVycm9yczogdHJ1ZSxcbiAgICAgICAgICAuLi5yZXNvbHZlZCxcbiAgICAgICAgICBvbkNhbmNlbFRva2VuOiAodG9rZW4pID0+IHtcbiAgICAgICAgICAgIG9uU3RhcnQodG9rZW4uY2FuY2VsKTtcbiAgICAgICAgICAgIHJlc29sdmVkLm9uQ2FuY2VsVG9rZW4/Lih0b2tlbik7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvbkZpbmlzaDogKHZpc2l0KSA9PiB7XG4gICAgICAgICAgICBvbkZpbmlzaCgpO1xuICAgICAgICAgICAgcmVzb2x2ZWQub25GaW5pc2g/Lih2aXNpdCk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGF1dG9TdGFydDogb3B0aW9ucy5hdXRvU3RhcnQgPz8gdHJ1ZSxcbiAgICAgICAga2VlcEFsaXZlOiBvcHRpb25zLmtlZXBBbGl2ZSA/PyBmYWxzZSxcbiAgICAgICAgbW9kZTogb3B0aW9ucy5tb2RlXG4gICAgICB9XG4gICAgKTtcbiAgfVxuICB2aXNpdChocmVmLCBvcHRpb25zID0ge30pIHtcbiAgICBvcHRpb25zLm9wdGltaXN0aWMgPSBvcHRpb25zLm9wdGltaXN0aWMgPz8gdGhpcy5wZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrO1xuICAgIHRoaXMucGVuZGluZ09wdGltaXN0aWNDYWxsYmFjayA9IHZvaWQgMDtcbiAgICBpZiAob3B0aW9ucy5vcHRpbWlzdGljKSB7XG4gICAgICBvcHRpb25zLmFzeW5jID0gb3B0aW9ucy5hc3luYyA/PyB0cnVlO1xuICAgIH1cbiAgICBjb25zdCB2aXNpdCA9IHRoaXMuZ2V0UGVuZGluZ1Zpc2l0KGhyZWYsIHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBzaG93UHJvZ3Jlc3M6IG9wdGlvbnMuc2hvd1Byb2dyZXNzID8/ICghb3B0aW9ucy5hc3luYyB8fCAhIW9wdGlvbnMub3B0aW1pc3RpYylcbiAgICB9KTtcbiAgICBjb25zdCBldmVudHMgPSB0aGlzLmdldFZpc2l0RXZlbnRzKG9wdGlvbnMpO1xuICAgIGlmIChldmVudHMub25CZWZvcmUodmlzaXQpID09PSBmYWxzZSB8fCAhZmlyZUJlZm9yZUV2ZW50KHZpc2l0KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50UGFnZVVybCA9IGhyZWZUb1VybChwYWdlLmdldCgpLnVybCk7XG4gICAgY29uc3QgaXNQYXJ0aWFsUmVsb2FkID0gdmlzaXQub25seS5sZW5ndGggPiAwIHx8IHZpc2l0LmV4Y2VwdC5sZW5ndGggPiAwIHx8IHZpc2l0LnJlc2V0Lmxlbmd0aCA+IDA7XG4gICAgY29uc3QgaXNTYW1lUGFnZSA9IGlzUGFydGlhbFJlbG9hZCA/IGlzU2FtZVVybFdpdGhvdXRRdWVyeU9ySGFzaCh2aXNpdC51cmwsIGN1cnJlbnRQYWdlVXJsKSA6IGlzU2FtZVVybFdpdGhvdXRIYXNoKHZpc2l0LnVybCwgY3VycmVudFBhZ2VVcmwpO1xuICAgIGlmICghaXNTYW1lUGFnZSkge1xuICAgICAgdGhpcy5hc3luY1JlcXVlc3RTdHJlYW0uY2FuY2VsSW5GbGlnaHQoXG4gICAgICAgIChyZXF1ZXN0KSA9PiAhcmVxdWVzdC5pc1ByZWZldGNoKCkgJiYgIXJlcXVlc3QuaXNPcHRpbWlzdGljKCkgJiYgaXNTYW1lVXJsV2l0aG91dFF1ZXJ5T3JIYXNoKHJlcXVlc3QuZ2V0VXJsKCksIGN1cnJlbnRQYWdlVXJsKVxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCF2aXNpdC5hc3luYykge1xuICAgICAgdGhpcy5zeW5jUmVxdWVzdFN0cmVhbS5pbnRlcnJ1cHRJbkZsaWdodCgpO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5vcHRpbWlzdGljKSB7XG4gICAgICB0aGlzLmFwcGx5T3B0aW1pc3RpY1VwZGF0ZShvcHRpb25zLm9wdGltaXN0aWMsIGV2ZW50cyk7XG4gICAgfVxuICAgIGlmICghcGFnZS5pc0NsZWFyZWQoKSAmJiAhdmlzaXQucHJlc2VydmVVcmwpIHtcbiAgICAgIFNjcm9sbC5zYXZlKCk7XG4gICAgfVxuICAgIGNvbnN0IHJlcXVlc3RQYXJhbXMgPSB7XG4gICAgICAuLi52aXNpdCxcbiAgICAgIC4uLmV2ZW50c1xuICAgIH07XG4gICAgY29uc3Qgc2VuZFJlcXVlc3QgPSAoKSA9PiB7XG4gICAgICBjb25zdCBwcmVmZXRjaGVkID0gcHJlZmV0Y2hlZFJlcXVlc3RzLmdldChyZXF1ZXN0UGFyYW1zKTtcbiAgICAgIGlmIChwcmVmZXRjaGVkKSB7XG4gICAgICAgIHByb2dyZXNzLnJldmVhbChwcmVmZXRjaGVkLmluRmxpZ2h0KTtcbiAgICAgICAgcHJlZmV0Y2hlZFJlcXVlc3RzLnVzZShwcmVmZXRjaGVkLCByZXF1ZXN0UGFyYW1zKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHByb2dyZXNzLnJldmVhbCh0cnVlKTtcbiAgICAgICAgY29uc3QgcmVxdWVzdFN0cmVhbSA9IHZpc2l0LmFzeW5jID8gdGhpcy5hc3luY1JlcXVlc3RTdHJlYW0gOiB0aGlzLnN5bmNSZXF1ZXN0U3RyZWFtO1xuICAgICAgICByZXF1ZXN0U3RyZWFtLnNlbmQoUmVxdWVzdC5jcmVhdGUocmVxdWVzdFBhcmFtcywgcGFnZS5nZXQoKSwgeyBvcHRpbWlzdGljOiAhIW9wdGlvbnMub3B0aW1pc3RpYyB9KSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh2aXNpdC5jb21wb25lbnQpKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgVGhlIFwiY29tcG9uZW50XCIgcHJvcCByZWNlaXZlZCBhbiBhcnJheSBvZiBjb21wb25lbnRzICgke3Zpc2l0LmNvbXBvbmVudC5qb2luKFwiLCBcIil9KSwgYnV0IG9ubHkgYSBzaW5nbGUgY29tcG9uZW50IHN0cmluZyBpcyBzdXBwb3J0ZWQgZm9yIGluc3RhbnQgdmlzaXRzLiBQYXNzIGFuIGV4cGxpY2l0IGNvbXBvbmVudCBuYW1lIGluc3RlYWQuYFxuICAgICAgKTtcbiAgICAgIHZpc2l0LmNvbXBvbmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmICh2aXNpdC5jb21wb25lbnQpIHtcbiAgICAgIGhpc3RvcnkucHJvY2Vzc1F1ZXVlKCkudGhlbigoKSA9PiB7XG4gICAgICAgIHRoaXMucGVyZm9ybUluc3RhbnRTd2FwKHZpc2l0KS50aGVuKCgpID0+IHtcbiAgICAgICAgICByZXF1ZXN0UGFyYW1zLnByZXNlcnZlU2Nyb2xsID0gdHJ1ZTtcbiAgICAgICAgICByZXF1ZXN0UGFyYW1zLnByZXNlcnZlU3RhdGUgPSB0cnVlO1xuICAgICAgICAgIHJlcXVlc3RQYXJhbXMucmVwbGFjZSA9IHRydWU7XG4gICAgICAgICAgcmVxdWVzdFBhcmFtcy52aWV3VHJhbnNpdGlvbiA9IGZhbHNlO1xuICAgICAgICAgIHNlbmRSZXF1ZXN0KCk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNlbmRSZXF1ZXN0KCk7XG4gICAgfVxuICB9XG4gIGdldENhY2hlZChocmVmLCBvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gcHJlZmV0Y2hlZFJlcXVlc3RzLmZpbmRDYWNoZWQodGhpcy5nZXRQcmVmZXRjaFBhcmFtcyhocmVmLCBvcHRpb25zKSk7XG4gIH1cbiAgZmx1c2goaHJlZiwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcHJlZmV0Y2hlZFJlcXVlc3RzLnJlbW92ZSh0aGlzLmdldFByZWZldGNoUGFyYW1zKGhyZWYsIG9wdGlvbnMpKTtcbiAgfVxuICBmbHVzaEFsbCgpIHtcbiAgICBwcmVmZXRjaGVkUmVxdWVzdHMucmVtb3ZlQWxsKCk7XG4gIH1cbiAgZmx1c2hCeUNhY2hlVGFncyh0YWdzKSB7XG4gICAgcHJlZmV0Y2hlZFJlcXVlc3RzLnJlbW92ZUJ5VGFncyhBcnJheS5pc0FycmF5KHRhZ3MpID8gdGFncyA6IFt0YWdzXSk7XG4gIH1cbiAgZ2V0UHJlZmV0Y2hpbmcoaHJlZiwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHByZWZldGNoZWRSZXF1ZXN0cy5maW5kSW5GbGlnaHQodGhpcy5nZXRQcmVmZXRjaFBhcmFtcyhocmVmLCBvcHRpb25zKSk7XG4gIH1cbiAgcHJlZmV0Y2goaHJlZiwgb3B0aW9ucyA9IHt9LCBwcmVmZXRjaE9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IG1ldGhvZCA9IG9wdGlvbnMubWV0aG9kID8/IChpc1VybE1ldGhvZFBhaXIoaHJlZikgPyBocmVmLm1ldGhvZCA6IFwiZ2V0XCIpO1xuICAgIGlmIChtZXRob2QgIT09IFwiZ2V0XCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlByZWZldGNoIHJlcXVlc3RzIG11c3QgdXNlIHRoZSBHRVQgbWV0aG9kXCIpO1xuICAgIH1cbiAgICBjb25zdCB2aXNpdCA9IHRoaXMuZ2V0UGVuZGluZ1Zpc2l0KGhyZWYsIHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBhc3luYzogdHJ1ZSxcbiAgICAgIHNob3dQcm9ncmVzczogZmFsc2UsXG4gICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICAgIHZpZXdUcmFuc2l0aW9uOiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IHZpc2l0VXJsID0gdmlzaXQudXJsLm9yaWdpbiArIHZpc2l0LnVybC5wYXRobmFtZSArIHZpc2l0LnVybC5zZWFyY2g7XG4gICAgY29uc3QgY3VycmVudFVybCA9IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gKyB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUgKyB3aW5kb3cubG9jYXRpb24uc2VhcmNoO1xuICAgIGlmICh2aXNpdFVybCA9PT0gY3VycmVudFVybCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBldmVudHMgPSB0aGlzLmdldFZpc2l0RXZlbnRzKG9wdGlvbnMpO1xuICAgIGlmIChldmVudHMub25CZWZvcmUodmlzaXQpID09PSBmYWxzZSB8fCAhZmlyZUJlZm9yZUV2ZW50KHZpc2l0KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwcm9ncmVzcy5oaWRlKCk7XG4gICAgdGhpcy5hc3luY1JlcXVlc3RTdHJlYW0uaW50ZXJydXB0SW5GbGlnaHQoKTtcbiAgICBjb25zdCByZXF1ZXN0UGFyYW1zID0ge1xuICAgICAgLi4udmlzaXQsXG4gICAgICAuLi5ldmVudHNcbiAgICB9O1xuICAgIGNvbnN0IGVuc3VyZUN1cnJlbnRQYWdlSXNTZXQgPSAoKSA9PiB7XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgY29uc3QgY2hlY2tJZlBhZ2VJc0RlZmluZWQgPSAoKSA9PiB7XG4gICAgICAgICAgaWYgKHBhZ2UuZ2V0KCkpIHtcbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0VGltZW91dChjaGVja0lmUGFnZUlzRGVmaW5lZCwgNTApO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgY2hlY2tJZlBhZ2VJc0RlZmluZWQoKTtcbiAgICAgIH0pO1xuICAgIH07XG4gICAgZW5zdXJlQ3VycmVudFBhZ2VJc1NldCgpLnRoZW4oKCkgPT4ge1xuICAgICAgcHJlZmV0Y2hlZFJlcXVlc3RzLmFkZChcbiAgICAgICAgcmVxdWVzdFBhcmFtcyxcbiAgICAgICAgKHBhcmFtcykgPT4ge1xuICAgICAgICAgIHRoaXMuYXN5bmNSZXF1ZXN0U3RyZWFtLnNlbmQoUmVxdWVzdC5jcmVhdGUocGFyYW1zLCBwYWdlLmdldCgpKSk7XG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBjYWNoZUZvcjogY29uZmlnLmdldChcInByZWZldGNoLmNhY2hlRm9yXCIpLFxuICAgICAgICAgIGNhY2hlVGFnczogW10sXG4gICAgICAgICAgLi4ucHJlZmV0Y2hPcHRpb25zXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfSk7XG4gIH1cbiAgY2xlYXJIaXN0b3J5KCkge1xuICAgIGhpc3RvcnkuY2xlYXIoKTtcbiAgfVxuICBkZWNyeXB0SGlzdG9yeSgpIHtcbiAgICByZXR1cm4gaGlzdG9yeS5kZWNyeXB0KCk7XG4gIH1cbiAgcmVzb2x2ZUNvbXBvbmVudChjb21wb25lbnQsIHBhZ2UyKSB7XG4gICAgcmV0dXJuIHBhZ2UucmVzb2x2ZShjb21wb25lbnQsIHBhZ2UyKTtcbiAgfVxuICByZXBsYWNlKHBhcmFtcykge1xuICAgIHRoaXMuY2xpZW50VmlzaXQocGFyYW1zLCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gIH1cbiAgcmVwbGFjZVByb3AobmFtZSwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgICB0aGlzLnJlcGxhY2Uoe1xuICAgICAgcHJlc2VydmVTY3JvbGw6IHRydWUsXG4gICAgICBwcmVzZXJ2ZVN0YXRlOiB0cnVlLFxuICAgICAgcHJvcHMoY3VycmVudFByb3BzKSB7XG4gICAgICAgIGNvbnN0IG5ld1ZhbHVlID0gdHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIgPyB2YWx1ZShnZXQ3KGN1cnJlbnRQcm9wcywgbmFtZSksIGN1cnJlbnRQcm9wcykgOiB2YWx1ZTtcbiAgICAgICAgcmV0dXJuIHNldFBhdGhQcmVzZXJ2aW5nSWRlbnRpdHkoY3VycmVudFByb3BzLCBuYW1lLCBuZXdWYWx1ZSk7XG4gICAgICB9LFxuICAgICAgLi4ub3B0aW9ucyB8fCB7fVxuICAgIH0pO1xuICB9XG4gIGFwcGVuZFRvUHJvcChuYW1lLCB2YWx1ZSwgb3B0aW9ucykge1xuICAgIHRoaXMucmVwbGFjZVByb3AoXG4gICAgICBuYW1lLFxuICAgICAgKGN1cnJlbnRWYWx1ZSwgY3VycmVudFByb3BzKSA9PiB7XG4gICAgICAgIGNvbnN0IG5ld1ZhbHVlID0gdHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIgPyB2YWx1ZShjdXJyZW50VmFsdWUsIGN1cnJlbnRQcm9wcykgOiB2YWx1ZTtcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGN1cnJlbnRWYWx1ZSkpIHtcbiAgICAgICAgICBjdXJyZW50VmFsdWUgPSBjdXJyZW50VmFsdWUgIT09IHZvaWQgMCA/IFtjdXJyZW50VmFsdWVdIDogW107XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFsuLi5jdXJyZW50VmFsdWUsIG5ld1ZhbHVlXTtcbiAgICAgIH0sXG4gICAgICBvcHRpb25zXG4gICAgKTtcbiAgfVxuICBwcmVwZW5kVG9Qcm9wKG5hbWUsIHZhbHVlLCBvcHRpb25zKSB7XG4gICAgdGhpcy5yZXBsYWNlUHJvcChcbiAgICAgIG5hbWUsXG4gICAgICAoY3VycmVudFZhbHVlLCBjdXJyZW50UHJvcHMpID0+IHtcbiAgICAgICAgY29uc3QgbmV3VmFsdWUgPSB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IHZhbHVlKGN1cnJlbnRWYWx1ZSwgY3VycmVudFByb3BzKSA6IHZhbHVlO1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoY3VycmVudFZhbHVlKSkge1xuICAgICAgICAgIGN1cnJlbnRWYWx1ZSA9IGN1cnJlbnRWYWx1ZSAhPT0gdm9pZCAwID8gW2N1cnJlbnRWYWx1ZV0gOiBbXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW25ld1ZhbHVlLCAuLi5jdXJyZW50VmFsdWVdO1xuICAgICAgfSxcbiAgICAgIG9wdGlvbnNcbiAgICApO1xuICB9XG4gIHB1c2gocGFyYW1zKSB7XG4gICAgdGhpcy5jbGllbnRWaXNpdChwYXJhbXMpO1xuICB9XG4gIGZsYXNoKGtleU9yRGF0YSwgdmFsdWUpIHtcbiAgICBjb25zdCBjdXJyZW50ID0gcGFnZS5nZXQoKS5mbGFzaDtcbiAgICBsZXQgZmxhc2g7XG4gICAgaWYgKHR5cGVvZiBrZXlPckRhdGEgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgZmxhc2ggPSBrZXlPckRhdGEoY3VycmVudCk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2Yga2V5T3JEYXRhID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBmbGFzaCA9IHsgLi4uY3VycmVudCwgW2tleU9yRGF0YV06IHZhbHVlIH07XG4gICAgfSBlbHNlIGlmIChrZXlPckRhdGEgJiYgT2JqZWN0LmtleXMoa2V5T3JEYXRhKS5sZW5ndGgpIHtcbiAgICAgIGZsYXNoID0geyAuLi5jdXJyZW50LCAuLi5rZXlPckRhdGEgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwYWdlLnNldEZsYXNoKGZsYXNoKTtcbiAgICBpZiAoT2JqZWN0LmtleXMoZmxhc2gpLmxlbmd0aCkge1xuICAgICAgZmlyZUZsYXNoRXZlbnQoZmxhc2gpO1xuICAgIH1cbiAgfVxuICBjbGllbnRWaXNpdChwYXJhbXMsIHsgcmVwbGFjZSA9IGZhbHNlIH0gPSB7fSkge1xuICAgIHRoaXMuY2xpZW50VmlzaXRRdWV1ZS5hZGQoKCkgPT4gdGhpcy5wZXJmb3JtQ2xpZW50VmlzaXQocGFyYW1zLCB7IHJlcGxhY2UgfSkpO1xuICB9XG4gIHBlcmZvcm1DbGllbnRWaXNpdChwYXJhbXMsIHsgcmVwbGFjZSA9IGZhbHNlIH0gPSB7fSkge1xuICAgIGNvbnN0IGN1cnJlbnQgPSBwYWdlLmdldCgpO1xuICAgIGNvbnN0IG9uY2VQcm9wcyA9IHR5cGVvZiBwYXJhbXMucHJvcHMgPT09IFwiZnVuY3Rpb25cIiA/IE9iamVjdC5mcm9tRW50cmllcyhcbiAgICAgIE9iamVjdC52YWx1ZXMoY3VycmVudC5vbmNlUHJvcHMgPz8ge30pLm1hcCgob25jZVByb3ApID0+IFtcbiAgICAgICAgb25jZVByb3AucHJvcCxcbiAgICAgICAgZ2V0NyhjdXJyZW50LnByb3BzLCBvbmNlUHJvcC5wcm9wKVxuICAgICAgXSlcbiAgICApIDoge307XG4gICAgY29uc3QgcHJvcHMgPSB0eXBlb2YgcGFyYW1zLnByb3BzID09PSBcImZ1bmN0aW9uXCIgPyBwYXJhbXMucHJvcHMoY3VycmVudC5wcm9wcywgb25jZVByb3BzKSA6IHBhcmFtcy5wcm9wcyA/PyBjdXJyZW50LnByb3BzO1xuICAgIGNvbnN0IGZsYXNoID0gdHlwZW9mIHBhcmFtcy5mbGFzaCA9PT0gXCJmdW5jdGlvblwiID8gcGFyYW1zLmZsYXNoKGN1cnJlbnQuZmxhc2gpIDogcGFyYW1zLmZsYXNoO1xuICAgIGNvbnN0IHsgdmlld1RyYW5zaXRpb24sIG9uRXJyb3IsIG9uRmluaXNoLCBvbkZsYXNoLCBvblN1Y2Nlc3MsIC4uLnBhZ2VQYXJhbXMgfSA9IHBhcmFtcztcbiAgICBjb25zdCBwYWdlMiA9IHtcbiAgICAgIC4uLmN1cnJlbnQsXG4gICAgICAuLi5wYWdlUGFyYW1zLFxuICAgICAgZmxhc2g6IGZsYXNoID8/IHt9LFxuICAgICAgcHJvcHNcbiAgICB9O1xuICAgIGNvbnN0IHByZXNlcnZlU2Nyb2xsID0gUmVxdWVzdFBhcmFtcy5yZXNvbHZlUHJlc2VydmVPcHRpb24ocGFyYW1zLnByZXNlcnZlU2Nyb2xsID8/IGZhbHNlLCBwYWdlMik7XG4gICAgY29uc3QgcHJlc2VydmVTdGF0ZSA9IFJlcXVlc3RQYXJhbXMucmVzb2x2ZVByZXNlcnZlT3B0aW9uKHBhcmFtcy5wcmVzZXJ2ZVN0YXRlID8/IGZhbHNlLCBwYWdlMik7XG4gICAgY29uc3QgdmlzaXRJZCA9IHRoaXMuY3JlYXRlVmlzaXRJZCgpO1xuICAgIHJldHVybiBwYWdlLnNldChwYWdlMiwge1xuICAgICAgcmVwbGFjZSxcbiAgICAgIHByZXNlcnZlU2Nyb2xsLFxuICAgICAgcHJlc2VydmVTdGF0ZSxcbiAgICAgIHZpZXdUcmFuc2l0aW9uLFxuICAgICAgdmlzaXRJZFxuICAgIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgZmlyZUNsaWVudFZpc2l0RXZlbnQocGFnZS5nZXQoKSwgeyByZXBsYWNlLCB2aXNpdElkIH0pO1xuICAgICAgY29uc3QgY3VycmVudEZsYXNoID0gcGFnZS5nZXQoKS5mbGFzaDtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhjdXJyZW50Rmxhc2gpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgZmlyZUZsYXNoRXZlbnQoY3VycmVudEZsYXNoKTtcbiAgICAgICAgb25GbGFzaD8uKGN1cnJlbnRGbGFzaCk7XG4gICAgICB9XG4gICAgICBjb25zdCBlcnJvcnMgPSBwYWdlLmdldCgpLnByb3BzLmVycm9ycyB8fCB7fTtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBvblN1Y2Nlc3M/LihwYWdlLmdldCgpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3Qgc2NvcGVkRXJyb3JzID0gcGFyYW1zLmVycm9yQmFnID8gZXJyb3JzW3BhcmFtcy5lcnJvckJhZyB8fCBcIlwiXSB8fCB7fSA6IGVycm9ycztcbiAgICAgIG9uRXJyb3I/LihzY29wZWRFcnJvcnMpO1xuICAgIH0pLmZpbmFsbHkoKCkgPT4gb25GaW5pc2g/LihwYXJhbXMpKTtcbiAgfVxuICBwZXJmb3JtSW5zdGFudFN3YXAodmlzaXQpIHtcbiAgICBjb25zdCBjdXJyZW50ID0gcGFnZS5nZXQoKTtcbiAgICBjb25zdCBzaGFyZWRQcm9wcyA9IE9iamVjdC5mcm9tRW50cmllcyhcbiAgICAgIChjdXJyZW50LnNoYXJlZFByb3BzID8/IFtdKS5maWx0ZXIoKGtleSkgPT4ga2V5IGluIGN1cnJlbnQucHJvcHMpLm1hcCgoa2V5KSA9PiBba2V5LCBjdXJyZW50LnByb3BzW2tleV1dKVxuICAgICk7XG4gICAgY29uc3QgcmVzb2x2ZWRQYWdlUHJvcHMgPSB0eXBlb2YgdmlzaXQucGFnZVByb3BzID09PSBcImZ1bmN0aW9uXCIgPyB2aXNpdC5wYWdlUHJvcHMoY2xvbmVEZWVwNChjdXJyZW50LnByb3BzKSwgY2xvbmVEZWVwNChzaGFyZWRQcm9wcykpIDogdmlzaXQucGFnZVByb3BzO1xuICAgIGNvbnN0IGludGVybWVkaWF0ZVByb3BzID0gcmVzb2x2ZWRQYWdlUHJvcHMgIT09IG51bGwgPyB7IC4uLnJlc29sdmVkUGFnZVByb3BzIH0gOiB7IC4uLnNoYXJlZFByb3BzIH07XG4gICAgY29uc3Qgb25jZVByb3BzID0gdGhpcy5wcmVzZXJ2ZU9uY2VQcm9wc09uSW5zdGFudFZpc2l0KGN1cnJlbnQsIGludGVybWVkaWF0ZVByb3BzKTtcbiAgICBjb25zdCBpbnRlcm1lZGlhdGVQYWdlID0ge1xuICAgICAgY29tcG9uZW50OiB2aXNpdC5jb21wb25lbnQsXG4gICAgICB1cmw6IHZpc2l0LnVybC5wYXRobmFtZSArIHZpc2l0LnVybC5zZWFyY2ggKyB2aXNpdC51cmwuaGFzaCxcbiAgICAgIHZlcnNpb246IGN1cnJlbnQudmVyc2lvbixcbiAgICAgIHByb3BzOiB7XG4gICAgICAgIC4uLmludGVybWVkaWF0ZVByb3BzLFxuICAgICAgICBlcnJvcnM6IHt9XG4gICAgICB9LFxuICAgICAgZmxhc2g6IHt9LFxuICAgICAgcmVzY3VlZFByb3BzOiBbXSxcbiAgICAgIGNsZWFySGlzdG9yeTogZmFsc2UsXG4gICAgICBlbmNyeXB0SGlzdG9yeTogY3VycmVudC5lbmNyeXB0SGlzdG9yeSxcbiAgICAgIHNoYXJlZFByb3BzOiBjdXJyZW50LnNoYXJlZFByb3BzLFxuICAgICAgb25jZVByb3BzLFxuICAgICAgcmVtZW1iZXJlZFN0YXRlOiB7fVxuICAgIH07XG4gICAgcmV0dXJuIHBhZ2Uuc2V0KGludGVybWVkaWF0ZVBhZ2UsIHtcbiAgICAgIHJlcGxhY2U6IHZpc2l0LnJlcGxhY2UsXG4gICAgICBwcmVzZXJ2ZVNjcm9sbDogUmVxdWVzdFBhcmFtcy5yZXNvbHZlUHJlc2VydmVPcHRpb24odmlzaXQucHJlc2VydmVTY3JvbGwsIGludGVybWVkaWF0ZVBhZ2UpLFxuICAgICAgcHJlc2VydmVTdGF0ZTogZmFsc2UsXG4gICAgICB2aWV3VHJhbnNpdGlvbjogdmlzaXQudmlld1RyYW5zaXRpb24sXG4gICAgICB2aXNpdElkOiB2aXNpdC5pZFxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBPbmNlIHByb3BzIGFyZSByZW1lbWJlcmVkIGNsaWVudC1zaWRlLCBzbyB0aGUgcGxhY2Vob2xkZXIgcGFnZSBtdXN0IHByZXNlcnZlIHRoZWlyIHZhbHVlc1xuICAgKiBhbmQgcmVnaXN0cnkuIE90aGVyd2lzZSB0aGUgc3dhcCBkaXNjYXJkcyB0aGUgdmFsdWUsIGFuZCBhbiBpbi1mbGlnaHQgcHJlZmV0Y2ggdGhhdCBhbHJlYWR5XG4gICAqIGNsYWltZWQgdGhlIHByb3AgcmVzb2x2ZXMgd2l0aCBub3RoaW5nIHRvIHJlc3RvcmUgaXQgZnJvbS5cbiAgICovXG4gIHByZXNlcnZlT25jZVByb3BzT25JbnN0YW50VmlzaXQoY3VycmVudCwgcHJvcHMpIHtcbiAgICBjb25zdCBvbmNlUHJvcHMgPSB7fTtcbiAgICBPYmplY3QuZW50cmllcyhjdXJyZW50Lm9uY2VQcm9wcyA/PyB7fSkuZm9yRWFjaCgoW2tleSwgb25jZVByb3BdKSA9PiB7XG4gICAgICBpZiAoZ2V0Nyhwcm9wcywgb25jZVByb3AucHJvcCkgIT09IHZvaWQgMCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50VmFsdWUgPSBnZXQ3KGN1cnJlbnQucHJvcHMsIG9uY2VQcm9wLnByb3ApO1xuICAgICAgaWYgKGN1cnJlbnRWYWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHNldDUocHJvcHMsIG9uY2VQcm9wLnByb3AsIGN1cnJlbnRWYWx1ZSk7XG4gICAgICBvbmNlUHJvcHNba2V5XSA9IG9uY2VQcm9wO1xuICAgIH0pO1xuICAgIHJldHVybiBvbmNlUHJvcHM7XG4gIH1cbiAgZ2V0UHJlZmV0Y2hQYXJhbXMoaHJlZiwgb3B0aW9ucykge1xuICAgIHJldHVybiB7XG4gICAgICAuLi50aGlzLmdldFBlbmRpbmdWaXNpdChocmVmLCB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIGFzeW5jOiB0cnVlLFxuICAgICAgICBzaG93UHJvZ3Jlc3M6IGZhbHNlLFxuICAgICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICAgICAgdmlld1RyYW5zaXRpb246IGZhbHNlXG4gICAgICB9KSxcbiAgICAgIC4uLnRoaXMuZ2V0VmlzaXRFdmVudHMob3B0aW9ucylcbiAgICB9O1xuICB9XG4gIGNyZWF0ZVZpc2l0SWQoKSB7XG4gICAgcmV0dXJuIHVpZCgpO1xuICB9XG4gIGdldFBlbmRpbmdWaXNpdChocmVmLCBvcHRpb25zKSB7XG4gICAgaWYgKGlzVXJsTWV0aG9kUGFpcihocmVmKSkge1xuICAgICAgY29uc3QgdXJsTWV0aG9kUGFpciA9IGhyZWY7XG4gICAgICBocmVmID0gdXJsTWV0aG9kUGFpci51cmw7XG4gICAgICBvcHRpb25zLm1ldGhvZCA9IG9wdGlvbnMubWV0aG9kID8/IHVybE1ldGhvZFBhaXIubWV0aG9kO1xuICAgIH1cbiAgICBjb25zdCBkZWZhdWx0VmlzaXRPcHRpb25zQ2FsbGJhY2sgPSBjb25maWcuZ2V0KFwidmlzaXRPcHRpb25zXCIpO1xuICAgIGNvbnN0IGNvbmZpZ3VyZWRPcHRpb25zID0gZGVmYXVsdFZpc2l0T3B0aW9uc0NhbGxiYWNrID8gZGVmYXVsdFZpc2l0T3B0aW9uc0NhbGxiYWNrKGhyZWYudG9TdHJpbmcoKSwgY2xvbmVEZWVwNChvcHRpb25zKSkgfHwge30gOiB7fTtcbiAgICBjb25zdCBtZXJnZWRPcHRpb25zID0ge1xuICAgICAgbWV0aG9kOiBcImdldFwiLFxuICAgICAgZGF0YToge30sXG4gICAgICByZXBsYWNlOiBmYWxzZSxcbiAgICAgIHByZXNlcnZlU2Nyb2xsOiBmYWxzZSxcbiAgICAgIHByZXNlcnZlU3RhdGU6IGZhbHNlLFxuICAgICAgb25seTogW10sXG4gICAgICBleGNlcHQ6IFtdLFxuICAgICAgaGVhZGVyczoge30sXG4gICAgICBlcnJvckJhZzogXCJcIixcbiAgICAgIGZvcmNlRm9ybURhdGE6IGZhbHNlLFxuICAgICAgcXVlcnlTdHJpbmdBcnJheUZvcm1hdDogXCJicmFja2V0c1wiLFxuICAgICAgYXN5bmM6IGZhbHNlLFxuICAgICAgc2hvd1Byb2dyZXNzOiB0cnVlLFxuICAgICAgZnJlc2g6IGZhbHNlLFxuICAgICAgcmVzZXQ6IFtdLFxuICAgICAgcHJlc2VydmVVcmw6IGZhbHNlLFxuICAgICAgcHJlc2VydmVFcnJvcnM6IGZhbHNlLFxuICAgICAgcHJlZmV0Y2g6IGZhbHNlLFxuICAgICAgaW52YWxpZGF0ZUNhY2hlVGFnczogW10sXG4gICAgICB2aWV3VHJhbnNpdGlvbjogZmFsc2UsXG4gICAgICBjb21wb25lbnQ6IG51bGwsXG4gICAgICBwYWdlUHJvcHM6IG51bGwsXG4gICAgICBjYWNoZWQ6IGZhbHNlLFxuICAgICAgLi4uc3RyaXBUb3BMZXZlbFVuZGVmaW5lZChvcHRpb25zKSxcbiAgICAgIC4uLnN0cmlwVG9wTGV2ZWxVbmRlZmluZWQoY29uZmlndXJlZE9wdGlvbnMpXG4gICAgfTtcbiAgICBjb25zdCBbdXJsLCBfZGF0YV0gPSB0cmFuc2Zvcm1VcmxBbmREYXRhKFxuICAgICAgaHJlZixcbiAgICAgIG1lcmdlZE9wdGlvbnMuZGF0YSxcbiAgICAgIG1lcmdlZE9wdGlvbnMubWV0aG9kLFxuICAgICAgbWVyZ2VkT3B0aW9ucy5mb3JjZUZvcm1EYXRhLFxuICAgICAgbWVyZ2VkT3B0aW9ucy5xdWVyeVN0cmluZ0FycmF5Rm9ybWF0XG4gICAgKTtcbiAgICBjb25zdCB2aXNpdCA9IHtcbiAgICAgIGlkOiB0aGlzLmNyZWF0ZVZpc2l0SWQoKSxcbiAgICAgIGNhbmNlbGxlZDogZmFsc2UsXG4gICAgICBjb21wbGV0ZWQ6IGZhbHNlLFxuICAgICAgaW50ZXJydXB0ZWQ6IGZhbHNlLFxuICAgICAgLi4ubWVyZ2VkT3B0aW9ucyxcbiAgICAgIHVybCxcbiAgICAgIGRhdGE6IF9kYXRhXG4gICAgfTtcbiAgICBpZiAodmlzaXQucHJlZmV0Y2gpIHtcbiAgICAgIHZpc2l0LmhlYWRlcnNbXCJQdXJwb3NlXCJdID0gXCJwcmVmZXRjaFwiO1xuICAgIH1cbiAgICByZXR1cm4gdmlzaXQ7XG4gIH1cbiAgZ2V0VmlzaXRFdmVudHMob3B0aW9ucykge1xuICAgIHJldHVybiB7XG4gICAgICBvbkNhbmNlbFRva2VuOiBvcHRpb25zLm9uQ2FuY2VsVG9rZW4gfHwgbm9vcCxcbiAgICAgIG9uQmVmb3JlOiBvcHRpb25zLm9uQmVmb3JlIHx8IG5vb3AsXG4gICAgICBvbkJlZm9yZVVwZGF0ZTogb3B0aW9ucy5vbkJlZm9yZVVwZGF0ZSB8fCBub29wLFxuICAgICAgb25TdGFydDogb3B0aW9ucy5vblN0YXJ0IHx8IG5vb3AsXG4gICAgICBvblByb2dyZXNzOiBvcHRpb25zLm9uUHJvZ3Jlc3MgfHwgbm9vcCxcbiAgICAgIG9uRmluaXNoOiBvcHRpb25zLm9uRmluaXNoIHx8IG5vb3AsXG4gICAgICBvbkNhbmNlbDogb3B0aW9ucy5vbkNhbmNlbCB8fCBub29wLFxuICAgICAgb25TdWNjZXNzOiBvcHRpb25zLm9uU3VjY2VzcyB8fCBub29wLFxuICAgICAgb25FcnJvcjogb3B0aW9ucy5vbkVycm9yIHx8IG5vb3AsXG4gICAgICBvbkh0dHBFeGNlcHRpb246IG9wdGlvbnMub25IdHRwRXhjZXB0aW9uIHx8IG5vb3AsXG4gICAgICBvbk5ldHdvcmtFcnJvcjogb3B0aW9ucy5vbk5ldHdvcmtFcnJvciB8fCBub29wLFxuICAgICAgb25GbGFzaDogb3B0aW9ucy5vbkZsYXNoIHx8IG5vb3AsXG4gICAgICBvblByZWZldGNoZWQ6IG9wdGlvbnMub25QcmVmZXRjaGVkIHx8IG5vb3AsXG4gICAgICBvblByZWZldGNoaW5nOiBvcHRpb25zLm9uUHJlZmV0Y2hpbmcgfHwgbm9vcFxuICAgIH07XG4gIH1cbiAgYXBwbHlPcHRpbWlzdGljVXBkYXRlKG9wdGltaXN0aWMsIGV2ZW50cykge1xuICAgIGNvbnN0IGN1cnJlbnRQcm9wcyA9IHBhZ2UuZ2V0KCkucHJvcHM7XG4gICAgY29uc3Qgb3B0aW1pc3RpY1Byb3BzID0gb3B0aW1pc3RpYyhjbG9uZURlZXA0KGN1cnJlbnRQcm9wcykpO1xuICAgIGlmICghb3B0aW1pc3RpY1Byb3BzKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNoYW5nZWRLZXlzID0gW107XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob3B0aW1pc3RpY1Byb3BzKSkge1xuICAgICAgaWYgKCFpc0VxdWFsMyhjdXJyZW50UHJvcHNba2V5XSwgb3B0aW1pc3RpY1Byb3BzW2tleV0pKSB7XG4gICAgICAgIGNoYW5nZWRLZXlzLnB1c2goa2V5KTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNoYW5nZWRLZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpZCA9IHBhZ2UubmV4dE9wdGltaXN0aWNJZCgpO1xuICAgIGNvbnN0IGNvbXBvbmVudCA9IHBhZ2UuZ2V0KCkuY29tcG9uZW50O1xuICAgIGZvciAoY29uc3Qga2V5IG9mIGNoYW5nZWRLZXlzKSB7XG4gICAgICBwYWdlLnNldEJhc2VsaW5lKGtleSwgY2xvbmVEZWVwNChjdXJyZW50UHJvcHNba2V5XSkpO1xuICAgIH1cbiAgICBwYWdlLnJlZ2lzdGVyT3B0aW1pc3RpYyhpZCwgb3B0aW1pc3RpYyk7XG4gICAgcGFnZS5zZXRQcm9wc1F1aWV0bHkoeyAuLi5jdXJyZW50UHJvcHMsIC4uLm9wdGltaXN0aWNQcm9wcyB9KTtcbiAgICBsZXQgc2hvdWxkUmVzdG9yZSA9IHRydWU7XG4gICAgY29uc3Qgb3JpZ2luYWxPblN1Y2Nlc3MgPSBldmVudHMub25TdWNjZXNzO1xuICAgIGV2ZW50cy5vblN1Y2Nlc3MgPSAocGFnZTIpID0+IHtcbiAgICAgIHNob3VsZFJlc3RvcmUgPSBmYWxzZTtcbiAgICAgIHJldHVybiBvcmlnaW5hbE9uU3VjY2VzcyhwYWdlMik7XG4gICAgfTtcbiAgICBjb25zdCBvcmlnaW5hbE9uRmluaXNoID0gZXZlbnRzLm9uRmluaXNoO1xuICAgIGV2ZW50cy5vbkZpbmlzaCA9ICh2aXNpdCkgPT4ge1xuICAgICAgcGFnZS51bnJlZ2lzdGVyT3B0aW1pc3RpYyhpZCk7XG4gICAgICBpZiAoc2hvdWxkUmVzdG9yZSAmJiBwYWdlLmdldCgpLmNvbXBvbmVudCA9PT0gY29tcG9uZW50KSB7XG4gICAgICAgIGNvbnN0IHJlcGxheWVkUHJvcHMgPSBwYWdlLnJlcGxheU9wdGltaXN0aWNzKCk7XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhyZXBsYXllZFByb3BzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcGFnZS5zZXRQcm9wc1F1aWV0bHkoeyAuLi5wYWdlLmdldCgpLnByb3BzLCAuLi5yZXBsYXllZFByb3BzIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAocGFnZS5wZW5kaW5nT3B0aW1pc3RpY0NvdW50KCkgPT09IDApIHtcbiAgICAgICAgcGFnZS5jbGVhck9wdGltaXN0aWNTdGF0ZSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG9yaWdpbmFsT25GaW5pc2godmlzaXQpO1xuICAgIH07XG4gIH1cbiAgbG9hZERlZmVycmVkUHJvcHMoZGVmZXJyZWQpIHtcbiAgICBpZiAoZGVmZXJyZWQpIHtcbiAgICAgIE9iamVjdC52YWx1ZXMoZGVmZXJyZWQpLmZvckVhY2goKHByb3BzKSA9PiB7XG4gICAgICAgIHRoaXMuZG9SZWxvYWQoeyBvbmx5OiBwcm9wcywgZGVmZXJyZWRQcm9wczogdHJ1ZSwgcHJlc2VydmVFcnJvcnM6IHRydWUgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn07XG5cbi8vIHNyYy91c2VGb3JtVXRpbHMudHNcbnZhciBVc2VGb3JtVXRpbHMgPSBjbGFzcyB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2FsbGJhY2sgdGhhdCByZXR1cm5zIGEgVXJsTWV0aG9kUGFpci5cbiAgICpcbiAgICogY3JlYXRlV2F5ZmluZGVyQ2FsbGJhY2sodXJsTWV0aG9kUGFpcilcbiAgICogY3JlYXRlV2F5ZmluZGVyQ2FsbGJhY2sobWV0aG9kLCB1cmwpXG4gICAqIGNyZWF0ZVdheWZpbmRlckNhbGxiYWNrKCgpID0+IHVybE1ldGhvZFBhaXIpXG4gICAqIGNyZWF0ZVdheWZpbmRlckNhbGxiYWNrKCgpID0+IG1ldGhvZCwgKCkgPT4gdXJsKVxuICAgKi9cbiAgc3RhdGljIGNyZWF0ZVdheWZpbmRlckNhbGxiYWNrKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKGFyZ3MubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHJldHVybiBpc1VybE1ldGhvZFBhaXIoYXJnc1swXSkgPyBhcmdzWzBdIDogYXJnc1swXSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbWV0aG9kOiB0eXBlb2YgYXJnc1swXSA9PT0gXCJmdW5jdGlvblwiID8gYXJnc1swXSgpIDogYXJnc1swXSxcbiAgICAgICAgdXJsOiB0eXBlb2YgYXJnc1sxXSA9PT0gXCJmdW5jdGlvblwiID8gYXJnc1sxXSgpIDogYXJnc1sxXVxuICAgICAgfTtcbiAgICB9O1xuICB9XG4gIC8qKlxuICAgKiBQYXJzZXMgYWxsIHVzZUZvcm0oKSBhcmd1bWVudHMgaW50byB7IHJlbWVtYmVyS2V5LCBkYXRhLCBwcmVjb2duaXRpb25FbmRwb2ludCB9LlxuICAgKlxuICAgKiB1c2VGb3JtKClcbiAgICogdXNlRm9ybShkYXRhKVxuICAgKiB1c2VGb3JtKHJlbWVtYmVyS2V5LCBkYXRhKVxuICAgKiB1c2VGb3JtKG1ldGhvZCwgdXJsLCBkYXRhKVxuICAgKiB1c2VGb3JtKHVybE1ldGhvZFBhaXIsIGRhdGEpXG4gICAqXG4gICAqL1xuICBzdGF0aWMgcGFyc2VVc2VGb3JtQXJndW1lbnRzKC4uLmFyZ3MpIHtcbiAgICBpZiAoYXJncy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHJlbWVtYmVyS2V5OiBudWxsLFxuICAgICAgICBkYXRhOiB7fSxcbiAgICAgICAgcHJlY29nbml0aW9uRW5kcG9pbnQ6IG51bGxcbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcmVtZW1iZXJLZXk6IG51bGwsXG4gICAgICAgIGRhdGE6IGFyZ3NbMF0sXG4gICAgICAgIHByZWNvZ25pdGlvbkVuZHBvaW50OiBudWxsXG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAoYXJncy5sZW5ndGggPT09IDIpIHtcbiAgICAgIGlmICh0eXBlb2YgYXJnc1swXSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlbWVtYmVyS2V5OiBhcmdzWzBdLFxuICAgICAgICAgIGRhdGE6IGFyZ3NbMV0sXG4gICAgICAgICAgcHJlY29nbml0aW9uRW5kcG9pbnQ6IG51bGxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHJlbWVtYmVyS2V5OiBudWxsLFxuICAgICAgICBkYXRhOiBhcmdzWzFdLFxuICAgICAgICBwcmVjb2duaXRpb25FbmRwb2ludDogdGhpcy5jcmVhdGVXYXlmaW5kZXJDYWxsYmFjayhhcmdzWzBdKVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIHJlbWVtYmVyS2V5OiBudWxsLFxuICAgICAgZGF0YTogYXJnc1syXSxcbiAgICAgIHByZWNvZ25pdGlvbkVuZHBvaW50OiB0aGlzLmNyZWF0ZVdheWZpbmRlckNhbGxiYWNrKGFyZ3NbMF0sIGFyZ3NbMV0pXG4gICAgfTtcbiAgfVxuICAvKipcbiAgICogUGFyc2VzIGFsbCBzdWJtaXNzaW9uIGFyZ3VtZW50cyBpbnRvIHsgbWV0aG9kLCB1cmwsIG9wdGlvbnMgfS5cbiAgICogSXQgdXNlcyB0aGUgUHJlY29nbml0aW9uIGVuZHBvaW50IGlmIG5vIGV4cGxpY2l0IG1ldGhvZC91cmwgYXJlIHByb3ZpZGVkLlxuICAgKlxuICAgKiBmb3JtLnN1Ym1pdChtZXRob2QsIHVybClcbiAgICogZm9ybS5zdWJtaXQobWV0aG9kLCB1cmwsIG9wdGlvbnMpXG4gICAqIGZvcm0uc3VibWl0KHVybE1ldGhvZFBhaXIpXG4gICAqIGZvcm0uc3VibWl0KHVybE1ldGhvZFBhaXIsIG9wdGlvbnMpXG4gICAqIGZvcm0uc3VibWl0KClcbiAgICogZm9ybS5zdWJtaXQob3B0aW9ucylcbiAgICovXG4gIHN0YXRpYyBwYXJzZVN1Ym1pdEFyZ3VtZW50cyhhcmdzLCBwcmVjb2duaXRpb25FbmRwb2ludCkge1xuICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMyB8fCBhcmdzLmxlbmd0aCA9PT0gMiAmJiB0eXBlb2YgYXJnc1swXSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIHsgbWV0aG9kOiBhcmdzWzBdLCB1cmw6IGFyZ3NbMV0sIG9wdGlvbnM6IGFyZ3NbMl0gPz8ge30gfTtcbiAgICB9XG4gICAgaWYgKGlzVXJsTWV0aG9kUGFpcihhcmdzWzBdKSkge1xuICAgICAgcmV0dXJuIHsgLi4uYXJnc1swXSwgb3B0aW9uczogYXJnc1sxXSA/PyB7fSB9O1xuICAgIH1cbiAgICByZXR1cm4geyAuLi5wcmVjb2duaXRpb25FbmRwb2ludCgpLCBvcHRpb25zOiBhcmdzWzBdID8/IHt9IH07XG4gIH1cbiAgLyoqXG4gICAqIE1lcmdlcyBoZWFkZXJzIGludG8gdGhlIFByZWNvZ25pdGlvbiB2YWxpZGF0ZSgpIGFyZ3VtZW50cy5cbiAgICovXG4gIHN0YXRpYyBtZXJnZUhlYWRlcnNGb3JWYWxpZGF0aW9uKGZpZWxkLCBjb25maWcyLCBoZWFkZXJzKSB7XG4gICAgY29uc3QgbWVyZ2UgPSAoY29uZmlnMykgPT4ge1xuICAgICAgY29uZmlnMy5oZWFkZXJzID0ge1xuICAgICAgICAuLi5oZWFkZXJzID8/IHt9LFxuICAgICAgICAuLi5jb25maWczLmhlYWRlcnMgPz8ge31cbiAgICAgIH07XG4gICAgICByZXR1cm4gY29uZmlnMztcbiAgICB9O1xuICAgIGlmIChmaWVsZCAmJiB0eXBlb2YgZmllbGQgPT09IFwib2JqZWN0XCIgJiYgIShcInRhcmdldFwiIGluIGZpZWxkKSkge1xuICAgICAgZmllbGQgPSBtZXJnZShmaWVsZCk7XG4gICAgfSBlbHNlIGlmIChjb25maWcyICYmIHR5cGVvZiBjb25maWcyID09PSBcIm9iamVjdFwiKSB7XG4gICAgICBjb25maWcyID0gbWVyZ2UoY29uZmlnMik7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZmllbGQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGNvbmZpZzIgPSBtZXJnZShjb25maWcyID8/IHt9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZmllbGQgPSBtZXJnZShmaWVsZCA/PyB7fSk7XG4gICAgfVxuICAgIHJldHVybiBbZmllbGQsIGNvbmZpZzJdO1xuICB9XG59O1xuXG4vLyBzcmMvYXhpb3NIdHRwQ2xpZW50LnRzXG5mdW5jdGlvbiBub3JtYWxpemVIZWFkZXJzKGhlYWRlcnMpIHtcbiAgaWYgKCFoZWFkZXJzIHx8IHR5cGVvZiBoZWFkZXJzICE9PSBcIm9iamVjdFwiKSB7XG4gICAgcmV0dXJuIHt9O1xuICB9XG4gIGNvbnN0IG5vcm1hbGl6ZWQgPSB7fTtcbiAgY29uc3QgZW50cmllcyA9IHR5cGVvZiBoZWFkZXJzLmVudHJpZXMgPT09IFwiZnVuY3Rpb25cIiA/IEFycmF5LmZyb20oaGVhZGVycy5lbnRyaWVzKCkpIDogT2JqZWN0LmVudHJpZXMoaGVhZGVycyk7XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGVudHJpZXMpIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBub3JtYWxpemVkW2tleS50b0xvd2VyQ2FzZSgpXSA9IHZhbHVlO1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIG5vcm1hbGl6ZWRba2V5LnRvTG93ZXJDYXNlKCldID0gdmFsdWUuam9pbihcIiwgXCIpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbm9ybWFsaXplZDtcbn1cbmZ1bmN0aW9uIGlzQmluYXJ5UmVxdWVzdEJvZHkodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiBCbG9iICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbHVlIGluc3RhbmNlb2YgQmxvYiB8fCB0eXBlb2YgQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgdmFsdWUgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciB8fCB0eXBlb2YgQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgQXJyYXlCdWZmZXIuaXNWaWV3KHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGhhc0NvbnRlbnRUeXBlSGVhZGVyKGhlYWRlcnMpIHtcbiAgcmV0dXJuIE9iamVjdC5rZXlzKGhlYWRlcnMgPz8ge30pLnNvbWUoKGtleSkgPT4ga2V5LnRvTG93ZXJDYXNlKCkgPT09IFwiY29udGVudC10eXBlXCIpO1xufVxuZnVuY3Rpb24gdG9IdHRwUHJvZ3Jlc3NFdmVudChheGlvc0V2ZW50KSB7XG4gIHJldHVybiB7XG4gICAgcHJvZ3Jlc3M6IGF4aW9zRXZlbnQucHJvZ3Jlc3MsXG4gICAgcGVyY2VudGFnZTogYXhpb3NFdmVudC5wcm9ncmVzcyA/IE1hdGgucm91bmQoYXhpb3NFdmVudC5wcm9ncmVzcyAqIDEwMCkgOiAwLFxuICAgIGxvYWRlZDogYXhpb3NFdmVudC5sb2FkZWQsXG4gICAgdG90YWw6IGF4aW9zRXZlbnQudG90YWxcbiAgfTtcbn1cbnZhciBheGlvc01vZHVsZVByb21pc2U7XG5mdW5jdGlvbiBsb2FkQXhpb3NNb2R1bGUoKSB7XG4gIGlmICghYXhpb3NNb2R1bGVQcm9taXNlKSB7XG4gICAgYXhpb3NNb2R1bGVQcm9taXNlID0gaW1wb3J0KFwiYXhpb3NcIikuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICBheGlvc01vZHVsZVByb21pc2UgPSB2b2lkIDA7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gYXhpb3NNb2R1bGVQcm9taXNlO1xufVxudmFyIEF4aW9zSHR0cENsaWVudCA9IGNsYXNzIHtcbiAgYXhpb3NJbnN0YW5jZTtcbiAgY29uc3RydWN0b3IoaW5zdGFuY2UpIHtcbiAgICB0aGlzLmF4aW9zSW5zdGFuY2UgPSBpbnN0YW5jZSA/IFByb21pc2UucmVzb2x2ZShpbnN0YW5jZSkgOiBsb2FkQXhpb3NNb2R1bGUoKS50aGVuKChtb2R1bGUpID0+IG1vZHVsZS5kZWZhdWx0KTtcbiAgfVxuICBhc3luYyBnZXRBeGlvcygpIHtcbiAgICByZXR1cm4gdGhpcy5heGlvc0luc3RhbmNlO1xuICB9XG4gIGFzeW5jIHJlcXVlc3QoY29uZmlnMikge1xuICAgIGNvbnN0IHByb2Nlc3NlZENvbmZpZyA9IGF3YWl0IGh0dHBIYW5kbGVycy5wcm9jZXNzUmVxdWVzdChjb25maWcyKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmRvUmVxdWVzdChwcm9jZXNzZWRDb25maWcpO1xuICAgICAgcmV0dXJuIGF3YWl0IGh0dHBIYW5kbGVycy5wcm9jZXNzUmVzcG9uc2UocmVzcG9uc2UpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2VFcnJvciB8fCBlcnJvciBpbnN0YW5jZW9mIEh0dHBOZXR3b3JrRXJyb3IgfHwgZXJyb3IgaW5zdGFuY2VvZiBIdHRwQ2FuY2VsbGVkRXJyb3IpIHtcbiAgICAgICAgYXdhaXQgaHR0cEhhbmRsZXJzLnByb2Nlc3NFcnJvcihlcnJvcik7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZG9SZXF1ZXN0KGNvbmZpZzIpIHtcbiAgICBjb25zdCBheGlvcyA9IGF3YWl0IHRoaXMuZ2V0QXhpb3MoKTtcbiAgICBjb25zdCBoZWFkZXJzID0geyAuLi5jb25maWcyLmhlYWRlcnMgPz8ge30gfTtcbiAgICBpZiAoaXNCaW5hcnlSZXF1ZXN0Qm9keShjb25maWcyLmRhdGEpICYmICFoYXNDb250ZW50VHlwZUhlYWRlcihjb25maWcyLmhlYWRlcnMpKSB7XG4gICAgICBoZWFkZXJzW1wiQ29udGVudC1UeXBlXCJdID0gZmFsc2U7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF4aW9zKHtcbiAgICAgICAgbWV0aG9kOiBjb25maWcyLm1ldGhvZCxcbiAgICAgICAgdXJsOiBjb25maWcyLnVybCxcbiAgICAgICAgZGF0YTogY29uZmlnMi5kYXRhLFxuICAgICAgICBwYXJhbXM6IGNvbmZpZzIucGFyYW1zLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBzaWduYWw6IGNvbmZpZzIuc2lnbmFsLFxuICAgICAgICByZXNwb25zZVR5cGU6IFwidGV4dFwiLFxuICAgICAgICBvblVwbG9hZFByb2dyZXNzOiBjb25maWcyLm9uVXBsb2FkUHJvZ3Jlc3MgPyAoZXZlbnQpID0+IGNvbmZpZzIub25VcGxvYWRQcm9ncmVzcyh0b0h0dHBQcm9ncmVzc0V2ZW50KGV2ZW50KSkgOiB2b2lkIDBcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgICAgIGRhdGE6IHJlc3BvbnNlLmRhdGEsXG4gICAgICAgIGhlYWRlcnM6IG5vcm1hbGl6ZUhlYWRlcnMocmVzcG9uc2UuaGVhZGVycylcbiAgICAgIH07XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnN0IGF4aW9zTW9kdWxlID0gYXdhaXQgbG9hZEF4aW9zTW9kdWxlKCk7XG4gICAgICBpZiAoYXhpb3NNb2R1bGUuZGVmYXVsdC5pc0NhbmNlbChlcnJvcikpIHtcbiAgICAgICAgdGhyb3cgbmV3IEh0dHBDYW5jZWxsZWRFcnJvcihcIlJlcXVlc3Qgd2FzIGNhbmNlbGxlZFwiLCBjb25maWcyLnVybCk7XG4gICAgICB9XG4gICAgICBpZiAoZXJyb3IgJiYgdHlwZW9mIGVycm9yID09PSBcIm9iamVjdFwiICYmIFwicmVzcG9uc2VcIiBpbiBlcnJvcikge1xuICAgICAgICBjb25zdCBheGlvc0Vycm9yID0gZXJyb3I7XG4gICAgICAgIGNvbnN0IGh0dHBSZXNwb25zZSA9IHtcbiAgICAgICAgICBzdGF0dXM6IGF4aW9zRXJyb3IucmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgIGRhdGE6IGF4aW9zRXJyb3IucmVzcG9uc2UuZGF0YSxcbiAgICAgICAgICBoZWFkZXJzOiBub3JtYWxpemVIZWFkZXJzKGF4aW9zRXJyb3IucmVzcG9uc2UuaGVhZGVycylcbiAgICAgICAgfTtcbiAgICAgICAgdGhyb3cgbmV3IEh0dHBSZXNwb25zZUVycm9yKFxuICAgICAgICAgIGBSZXF1ZXN0IGZhaWxlZCB3aXRoIHN0YXR1cyAke2F4aW9zRXJyb3IucmVzcG9uc2Uuc3RhdHVzfWAsXG4gICAgICAgICAgaHR0cFJlc3BvbnNlLFxuICAgICAgICAgIGNvbmZpZzIudXJsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgSHR0cE5ldHdvcmtFcnJvcihcbiAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIk5ldHdvcmsgZXJyb3JcIixcbiAgICAgICAgY29uZmlnMi51cmwsXG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvciA6IHZvaWQgMFxuICAgICAgKTtcbiAgICB9XG4gIH1cbn07XG5mdW5jdGlvbiBheGlvc0FkYXB0ZXIoaW5zdGFuY2UpIHtcbiAgcmV0dXJuIG5ldyBBeGlvc0h0dHBDbGllbnQoaW5zdGFuY2UpO1xufVxuXG4vLyBzcmMvZm9ybU9iamVjdC50c1xuaW1wb3J0IHsgZ2V0IGFzIGdldDgsIHNldCBhcyBzZXQ2IH0gZnJvbSBcImVzLXRvb2xraXQvY29tcGF0XCI7XG5mdW5jdGlvbiB1bmRvdEtleShrZXkpIHtcbiAgaWYgKCFrZXkuaW5jbHVkZXMoXCIuXCIpKSB7XG4gICAgcmV0dXJuIGtleTtcbiAgfVxuICBjb25zdCB0cmFuc2Zvcm1TZWdtZW50ID0gKHNlZ21lbnQpID0+IHtcbiAgICBpZiAoc2VnbWVudC5zdGFydHNXaXRoKFwiW1wiKSAmJiBzZWdtZW50LmVuZHNXaXRoKFwiXVwiKSkge1xuICAgICAgcmV0dXJuIHNlZ21lbnQ7XG4gICAgfVxuICAgIHJldHVybiBzZWdtZW50LnNwbGl0KFwiLlwiKS5yZWR1Y2UoKHJlc3VsdCwgcGFydCwgaW5kZXgpID0+IGluZGV4ID09PSAwID8gcGFydCA6IGAke3Jlc3VsdH1bJHtwYXJ0fV1gKTtcbiAgfTtcbiAgcmV0dXJuIGtleS5yZXBsYWNlKC9cXFxcXFwuL2csIFwiX19FU0NBUEVEX0RPVF9fXCIpLnNwbGl0KC8oXFxbW15cXF1dKlxcXSkvKS5maWx0ZXIoQm9vbGVhbikubWFwKHRyYW5zZm9ybVNlZ21lbnQpLmpvaW4oXCJcIikucmVwbGFjZSgvX19FU0NBUEVEX0RPVF9fL2csIFwiLlwiKTtcbn1cbmZ1bmN0aW9uIHBhcnNlS2V5MihrZXkpIHtcbiAgY29uc3QgcGF0aCA9IFtdO1xuICBjb25zdCBwYXR0ZXJuID0gLyhbXlxcW1xcXV0rKXxcXFsoXFxkKilcXF0vZztcbiAgbGV0IG1hdGNoO1xuICB3aGlsZSAoKG1hdGNoID0gcGF0dGVybi5leGVjKGtleSkpICE9PSBudWxsKSB7XG4gICAgaWYgKG1hdGNoWzFdICE9PSB2b2lkIDApIHtcbiAgICAgIHBhdGgucHVzaChtYXRjaFsxXSk7XG4gICAgfSBlbHNlIGlmIChtYXRjaFsyXSAhPT0gdm9pZCAwKSB7XG4gICAgICBwYXRoLnB1c2gobWF0Y2hbMl0gPT09IFwiXCIgPyBcIlwiIDogTnVtYmVyKG1hdGNoWzJdKSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gc2V0TmVzdGVkT2JqZWN0KG9iaiwgcGF0aCwgdmFsdWUpIHtcbiAgbGV0IGN1cnJlbnQgPSBvYmo7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcGF0aC5sZW5ndGggLSAxOyBpKyspIHtcbiAgICBpZiAoIShwYXRoW2ldIGluIGN1cnJlbnQpKSB7XG4gICAgICBjdXJyZW50W3BhdGhbaV1dID0ge307XG4gICAgfVxuICAgIGN1cnJlbnQgPSBjdXJyZW50W3BhdGhbaV1dO1xuICB9XG4gIGN1cnJlbnRbcGF0aFtwYXRoLmxlbmd0aCAtIDFdXSA9IHZhbHVlO1xufVxuZnVuY3Rpb24gb2JqZWN0SGFzU2VxdWVudGlhbE51bWVyaWNLZXlzKHZhbHVlKSB7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSk7XG4gIGNvbnN0IG51bWVyaWNLZXlzID0ga2V5cy5maWx0ZXIoKGspID0+IC9eXFxkKyQvLnRlc3QoaykpLm1hcChOdW1iZXIpLnNvcnQoKGEsIGIpID0+IGEgLSBiKTtcbiAgcmV0dXJuIGtleXMubGVuZ3RoID09PSBudW1lcmljS2V5cy5sZW5ndGggJiYgbnVtZXJpY0tleXMubGVuZ3RoID4gMCAmJiBudW1lcmljS2V5c1swXSA9PT0gMCAmJiBudW1lcmljS2V5cy5ldmVyeSgobiwgaSkgPT4gbiA9PT0gaSk7XG59XG5mdW5jdGlvbiBjb252ZXJ0U2VxdWVudGlhbE9iamVjdHNUb0FycmF5cyh2YWx1ZSkge1xuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWUubWFwKGNvbnZlcnRTZXF1ZW50aWFsT2JqZWN0c1RvQXJyYXlzKTtcbiAgfVxuICBpZiAodHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiIHx8IHZhbHVlID09PSBudWxsIHx8IGlzRmlsZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgaWYgKG9iamVjdEhhc1NlcXVlbnRpYWxOdW1lcmljS2V5cyh2YWx1ZSkpIHtcbiAgICBjb25zdCByZXN1bHQyID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoOyBpKyspIHtcbiAgICAgIHJlc3VsdDJbaV0gPSBjb252ZXJ0U2VxdWVudGlhbE9iamVjdHNUb0FycmF5cyh2YWx1ZVtpXSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQyO1xuICB9XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiB2YWx1ZSkge1xuICAgIHJlc3VsdFtrZXldID0gY29udmVydFNlcXVlbnRpYWxPYmplY3RzVG9BcnJheXModmFsdWVba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGZvcm1EYXRhVG9PYmplY3Qoc291cmNlKSB7XG4gIGNvbnN0IGZvcm0gPSB7fTtcbiAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2Ygc291cmNlLmVudHJpZXMoKSkge1xuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEZpbGUgJiYgdmFsdWUuc2l6ZSA9PT0gMCAmJiB2YWx1ZS5uYW1lID09PSBcIlwiKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgcGF0aCA9IHBhcnNlS2V5Mih1bmRvdEtleShrZXkpKTtcbiAgICBpZiAocGF0aFtwYXRoLmxlbmd0aCAtIDFdID09PSBcIlwiKSB7XG4gICAgICBjb25zdCBhcnJheVBhdGggPSBwYXRoLnNsaWNlKDAsIC0xKTtcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gZ2V0OChmb3JtLCBhcnJheVBhdGgpO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZXhpc3RpbmcpKSB7XG4gICAgICAgIGV4aXN0aW5nLnB1c2godmFsdWUpO1xuICAgICAgfSBlbHNlIGlmIChleGlzdGluZyAmJiB0eXBlb2YgZXhpc3RpbmcgPT09IFwib2JqZWN0XCIgJiYgIWlzRmlsZShleGlzdGluZykpIHtcbiAgICAgICAgY29uc3QgbnVtZXJpY0tleXMgPSBPYmplY3Qua2V5cyhleGlzdGluZykuZmlsdGVyKChrKSA9PiAvXlxcZCskLy50ZXN0KGspKS5tYXAoTnVtYmVyKS5zb3J0KChhLCBiKSA9PiBhIC0gYik7XG4gICAgICAgIHNldDYoZm9ybSwgYXJyYXlQYXRoLCBudW1lcmljS2V5cy5sZW5ndGggPiAwID8gWy4uLm51bWVyaWNLZXlzLm1hcCgoaykgPT4gZXhpc3Rpbmdba10pLCB2YWx1ZV0gOiBbdmFsdWVdKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldDYoZm9ybSwgYXJyYXlQYXRoLCBbdmFsdWVdKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBzZXROZXN0ZWRPYmplY3QoZm9ybSwgcGF0aC5tYXAoU3RyaW5nKSwgdmFsdWUpO1xuICB9XG4gIHJldHVybiBjb252ZXJ0U2VxdWVudGlhbE9iamVjdHNUb0FycmF5cyhmb3JtKTtcbn1cblxuLy8gc3JjL2hlYWQudHNcbnZhciBzZXJ2ZXJIZWFkUHJvdmlkZXJJZCA9IFwic2VydmVyXCI7XG5mdW5jdGlvbiBlbnN1cmVFbGVtZW50SGFzSW5lcnRpYUF0dHJpYnV0ZShlbGVtZW50LCBpbmRleCkge1xuICBpZiAoZWxlbWVudC5tYXRjaCgvXFxzZGF0YS1pbmVydGlhKD18XFxzfD4pLykpIHtcbiAgICByZXR1cm4gZWxlbWVudDtcbiAgfVxuICByZXR1cm4gZWxlbWVudC5yZXBsYWNlKC9ePChbYS16QS1aXVteXFxzLz5dKikvLCBgPCQxIGRhdGEtaW5lcnRpYT1cInNlcnZlci1oZWFkLSR7aW5kZXh9XCJgKTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVTZXJ2ZXJIZWFkKHBhZ2UyLCBzZXJ2ZXJIZWFkKSB7XG4gIGlmICghc2VydmVySGVhZCkge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICBjb25zdCBlbGVtZW50cyA9IHR5cGVvZiBzZXJ2ZXJIZWFkID09PSBcImZ1bmN0aW9uXCIgPyBzZXJ2ZXJIZWFkKHBhZ2UyKSA6IHBhZ2UyLnByb3BzW3NlcnZlckhlYWQgPT09IHRydWUgPyBcImhlYWRcIiA6IHNlcnZlckhlYWRdO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoZWxlbWVudHMpKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHJldHVybiBlbGVtZW50cy5tYXAoKGVsZW1lbnQpID0+IHR5cGVvZiBlbGVtZW50ID09PSBcInN0cmluZ1wiID8gZWxlbWVudC50cmltKCkgOiBlbGVtZW50KS5maWx0ZXIoKGVsZW1lbnQpID0+IHR5cGVvZiBlbGVtZW50ID09PSBcInN0cmluZ1wiICYmIGVsZW1lbnQubGVuZ3RoID4gMCkubWFwKGVuc3VyZUVsZW1lbnRIYXNJbmVydGlhQXR0cmlidXRlKTtcbn1cbnZhciBSZW5kZXJlciA9IHtcbiAgYnVpbGRET01FbGVtZW50KHRhZykge1xuICAgIGNvbnN0IHRlbXBsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInRlbXBsYXRlXCIpO1xuICAgIHRlbXBsYXRlLmlubmVySFRNTCA9IHRhZztcbiAgICBjb25zdCBub2RlID0gdGVtcGxhdGUuY29udGVudC5maXJzdENoaWxkO1xuICAgIGlmICghdGFnLnN0YXJ0c1dpdGgoXCI8c2NyaXB0IFwiKSkge1xuICAgICAgcmV0dXJuIG5vZGU7XG4gICAgfVxuICAgIGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIik7XG4gICAgc2NyaXB0LmlubmVySFRNTCA9IG5vZGUuaW5uZXJIVE1MO1xuICAgIG5vZGUuZ2V0QXR0cmlidXRlTmFtZXMoKS5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgICBzY3JpcHQuc2V0QXR0cmlidXRlKG5hbWUsIG5vZGUuZ2V0QXR0cmlidXRlKG5hbWUpIHx8IFwiXCIpO1xuICAgIH0pO1xuICAgIHJldHVybiBzY3JpcHQ7XG4gIH0sXG4gIGlzSW5lcnRpYU1hbmFnZWRFbGVtZW50KGVsZW1lbnQpIHtcbiAgICByZXR1cm4gZWxlbWVudC5ub2RlVHlwZSA9PT0gTm9kZS5FTEVNRU5UX05PREUgJiYgZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWluZXJ0aWFcIikgIT09IG51bGw7XG4gIH0sXG4gIGZpbmRNYXRjaGluZ0VsZW1lbnRJbmRleChlbGVtZW50LCBlbGVtZW50cykge1xuICAgIGNvbnN0IGtleSA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS1pbmVydGlhXCIpO1xuICAgIGlmIChrZXkgIT09IG51bGwpIHtcbiAgICAgIHJldHVybiBlbGVtZW50cy5maW5kSW5kZXgoKGVsZW1lbnQyKSA9PiBlbGVtZW50Mi5nZXRBdHRyaWJ1dGUoXCJkYXRhLWluZXJ0aWFcIikgPT09IGtleSk7XG4gICAgfVxuICAgIHJldHVybiAtMTtcbiAgfSxcbiAgdXBkYXRlOiBkZWJvdW5jZShmdW5jdGlvbihlbGVtZW50cykge1xuICAgIGNvbnN0IHNvdXJjZUVsZW1lbnRzID0gZWxlbWVudHMubWFwKChlbGVtZW50KSA9PiB0aGlzLmJ1aWxkRE9NRWxlbWVudChlbGVtZW50KSk7XG4gICAgY29uc3QgdGFyZ2V0RWxlbWVudHMgPSBBcnJheS5mcm9tKGRvY3VtZW50LmhlYWQuY2hpbGROb2RlcykuZmlsdGVyKFxuICAgICAgKGVsZW1lbnQpID0+IHRoaXMuaXNJbmVydGlhTWFuYWdlZEVsZW1lbnQoZWxlbWVudClcbiAgICApO1xuICAgIGlmIChzb3VyY2VFbGVtZW50cy5zb21lKChlbGVtZW50KSA9PiBlbGVtZW50IGluc3RhbmNlb2YgSFRNTFRpdGxlRWxlbWVudCkpIHtcbiAgICAgIGRvY3VtZW50LmhlYWQucXVlcnlTZWxlY3RvckFsbChcInRpdGxlOm5vdChbZGF0YS1pbmVydGlhXSlcIikuZm9yRWFjaCgodGl0bGUpID0+IHRpdGxlLnJlbW92ZSgpKTtcbiAgICB9XG4gICAgdGFyZ2V0RWxlbWVudHMuZm9yRWFjaCgodGFyZ2V0RWxlbWVudCkgPT4ge1xuICAgICAgY29uc3QgaW5kZXggPSB0aGlzLmZpbmRNYXRjaGluZ0VsZW1lbnRJbmRleCh0YXJnZXRFbGVtZW50LCBzb3VyY2VFbGVtZW50cyk7XG4gICAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICAgIHRhcmdldEVsZW1lbnQucmVtb3ZlKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNvdXJjZUVsZW1lbnQgPSBzb3VyY2VFbGVtZW50cy5zcGxpY2UoaW5kZXgsIDEpWzBdO1xuICAgICAgaWYgKHNvdXJjZUVsZW1lbnQgJiYgIXRhcmdldEVsZW1lbnQuaXNFcXVhbE5vZGUoc291cmNlRWxlbWVudCkpIHtcbiAgICAgICAgdGFyZ2V0RWxlbWVudC5yZXBsYWNlV2l0aChzb3VyY2VFbGVtZW50KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBzb3VyY2VFbGVtZW50cy5mb3JFYWNoKChlbGVtZW50KSA9PiB7XG4gICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGVsZW1lbnQpO1xuICAgIH0pO1xuICB9LCAxKVxufTtcbmZ1bmN0aW9uIGNyZWF0ZUhlYWRNYW5hZ2VyKGlzU2VydmVyMywgdGl0bGVDYWxsYmFjaywgb25VcGRhdGUsIGluaXRpYWxTZXJ2ZXJIZWFkID0gW10pIHtcbiAgY29uc3Qgc3RhdGVzID0gaW5pdGlhbFNlcnZlckhlYWQubGVuZ3RoID8geyBbc2VydmVySGVhZFByb3ZpZGVySWRdOiBpbml0aWFsU2VydmVySGVhZCB9IDoge307XG4gIGxldCBsYXN0UHJvdmlkZXJJZCA9IDA7XG4gIGZ1bmN0aW9uIGNvbm5lY3QoKSB7XG4gICAgY29uc3QgaWQgPSBsYXN0UHJvdmlkZXJJZCArPSAxO1xuICAgIHN0YXRlc1tpZF0gPSBbXTtcbiAgICByZXR1cm4gaWQudG9TdHJpbmcoKTtcbiAgfVxuICBmdW5jdGlvbiBkaXNjb25uZWN0KGlkKSB7XG4gICAgaWYgKGlkID09PSBudWxsIHx8IE9iamVjdC5rZXlzKHN0YXRlcykuaW5kZXhPZihpZCkgPT09IC0xKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGRlbGV0ZSBzdGF0ZXNbaWRdO1xuICAgIGNvbW1pdCgpO1xuICB9XG4gIGZ1bmN0aW9uIHJlY29ubmVjdChpZCkge1xuICAgIGlmIChPYmplY3Qua2V5cyhzdGF0ZXMpLmluZGV4T2YoaWQpID09PSAtMSkge1xuICAgICAgc3RhdGVzW2lkXSA9IFtdO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiB1cGRhdGUoaWQsIGVsZW1lbnRzID0gW10pIHtcbiAgICBpZiAoaWQgIT09IG51bGwgJiYgT2JqZWN0LmtleXMoc3RhdGVzKS5pbmRleE9mKGlkKSA+IC0xKSB7XG4gICAgICBzdGF0ZXNbaWRdID0gZWxlbWVudHM7XG4gICAgfVxuICAgIGNvbW1pdCgpO1xuICB9XG4gIGZ1bmN0aW9uIHVwZGF0ZVNlcnZlckhlYWQoZWxlbWVudHMgPSBbXSkge1xuICAgIGlmIChlbGVtZW50cy5sZW5ndGgpIHtcbiAgICAgIHN0YXRlc1tzZXJ2ZXJIZWFkUHJvdmlkZXJJZF0gPSBlbGVtZW50cztcbiAgICB9IGVsc2Uge1xuICAgICAgZGVsZXRlIHN0YXRlc1tzZXJ2ZXJIZWFkUHJvdmlkZXJJZF07XG4gICAgfVxuICAgIGNvbW1pdCgpO1xuICB9XG4gIGZ1bmN0aW9uIGNvbGxlY3QoKSB7XG4gICAgY29uc3QgdGl0bGUgPSB0aXRsZUNhbGxiYWNrKFwiXCIpO1xuICAgIGNvbnN0IHNlcnZlckhlYWQgPSBzdGF0ZXNbc2VydmVySGVhZFByb3ZpZGVySWRdIHx8IFtdO1xuICAgIGNvbnN0IHByb3ZpZGVySGVhZCA9IE9iamVjdC5rZXlzKHN0YXRlcykuZmlsdGVyKChpZCkgPT4gaWQgIT09IHNlcnZlckhlYWRQcm92aWRlcklkKS5mbGF0TWFwKChpZCkgPT4gc3RhdGVzW2lkXSk7XG4gICAgY29uc3QgZGVmYXVsdHMgPSB7XG4gICAgICAuLi50aXRsZSA/IHsgdGl0bGU6IGA8dGl0bGUgZGF0YS1pbmVydGlhPVwiXCI+JHt0aXRsZX08L3RpdGxlPmAgfSA6IHt9XG4gICAgfTtcbiAgICBjb25zdCBlbGVtZW50cyA9IHNlcnZlckhlYWQuY29uY2F0KHByb3ZpZGVySGVhZCkucmVkdWNlKChjYXJyeSwgZWxlbWVudCkgPT4ge1xuICAgICAgaWYgKGVsZW1lbnQuaW5kZXhPZihcIjxcIikgPT09IC0xKSB7XG4gICAgICAgIHJldHVybiBjYXJyeTtcbiAgICAgIH1cbiAgICAgIGlmIChlbGVtZW50LmluZGV4T2YoXCI8dGl0bGUgXCIpID09PSAwKSB7XG4gICAgICAgIGNvbnN0IHRpdGxlMiA9IGVsZW1lbnQubWF0Y2goLyg8dGl0bGUgW14+XSs+KSguKj8pKDxcXC90aXRsZT4pL3MpO1xuICAgICAgICBjYXJyeS50aXRsZSA9IHRpdGxlMiA/IGAke3RpdGxlMlsxXX0ke3RpdGxlQ2FsbGJhY2sodGl0bGUyWzJdKX0ke3RpdGxlMlszXX1gIDogZWxlbWVudDtcbiAgICAgICAgcmV0dXJuIGNhcnJ5O1xuICAgICAgfVxuICAgICAgY29uc3QgbWF0Y2ggPSBlbGVtZW50Lm1hdGNoKC8gZGF0YS1pbmVydGlhPShbXCInXSlbXlwiJ10rXFwxLyk7XG4gICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgY2FycnlbbWF0Y2hbMF1dID0gZWxlbWVudDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhcnJ5W09iamVjdC5rZXlzKGNhcnJ5KS5sZW5ndGhdID0gZWxlbWVudDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjYXJyeTtcbiAgICB9LCBkZWZhdWx0cyk7XG4gICAgcmV0dXJuIE9iamVjdC52YWx1ZXMoZWxlbWVudHMpO1xuICB9XG4gIGZ1bmN0aW9uIGNvbW1pdCgpIHtcbiAgICBpc1NlcnZlcjMgPyBvblVwZGF0ZShjb2xsZWN0KCkpIDogUmVuZGVyZXIudXBkYXRlKGNvbGxlY3QoKSk7XG4gIH1cbiAgY29tbWl0KCk7XG4gIHJldHVybiB7XG4gICAgZm9yY2VVcGRhdGU6IGNvbW1pdCxcbiAgICB1cGRhdGVTZXJ2ZXJIZWFkLFxuICAgIGNyZWF0ZVByb3ZpZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgIGNvbnN0IGlkID0gY29ubmVjdCgpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcmVjb25uZWN0OiAoKSA9PiByZWNvbm5lY3QoaWQpLFxuICAgICAgICB1cGRhdGU6IChlbGVtZW50cykgPT4gdXBkYXRlKGlkLCBlbGVtZW50cyksXG4gICAgICAgIGRpc2Nvbm5lY3Q6ICgpID0+IGRpc2Nvbm5lY3QoaWQpXG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn1cblxuLy8gc3JjL2luZmluaXRlU2Nyb2xsL2RhdGEudHNcbnZhciBNRVJHRV9JTlRFTlRfSEVBREVSID0gXCJYLUluZXJ0aWEtSW5maW5pdGUtU2Nyb2xsLU1lcmdlLUludGVudFwiO1xudmFyIHVzZUluZmluaXRlU2Nyb2xsRGF0YSA9IChvcHRpb25zKSA9PiB7XG4gIGNvbnN0IGdldFNjcm9sbFByb3BGcm9tQ3VycmVudFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qgc2Nyb2xsUHJvcCA9IHBhZ2UuZ2V0KCkuc2Nyb2xsUHJvcHM/LltvcHRpb25zLmdldFByb3BOYW1lKCldO1xuICAgIGlmIChzY3JvbGxQcm9wKSB7XG4gICAgICByZXR1cm4gc2Nyb2xsUHJvcDtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBUaGUgcGFnZSBvYmplY3QgZG9lcyBub3QgY29udGFpbiBhIHNjcm9sbCBwcm9wIG5hbWVkIFwiJHtvcHRpb25zLmdldFByb3BOYW1lKCl9XCIuYCk7XG4gIH07XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGNvbXBvbmVudDogbnVsbCxcbiAgICBsb2FkaW5nOiBmYWxzZSxcbiAgICBwcmV2aW91c1BhZ2U6IG51bGwsXG4gICAgbmV4dFBhZ2U6IG51bGwsXG4gICAgbGFzdExvYWRlZFBhZ2U6IG51bGwsXG4gICAgcmVxdWVzdENvdW50OiAwXG4gIH07XG4gIGNvbnN0IHJlc2V0U3RhdGUgPSAoKSA9PiB7XG4gICAgY29uc3Qgc2Nyb2xsUHJvcCA9IGdldFNjcm9sbFByb3BGcm9tQ3VycmVudFBhZ2UoKTtcbiAgICBzdGF0ZS5jb21wb25lbnQgPSBwYWdlLmdldCgpLmNvbXBvbmVudDtcbiAgICBzdGF0ZS5sb2FkaW5nID0gZmFsc2U7XG4gICAgc3RhdGUucHJldmlvdXNQYWdlID0gc2Nyb2xsUHJvcC5wcmV2aW91c1BhZ2U7XG4gICAgc3RhdGUubmV4dFBhZ2UgPSBzY3JvbGxQcm9wLm5leHRQYWdlO1xuICAgIHN0YXRlLmxhc3RMb2FkZWRQYWdlID0gc2Nyb2xsUHJvcC5jdXJyZW50UGFnZTtcbiAgICBzdGF0ZS5yZXF1ZXN0Q291bnQgPSAwO1xuICB9O1xuICBjb25zdCBnZXRSZW1lbWJlcktleSA9ICgpID0+IGBpbmVydGlhOmluZmluaXRlLXNjcm9sbC1kYXRhOiR7b3B0aW9ucy5nZXRQcm9wTmFtZSgpfWA7XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgcmVzZXRTdGF0ZSgpO1xuICAgIGNvbnN0IHJlbWVtYmVyZWRTdGF0ZSA9IHJvdXRlci5yZXN0b3JlKGdldFJlbWVtYmVyS2V5KCkpO1xuICAgIGlmIChyZW1lbWJlcmVkU3RhdGUgJiYgdHlwZW9mIHJlbWVtYmVyZWRTdGF0ZSA9PT0gXCJvYmplY3RcIiAmJiByZW1lbWJlcmVkU3RhdGUubGFzdExvYWRlZFBhZ2UgPT09IGdldFNjcm9sbFByb3BGcm9tQ3VycmVudFBhZ2UoKS5jdXJyZW50UGFnZSkge1xuICAgICAgc3RhdGUucHJldmlvdXNQYWdlID0gcmVtZW1iZXJlZFN0YXRlLnByZXZpb3VzUGFnZTtcbiAgICAgIHN0YXRlLm5leHRQYWdlID0gcmVtZW1iZXJlZFN0YXRlLm5leHRQYWdlO1xuICAgICAgc3RhdGUubGFzdExvYWRlZFBhZ2UgPSByZW1lbWJlcmVkU3RhdGUubGFzdExvYWRlZFBhZ2U7XG4gICAgICBzdGF0ZS5yZXF1ZXN0Q291bnQgPSByZW1lbWJlcmVkU3RhdGUucmVxdWVzdENvdW50IHx8IDA7XG4gICAgfVxuICB9XG4gIGNvbnN0IHJlbW92ZUV2ZW50TGlzdGVuZXIgPSByb3V0ZXIub24oXCJzdWNjZXNzXCIsIChldmVudCkgPT4ge1xuICAgIGlmIChzdGF0ZS5jb21wb25lbnQgPT09IGV2ZW50LmRldGFpbC5wYWdlLmNvbXBvbmVudCAmJiBnZXRTY3JvbGxQcm9wRnJvbUN1cnJlbnRQYWdlKCkucmVzZXQpIHtcbiAgICAgIHJlc2V0U3RhdGUoKTtcbiAgICAgIG9wdGlvbnMub25SZXNldD8uKCk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgZ2V0U2Nyb2xsUHJvcEtleUZvclNpZGUgPSAoc2lkZSkgPT4ge1xuICAgIHJldHVybiBzaWRlID09PSBcIm5leHRcIiA/IFwibmV4dFBhZ2VcIiA6IFwicHJldmlvdXNQYWdlXCI7XG4gIH07XG4gIGNvbnN0IGZpbmRQYWdlVG9Mb2FkID0gKHNpZGUpID0+IHtcbiAgICBjb25zdCBwYWdlUHJvcE5hbWUgPSBnZXRTY3JvbGxQcm9wS2V5Rm9yU2lkZShzaWRlKTtcbiAgICByZXR1cm4gc3RhdGVbcGFnZVByb3BOYW1lXTtcbiAgfTtcbiAgY29uc3Qgc3luY1N0YXRlT25TdWNjZXNzID0gKHNpZGUpID0+IHtcbiAgICBjb25zdCBzY3JvbGxQcm9wID0gZ2V0U2Nyb2xsUHJvcEZyb21DdXJyZW50UGFnZSgpO1xuICAgIGNvbnN0IHBhZ2luYXRpb25Qcm9wID0gZ2V0U2Nyb2xsUHJvcEtleUZvclNpZGUoc2lkZSk7XG4gICAgc3RhdGUubGFzdExvYWRlZFBhZ2UgPSBzY3JvbGxQcm9wLmN1cnJlbnRQYWdlO1xuICAgIHN0YXRlW3BhZ2luYXRpb25Qcm9wXSA9IHNjcm9sbFByb3BbcGFnaW5hdGlvblByb3BdO1xuICAgIHN0YXRlLnJlcXVlc3RDb3VudCArPSAxO1xuICAgIHJvdXRlci5yZW1lbWJlcihcbiAgICAgIHtcbiAgICAgICAgcHJldmlvdXNQYWdlOiBzdGF0ZS5wcmV2aW91c1BhZ2UsXG4gICAgICAgIG5leHRQYWdlOiBzdGF0ZS5uZXh0UGFnZSxcbiAgICAgICAgbGFzdExvYWRlZFBhZ2U6IHN0YXRlLmxhc3RMb2FkZWRQYWdlLFxuICAgICAgICByZXF1ZXN0Q291bnQ6IHN0YXRlLnJlcXVlc3RDb3VudFxuICAgICAgfSxcbiAgICAgIGdldFJlbWVtYmVyS2V5KClcbiAgICApO1xuICB9O1xuICBjb25zdCBnZXRQYWdlTmFtZSA9ICgpID0+IGdldFNjcm9sbFByb3BGcm9tQ3VycmVudFBhZ2UoKS5wYWdlTmFtZTtcbiAgY29uc3QgZ2V0UmVxdWVzdENvdW50ID0gKCkgPT4gc3RhdGUucmVxdWVzdENvdW50O1xuICBjb25zdCBmZXRjaFBhZ2UgPSAoc2lkZSwgcmVsb2FkT3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgY29uc3QgcGFnZTIgPSBmaW5kUGFnZVRvTG9hZChzaWRlKTtcbiAgICBpZiAoc3RhdGUubG9hZGluZyB8fCBwYWdlMiA9PT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdGF0ZS5sb2FkaW5nID0gdHJ1ZTtcbiAgICByb3V0ZXIucmVsb2FkKHtcbiAgICAgIHByZXNlcnZlRXJyb3JzOiB0cnVlLFxuICAgICAgLi4ucmVsb2FkT3B0aW9ucyxcbiAgICAgIGRhdGE6IHsgLi4ucmVsb2FkT3B0aW9ucy5kYXRhIHx8IHt9LCBbZ2V0UGFnZU5hbWUoKV06IHBhZ2UyIH0sXG4gICAgICBvbmx5OiBbLi4ucmVsb2FkT3B0aW9ucy5vbmx5IHx8IFtdLCBvcHRpb25zLmdldFByb3BOYW1lKCldLFxuICAgICAgcHJlc2VydmVVcmw6IHRydWUsXG4gICAgICAvLyB3ZSBoYW5kbGUgVVJMIHVwZGF0ZXMgbWFudWFsbHkgdmlhIHVzZUluZmluaXRlU2Nyb2xsUXVlcnlTdHJpbmcoKVxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBbTUVSR0VfSU5URU5UX0hFQURFUl06IHNpZGUgPT09IFwicHJldmlvdXNcIiA/IFwicHJlcGVuZFwiIDogXCJhcHBlbmRcIixcbiAgICAgICAgLi4ucmVsb2FkT3B0aW9ucy5oZWFkZXJzXG4gICAgICB9LFxuICAgICAgb25CZWZvcmU6ICh2aXNpdCkgPT4ge1xuICAgICAgICBzaWRlID09PSBcIm5leHRcIiA/IG9wdGlvbnMub25CZWZvcmVOZXh0UmVxdWVzdCgpIDogb3B0aW9ucy5vbkJlZm9yZVByZXZpb3VzUmVxdWVzdCgpO1xuICAgICAgICByZWxvYWRPcHRpb25zLm9uQmVmb3JlPy4odmlzaXQpO1xuICAgICAgfSxcbiAgICAgIG9uQmVmb3JlVXBkYXRlOiAocGFnZTMpID0+IHtcbiAgICAgICAgb3B0aW9ucy5vbkJlZm9yZVVwZGF0ZSgpO1xuICAgICAgICByZWxvYWRPcHRpb25zLm9uQmVmb3JlVXBkYXRlPy4ocGFnZTMpO1xuICAgICAgfSxcbiAgICAgIG9uU3VjY2VzczogKHBhZ2UzKSA9PiB7XG4gICAgICAgIHN5bmNTdGF0ZU9uU3VjY2VzcyhzaWRlKTtcbiAgICAgICAgcmVsb2FkT3B0aW9ucy5vblN1Y2Nlc3M/LihwYWdlMyk7XG4gICAgICB9LFxuICAgICAgb25GaW5pc2g6ICh2aXNpdCkgPT4ge1xuICAgICAgICBzdGF0ZS5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGNvbXBsZXRlZCA9IHZpc2l0LmNvbXBsZXRlZDtcbiAgICAgICAgY29uc3QgcGFnZTMgPSBjb21wbGV0ZWQgPyBzdGF0ZS5sYXN0TG9hZGVkUGFnZSA6IG51bGw7XG4gICAgICAgIHNpZGUgPT09IFwibmV4dFwiID8gb3B0aW9ucy5vbkNvbXBsZXRlTmV4dFJlcXVlc3QocGFnZTMsIHsgcGFnZTogcGFnZTMsIGNvbXBsZXRlZCB9KSA6IG9wdGlvbnMub25Db21wbGV0ZVByZXZpb3VzUmVxdWVzdChwYWdlMywgeyBwYWdlOiBwYWdlMywgY29tcGxldGVkIH0pO1xuICAgICAgICByZWxvYWRPcHRpb25zLm9uRmluaXNoPy4odmlzaXQpO1xuICAgICAgfVxuICAgIH0pO1xuICB9O1xuICBjb25zdCBnZXRMYXN0TG9hZGVkUGFnZSA9ICgpID0+IHN0YXRlLmxhc3RMb2FkZWRQYWdlO1xuICBjb25zdCBoYXNQcmV2aW91cyA9ICgpID0+ICEhc3RhdGUucHJldmlvdXNQYWdlO1xuICBjb25zdCBoYXNOZXh0ID0gKCkgPT4gISFzdGF0ZS5uZXh0UGFnZTtcbiAgY29uc3QgZmV0Y2hQcmV2aW91cyA9IChyZWxvYWRPcHRpb25zKSA9PiBmZXRjaFBhZ2UoXCJwcmV2aW91c1wiLCByZWxvYWRPcHRpb25zKTtcbiAgY29uc3QgZmV0Y2hOZXh0ID0gKHJlbG9hZE9wdGlvbnMpID0+IGZldGNoUGFnZShcIm5leHRcIiwgcmVsb2FkT3B0aW9ucyk7XG4gIHJldHVybiB7XG4gICAgZ2V0TGFzdExvYWRlZFBhZ2UsXG4gICAgZ2V0UGFnZU5hbWUsXG4gICAgZ2V0UmVxdWVzdENvdW50LFxuICAgIGhhc1ByZXZpb3VzLFxuICAgIGhhc05leHQsXG4gICAgZmV0Y2hOZXh0LFxuICAgIGZldGNoUHJldmlvdXMsXG4gICAgcmVtb3ZlRXZlbnRMaXN0ZW5lclxuICB9O1xufTtcblxuLy8gc3JjL2ludGVyc2VjdGlvbk9ic2VydmVycy50c1xudmFyIHVzZUludGVyc2VjdGlvbk9ic2VydmVycyA9ICgpID0+IHtcbiAgY29uc3QgaW50ZXJzZWN0aW9uT2JzZXJ2ZXJzID0gW107XG4gIGNvbnN0IG5ld0ludGVyc2VjdGlvbk9ic2VydmVyID0gKGNhbGxiYWNrLCBvcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcigoZW50cmllcykgPT4ge1xuICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBlbnRyaWVzKSB7XG4gICAgICAgIGlmIChlbnRyeS5pc0ludGVyc2VjdGluZykge1xuICAgICAgICAgIGNhbGxiYWNrKGVudHJ5KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIG9wdGlvbnMpO1xuICAgIGludGVyc2VjdGlvbk9ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcbiAgICByZXR1cm4gb2JzZXJ2ZXI7XG4gIH07XG4gIGNvbnN0IGZsdXNoQWxsID0gKCkgPT4ge1xuICAgIGludGVyc2VjdGlvbk9ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZGlzY29ubmVjdCgpKTtcbiAgICBpbnRlcnNlY3Rpb25PYnNlcnZlcnMubGVuZ3RoID0gMDtcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICBuZXc6IG5ld0ludGVyc2VjdGlvbk9ic2VydmVyLFxuICAgIGZsdXNoQWxsXG4gIH07XG59O1xuXG4vLyBzcmMvaW5maW5pdGVTY3JvbGwvZWxlbWVudHMudHNcbnZhciBJTkZJTklURV9TQ1JPTExfUEFHRV9LRVkgPSBcImluZmluaXRlU2Nyb2xsUGFnZVwiO1xudmFyIElORklOSVRFX1NDUk9MTF9JR05PUkVfS0VZID0gXCJpbmZpbml0ZVNjcm9sbElnbm9yZVwiO1xudmFyIGdldFBhZ2VGcm9tRWxlbWVudCA9IChlbGVtZW50KSA9PiBlbGVtZW50LmRhdGFzZXRbSU5GSU5JVEVfU0NST0xMX1BBR0VfS0VZXTtcbnZhciB1c2VJbmZpbml0ZVNjcm9sbEVsZW1lbnRNYW5hZ2VyID0gKG9wdGlvbnMpID0+IHtcbiAgY29uc3QgaW50ZXJzZWN0aW9uT2JzZXJ2ZXJzID0gdXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJzKCk7XG4gIGxldCBpdGVtc09ic2VydmVyO1xuICBsZXQgc3RhcnRFbGVtZW50T2JzZXJ2ZXI7XG4gIGxldCBlbmRFbGVtZW50T2JzZXJ2ZXI7XG4gIGxldCBpdGVtc011dGF0aW9uT2JzZXJ2ZXI7XG4gIGxldCB0cmlnZ2Vyc0VuYWJsZWQgPSBmYWxzZTtcbiAgY29uc3Qgc2V0dXBPYnNlcnZlcnMgPSAoKSA9PiB7XG4gICAgaXRlbXNNdXRhdGlvbk9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKG11dGF0aW9ucykgPT4ge1xuICAgICAgbXV0YXRpb25zLmZvckVhY2goKG11dGF0aW9uKSA9PiB7XG4gICAgICAgIG11dGF0aW9uLmFkZGVkTm9kZXMuZm9yRWFjaCgobm9kZSkgPT4ge1xuICAgICAgICAgIGlmIChub2RlLm5vZGVUeXBlICE9PSBOb2RlLkVMRU1FTlRfTk9ERSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhZGRlZEVsZW1lbnRzLmFkZChub2RlKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIHJlbWVtYmVyRWxlbWVudHNEZWJvdW5jZWQoKTtcbiAgICB9KTtcbiAgICBpdGVtc011dGF0aW9uT2JzZXJ2ZXIub2JzZXJ2ZShvcHRpb25zLmdldEl0ZW1zRWxlbWVudCgpLCB7IGNoaWxkTGlzdDogdHJ1ZSB9KTtcbiAgICBpdGVtc09ic2VydmVyID0gaW50ZXJzZWN0aW9uT2JzZXJ2ZXJzLm5ldyhcbiAgICAgIChlbnRyeSkgPT4gb3B0aW9ucy5vbkl0ZW1JbnRlcnNlY3RlZChlbnRyeS50YXJnZXQpXG4gICAgKTtcbiAgICBjb25zdCBvYnNlcnZlck9wdGlvbnMgPSB7XG4gICAgICByb290OiBvcHRpb25zLmdldFNjcm9sbGFibGVQYXJlbnQoKSxcbiAgICAgIHJvb3RNYXJnaW46IGAke01hdGgubWF4KDEsIG9wdGlvbnMuZ2V0VHJpZ2dlck1hcmdpbigpKX1weGBcbiAgICB9O1xuICAgIHN0YXJ0RWxlbWVudE9ic2VydmVyID0gaW50ZXJzZWN0aW9uT2JzZXJ2ZXJzLm5ldyhvcHRpb25zLm9uUHJldmlvdXNUcmlnZ2VyZWQsIG9ic2VydmVyT3B0aW9ucyk7XG4gICAgZW5kRWxlbWVudE9ic2VydmVyID0gaW50ZXJzZWN0aW9uT2JzZXJ2ZXJzLm5ldyhvcHRpb25zLm9uTmV4dFRyaWdnZXJlZCwgb2JzZXJ2ZXJPcHRpb25zKTtcbiAgfTtcbiAgY29uc3QgZW5hYmxlVHJpZ2dlcnMgPSAoKSA9PiB7XG4gICAgaWYgKHRyaWdnZXJzRW5hYmxlZCkge1xuICAgICAgZGlzYWJsZVRyaWdnZXJzKCk7XG4gICAgfVxuICAgIGNvbnN0IHN0YXJ0RWxlbWVudCA9IG9wdGlvbnMuZ2V0U3RhcnRFbGVtZW50KCk7XG4gICAgY29uc3QgZW5kRWxlbWVudCA9IG9wdGlvbnMuZ2V0RW5kRWxlbWVudCgpO1xuICAgIGlmIChzdGFydEVsZW1lbnQgJiYgb3B0aW9ucy5zaG91bGRGZXRjaFByZXZpb3VzKCkpIHtcbiAgICAgIHN0YXJ0RWxlbWVudE9ic2VydmVyLm9ic2VydmUoc3RhcnRFbGVtZW50KTtcbiAgICB9XG4gICAgaWYgKGVuZEVsZW1lbnQgJiYgb3B0aW9ucy5zaG91bGRGZXRjaE5leHQoKSkge1xuICAgICAgZW5kRWxlbWVudE9ic2VydmVyLm9ic2VydmUoZW5kRWxlbWVudCk7XG4gICAgfVxuICAgIHRyaWdnZXJzRW5hYmxlZCA9IHRydWU7XG4gIH07XG4gIGNvbnN0IGRpc2FibGVUcmlnZ2VycyA9ICgpID0+IHtcbiAgICBpZiAoIXRyaWdnZXJzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdGFydEVsZW1lbnRPYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgZW5kRWxlbWVudE9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICB0cmlnZ2Vyc0VuYWJsZWQgPSBmYWxzZTtcbiAgfTtcbiAgY29uc3QgcmVmcmVzaFRyaWdnZXJzID0gKCkgPT4ge1xuICAgIGlmICh0cmlnZ2Vyc0VuYWJsZWQpIHtcbiAgICAgIGVuYWJsZVRyaWdnZXJzKCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBmbHVzaEFsbCA9ICgpID0+IHtcbiAgICBkaXNhYmxlVHJpZ2dlcnMoKTtcbiAgICBpbnRlcnNlY3Rpb25PYnNlcnZlcnMuZmx1c2hBbGwoKTtcbiAgICBpdGVtc011dGF0aW9uT2JzZXJ2ZXI/LmRpc2Nvbm5lY3QoKTtcbiAgfTtcbiAgY29uc3QgYWRkZWRFbGVtZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGNvbnN0IGVsZW1lbnRJc1VudGFnZ2VkID0gKGVsZW1lbnQpID0+ICEoSU5GSU5JVEVfU0NST0xMX1BBR0VfS0VZIGluIGVsZW1lbnQuZGF0YXNldCkgJiYgIShJTkZJTklURV9TQ1JPTExfSUdOT1JFX0tFWSBpbiBlbGVtZW50LmRhdGFzZXQpO1xuICBjb25zdCBwcm9jZXNzTWFudWFsbHlBZGRlZEVsZW1lbnRzID0gKCkgPT4ge1xuICAgIEFycmF5LmZyb20oYWRkZWRFbGVtZW50cykuZm9yRWFjaCgoZWxlbWVudCkgPT4ge1xuICAgICAgaWYgKGVsZW1lbnRJc1VudGFnZ2VkKGVsZW1lbnQpKSB7XG4gICAgICAgIGVsZW1lbnQuZGF0YXNldFtJTkZJTklURV9TQ1JPTExfSUdOT1JFX0tFWV0gPSBcInRydWVcIjtcbiAgICAgIH1cbiAgICAgIGl0ZW1zT2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KTtcbiAgICB9KTtcbiAgICBhZGRlZEVsZW1lbnRzLmNsZWFyKCk7XG4gIH07XG4gIGNvbnN0IGZpbmRVbnRhZ2dlZEVsZW1lbnRzID0gKGNvbnRhaW5lckVsZW1lbnQpID0+IHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShcbiAgICAgIGNvbnRhaW5lckVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChcbiAgICAgICAgYDpzY29wZSA+ICo6bm90KFtkYXRhLWluZmluaXRlLXNjcm9sbC1wYWdlXSk6bm90KFtkYXRhLWluZmluaXRlLXNjcm9sbC1pZ25vcmVdKWBcbiAgICAgIClcbiAgICApO1xuICB9O1xuICBsZXQgaGFzUmVzdG9yZWRFbGVtZW50cyA9IGZhbHNlO1xuICBjb25zdCBwcm9jZXNzU2VydmVyTG9hZGVkRWxlbWVudHMgPSAobG9hZGVkUGFnZSkgPT4ge1xuICAgIGlmICghaGFzUmVzdG9yZWRFbGVtZW50cykge1xuICAgICAgaGFzUmVzdG9yZWRFbGVtZW50cyA9IHRydWU7XG4gICAgICBpZiAocmVzdG9yZUVsZW1lbnRzKCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICBmaW5kVW50YWdnZWRFbGVtZW50cyhvcHRpb25zLmdldEl0ZW1zRWxlbWVudCgpKS5mb3JFYWNoKChlbGVtZW50KSA9PiB7XG4gICAgICBpZiAoZWxlbWVudElzVW50YWdnZWQoZWxlbWVudCkpIHtcbiAgICAgICAgZWxlbWVudC5kYXRhc2V0W0lORklOSVRFX1NDUk9MTF9QQUdFX0tFWV0gPSBsb2FkZWRQYWdlPy50b1N0cmluZygpIHx8IFwiMVwiO1xuICAgICAgfVxuICAgICAgaXRlbXNPYnNlcnZlci5vYnNlcnZlKGVsZW1lbnQpO1xuICAgIH0pO1xuICAgIHJlbWVtYmVyRWxlbWVudHMoKTtcbiAgfTtcbiAgY29uc3QgZ2V0RWxlbWVudHNSZW1lbWJlcktleSA9ICgpID0+IGBpbmVydGlhOmluZmluaXRlLXNjcm9sbC1lbGVtZW50czoke29wdGlvbnMuZ2V0UHJvcE5hbWUoKX1gO1xuICBjb25zdCByZW1lbWJlckVsZW1lbnRzID0gKCkgPT4ge1xuICAgIGNvbnN0IHBhZ2VFbGVtZW50UmFuZ2UgPSB7fTtcbiAgICBjb25zdCBjaGlsZE5vZGVzID0gb3B0aW9ucy5nZXRJdGVtc0VsZW1lbnQoKS5jaGlsZE5vZGVzO1xuICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBjaGlsZE5vZGVzLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgY29uc3Qgbm9kZSA9IGNoaWxkTm9kZXNbaW5kZXhdO1xuICAgICAgaWYgKG5vZGUubm9kZVR5cGUgIT09IE5vZGUuRUxFTUVOVF9OT0RFKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgcGFnZTIgPSBnZXRQYWdlRnJvbUVsZW1lbnQobm9kZSk7XG4gICAgICBpZiAodHlwZW9mIHBhZ2UyID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKCEocGFnZTIgaW4gcGFnZUVsZW1lbnRSYW5nZSkpIHtcbiAgICAgICAgcGFnZUVsZW1lbnRSYW5nZVtwYWdlMl0gPSB7IGZyb206IGluZGV4LCB0bzogaW5kZXggfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhZ2VFbGVtZW50UmFuZ2VbcGFnZTJdLnRvID0gaW5kZXg7XG4gICAgICB9XG4gICAgfVxuICAgIHJvdXRlci5yZW1lbWJlcihwYWdlRWxlbWVudFJhbmdlLCBnZXRFbGVtZW50c1JlbWVtYmVyS2V5KCkpO1xuICB9O1xuICBjb25zdCByZW1lbWJlckVsZW1lbnRzRGVib3VuY2VkID0gZGVib3VuY2UocmVtZW1iZXJFbGVtZW50cywgMjUwKTtcbiAgY29uc3QgcmVzdG9yZUVsZW1lbnRzID0gKCkgPT4ge1xuICAgIGNvbnN0IHBhZ2VFbGVtZW50UmFuZ2UgPSByb3V0ZXIucmVzdG9yZShnZXRFbGVtZW50c1JlbWVtYmVyS2V5KCkpO1xuICAgIGlmICghcGFnZUVsZW1lbnRSYW5nZSB8fCB0eXBlb2YgcGFnZUVsZW1lbnRSYW5nZSAhPT0gXCJvYmplY3RcIikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBjaGlsZE5vZGVzID0gb3B0aW9ucy5nZXRJdGVtc0VsZW1lbnQoKS5jaGlsZE5vZGVzO1xuICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBjaGlsZE5vZGVzLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgY29uc3Qgbm9kZSA9IGNoaWxkTm9kZXNbaW5kZXhdO1xuICAgICAgaWYgKG5vZGUubm9kZVR5cGUgIT09IE5vZGUuRUxFTUVOVF9OT0RFKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgZWxlbWVudCA9IG5vZGU7XG4gICAgICBsZXQgZWxlbWVudFBhZ2U7XG4gICAgICBmb3IgKGNvbnN0IFtwYWdlMiwgcmFuZ2VdIG9mIE9iamVjdC5lbnRyaWVzKHBhZ2VFbGVtZW50UmFuZ2UpKSB7XG4gICAgICAgIGlmIChpbmRleCA+PSByYW5nZS5mcm9tICYmIGluZGV4IDw9IHJhbmdlLnRvKSB7XG4gICAgICAgICAgZWxlbWVudFBhZ2UgPSBwYWdlMjtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGVsZW1lbnRQYWdlKSB7XG4gICAgICAgIGVsZW1lbnQuZGF0YXNldFtJTkZJTklURV9TQ1JPTExfUEFHRV9LRVldID0gZWxlbWVudFBhZ2U7XG4gICAgICB9IGVsc2UgaWYgKCFlbGVtZW50SXNVbnRhZ2dlZChlbGVtZW50KSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGVsZW1lbnQuZGF0YXNldFtJTkZJTklURV9TQ1JPTExfSUdOT1JFX0tFWV0gPSBcInRydWVcIjtcbiAgICAgIH1cbiAgICAgIGl0ZW1zT2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG4gIHJldHVybiB7XG4gICAgc2V0dXBPYnNlcnZlcnMsXG4gICAgZW5hYmxlVHJpZ2dlcnMsXG4gICAgZGlzYWJsZVRyaWdnZXJzLFxuICAgIHJlZnJlc2hUcmlnZ2VycyxcbiAgICBmbHVzaEFsbCxcbiAgICBwcm9jZXNzTWFudWFsbHlBZGRlZEVsZW1lbnRzLFxuICAgIHByb2Nlc3NTZXJ2ZXJMb2FkZWRFbGVtZW50c1xuICB9O1xufTtcblxuLy8gc3JjL2luZmluaXRlU2Nyb2xsL3F1ZXJ5U3RyaW5nLnRzXG52YXIgcXVldWUzID0gbmV3IFF1ZXVlKCk7XG52YXIgaW5pdGlhbFVybDtcbnZhciBwYXlsb2FkVXJsO1xudmFyIGluaXRpYWxVcmxXYXNBYnNvbHV0ZSA9IG51bGw7XG52YXIgdXNlSW5maW5pdGVTY3JvbGxRdWVyeVN0cmluZyA9IChvcHRpb25zKSA9PiB7XG4gIGxldCBlbmFibGVkID0gdHJ1ZTtcbiAgY29uc3QgcXVldWVQYWdlVXBkYXRlID0gKHBhZ2UyKSA9PiB7XG4gICAgcXVldWUzLmFkZCgoKSA9PiB7XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgaWYgKCFlbmFibGVkKSB7XG4gICAgICAgICAgaW5pdGlhbFVybCA9IHBheWxvYWRVcmwgPSBudWxsO1xuICAgICAgICAgIHJldHVybiByZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpbml0aWFsVXJsIHx8ICFwYXlsb2FkVXJsKSB7XG4gICAgICAgICAgY29uc3QgY3VycmVudFBhZ2VVcmwgPSBwYWdlLmdldCgpLnVybDtcbiAgICAgICAgICBpbml0aWFsVXJsID0gaHJlZlRvVXJsKGN1cnJlbnRQYWdlVXJsKTtcbiAgICAgICAgICBwYXlsb2FkVXJsID0gaHJlZlRvVXJsKGN1cnJlbnRQYWdlVXJsKTtcbiAgICAgICAgICBpbml0aWFsVXJsV2FzQWJzb2x1dGUgPSB1cmxIYXNQcm90b2NvbChjdXJyZW50UGFnZVVybCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGFnZU5hbWUgPSBvcHRpb25zLmdldFBhZ2VOYW1lKCk7XG4gICAgICAgIGNvbnN0IHNlYXJjaFBhcmFtcyA9IHBheWxvYWRVcmwuc2VhcmNoUGFyYW1zO1xuICAgICAgICBpZiAocGFnZTIgPT09IFwiMVwiKSB7XG4gICAgICAgICAgc2VhcmNoUGFyYW1zLmRlbGV0ZShwYWdlTmFtZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2VhcmNoUGFyYW1zLnNldChwYWdlTmFtZSwgcGFnZTIpO1xuICAgICAgICB9XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gcmVzb2x2ZSgpKTtcbiAgICAgIH0pO1xuICAgIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgaWYgKGVuYWJsZWQgJiYgaW5pdGlhbFVybCAmJiBwYXlsb2FkVXJsICYmIGluaXRpYWxVcmwuaHJlZiAhPT0gcGF5bG9hZFVybC5ocmVmICYmIGluaXRpYWxVcmxXYXNBYnNvbHV0ZSAhPT0gbnVsbCkge1xuICAgICAgICByb3V0ZXIucmVwbGFjZSh7XG4gICAgICAgICAgdXJsOiB1cmxUb1N0cmluZyhwYXlsb2FkVXJsLCBpbml0aWFsVXJsV2FzQWJzb2x1dGUpLFxuICAgICAgICAgIHByZXNlcnZlU2Nyb2xsOiB0cnVlLFxuICAgICAgICAgIHByZXNlcnZlU3RhdGU6IHRydWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpbml0aWFsVXJsID0gcGF5bG9hZFVybCA9IGluaXRpYWxVcmxXYXNBYnNvbHV0ZSA9IG51bGw7XG4gICAgfSk7XG4gIH07XG4gIGNvbnN0IG9uSXRlbUludGVyc2VjdGVkID0gZGVib3VuY2UoKGl0ZW1FbGVtZW50KSA9PiB7XG4gICAgY29uc3QgaXRlbXNFbGVtZW50ID0gb3B0aW9ucy5nZXRJdGVtc0VsZW1lbnQoKTtcbiAgICBpZiAoIWVuYWJsZWQgfHwgb3B0aW9ucy5zaG91bGRQcmVzZXJ2ZVVybCgpIHx8ICFpdGVtRWxlbWVudCB8fCAhaXRlbXNFbGVtZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBhZ2VNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIGNvbnN0IGVsZW1lbnRzID0gWy4uLml0ZW1zRWxlbWVudC5jaGlsZHJlbl07XG4gICAgZ2V0RWxlbWVudHNJblZpZXdwb3J0RnJvbUNvbGxlY3Rpb24oZWxlbWVudHMsIGl0ZW1FbGVtZW50KS5mb3JFYWNoKChlbGVtZW50KSA9PiB7XG4gICAgICBjb25zdCBwYWdlMiA9IGdldFBhZ2VGcm9tRWxlbWVudChlbGVtZW50KSA/PyBcIjFcIjtcbiAgICAgIGlmIChwYWdlTWFwLmhhcyhwYWdlMikpIHtcbiAgICAgICAgcGFnZU1hcC5zZXQocGFnZTIsIHBhZ2VNYXAuZ2V0KHBhZ2UyKSArIDEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGFnZU1hcC5zZXQocGFnZTIsIDEpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IHNvcnRlZFBhZ2VzID0gQXJyYXkuZnJvbShwYWdlTWFwLmVudHJpZXMoKSkuc29ydCgoYSwgYikgPT4gYlsxXSAtIGFbMV0pO1xuICAgIGNvbnN0IG1vc3RWaXNpYmxlUGFnZSA9IHNvcnRlZFBhZ2VzWzBdPy5bMF07XG4gICAgaWYgKG1vc3RWaXNpYmxlUGFnZSAhPT0gdm9pZCAwKSB7XG4gICAgICBxdWV1ZVBhZ2VVcGRhdGUobW9zdFZpc2libGVQYWdlKTtcbiAgICB9XG4gIH0sIDI1MCk7XG4gIHJldHVybiB7XG4gICAgb25JdGVtSW50ZXJzZWN0ZWQsXG4gICAgY2FuY2VsOiAoKSA9PiBlbmFibGVkID0gZmFsc2VcbiAgfTtcbn07XG5cbi8vIHNyYy9pbmZpbml0ZVNjcm9sbC9zY3JvbGxQcmVzZXJ2YXRpb24udHNcbnZhciB1c2VJbmZpbml0ZVNjcm9sbFByZXNlcnZhdGlvbiA9IChvcHRpb25zKSA9PiB7XG4gIGNvbnN0IGNyZWF0ZUNhbGxiYWNrcyA9ICgpID0+IHtcbiAgICBsZXQgY3VycmVudFNjcm9sbFRvcDtcbiAgICBsZXQgcmVmZXJlbmNlRWxlbWVudCA9IG51bGw7XG4gICAgbGV0IHJlZmVyZW5jZUVsZW1lbnRUb3AgPSAwO1xuICAgIGNvbnN0IGNhcHR1cmVTY3JvbGxQb3NpdGlvbiA9ICgpID0+IHtcbiAgICAgIGNvbnN0IHNjcm9sbGFibGVDb250YWluZXIgPSBvcHRpb25zLmdldFNjcm9sbGFibGVQYXJlbnQoKTtcbiAgICAgIGNvbnN0IGl0ZW1zRWxlbWVudCA9IG9wdGlvbnMuZ2V0SXRlbXNFbGVtZW50KCk7XG4gICAgICBjdXJyZW50U2Nyb2xsVG9wID0gc2Nyb2xsYWJsZUNvbnRhaW5lcj8uc2Nyb2xsVG9wIHx8IHdpbmRvdy5zY3JvbGxZO1xuICAgICAgY29uc3QgdmlzaWJsZUVsZW1lbnRzID0gZ2V0RWxlbWVudHNJblZpZXdwb3J0RnJvbUNvbGxlY3Rpb24oWy4uLml0ZW1zRWxlbWVudC5jaGlsZHJlbl0pO1xuICAgICAgaWYgKHZpc2libGVFbGVtZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJlZmVyZW5jZUVsZW1lbnQgPSB2aXNpYmxlRWxlbWVudHNbMF07XG4gICAgICAgIGNvbnN0IGNvbnRhaW5lclJlY3QgPSBzY3JvbGxhYmxlQ29udGFpbmVyPy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSB8fCB7IHRvcDogMCB9O1xuICAgICAgICBjb25zdCBjb250YWluZXJUb3AgPSBzY3JvbGxhYmxlQ29udGFpbmVyID8gY29udGFpbmVyUmVjdC50b3AgOiAwO1xuICAgICAgICBjb25zdCByZWN0ID0gcmVmZXJlbmNlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgcmVmZXJlbmNlRWxlbWVudFRvcCA9IHJlY3QudG9wIC0gY29udGFpbmVyVG9wO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgcmVzdG9yZVNjcm9sbFBvc2l0aW9uID0gKCkgPT4ge1xuICAgICAgaWYgKCFyZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxldCBhdHRlbXB0cyA9IDA7XG4gICAgICBsZXQgcmVzdG9yZWQgPSBmYWxzZTtcbiAgICAgIGNvbnN0IHJlc3RvcmUgPSAoKSA9PiB7XG4gICAgICAgIGF0dGVtcHRzKys7XG4gICAgICAgIGlmIChyZXN0b3JlZCB8fCBhdHRlbXB0cyA+IDEwKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNjcm9sbGFibGVDb250YWluZXIgPSBvcHRpb25zLmdldFNjcm9sbGFibGVQYXJlbnQoKTtcbiAgICAgICAgY29uc3QgY29udGFpbmVyUmVjdCA9IHNjcm9sbGFibGVDb250YWluZXI/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpIHx8IHsgdG9wOiAwIH07XG4gICAgICAgIGNvbnN0IGNvbnRhaW5lclRvcCA9IHNjcm9sbGFibGVDb250YWluZXIgPyBjb250YWluZXJSZWN0LnRvcCA6IDA7XG4gICAgICAgIGNvbnN0IG5ld1JlY3QgPSByZWZlcmVuY2VFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICBjb25zdCBuZXdFbGVtZW50VG9wID0gbmV3UmVjdC50b3AgLSBjb250YWluZXJUb3A7XG4gICAgICAgIGNvbnN0IGFkanVzdG1lbnQgPSBuZXdFbGVtZW50VG9wIC0gcmVmZXJlbmNlRWxlbWVudFRvcDtcbiAgICAgICAgaWYgKGFkanVzdG1lbnQgPT09IDApIHtcbiAgICAgICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlc3RvcmUpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc2Nyb2xsYWJsZUNvbnRhaW5lcikge1xuICAgICAgICAgIHNjcm9sbGFibGVDb250YWluZXIuc2Nyb2xsVG8oeyB0b3A6IGN1cnJlbnRTY3JvbGxUb3AgKyBhZGp1c3RtZW50IH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCB3aW5kb3cuc2Nyb2xsWSArIGFkanVzdG1lbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJlc3RvcmVkID0gdHJ1ZTtcbiAgICAgIH07XG4gICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlc3RvcmUpO1xuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGNhcHR1cmVTY3JvbGxQb3NpdGlvbixcbiAgICAgIHJlc3RvcmVTY3JvbGxQb3NpdGlvblxuICAgIH07XG4gIH07XG4gIHJldHVybiB7XG4gICAgY3JlYXRlQ2FsbGJhY2tzXG4gIH07XG59O1xuXG4vLyBzcmMvaW5maW5pdGVTY3JvbGwudHNcbmZ1bmN0aW9uIHVzZUluZmluaXRlU2Nyb2xsKG9wdGlvbnMpIHtcbiAgY29uc3QgcXVlcnlTdHJpbmdNYW5hZ2VyID0gdXNlSW5maW5pdGVTY3JvbGxRdWVyeVN0cmluZyh7IC4uLm9wdGlvbnMsIGdldFBhZ2VOYW1lOiAoKSA9PiBkYXRhTWFuYWdlci5nZXRQYWdlTmFtZSgpIH0pO1xuICBjb25zdCBzY3JvbGxQcmVzZXJ2YXRpb24gPSB1c2VJbmZpbml0ZVNjcm9sbFByZXNlcnZhdGlvbihvcHRpb25zKTtcbiAgY29uc3QgZWxlbWVudE1hbmFnZXIgPSB1c2VJbmZpbml0ZVNjcm9sbEVsZW1lbnRNYW5hZ2VyKHtcbiAgICAuLi5vcHRpb25zLFxuICAgIC8vIEFzIGl0ZW1zIGVudGVyIHZpZXdwb3J0LCB1cGRhdGUgVVJMIHRvIHJlZmxlY3QgdGhlIG1vc3QgdmlzaWJsZSBwYWdlXG4gICAgb25JdGVtSW50ZXJzZWN0ZWQ6IHF1ZXJ5U3RyaW5nTWFuYWdlci5vbkl0ZW1JbnRlcnNlY3RlZCxcbiAgICBvblByZXZpb3VzVHJpZ2dlcmVkOiAoKSA9PiBkYXRhTWFuYWdlci5mZXRjaFByZXZpb3VzKCksXG4gICAgb25OZXh0VHJpZ2dlcmVkOiAoKSA9PiBkYXRhTWFuYWdlci5mZXRjaE5leHQoKVxuICB9KTtcbiAgY29uc3QgZGF0YU1hbmFnZXIgPSB1c2VJbmZpbml0ZVNjcm9sbERhdGEoe1xuICAgIC4uLm9wdGlvbnMsXG4gICAgLy8gQmVmb3JlIHVwZGF0aW5nIHBhZ2UgZGF0YSwgdGFnIGFueSBtYW51YWxseSBhZGRlZCBET00gZWxlbWVudHNcbiAgICAvLyBzbyB0aGV5IGRvbid0IGdldCBjb25mdXNlZCB3aXRoIHNlcnZlci1sb2FkZWQgY29udGVudFxuICAgIG9uQmVmb3JlVXBkYXRlOiBlbGVtZW50TWFuYWdlci5wcm9jZXNzTWFudWFsbHlBZGRlZEVsZW1lbnRzLFxuICAgIC8vIEFmdGVyIHN1Y2Nlc3NmdWwgcmVxdWVzdCwgdGFnIG5ldyBzZXJ2ZXIgY29udGVudFxuICAgIG9uQ29tcGxldGVQcmV2aW91c1JlcXVlc3Q6IChfLCBkZXRhaWxzKSA9PiB7XG4gICAgICBvcHRpb25zLm9uQ29tcGxldGVQcmV2aW91c1JlcXVlc3QoZGV0YWlscyk7XG4gICAgICBpZiAoZGV0YWlscy5jb21wbGV0ZWQpIHtcbiAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IGVsZW1lbnRNYW5hZ2VyLnByb2Nlc3NTZXJ2ZXJMb2FkZWRFbGVtZW50cyhkZXRhaWxzLnBhZ2UpLCAyKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uQ29tcGxldGVOZXh0UmVxdWVzdDogKF8sIGRldGFpbHMpID0+IHtcbiAgICAgIG9wdGlvbnMub25Db21wbGV0ZU5leHRSZXF1ZXN0KGRldGFpbHMpO1xuICAgICAgaWYgKGRldGFpbHMuY29tcGxldGVkKSB7XG4gICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiBlbGVtZW50TWFuYWdlci5wcm9jZXNzU2VydmVyTG9hZGVkRWxlbWVudHMoZGV0YWlscy5wYWdlKSwgMik7XG4gICAgICB9XG4gICAgfSxcbiAgICBvblJlc2V0OiBvcHRpb25zLm9uRGF0YVJlc2V0XG4gIH0pO1xuICBjb25zdCBhZGRTY3JvbGxQcmVzZXJ2YXRpb25DYWxsYmFja3MgPSAocmVsb2FkT3B0aW9ucykgPT4ge1xuICAgIGNvbnN0IHsgY2FwdHVyZVNjcm9sbFBvc2l0aW9uLCByZXN0b3JlU2Nyb2xsUG9zaXRpb24gfSA9IHNjcm9sbFByZXNlcnZhdGlvbi5jcmVhdGVDYWxsYmFja3MoKTtcbiAgICBjb25zdCBvcmlnaW5hbE9uQmVmb3JlVXBkYXRlID0gcmVsb2FkT3B0aW9ucy5vbkJlZm9yZVVwZGF0ZSB8fCAoKCkgPT4ge1xuICAgIH0pO1xuICAgIGNvbnN0IG9yaWdpbmFsT25TdWNjZXNzID0gcmVsb2FkT3B0aW9ucy5vblN1Y2Nlc3MgfHwgKCgpID0+IHtcbiAgICB9KTtcbiAgICByZWxvYWRPcHRpb25zLm9uQmVmb3JlVXBkYXRlID0gKHBhZ2UyKSA9PiB7XG4gICAgICBvcmlnaW5hbE9uQmVmb3JlVXBkYXRlKHBhZ2UyKTtcbiAgICAgIGNhcHR1cmVTY3JvbGxQb3NpdGlvbigpO1xuICAgIH07XG4gICAgcmVsb2FkT3B0aW9ucy5vblN1Y2Nlc3MgPSAocGFnZTIpID0+IHtcbiAgICAgIG9yaWdpbmFsT25TdWNjZXNzKHBhZ2UyKTtcbiAgICAgIHJlc3RvcmVTY3JvbGxQb3NpdGlvbigpO1xuICAgIH07XG4gICAgcmV0dXJuIHJlbG9hZE9wdGlvbnM7XG4gIH07XG4gIGNvbnN0IG9yaWdpbmFsRmV0Y2hOZXh0ID0gZGF0YU1hbmFnZXIuZmV0Y2hOZXh0O1xuICBkYXRhTWFuYWdlci5mZXRjaE5leHQgPSAocmVsb2FkT3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgcmVsb2FkT3B0aW9ucyA9IHsgLi4ub3B0aW9ucy5nZXRSZWxvYWRPcHRpb25zPy4oKSwgLi4ucmVsb2FkT3B0aW9ucyB9O1xuICAgIGlmIChvcHRpb25zLmluUmV2ZXJzZU1vZGUoKSkge1xuICAgICAgcmVsb2FkT3B0aW9ucyA9IGFkZFNjcm9sbFByZXNlcnZhdGlvbkNhbGxiYWNrcyhyZWxvYWRPcHRpb25zKTtcbiAgICB9XG4gICAgb3JpZ2luYWxGZXRjaE5leHQocmVsb2FkT3B0aW9ucyk7XG4gIH07XG4gIGNvbnN0IG9yaWdpbmFsRmV0Y2hQcmV2aW91cyA9IGRhdGFNYW5hZ2VyLmZldGNoUHJldmlvdXM7XG4gIGRhdGFNYW5hZ2VyLmZldGNoUHJldmlvdXMgPSAocmVsb2FkT3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgcmVsb2FkT3B0aW9ucyA9IHsgLi4ub3B0aW9ucy5nZXRSZWxvYWRPcHRpb25zPy4oKSwgLi4ucmVsb2FkT3B0aW9ucyB9O1xuICAgIGlmICghb3B0aW9ucy5pblJldmVyc2VNb2RlKCkpIHtcbiAgICAgIHJlbG9hZE9wdGlvbnMgPSBhZGRTY3JvbGxQcmVzZXJ2YXRpb25DYWxsYmFja3MocmVsb2FkT3B0aW9ucyk7XG4gICAgfVxuICAgIG9yaWdpbmFsRmV0Y2hQcmV2aW91cyhyZWxvYWRPcHRpb25zKTtcbiAgfTtcbiAgY29uc3QgcmVtb3ZlRXZlbnRMaXN0ZW5lciA9IHJvdXRlci5vbihcInN1Y2Nlc3NcIiwgKCkgPT4gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGVsZW1lbnRNYW5hZ2VyLnJlZnJlc2hUcmlnZ2VycywgMikpO1xuICByZXR1cm4ge1xuICAgIGRhdGFNYW5hZ2VyLFxuICAgIGVsZW1lbnRNYW5hZ2VyLFxuICAgIGZsdXNoOiAoKSA9PiB7XG4gICAgICByZW1vdmVFdmVudExpc3RlbmVyKCk7XG4gICAgICBkYXRhTWFuYWdlci5yZW1vdmVFdmVudExpc3RlbmVyKCk7XG4gICAgICBlbGVtZW50TWFuYWdlci5mbHVzaEFsbCgpO1xuICAgICAgcXVlcnlTdHJpbmdNYW5hZ2VyLmNhbmNlbCgpO1xuICAgIH1cbiAgfTtcbn1cblxuLy8gc3JjL2xheW91dC50c1xuaW1wb3J0IHsgaXNFcXVhbCBhcyBpc0VxdWFsNCB9IGZyb20gXCJlcy10b29sa2l0XCI7XG5mdW5jdGlvbiBjcmVhdGVMYXlvdXRQcm9wc1N0b3JlKCkge1xuICBsZXQgc2hhcmVkID0ge307XG4gIGxldCBuYW1lZCA9IHt9O1xuICBsZXQgc25hcHNob3QgPSB7IHNoYXJlZCwgbmFtZWQgfTtcbiAgY29uc3QgbGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgbGV0IHBlbmRpbmdOb3RpZnkgPSBmYWxzZTtcbiAgY29uc3QgdXBkYXRlU25hcHNob3QgPSAoKSA9PiB7XG4gICAgc25hcHNob3QgPSB7IHNoYXJlZCwgbmFtZWQgfTtcbiAgfTtcbiAgY29uc3Qgbm90aWZ5ID0gKCkgPT4ge1xuICAgIGlmIChwZW5kaW5nTm90aWZ5KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHBlbmRpbmdOb3RpZnkgPSB0cnVlO1xuICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgIHBlbmRpbmdOb3RpZnkgPSBmYWxzZTtcbiAgICAgIGxpc3RlbmVycy5mb3JFYWNoKChmbikgPT4gZm4oKSk7XG4gICAgfSk7XG4gIH07XG4gIHJldHVybiB7XG4gICAgc2V0KHByb3BzKSB7XG4gICAgICBjb25zdCBtZXJnZWQgPSB7IC4uLnNoYXJlZCwgLi4ucHJvcHMgfTtcbiAgICAgIGlmIChpc0VxdWFsNChzaGFyZWQsIG1lcmdlZCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2hhcmVkID0gbWVyZ2VkO1xuICAgICAgdXBkYXRlU25hcHNob3QoKTtcbiAgICAgIG5vdGlmeSgpO1xuICAgIH0sXG4gICAgc2V0Rm9yKG5hbWUsIHByb3BzKSB7XG4gICAgICBjb25zdCBjdXJyZW50ID0gbmFtZWRbbmFtZV0gfHwge307XG4gICAgICBjb25zdCBtZXJnZWQgPSB7IC4uLmN1cnJlbnQsIC4uLnByb3BzIH07XG4gICAgICBpZiAoaXNFcXVhbDQoY3VycmVudCwgbWVyZ2VkKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBuYW1lZCA9IHsgLi4ubmFtZWQsIFtuYW1lXTogbWVyZ2VkIH07XG4gICAgICB1cGRhdGVTbmFwc2hvdCgpO1xuICAgICAgbm90aWZ5KCk7XG4gICAgfSxcbiAgICByZXNldCgpIHtcbiAgICAgIHNoYXJlZCA9IHt9O1xuICAgICAgbmFtZWQgPSB7fTtcbiAgICAgIHVwZGF0ZVNuYXBzaG90KCk7XG4gICAgICBub3RpZnkoKTtcbiAgICB9LFxuICAgIHN1YnNjcmliZShjYWxsYmFjaykge1xuICAgICAgbGlzdGVuZXJzLmFkZChjYWxsYmFjayk7XG4gICAgICByZXR1cm4gKCkgPT4gbGlzdGVuZXJzLmRlbGV0ZShjYWxsYmFjayk7XG4gICAgfSxcbiAgICBnZXQ6ICgpID0+IHNuYXBzaG90XG4gIH07XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpO1xufVxuZnVuY3Rpb24gaGFzQ29tcG9uZW50S2V5KHZhbHVlKSB7XG4gIHJldHVybiBpc1BsYWluT2JqZWN0KHZhbHVlKSAmJiBcImNvbXBvbmVudFwiIGluIHZhbHVlO1xufVxuZnVuY3Rpb24gaGFzQ29tcG9uZW50RW50cnkodmFsdWUsIGlzQ29tcG9uZW50KSB7XG4gIHJldHVybiBcImNvbXBvbmVudFwiIGluIHZhbHVlICYmIGlzQ29tcG9uZW50KHZhbHVlLmNvbXBvbmVudCk7XG59XG5mdW5jdGlvbiBpc05hbWVkTGF5b3V0cyh2YWx1ZSwgaXNDb21wb25lbnQpIHtcbiAgaWYgKCFpc1BsYWluT2JqZWN0KHZhbHVlKSB8fCBpc0NvbXBvbmVudCh2YWx1ZSkgfHwgaGFzQ29tcG9uZW50RW50cnkodmFsdWUsIGlzQ29tcG9uZW50KSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LnZhbHVlcyh2YWx1ZSkuZXZlcnkoXG4gICAgKHYpID0+IGlzQ29tcG9uZW50KHYpIHx8IEFycmF5LmlzQXJyYXkodikgJiYgaXNDb21wb25lbnQodlswXSkgfHwgaGFzQ29tcG9uZW50S2V5KHYpICYmIGlzQ29tcG9uZW50KHYuY29tcG9uZW50KVxuICApO1xufVxuZnVuY3Rpb24gaXNQcm9wc09iamVjdCh2YWx1ZSwgaXNDb21wb25lbnQpIHtcbiAgcmV0dXJuIGlzUGxhaW5PYmplY3QodmFsdWUpICYmICFpc0NvbXBvbmVudCh2YWx1ZSkgJiYgIWhhc0NvbXBvbmVudEVudHJ5KHZhbHVlLCBpc0NvbXBvbmVudCkgJiYgIWlzTmFtZWRMYXlvdXRzKHZhbHVlLCBpc0NvbXBvbmVudCk7XG59XG5mdW5jdGlvbiBpc1Byb3BzT2JqZWN0T3JDYWxsYmFjayh2YWx1ZSwgaXNDb21wb25lbnQpIHtcbiAgaWYgKGlzUHJvcHNPYmplY3QodmFsdWUsIGlzQ29tcG9uZW50KSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmICghaXNQbGFpbk9iamVjdCh2YWx1ZSkgfHwgaXNDb21wb25lbnQodmFsdWUpIHx8IGhhc0NvbXBvbmVudEVudHJ5KHZhbHVlLCBpc0NvbXBvbmVudCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdmFsdWVzID0gT2JqZWN0LnZhbHVlcyh2YWx1ZSk7XG4gIHJldHVybiB2YWx1ZXMubGVuZ3RoID4gMCAmJiB2YWx1ZXMuZXZlcnkoKHYpID0+IHR5cGVvZiB2ID09PSBcImZ1bmN0aW9uXCIpO1xufVxuZnVuY3Rpb24gaXNUdXBsZSh2YWx1ZSwgaXNDb21wb25lbnQpIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlLmxlbmd0aCA9PT0gMiAmJiBpc0NvbXBvbmVudCh2YWx1ZVswXSkgJiYgaXNQbGFpbk9iamVjdCh2YWx1ZVsxXSkgJiYgIWlzQ29tcG9uZW50KHZhbHVlWzFdKTtcbn1cbmZ1bmN0aW9uIGV4dHJhY3QoaXRlbSwgaXNDb21wb25lbnQpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoaXRlbSkgJiYgaXNDb21wb25lbnQoaXRlbVswXSkpIHtcbiAgICByZXR1cm4geyBjb21wb25lbnQ6IGl0ZW1bMF0sIHByb3BzOiBpdGVtWzFdID8/IHt9IH07XG4gIH1cbiAgaWYgKGhhc0NvbXBvbmVudEtleShpdGVtKSAmJiBpc0NvbXBvbmVudChpdGVtLmNvbXBvbmVudCkpIHtcbiAgICByZXR1cm4geyBjb21wb25lbnQ6IGl0ZW0uY29tcG9uZW50LCBwcm9wczogaXRlbS5wcm9wcyA/PyB7fSB9O1xuICB9XG4gIGlmIChpc0NvbXBvbmVudChpdGVtKSkge1xuICAgIHJldHVybiB7IGNvbXBvbmVudDogaXRlbSwgcHJvcHM6IHt9IH07XG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGxheW91dCBkZWZpbml0aW9uOiByZWNlaXZlZCAke3R5cGVvZiBpdGVtfWApO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplTGF5b3V0cyhsYXlvdXQsIGlzQ29tcG9uZW50LCBpc1JlbmRlckZ1bmN0aW9uKSB7XG4gIGlmICghbGF5b3V0IHx8IGlzUmVuZGVyRnVuY3Rpb24gJiYgaXNSZW5kZXJGdW5jdGlvbihsYXlvdXQpKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGlmIChpc05hbWVkTGF5b3V0cyhsYXlvdXQsIGlzQ29tcG9uZW50KSkge1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyhsYXlvdXQpLm1hcCgoW25hbWUsIHZhbHVlXSkgPT4gKHsgLi4uZXh0cmFjdCh2YWx1ZSwgaXNDb21wb25lbnQpLCBuYW1lIH0pKTtcbiAgfVxuICBpZiAoaXNUdXBsZShsYXlvdXQsIGlzQ29tcG9uZW50KSkge1xuICAgIHJldHVybiBbeyBjb21wb25lbnQ6IGxheW91dFswXSwgcHJvcHM6IGxheW91dFsxXSA/PyB7fSB9XTtcbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheShsYXlvdXQpKSB7XG4gICAgcmV0dXJuIGxheW91dC5tYXAoKGl0ZW0pID0+IGV4dHJhY3QoaXRlbSwgaXNDb21wb25lbnQpKTtcbiAgfVxuICBpZiAoaGFzQ29tcG9uZW50S2V5KGxheW91dCkgJiYgaXNDb21wb25lbnQobGF5b3V0LmNvbXBvbmVudCkpIHtcbiAgICByZXR1cm4gW3sgY29tcG9uZW50OiBsYXlvdXQuY29tcG9uZW50LCBwcm9wczogbGF5b3V0LnByb3BzID8/IHt9IH1dO1xuICB9XG4gIGlmIChpc0NvbXBvbmVudChsYXlvdXQpKSB7XG4gICAgcmV0dXJuIFt7IGNvbXBvbmVudDogbGF5b3V0LCBwcm9wczoge30gfV07XG4gIH1cbiAgcmV0dXJuIFtdO1xufVxuXG4vLyBzcmMvbmF2aWdhdGlvbkV2ZW50cy50c1xuZnVuY3Rpb24gaXNDb250ZW50RWRpdGFibGVPclByZXZlbnRlZChldmVudCkge1xuICByZXR1cm4gZXZlbnQudGFyZ2V0IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgJiYgZXZlbnQudGFyZ2V0LmlzQ29udGVudEVkaXRhYmxlIHx8IGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQ7XG59XG5mdW5jdGlvbiBzaG91bGRJbnRlcmNlcHQoZXZlbnQpIHtcbiAgY29uc3QgaXNMaW5rID0gZXZlbnQuY3VycmVudFRhcmdldC50YWdOYW1lLnRvTG93ZXJDYXNlKCkgPT09IFwiYVwiO1xuICBjb25zdCB0YXJnZXQgPSBpc0xpbmsgPyBldmVudC5jdXJyZW50VGFyZ2V0LnRhcmdldCA6IFwiXCI7XG4gIHJldHVybiAhKGlzQ29udGVudEVkaXRhYmxlT3JQcmV2ZW50ZWQoZXZlbnQpIHx8IGlzTGluayAmJiBldmVudC5hbHRLZXkgfHwgaXNMaW5rICYmIGV2ZW50LmN0cmxLZXkgfHwgaXNMaW5rICYmIGV2ZW50Lm1ldGFLZXkgfHwgaXNMaW5rICYmIGV2ZW50LnNoaWZ0S2V5IHx8IGlzTGluayAmJiB0YXJnZXQgIT09IFwiXCIgJiYgdGFyZ2V0ICE9PSBcIl9zZWxmXCIgfHwgaXNMaW5rICYmIFwiYnV0dG9uXCIgaW4gZXZlbnQgJiYgZXZlbnQuYnV0dG9uICE9PSAwKTtcbn1cbmZ1bmN0aW9uIHNob3VsZE5hdmlnYXRlKGV2ZW50KSB7XG4gIGNvbnN0IGlzQnV0dG9uID0gZXZlbnQuY3VycmVudFRhcmdldC50YWdOYW1lLnRvTG93ZXJDYXNlKCkgPT09IFwiYnV0dG9uXCI7XG4gIHJldHVybiAhaXNDb250ZW50RWRpdGFibGVPclByZXZlbnRlZChldmVudCkgJiYgKGV2ZW50LmtleSA9PT0gXCJFbnRlclwiIHx8IGlzQnV0dG9uICYmIGV2ZW50LmtleSA9PT0gXCIgXCIpO1xufVxuXG4vLyBzcmMvcHJvZ3Jlc3MtY29tcG9uZW50LnRzXG52YXIgYmFzZUNvbXBvbmVudFNlbGVjdG9yID0gXCJucHJvZ3Jlc3NcIjtcbnZhciB1c2VQb3BvdmVyO1xudmFyIHByb2dyZXNzMjtcbnZhciBzZXR0aW5ncyA9IHtcbiAgbWluaW11bTogMC4wOCxcbiAgZWFzaW5nOiBcImxpbmVhclwiLFxuICBzcGVlZDogMjAwLFxuICB0cmlja2xlOiB0cnVlLFxuICB0cmlja2xlU3BlZWQ6IDIwMCxcbiAgc2hvd1NwaW5uZXI6IHRydWUsXG4gIGJhclNlbGVjdG9yOiAnLmJhciwgW3JvbGU9XCJiYXJcIl0nLFxuICBzcGlubmVyU2VsZWN0b3I6ICcuc3Bpbm5lciwgW3JvbGU9XCJzcGlubmVyXCJdJyxcbiAgcGFyZW50OiBcImJvZHlcIixcbiAgY29sb3I6IFwiIzI5ZFwiLFxuICBpbmNsdWRlQ1NTOiB0cnVlLFxuICBwb3BvdmVyOiBudWxsLFxuICB0ZW1wbGF0ZTogW1xuICAgICc8ZGl2IGNsYXNzPVwiYmFyXCI+JyxcbiAgICAnPGRpdiBjbGFzcz1cInBlZ1wiPjwvZGl2PicsXG4gICAgXCI8L2Rpdj5cIixcbiAgICAnPGRpdiBjbGFzcz1cInNwaW5uZXJcIj4nLFxuICAgICc8ZGl2IGNsYXNzPVwic3Bpbm5lci1pY29uXCI+PC9kaXY+JyxcbiAgICBcIjwvZGl2PlwiXG4gIF0uam9pbihcIlwiKVxufTtcbnZhciBzdGF0dXMgPSBudWxsO1xudmFyIGhpZGRlbiA9IGZhbHNlO1xudmFyIGNvbmZpZ3VyZSA9IChvcHRpb25zKSA9PiB7XG4gIE9iamVjdC5hc3NpZ24oc2V0dGluZ3MsIG9wdGlvbnMpO1xuICB1c2VQb3BvdmVyID0gc2V0dGluZ3MucG9wb3ZlciA/PyBcInBvcG92ZXJcIiBpbiBIVE1MRWxlbWVudC5wcm90b3R5cGU7XG4gIGlmIChzZXR0aW5ncy5pbmNsdWRlQ1NTKSB7XG4gICAgaW5qZWN0Q1NTKHNldHRpbmdzLmNvbG9yKTtcbiAgfVxuICBwcm9ncmVzczIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICBwcm9ncmVzczIuaWQgPSBiYXNlQ29tcG9uZW50U2VsZWN0b3I7XG4gIHByb2dyZXNzMi5zZXRBdHRyaWJ1dGUoXCJhcmlhLWhpZGRlblwiLCBcInRydWVcIik7XG4gIHByb2dyZXNzMi5pbm5lckhUTUwgPSBzZXR0aW5ncy50ZW1wbGF0ZTtcbiAgaWYgKHVzZVBvcG92ZXIpIHtcbiAgICBwcm9ncmVzczIucG9wb3ZlciA9IFwibWFudWFsXCI7XG4gIH1cbn07XG52YXIgc2V0NyA9IChuKSA9PiB7XG4gIGNvbnN0IHN0YXJ0ZWQgPSBpc1N0YXJ0ZWQoKTtcbiAgbiA9IGNsYW1wKG4sIHNldHRpbmdzLm1pbmltdW0sIDEpO1xuICBzdGF0dXMgPSBuID09PSAxID8gbnVsbCA6IG47XG4gIGNvbnN0IHByb2dyZXNzMyA9IHJlbmRlcighc3RhcnRlZCk7XG4gIGNvbnN0IGJhciA9IHByb2dyZXNzMy5xdWVyeVNlbGVjdG9yKHNldHRpbmdzLmJhclNlbGVjdG9yKTtcbiAgY29uc3Qgc3BlZWQgPSBzZXR0aW5ncy5zcGVlZDtcbiAgY29uc3QgZWFzZSA9IHNldHRpbmdzLmVhc2luZztcbiAgcHJvZ3Jlc3MzLm9mZnNldFdpZHRoO1xuICBxdWV1ZTQoKG5leHQpID0+IHtcbiAgICBjb25zdCBiYXJTdHlsZXMgPSB7XG4gICAgICB0cmFuc2l0aW9uOiBgYWxsICR7c3BlZWR9bXMgJHtlYXNlfWAsXG4gICAgICB0cmFuc2Zvcm06IGB0cmFuc2xhdGUzZCgke3RvQmFyUGVyY2VudGFnZShuKX0lLDAsMClgXG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBiYXJTdHlsZXMpIHtcbiAgICAgIGJhci5zdHlsZVtrZXldID0gYmFyU3R5bGVzW2tleV07XG4gICAgfVxuICAgIGlmIChuICE9PSAxKSB7XG4gICAgICByZXR1cm4gc2V0VGltZW91dChuZXh0LCBzcGVlZCk7XG4gICAgfVxuICAgIHByb2dyZXNzMy5zdHlsZS50cmFuc2l0aW9uID0gXCJub25lXCI7XG4gICAgcHJvZ3Jlc3MzLnN0eWxlLm9wYWNpdHkgPSBcIjFcIjtcbiAgICBwcm9ncmVzczMub2Zmc2V0V2lkdGg7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBwcm9ncmVzczMuc3R5bGUudHJhbnNpdGlvbiA9IGBhbGwgJHtzcGVlZH1tcyBsaW5lYXJgO1xuICAgICAgcHJvZ3Jlc3MzLnN0eWxlLm9wYWNpdHkgPSBcIjBcIjtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICByZW1vdmUoKTtcbiAgICAgICAgcHJvZ3Jlc3MzLnN0eWxlLnRyYW5zaXRpb24gPSBcIlwiO1xuICAgICAgICBwcm9ncmVzczMuc3R5bGUub3BhY2l0eSA9IFwiXCI7XG4gICAgICAgIG5leHQoKTtcbiAgICAgIH0sIHNwZWVkKTtcbiAgICB9LCBzcGVlZCk7XG4gIH0pO1xufTtcbnZhciBpc1N0YXJ0ZWQgPSAoKSA9PiB0eXBlb2Ygc3RhdHVzID09PSBcIm51bWJlclwiO1xudmFyIHN0YXJ0ID0gKCkgPT4ge1xuICBpZiAoIXN0YXR1cykge1xuICAgIHNldDcoMCk7XG4gIH1cbiAgY29uc3Qgd29yayA9IGZ1bmN0aW9uKCkge1xuICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoIXN0YXR1cykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpbmNyZWFzZUJ5UmFuZG9tKCk7XG4gICAgICB3b3JrKCk7XG4gICAgfSwgc2V0dGluZ3MudHJpY2tsZVNwZWVkKTtcbiAgfTtcbiAgaWYgKHNldHRpbmdzLnRyaWNrbGUpIHtcbiAgICB3b3JrKCk7XG4gIH1cbn07XG52YXIgZG9uZSA9IChmb3JjZSkgPT4ge1xuICBpZiAoIWZvcmNlICYmICFzdGF0dXMpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaW5jcmVhc2VCeVJhbmRvbSgwLjMgKyAwLjUgKiBNYXRoLnJhbmRvbSgpKTtcbiAgc2V0NygxKTtcbn07XG52YXIgaW5jcmVhc2VCeVJhbmRvbSA9IChhbW91bnQpID0+IHtcbiAgY29uc3QgbiA9IHN0YXR1cztcbiAgaWYgKG4gPT09IG51bGwpIHtcbiAgICByZXR1cm4gc3RhcnQoKTtcbiAgfVxuICBpZiAobiA+IDEpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgYW1vdW50ID0gdHlwZW9mIGFtb3VudCA9PT0gXCJudW1iZXJcIiA/IGFtb3VudCA6ICgoKSA9PiB7XG4gICAgY29uc3QgcmFuZ2VzID0ge1xuICAgICAgMC4xOiBbMCwgMC4yXSxcbiAgICAgIDAuMDQ6IFswLjIsIDAuNV0sXG4gICAgICAwLjAyOiBbMC41LCAwLjhdLFxuICAgICAgNWUtMzogWzAuOCwgMC45OV1cbiAgICB9O1xuICAgIGZvciAoY29uc3QgciBpbiByYW5nZXMpIHtcbiAgICAgIGlmIChuID49IHJhbmdlc1tyXVswXSAmJiBuIDwgcmFuZ2VzW3JdWzFdKSB7XG4gICAgICAgIHJldHVybiBwYXJzZUZsb2F0KHIpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gMDtcbiAgfSkoKTtcbiAgcmV0dXJuIHNldDcoY2xhbXAobiArIGFtb3VudCwgMCwgMC45OTQpKTtcbn07XG52YXIgcmVuZGVyID0gKGZyb21TdGFydCkgPT4ge1xuICBpZiAoaXNSZW5kZXJlZCgpKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGJhc2VDb21wb25lbnRTZWxlY3Rvcik7XG4gIH1cbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5hZGQoYCR7YmFzZUNvbXBvbmVudFNlbGVjdG9yfS1idXN5YCk7XG4gIGNvbnN0IGJhciA9IHByb2dyZXNzMi5xdWVyeVNlbGVjdG9yKHNldHRpbmdzLmJhclNlbGVjdG9yKTtcbiAgY29uc3QgcGVyYyA9IGZyb21TdGFydCA/IFwiLTEwMFwiIDogdG9CYXJQZXJjZW50YWdlKHN0YXR1cyB8fCAwKTtcbiAgYmFyLnN0eWxlLnRyYW5zaXRpb24gPSBcImFsbCAwIGxpbmVhclwiO1xuICBiYXIuc3R5bGUudHJhbnNmb3JtID0gYHRyYW5zbGF0ZTNkKCR7cGVyY30lLDAsMClgO1xuICBpZiAoIXNldHRpbmdzLnNob3dTcGlubmVyKSB7XG4gICAgcHJvZ3Jlc3MyLnF1ZXJ5U2VsZWN0b3Ioc2V0dGluZ3Muc3Bpbm5lclNlbGVjdG9yKT8ucmVtb3ZlKCk7XG4gIH1cbiAgaWYgKHVzZVBvcG92ZXIpIHtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHByb2dyZXNzMik7XG4gICAgaWYgKCFoaWRkZW4pIHtcbiAgICAgIHByb2dyZXNzMi5zaG93UG9wb3ZlcigpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBjb25zdCBwYXJlbnQgPSBnZXRQYXJlbnQoKTtcbiAgICBpZiAocGFyZW50ICE9PSBkb2N1bWVudC5ib2R5KSB7XG4gICAgICBwYXJlbnQuY2xhc3NMaXN0LmFkZChgJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9LWN1c3RvbS1wYXJlbnRgKTtcbiAgICB9XG4gICAgcGFyZW50LmFwcGVuZENoaWxkKHByb2dyZXNzMik7XG4gICAgaWYgKGhpZGRlbikge1xuICAgICAgcHJvZ3Jlc3MyLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHByb2dyZXNzMjtcbn07XG52YXIgZ2V0UGFyZW50ID0gKCkgPT4ge1xuICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZXR0aW5ncy5wYXJlbnQpO1xufTtcbnZhciByZW1vdmUgPSAoKSA9PiB7XG4gIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKGAke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0tYnVzeWApO1xuICBpZiAodXNlUG9wb3ZlciAmJiBwcm9ncmVzczI/LmlzQ29ubmVjdGVkKSB7XG4gICAgdHJ5IHtcbiAgICAgIHByb2dyZXNzMi5oaWRlUG9wb3ZlcigpO1xuICAgIH0gY2F0Y2gge1xuICAgIH1cbiAgfVxuICBpZiAoIXVzZVBvcG92ZXIpIHtcbiAgICBnZXRQYXJlbnQoKS5jbGFzc0xpc3QucmVtb3ZlKGAke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0tY3VzdG9tLXBhcmVudGApO1xuICB9XG4gIHByb2dyZXNzMj8ucmVtb3ZlKCk7XG59O1xudmFyIGlzUmVuZGVyZWQgPSAoKSA9PiB7XG4gIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChiYXNlQ29tcG9uZW50U2VsZWN0b3IpICE9PSBudWxsO1xufTtcbmZ1bmN0aW9uIGNsYW1wKG4sIG1pbiwgbWF4KSB7XG4gIGlmIChuIDwgbWluKSB7XG4gICAgcmV0dXJuIG1pbjtcbiAgfVxuICBpZiAobiA+IG1heCkge1xuICAgIHJldHVybiBtYXg7XG4gIH1cbiAgcmV0dXJuIG47XG59XG52YXIgdG9CYXJQZXJjZW50YWdlID0gKG4pID0+ICgtMSArIG4pICogMTAwO1xudmFyIHF1ZXVlNCA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4ge1xuICBjb25zdCBwZW5kaW5nID0gW107XG4gIGNvbnN0IG5leHQgPSAoKSA9PiB7XG4gICAgY29uc3QgZm4gPSBwZW5kaW5nLnNoaWZ0KCk7XG4gICAgaWYgKGZuKSB7XG4gICAgICBmbihuZXh0KTtcbiAgICB9XG4gIH07XG4gIHJldHVybiAoZm4pID0+IHtcbiAgICBwZW5kaW5nLnB1c2goZm4pO1xuICAgIGlmIChwZW5kaW5nLmxlbmd0aCA9PT0gMSkge1xuICAgICAgbmV4dCgpO1xuICAgIH1cbiAgfTtcbn0pKCk7XG52YXIgaW5qZWN0Q1NTID0gKGNvbG9yKSA9PiB7XG4gIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG4gIGNvbnN0IG5vbmNlID0gY29uZmlnLmdldChcIm5vbmNlXCIpO1xuICBpZiAobm9uY2UpIHtcbiAgICBlbGVtZW50Lm5vbmNlID0gbm9uY2U7XG4gIH1cbiAgZWxlbWVudC50ZXh0Q29udGVudCA9IGBcbiAgICAjJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9IHtcbiAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgYmFja2dyb3VuZDogbm9uZTtcbiAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgIG1hcmdpbjogMDtcbiAgICAgIHBhZGRpbmc6IDA7XG4gICAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgIGluc2V0OiB1bnNldDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgaGVpZ2h0OiAwO1xuICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgdG9wOiAwO1xuICAgICAgbGVmdDogMDtcbiAgICB9XG5cbiAgICAjJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9OjpiYWNrZHJvcCB7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cblxuICAgICMke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0gLmJhciB7XG4gICAgICBiYWNrZ3JvdW5kOiAke2NvbG9yfTtcblxuICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgei1pbmRleDogMTAzMTtcbiAgICAgIHRvcDogMDtcbiAgICAgIGxlZnQ6IDA7XG5cbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgaGVpZ2h0OiAycHg7XG4gICAgfVxuXG4gICAgIyR7YmFzZUNvbXBvbmVudFNlbGVjdG9yfSAucGVnIHtcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgcmlnaHQ6IDBweDtcbiAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAxMHB4ICR7Y29sb3J9LCAwIDAgNXB4ICR7Y29sb3J9O1xuICAgICAgb3BhY2l0eTogMS4wO1xuXG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgzZGVnKSB0cmFuc2xhdGUoMHB4LCAtNHB4KTtcbiAgICB9XG5cbiAgICAjJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9IC5zcGlubmVyIHtcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgei1pbmRleDogMTAzMTtcbiAgICAgIHRvcDogMTVweDtcbiAgICAgIHJpZ2h0OiAxNXB4O1xuICAgIH1cblxuICAgICMke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0gLnNwaW5uZXItaWNvbiB7XG4gICAgICB3aWR0aDogMThweDtcbiAgICAgIGhlaWdodDogMThweDtcbiAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cbiAgICAgIGJvcmRlcjogc29saWQgMnB4IHRyYW5zcGFyZW50O1xuICAgICAgYm9yZGVyLXRvcC1jb2xvcjogJHtjb2xvcn07XG4gICAgICBib3JkZXItbGVmdC1jb2xvcjogJHtjb2xvcn07XG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG5cbiAgICAgIGFuaW1hdGlvbjogJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9LXNwaW5uZXIgNDAwbXMgbGluZWFyIGluZmluaXRlO1xuICAgIH1cblxuICAgIC4ke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0tY3VzdG9tLXBhcmVudCB7XG4gICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIH1cblxuICAgIC4ke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0tY3VzdG9tLXBhcmVudCAjJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9IC5zcGlubmVyLFxuICAgIC4ke2Jhc2VDb21wb25lbnRTZWxlY3Rvcn0tY3VzdG9tLXBhcmVudCAjJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9IC5iYXIge1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIH1cblxuICAgIEBrZXlmcmFtZXMgJHtiYXNlQ29tcG9uZW50U2VsZWN0b3J9LXNwaW5uZXIge1xuICAgICAgMCUgICB7IHRyYW5zZm9ybTogcm90YXRlKDBkZWcpOyB9XG4gICAgICAxMDAlIHsgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTsgfVxuICAgIH1cbiAgYDtcbiAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChlbGVtZW50KTtcbn07XG52YXIgc2hvdyA9ICgpID0+IHtcbiAgaGlkZGVuID0gZmFsc2U7XG4gIGlmICghcHJvZ3Jlc3MyPy5pc0Nvbm5lY3RlZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodXNlUG9wb3Zlcikge1xuICAgIHRyeSB7XG4gICAgICBwcm9ncmVzczIuc2hvd1BvcG92ZXIoKTtcbiAgICB9IGNhdGNoIHtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcHJvZ3Jlc3MyLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xuICB9XG59O1xudmFyIGhpZGUgPSAoKSA9PiB7XG4gIGhpZGRlbiA9IHRydWU7XG4gIGlmICghcHJvZ3Jlc3MyPy5pc0Nvbm5lY3RlZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodXNlUG9wb3Zlcikge1xuICAgIHRyeSB7XG4gICAgICBwcm9ncmVzczIuaGlkZVBvcG92ZXIoKTtcbiAgICB9IGNhdGNoIHtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcHJvZ3Jlc3MyLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgfVxufTtcbnZhciBwcm9ncmVzc19jb21wb25lbnRfZGVmYXVsdCA9IHtcbiAgY29uZmlndXJlLFxuICBpc1N0YXJ0ZWQsXG4gIGRvbmUsXG4gIHNldDogc2V0NyxcbiAgcmVtb3ZlLFxuICBzdGFydCxcbiAgc3RhdHVzLFxuICBzaG93LFxuICBoaWRlXG59O1xuXG4vLyBzcmMvcHJvZ3Jlc3MudHNcbnZhciBQcm9ncmVzcyA9IGNsYXNzIHtcbiAgaGlkZUNvdW50ID0gMDtcbiAgc3RhcnQoKSB7XG4gICAgcHJvZ3Jlc3NfY29tcG9uZW50X2RlZmF1bHQuc3RhcnQoKTtcbiAgfVxuICByZXZlYWwoZm9yY2UgPSBmYWxzZSkge1xuICAgIHRoaXMuaGlkZUNvdW50ID0gTWF0aC5tYXgoMCwgdGhpcy5oaWRlQ291bnQgLSAxKTtcbiAgICBpZiAoZm9yY2UgfHwgdGhpcy5oaWRlQ291bnQgPT09IDApIHtcbiAgICAgIHByb2dyZXNzX2NvbXBvbmVudF9kZWZhdWx0LnNob3coKTtcbiAgICB9XG4gIH1cbiAgaGlkZSgpIHtcbiAgICB0aGlzLmhpZGVDb3VudCsrO1xuICAgIHByb2dyZXNzX2NvbXBvbmVudF9kZWZhdWx0LmhpZGUoKTtcbiAgfVxuICBzZXQoc3RhdHVzMikge1xuICAgIHByb2dyZXNzX2NvbXBvbmVudF9kZWZhdWx0LnNldChNYXRoLm1heCgwLCBNYXRoLm1pbigxLCBzdGF0dXMyKSkpO1xuICB9XG4gIGZpbmlzaCgpIHtcbiAgICBwcm9ncmVzc19jb21wb25lbnRfZGVmYXVsdC5kb25lKCk7XG4gIH1cbiAgcmVzZXQoKSB7XG4gICAgcHJvZ3Jlc3NfY29tcG9uZW50X2RlZmF1bHQuc2V0KDApO1xuICB9XG4gIHJlbW92ZSgpIHtcbiAgICBwcm9ncmVzc19jb21wb25lbnRfZGVmYXVsdC5kb25lKCk7XG4gICAgcHJvZ3Jlc3NfY29tcG9uZW50X2RlZmF1bHQucmVtb3ZlKCk7XG4gIH1cbiAgaXNTdGFydGVkKCkge1xuICAgIHJldHVybiBwcm9ncmVzc19jb21wb25lbnRfZGVmYXVsdC5pc1N0YXJ0ZWQoKTtcbiAgfVxuICBnZXRTdGF0dXMoKSB7XG4gICAgcmV0dXJuIHByb2dyZXNzX2NvbXBvbmVudF9kZWZhdWx0LnN0YXR1cztcbiAgfVxufTtcbnZhciBwcm9ncmVzcyA9IG5ldyBQcm9ncmVzcygpO1xuZnVuY3Rpb24gYWRkRXZlbnRMaXN0ZW5lcnMoZGVsYXkpIHtcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImluZXJ0aWE6c3RhcnRcIiwgKGUpID0+IGhhbmRsZVN0YXJ0RXZlbnQoZSwgZGVsYXkpKTtcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImluZXJ0aWE6cHJvZ3Jlc3NcIiwgaGFuZGxlUHJvZ3Jlc3NFdmVudCk7XG59XG5mdW5jdGlvbiBoYW5kbGVTdGFydEV2ZW50KGV2ZW50LCBkZWxheSkge1xuICBpZiAoIWV2ZW50LmRldGFpbC52aXNpdC5zaG93UHJvZ3Jlc3MpIHtcbiAgICBwcm9ncmVzcy5oaWRlKCk7XG4gIH1cbiAgY29uc3QgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4gcHJvZ3Jlc3Muc3RhcnQoKSwgZGVsYXkpO1xuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiaW5lcnRpYTpmaW5pc2hcIiwgKGUpID0+IGZpbmlzaChlLCB0aW1lb3V0KSwgeyBvbmNlOiB0cnVlIH0pO1xufVxuZnVuY3Rpb24gaGFuZGxlUHJvZ3Jlc3NFdmVudChldmVudCkge1xuICBpZiAocHJvZ3Jlc3MuaXNTdGFydGVkKCkgJiYgZXZlbnQuZGV0YWlsLnByb2dyZXNzPy5wZXJjZW50YWdlKSB7XG4gICAgcHJvZ3Jlc3Muc2V0KE1hdGgubWF4KHByb2dyZXNzLmdldFN0YXR1cygpLCBldmVudC5kZXRhaWwucHJvZ3Jlc3MucGVyY2VudGFnZSAvIDEwMCAqIDAuOSkpO1xuICB9XG59XG5mdW5jdGlvbiBmaW5pc2goZXZlbnQsIHRpbWVvdXQpIHtcbiAgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICBpZiAoIXByb2dyZXNzLmlzU3RhcnRlZCgpKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChldmVudC5kZXRhaWwudmlzaXQuY29tcGxldGVkKSB7XG4gICAgcHJvZ3Jlc3MuZmluaXNoKCk7XG4gIH0gZWxzZSBpZiAoZXZlbnQuZGV0YWlsLnZpc2l0LmludGVycnVwdGVkKSB7XG4gICAgcHJvZ3Jlc3MucmVzZXQoKTtcbiAgfSBlbHNlIGlmIChldmVudC5kZXRhaWwudmlzaXQuY2FuY2VsbGVkKSB7XG4gICAgcHJvZ3Jlc3MucmVtb3ZlKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHNldHVwUHJvZ3Jlc3Moe1xuICBkZWxheSA9IDI1MCxcbiAgY29sb3IgPSBcIiMyOWRcIixcbiAgaW5jbHVkZUNTUyA9IHRydWUsXG4gIHNob3dTcGlubmVyID0gZmFsc2UsXG4gIHBvcG92ZXIgPSBudWxsXG59ID0ge30pIHtcbiAgYWRkRXZlbnRMaXN0ZW5lcnMoZGVsYXkpO1xuICBwcm9ncmVzc19jb21wb25lbnRfZGVmYXVsdC5jb25maWd1cmUoe1xuICAgIHNob3dTcGlubmVyLFxuICAgIGluY2x1ZGVDU1MsXG4gICAgY29sb3IsXG4gICAgcG9wb3ZlclxuICB9KTtcbn1cblxuLy8gc3JjL3Jlc2V0Rm9ybUZpZWxkcy50c1xudmFyIEZvcm1Db21wb25lbnRSZXNldFN5bWJvbCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJGb3JtQ29tcG9uZW50UmVzZXRcIik7XG5mdW5jdGlvbiBpc0Zvcm1FbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50IHx8IGVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MU2VsZWN0RWxlbWVudCB8fCBlbGVtZW50IGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudDtcbn1cbmZ1bmN0aW9uIHJlc2V0SW5wdXRFbGVtZW50KGlucHV0LCBkZWZhdWx0VmFsdWVzKSB7XG4gIGNvbnN0IG9sZFZhbHVlID0gaW5wdXQudmFsdWU7XG4gIGNvbnN0IG9sZENoZWNrZWQgPSBpbnB1dC5jaGVja2VkO1xuICBzd2l0Y2ggKGlucHV0LnR5cGUudG9Mb3dlckNhc2UoKSkge1xuICAgIGNhc2UgXCJjaGVja2JveFwiOlxuICAgICAgaW5wdXQuY2hlY2tlZCA9IGRlZmF1bHRWYWx1ZXMuaW5jbHVkZXMoaW5wdXQudmFsdWUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInJhZGlvXCI6XG4gICAgICBpbnB1dC5jaGVja2VkID0gZGVmYXVsdFZhbHVlc1swXSA9PT0gaW5wdXQudmFsdWU7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZmlsZVwiOlxuICAgICAgaW5wdXQudmFsdWUgPSBcIlwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImJ1dHRvblwiOlxuICAgIGNhc2UgXCJzdWJtaXRcIjpcbiAgICBjYXNlIFwicmVzZXRcIjpcbiAgICBjYXNlIFwiaW1hZ2VcIjpcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBpbnB1dC52YWx1ZSA9IGRlZmF1bHRWYWx1ZXNbMF0gIT09IG51bGwgJiYgZGVmYXVsdFZhbHVlc1swXSAhPT0gdm9pZCAwID8gU3RyaW5nKGRlZmF1bHRWYWx1ZXNbMF0pIDogXCJcIjtcbiAgfVxuICByZXR1cm4gaW5wdXQudmFsdWUgIT09IG9sZFZhbHVlIHx8IGlucHV0LmNoZWNrZWQgIT09IG9sZENoZWNrZWQ7XG59XG5mdW5jdGlvbiByZXNldFNlbGVjdEVsZW1lbnQoc2VsZWN0LCBkZWZhdWx0VmFsdWVzKSB7XG4gIGNvbnN0IG9sZFZhbHVlID0gc2VsZWN0LnZhbHVlO1xuICBjb25zdCBvbGRTZWxlY3RlZE9wdGlvbnMgPSBBcnJheS5mcm9tKHNlbGVjdC5zZWxlY3RlZE9wdGlvbnMpLm1hcCgob3B0KSA9PiBvcHQudmFsdWUpO1xuICBpZiAoc2VsZWN0Lm11bHRpcGxlKSB7XG4gICAgY29uc3QgZGVmYXVsdFN0cmluZ3MgPSBkZWZhdWx0VmFsdWVzLm1hcCgodmFsdWUpID0+IFN0cmluZyh2YWx1ZSkpO1xuICAgIEFycmF5LmZyb20oc2VsZWN0Lm9wdGlvbnMpLmZvckVhY2goKG9wdGlvbikgPT4ge1xuICAgICAgb3B0aW9uLnNlbGVjdGVkID0gZGVmYXVsdFN0cmluZ3MuaW5jbHVkZXMob3B0aW9uLnZhbHVlKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBzZWxlY3QudmFsdWUgPSBkZWZhdWx0VmFsdWVzWzBdICE9PSB2b2lkIDAgPyBTdHJpbmcoZGVmYXVsdFZhbHVlc1swXSkgOiBcIlwiO1xuICB9XG4gIGNvbnN0IG5ld1NlbGVjdGVkT3B0aW9ucyA9IEFycmF5LmZyb20oc2VsZWN0LnNlbGVjdGVkT3B0aW9ucykubWFwKChvcHQpID0+IG9wdC52YWx1ZSk7XG4gIGNvbnN0IGhhc0NoYW5nZWQgPSBzZWxlY3QubXVsdGlwbGUgPyBKU09OLnN0cmluZ2lmeShvbGRTZWxlY3RlZE9wdGlvbnMuc29ydCgpKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3U2VsZWN0ZWRPcHRpb25zLnNvcnQoKSkgOiBzZWxlY3QudmFsdWUgIT09IG9sZFZhbHVlO1xuICByZXR1cm4gaGFzQ2hhbmdlZDtcbn1cbmZ1bmN0aW9uIHJlc2V0Rm9ybUVsZW1lbnQoZWxlbWVudCwgZGVmYXVsdFZhbHVlcykge1xuICBpZiAoZWxlbWVudC5kaXNhYmxlZCkge1xuICAgIGlmIChlbGVtZW50IGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCkge1xuICAgICAgY29uc3Qgb2xkVmFsdWUgPSBlbGVtZW50LnZhbHVlO1xuICAgICAgY29uc3Qgb2xkQ2hlY2tlZCA9IGVsZW1lbnQuY2hlY2tlZDtcbiAgICAgIHN3aXRjaCAoZWxlbWVudC50eXBlLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgY2FzZSBcImNoZWNrYm94XCI6XG4gICAgICAgIGNhc2UgXCJyYWRpb1wiOlxuICAgICAgICAgIGVsZW1lbnQuY2hlY2tlZCA9IGVsZW1lbnQuZGVmYXVsdENoZWNrZWQ7XG4gICAgICAgICAgcmV0dXJuIGVsZW1lbnQuY2hlY2tlZCAhPT0gb2xkQ2hlY2tlZDtcbiAgICAgICAgY2FzZSBcImZpbGVcIjpcbiAgICAgICAgICBlbGVtZW50LnZhbHVlID0gXCJcIjtcbiAgICAgICAgICByZXR1cm4gb2xkVmFsdWUgIT09IFwiXCI7XG4gICAgICAgIGNhc2UgXCJidXR0b25cIjpcbiAgICAgICAgY2FzZSBcInN1Ym1pdFwiOlxuICAgICAgICBjYXNlIFwicmVzZXRcIjpcbiAgICAgICAgY2FzZSBcImltYWdlXCI6XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIGVsZW1lbnQudmFsdWUgPSBlbGVtZW50LmRlZmF1bHRWYWx1ZTtcbiAgICAgICAgICByZXR1cm4gZWxlbWVudC52YWx1ZSAhPT0gb2xkVmFsdWU7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChlbGVtZW50IGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpIHtcbiAgICAgIGNvbnN0IG9sZFNlbGVjdGVkT3B0aW9ucyA9IEFycmF5LmZyb20oZWxlbWVudC5zZWxlY3RlZE9wdGlvbnMpLm1hcCgob3B0KSA9PiBvcHQudmFsdWUpO1xuICAgICAgQXJyYXkuZnJvbShlbGVtZW50Lm9wdGlvbnMpLmZvckVhY2goKG9wdGlvbikgPT4ge1xuICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSBvcHRpb24uZGVmYXVsdFNlbGVjdGVkO1xuICAgICAgfSk7XG4gICAgICBjb25zdCBuZXdTZWxlY3RlZE9wdGlvbnMgPSBBcnJheS5mcm9tKGVsZW1lbnQuc2VsZWN0ZWRPcHRpb25zKS5tYXAoKG9wdCkgPT4gb3B0LnZhbHVlKTtcbiAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeShvbGRTZWxlY3RlZE9wdGlvbnMuc29ydCgpKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3U2VsZWN0ZWRPcHRpb25zLnNvcnQoKSk7XG4gICAgfSBlbHNlIGlmIChlbGVtZW50IGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCkge1xuICAgICAgY29uc3Qgb2xkVmFsdWUgPSBlbGVtZW50LnZhbHVlO1xuICAgICAgZWxlbWVudC52YWx1ZSA9IGVsZW1lbnQuZGVmYXVsdFZhbHVlO1xuICAgICAgcmV0dXJuIGVsZW1lbnQudmFsdWUgIT09IG9sZFZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSB7XG4gICAgcmV0dXJuIHJlc2V0SW5wdXRFbGVtZW50KGVsZW1lbnQsIGRlZmF1bHRWYWx1ZXMpO1xuICB9IGVsc2UgaWYgKGVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MU2VsZWN0RWxlbWVudCkge1xuICAgIHJldHVybiByZXNldFNlbGVjdEVsZW1lbnQoZWxlbWVudCwgZGVmYXVsdFZhbHVlcyk7XG4gIH0gZWxzZSBpZiAoZWxlbWVudCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQpIHtcbiAgICBjb25zdCBvbGRWYWx1ZSA9IGVsZW1lbnQudmFsdWU7XG4gICAgZWxlbWVudC52YWx1ZSA9IGRlZmF1bHRWYWx1ZXNbMF0gIT09IHZvaWQgMCA/IFN0cmluZyhkZWZhdWx0VmFsdWVzWzBdKSA6IFwiXCI7XG4gICAgcmV0dXJuIGVsZW1lbnQudmFsdWUgIT09IG9sZFZhbHVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIHJlc2V0RmllbGRFbGVtZW50cyhlbGVtZW50cywgZGVmYXVsdFZhbHVlcykge1xuICBsZXQgaGFzQ2hhbmdlZCA9IGZhbHNlO1xuICBpZiAoZWxlbWVudHMgaW5zdGFuY2VvZiBSYWRpb05vZGVMaXN0IHx8IGVsZW1lbnRzIGluc3RhbmNlb2YgSFRNTENvbGxlY3Rpb24pIHtcbiAgICBBcnJheS5mcm9tKGVsZW1lbnRzKS5mb3JFYWNoKChub2RlLCBpbmRleCkgPT4ge1xuICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBFbGVtZW50ICYmIGlzRm9ybUVsZW1lbnQobm9kZSkpIHtcbiAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIFtcImNoZWNrYm94XCIsIFwicmFkaW9cIl0uaW5jbHVkZXMobm9kZS50eXBlLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgICAgICAgaWYgKHJlc2V0Rm9ybUVsZW1lbnQobm9kZSwgZGVmYXVsdFZhbHVlcykpIHtcbiAgICAgICAgICAgIGhhc0NoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBpbmRleGVkRGVmYXVsdFZhbHVlcyA9IGRlZmF1bHRWYWx1ZXNbaW5kZXhdICE9PSB2b2lkIDAgPyBbZGVmYXVsdFZhbHVlc1tpbmRleF1dIDogW2RlZmF1bHRWYWx1ZXNbMF0gPz8gbnVsbF0uZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICAgIGlmIChyZXNldEZvcm1FbGVtZW50KG5vZGUsIGluZGV4ZWREZWZhdWx0VmFsdWVzKSkge1xuICAgICAgICAgICAgaGFzQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH0gZWxzZSBpZiAoaXNGb3JtRWxlbWVudChlbGVtZW50cykpIHtcbiAgICBoYXNDaGFuZ2VkID0gcmVzZXRGb3JtRWxlbWVudChlbGVtZW50cywgZGVmYXVsdFZhbHVlcyk7XG4gIH1cbiAgcmV0dXJuIGhhc0NoYW5nZWQ7XG59XG5mdW5jdGlvbiByZXNldEZvcm1GaWVsZHMoZm9ybUVsZW1lbnQsIGRlZmF1bHRzLCBmaWVsZE5hbWVzKSB7XG4gIGlmICghZm9ybUVsZW1lbnQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcmVzZXRFbnRpcmVGb3JtID0gIWZpZWxkTmFtZXMgfHwgZmllbGROYW1lcy5sZW5ndGggPT09IDA7XG4gIGlmIChyZXNldEVudGlyZUZvcm0pIHtcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YShmb3JtRWxlbWVudCk7XG4gICAgY29uc3QgZm9ybUVsZW1lbnROYW1lcyA9IEFycmF5LmZyb20oZm9ybUVsZW1lbnQuZWxlbWVudHMpLm1hcCgoZWwpID0+IGlzRm9ybUVsZW1lbnQoZWwpID8gZWwubmFtZSA6IFwiXCIpLmZpbHRlcihCb29sZWFuKTtcbiAgICBmaWVsZE5hbWVzID0gWy4uLi8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFsuLi5kZWZhdWx0cy5rZXlzKCksIC4uLmZvcm1EYXRhLmtleXMoKSwgLi4uZm9ybUVsZW1lbnROYW1lc10pXTtcbiAgfVxuICBsZXQgaGFzQ2hhbmdlZCA9IGZhbHNlO1xuICBmaWVsZE5hbWVzLmZvckVhY2goKGZpZWxkTmFtZSkgPT4ge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gZm9ybUVsZW1lbnQuZWxlbWVudHMubmFtZWRJdGVtKGZpZWxkTmFtZSk7XG4gICAgaWYgKGVsZW1lbnRzKSB7XG4gICAgICBpZiAocmVzZXRGaWVsZEVsZW1lbnRzKGVsZW1lbnRzLCBkZWZhdWx0cy5nZXRBbGwoZmllbGROYW1lKSkpIHtcbiAgICAgICAgaGFzQ2hhbmdlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgaWYgKGhhc0NoYW5nZWQgJiYgcmVzZXRFbnRpcmVGb3JtKSB7XG4gICAgZm9ybUVsZW1lbnQuZGlzcGF0Y2hFdmVudChcbiAgICAgIG5ldyBDdXN0b21FdmVudChcInJlc2V0XCIsIHsgYnViYmxlczogdHJ1ZSwgY2FuY2VsYWJsZTogdHJ1ZSwgZGV0YWlsOiB7IFtGb3JtQ29tcG9uZW50UmVzZXRTeW1ib2xdOiB0cnVlIH0gfSlcbiAgICApO1xuICB9XG59XG5cbi8vIHNyYy9zc3JVdGlscy50c1xuZnVuY3Rpb24gYnVpbGRTU1JCb2R5KGlkLCBwYWdlMiwgaHRtbCkge1xuICBjb25zdCBqc29uID0gSlNPTi5zdHJpbmdpZnkocGFnZTIpLnJlcGxhY2UoL1xcLy9nLCBcIlxcXFwvXCIpLnJlcGxhY2UoLzwvZywgXCJcXFxcdTAwM2NcIik7XG4gIHJldHVybiBgPHNjcmlwdCBkYXRhLXBhZ2U9XCIke2lkfVwiIHR5cGU9XCJhcHBsaWNhdGlvbi9qc29uXCI+JHtqc29ufTxcXC9zY3JpcHQ+PGRpdiBkYXRhLXNlcnZlci1yZW5kZXJlZD1cInRydWVcIiBpZD1cIiR7aWR9XCI+JHtodG1sfTwvZGl2PmA7XG59XG5cbi8vIHNyYy9pbmRleC50c1xudmFyIHJvdXRlciA9IG5ldyBSb3V0ZXIoKTtcbmV4cG9ydCB7XG4gIEZvcm1Db21wb25lbnRSZXNldFN5bWJvbCxcbiAgSHR0cENhbmNlbGxlZEVycm9yLFxuICBIdHRwRXJyb3IsXG4gIEh0dHBOZXR3b3JrRXJyb3IsXG4gIEh0dHBSZXNwb25zZUVycm9yLFxuICBVc2VGb3JtVXRpbHMsXG4gIFhockh0dHBDbGllbnQsXG4gIGF4aW9zQWRhcHRlcixcbiAgYnVpbGRTU1JCb2R5LFxuICBjb25maWcsXG4gIGNyZWF0ZUhlYWRNYW5hZ2VyLFxuICBjcmVhdGVMYXlvdXRQcm9wc1N0b3JlLFxuICBleHBvc2VJbnRlcmNlcHRvcnMsXG4gIGZvcm1EYXRhVG9PYmplY3QsXG4gIGdldEluaXRpYWxQYWdlRnJvbURPTSxcbiAgZ2V0U2Nyb2xsYWJsZVBhcmVudCxcbiAgaGFzRmlsZXMsXG4gIGhyZWZUb1VybCxcbiAgaHR0cCxcbiAgaW50ZXJjZXB0b3JzLFxuICBpc1BhdGhPclN1YlBhdGgsXG4gIGlzUHJvcHNPYmplY3QsXG4gIGlzUHJvcHNPYmplY3RPckNhbGxiYWNrLFxuICBpc1NhbWVVcmxXaXRob3V0UXVlcnlPckhhc2gsXG4gIGlzVXJsTWV0aG9kUGFpcixcbiAgbWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nLFxuICBub3JtYWxpemVMYXlvdXRzLFxuICBvYmplY3RUb0Zvcm1EYXRhLFxuICBwYXJ0aWFsUmVsb2FkUmVxdWVzdHNQcm9wLFxuICBwYXJ0aWFsUmVsb2FkUmVxdWVzdHNTb21lUHJvcHMsXG4gIHByb2dyZXNzLFxuICByZXNldEZvcm1GaWVsZHMsXG4gIHJlc29sdmVTZXJ2ZXJIZWFkLFxuICByZXNvbHZlVXJsTWV0aG9kUGFpckNvbXBvbmVudCxcbiAgcm91dGVyLFxuICBzZXR1cFByb2dyZXNzLFxuICBzaG91bGRJbnRlcmNlcHQsXG4gIHNob3VsZE5hdmlnYXRlLFxuICB1cmxIYXNQcm90b2NvbCxcbiAgdXJsVG9TdHJpbmcsXG4gIHVybFdpdGhvdXRIYXNoLFxuICB1c2VJbmZpbml0ZVNjcm9sbCxcbiAgeGhySHR0cENsaWVudFxufTtcbi8qIE5Qcm9ncmVzcywgKGMpIDIwMTMsIDIwMTQgUmljbyBTdGEuIENydXogLSBodHRwOi8vcmljb3N0YWNydXouY29tL25wcm9ncmVzc1xuICogQGxpY2Vuc2UgTUlUICovXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXBcbiIsIi8vIHNyYy9pbmRleC50c1xuaW1wb3J0IHsgY29uZmlnIGFzIGNvcmVDb25maWcgfSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBodHRwIGFzIGh0dHAyLCBwcm9ncmVzcywgcm91dGVyIGFzIHJvdXRlcjEyIH0gZnJvbSBcIkBpbmVydGlhanMvY29yZVwiO1xuXG4vLyBzcmMvYXBwLnRzXG5pbXBvcnQge1xuICBjcmVhdGVIZWFkTWFuYWdlcixcbiAgaXNQcm9wc09iamVjdCxcbiAgaXNQcm9wc09iamVjdE9yQ2FsbGJhY2ssXG4gIG5vcm1hbGl6ZUxheW91dHMsXG4gIHJlc29sdmVTZXJ2ZXJIZWFkLFxuICByb3V0ZXIgYXMgcm91dGVyNFxufSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQge1xuICBjb21wdXRlZCxcbiAgZGVmaW5lQ29tcG9uZW50LFxuICBoLFxuICBtYXJrUmF3LFxuICByZWFjdGl2ZSBhcyByZWFjdGl2ZTIsXG4gIHJlZiBhcyByZWYyLFxuICBzaGFsbG93UmVmXG59IGZyb20gXCJ2dWVcIjtcblxuLy8gc3JjL2xheW91dFByb3BzLnRzXG5pbXBvcnQgeyBjcmVhdGVMYXlvdXRQcm9wc1N0b3JlIH0gZnJvbSBcIkBpbmVydGlhanMvY29yZVwiO1xuaW1wb3J0IHsgcmVmIH0gZnJvbSBcInZ1ZVwiO1xudmFyIHN0b3JlID0gY3JlYXRlTGF5b3V0UHJvcHNTdG9yZSgpO1xudmFyIHN0YXRlID0gcmVmKHN0b3JlLmdldCgpKTtcbnN0b3JlLnN1YnNjcmliZSgoKSA9PiB7XG4gIHN0YXRlLnZhbHVlID0gc3RvcmUuZ2V0KCk7XG59KTtcbmZ1bmN0aW9uIHNldExheW91dFByb3BzKG5hbWVPclByb3BzLCBwcm9wcykge1xuICBpZiAodHlwZW9mIG5hbWVPclByb3BzID09PSBcInN0cmluZ1wiKSB7XG4gICAgc3RvcmUuc2V0Rm9yKG5hbWVPclByb3BzLCBwcm9wcyk7XG4gIH0gZWxzZSB7XG4gICAgc3RvcmUuc2V0KG5hbWVPclByb3BzKTtcbiAgfVxufVxuZnVuY3Rpb24gcmVzZXRMYXlvdXRQcm9wcygpIHtcbiAgc3RvcmUucmVzZXQoKTtcbiAgc3RhdGUudmFsdWUgPSBzdG9yZS5nZXQoKTtcbn1cblxuLy8gc3JjL3JlbWVtYmVyLnRzXG5pbXBvcnQgeyByb3V0ZXIgfSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBjbG9uZURlZXAgfSBmcm9tIFwiZXMtdG9vbGtpdFwiO1xudmFyIHJlbWVtYmVyID0ge1xuICBjcmVhdGVkKCkge1xuICAgIGlmICghdGhpcy4kb3B0aW9ucy5yZW1lbWJlcikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheSh0aGlzLiRvcHRpb25zLnJlbWVtYmVyKSkge1xuICAgICAgdGhpcy4kb3B0aW9ucy5yZW1lbWJlciA9IHsgZGF0YTogdGhpcy4kb3B0aW9ucy5yZW1lbWJlciB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHRoaXMuJG9wdGlvbnMucmVtZW1iZXIgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHRoaXMuJG9wdGlvbnMucmVtZW1iZXIgPSB7IGRhdGE6IFt0aGlzLiRvcHRpb25zLnJlbWVtYmVyXSB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHRoaXMuJG9wdGlvbnMucmVtZW1iZXIuZGF0YSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgdGhpcy4kb3B0aW9ucy5yZW1lbWJlciA9IHsgZGF0YTogW3RoaXMuJG9wdGlvbnMucmVtZW1iZXIuZGF0YV0gfTtcbiAgICB9XG4gICAgY29uc3QgcmVtZW1iZXJLZXkgPSB0aGlzLiRvcHRpb25zLnJlbWVtYmVyLmtleSBpbnN0YW5jZW9mIEZ1bmN0aW9uID8gdGhpcy4kb3B0aW9ucy5yZW1lbWJlci5rZXkuY2FsbCh0aGlzKSA6IHRoaXMuJG9wdGlvbnMucmVtZW1iZXIua2V5O1xuICAgIGNvbnN0IHJlc3RvcmVkID0gcm91dGVyLnJlc3RvcmUocmVtZW1iZXJLZXkpO1xuICAgIGNvbnN0IHJlbWVtYmVyYWJsZSA9IHRoaXMuJG9wdGlvbnMucmVtZW1iZXIuZGF0YS5maWx0ZXIoKGtleTIpID0+IHtcbiAgICAgIHJldHVybiAhKHRoaXNba2V5Ml0gIT09IG51bGwgJiYgdHlwZW9mIHRoaXNba2V5Ml0gPT09IFwib2JqZWN0XCIgJiYgdGhpc1trZXkyXS5fX3JlbWVtYmVyYWJsZSA9PT0gZmFsc2UpO1xuICAgIH0pO1xuICAgIGNvbnN0IGhhc0NhbGxiYWNrcyA9IChrZXkyKSA9PiB7XG4gICAgICByZXR1cm4gdGhpc1trZXkyXSAhPT0gbnVsbCAmJiB0eXBlb2YgdGhpc1trZXkyXSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdGhpc1trZXkyXS5fX3JlbWVtYmVyID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIHRoaXNba2V5Ml0uX19yZXN0b3JlID09PSBcImZ1bmN0aW9uXCI7XG4gICAgfTtcbiAgICByZW1lbWJlcmFibGUuZm9yRWFjaCgoa2V5MikgPT4ge1xuICAgICAgaWYgKHRoaXNba2V5Ml0gIT09IHZvaWQgMCAmJiByZXN0b3JlZCAhPT0gdm9pZCAwICYmIHJlc3RvcmVkW2tleTJdICE9PSB2b2lkIDApIHtcbiAgICAgICAgaGFzQ2FsbGJhY2tzKGtleTIpID8gdGhpc1trZXkyXS5fX3Jlc3RvcmUocmVzdG9yZWRba2V5Ml0pIDogdGhpc1trZXkyXSA9IHJlc3RvcmVkW2tleTJdO1xuICAgICAgfVxuICAgICAgdGhpcy4kd2F0Y2goXG4gICAgICAgIGtleTIsXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICByb3V0ZXIucmVtZW1iZXIoXG4gICAgICAgICAgICByZW1lbWJlcmFibGUucmVkdWNlKFxuICAgICAgICAgICAgICAoZGF0YSwga2V5MykgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5kYXRhLFxuICAgICAgICAgICAgICAgIFtrZXkzXTogY2xvbmVEZWVwKGhhc0NhbGxiYWNrcyhrZXkzKSA/IHRoaXNba2V5M10uX19yZW1lbWJlcigpIDogdGhpc1trZXkzXSlcbiAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgIHt9XG4gICAgICAgICAgICApLFxuICAgICAgICAgICAgcmVtZW1iZXJLZXlcbiAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICB7IGltbWVkaWF0ZTogdHJ1ZSwgZGVlcDogdHJ1ZSB9XG4gICAgICApO1xuICAgIH0pO1xuICB9XG59O1xudmFyIHJlbWVtYmVyX2RlZmF1bHQgPSByZW1lbWJlcjtcblxuLy8gc3JjL3VzZUZvcm0udHNcbmltcG9ydCB7XG4gIHJvdXRlciBhcyByb3V0ZXIzLFxuICBVc2VGb3JtVXRpbHMgYXMgVXNlRm9ybVV0aWxzMlxufSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBjbG9uZURlZXAgYXMgY2xvbmVEZWVwMyB9IGZyb20gXCJlcy10b29sa2l0XCI7XG5cbi8vIHNyYy91c2VGb3JtU3RhdGUudHNcbmltcG9ydCB7XG4gIHJvdXRlciBhcyByb3V0ZXIyLFxuICBVc2VGb3JtVXRpbHNcbn0gZnJvbSBcIkBpbmVydGlhanMvY29yZVwiO1xuaW1wb3J0IHsgY2xvbmVEZWVwIGFzIGNsb25lRGVlcDIsIGlzRXF1YWwgfSBmcm9tIFwiZXMtdG9vbGtpdFwiO1xuaW1wb3J0IHsgZ2V0LCBoYXMsIHNldCB9IGZyb20gXCJlcy10b29sa2l0L2NvbXBhdFwiO1xuaW1wb3J0IHtcbiAgY3JlYXRlVmFsaWRhdG9yLFxuICByZXNvbHZlTmFtZSxcbiAgdG9TaW1wbGVWYWxpZGF0aW9uRXJyb3JzXG59IGZyb20gXCJsYXJhdmVsLXByZWNvZ25pdGlvblwiO1xuaW1wb3J0IHsgcmVhY3RpdmUsIHdhdGNoIH0gZnJvbSBcInZ1ZVwiO1xuZnVuY3Rpb24gdXNlRm9ybVN0YXRlKG9wdGlvbnMpIHtcbiAgY29uc3QgeyBkYXRhOiBkYXRhT3B0aW9uLCByZW1lbWJlcktleSB9ID0gb3B0aW9ucztcbiAgbGV0IHsgcHJlY29nbml0aW9uRW5kcG9pbnQgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzRGF0YUZ1bmN0aW9uID0gdHlwZW9mIGRhdGFPcHRpb24gPT09IFwiZnVuY3Rpb25cIjtcbiAgY29uc3QgcmVzb2x2ZURhdGEgPSAoKSA9PiBpc0RhdGFGdW5jdGlvbiA/IGRhdGFPcHRpb24oKSA6IGRhdGFPcHRpb247XG4gIGNvbnN0IHJlc3RvcmVkID0gcmVtZW1iZXJLZXkgPyByb3V0ZXIyLnJlc3RvcmUocmVtZW1iZXJLZXkpIDogbnVsbDtcbiAgY29uc3QgaW5pdGlhbERhdGEgPSByZXN0b3JlZD8uZGF0YSA/PyBjbG9uZURlZXAyKHJlc29sdmVEYXRhKCkpO1xuICBsZXQgZGVmYXVsdHMgPSBjbG9uZURlZXAyKGluaXRpYWxEYXRhKTtcbiAgbGV0IHRyYW5zZm9ybSA9IChkYXRhKSA9PiBkYXRhO1xuICBsZXQgdmFsaWRhdG9yUmVmID0gbnVsbDtcbiAgbGV0IHdpdGhBbGxFcnJvcnMgPSBudWxsO1xuICBjb25zdCB3aXRoQWxsRXJyb3JzRW5hYmxlZCA9ICgpID0+IHdpdGhBbGxFcnJvcnMgPz8gY29uZmlnLmdldChcImZvcm0ud2l0aEFsbEVycm9yc1wiKTtcbiAgbGV0IHJlY2VudGx5U3VjY2Vzc2Z1bFRpbWVvdXRJZDtcbiAgbGV0IGRlZmF1bHRzQ2FsbGVkSW5PblN1Y2Nlc3MgPSBmYWxzZTtcbiAgbGV0IHJlbWVtYmVyRXhjbHVkZUtleXMgPSBbXTtcbiAgY29uc3QgZm9ybSA9IHJlYWN0aXZlKHtcbiAgICAuLi5jbG9uZURlZXAyKGRlZmF1bHRzKSxcbiAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICBlcnJvcnM6IHt9LFxuICAgIGhhc0Vycm9yczogZmFsc2UsXG4gICAgcHJvY2Vzc2luZzogZmFsc2UsXG4gICAgcHJvZ3Jlc3M6IG51bGwsXG4gICAgd2FzU3VjY2Vzc2Z1bDogZmFsc2UsXG4gICAgcmVjZW50bHlTdWNjZXNzZnVsOiBmYWxzZSxcbiAgICB3aXRoUHJlY29nbml0aW9uKC4uLmFyZ3MpIHtcbiAgICAgIHByZWNvZ25pdGlvbkVuZHBvaW50ID0gVXNlRm9ybVV0aWxzLmNyZWF0ZVdheWZpbmRlckNhbGxiYWNrKC4uLmFyZ3MpO1xuICAgICAgY29uc3QgZm9ybVdpdGhQcmVjb2duaXRpb24gPSB0aGlzO1xuICAgICAgY29uc3QgdmFsaWRhdG9yID0gY3JlYXRlVmFsaWRhdG9yKFxuICAgICAgICAoY2xpZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgeyBtZXRob2QsIHVybCB9ID0gcHJlY29nbml0aW9uRW5kcG9pbnQoKTtcbiAgICAgICAgICBjb25zdCB0cmFuc2Zvcm1lZERhdGEgPSBjbG9uZURlZXAyKHRyYW5zZm9ybSh0aGlzLmRhdGEoKSkpO1xuICAgICAgICAgIHJldHVybiBjbGllbnRbbWV0aG9kXSh1cmwsIHRyYW5zZm9ybWVkRGF0YSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNsb25lRGVlcDIoZGVmYXVsdHMpXG4gICAgICApO1xuICAgICAgdmFsaWRhdG9yUmVmID0gdmFsaWRhdG9yO1xuICAgICAgdmFsaWRhdG9yLm9uKFwidmFsaWRhdGluZ0NoYW5nZWRcIiwgKCkgPT4ge1xuICAgICAgICBmb3JtV2l0aFByZWNvZ25pdGlvbi52YWxpZGF0aW5nID0gdmFsaWRhdG9yLnZhbGlkYXRpbmcoKTtcbiAgICAgIH0pLm9uKFwidmFsaWRhdGVkQ2hhbmdlZFwiLCAoKSA9PiB7XG4gICAgICAgIGZvcm1XaXRoUHJlY29nbml0aW9uLl9fdmFsaWQgPSB2YWxpZGF0b3IudmFsaWQoKTtcbiAgICAgIH0pLm9uKFwidG91Y2hlZENoYW5nZWRcIiwgKCkgPT4ge1xuICAgICAgICBmb3JtV2l0aFByZWNvZ25pdGlvbi5fX3RvdWNoZWQgPSB2YWxpZGF0b3IudG91Y2hlZCgpO1xuICAgICAgfSkub24oXCJlcnJvcnNDaGFuZ2VkXCIsICgpID0+IHtcbiAgICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9ycyA9IHdpdGhBbGxFcnJvcnNFbmFibGVkKCkgPyB2YWxpZGF0b3IuZXJyb3JzKCkgOiB0b1NpbXBsZVZhbGlkYXRpb25FcnJvcnModmFsaWRhdG9yLmVycm9ycygpKTtcbiAgICAgICAgdGhpcy5lcnJvcnMgPSB7fTtcbiAgICAgICAgdGhpcy5zZXRFcnJvcih2YWxpZGF0aW9uRXJyb3JzKTtcbiAgICAgICAgZm9ybVdpdGhQcmVjb2duaXRpb24uX192YWxpZCA9IHZhbGlkYXRvci52YWxpZCgpO1xuICAgICAgfSk7XG4gICAgICBjb25zdCB0YXAgPSAodmFsdWUsIGNhbGxiYWNrKSA9PiB7XG4gICAgICAgIGNhbGxiYWNrKHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfTtcbiAgICAgIE9iamVjdC5hc3NpZ24oZm9ybVdpdGhQcmVjb2duaXRpb24sIHtcbiAgICAgICAgX190b3VjaGVkOiBbXSxcbiAgICAgICAgX192YWxpZDogW10sXG4gICAgICAgIHZhbGlkYXRpbmc6IGZhbHNlLFxuICAgICAgICB2YWxpZGF0b3I6ICgpID0+IHZhbGlkYXRvcixcbiAgICAgICAgd2l0aEFsbEVycm9yczogKCkgPT4gdGFwKGZvcm1XaXRoUHJlY29nbml0aW9uLCAoKSA9PiB3aXRoQWxsRXJyb3JzID0gdHJ1ZSksXG4gICAgICAgIHZhbGlkOiAoZmllbGQpID0+IGZvcm1XaXRoUHJlY29nbml0aW9uLl9fdmFsaWQuaW5jbHVkZXMoZmllbGQpLFxuICAgICAgICBpbnZhbGlkOiAoZmllbGQpID0+IGZpZWxkIGluIHRoaXMuZXJyb3JzLFxuICAgICAgICBzZXRWYWxpZGF0aW9uVGltZW91dDogKGR1cmF0aW9uKSA9PiB0YXAoZm9ybVdpdGhQcmVjb2duaXRpb24sICgpID0+IHZhbGlkYXRvci5zZXRUaW1lb3V0KGR1cmF0aW9uKSksXG4gICAgICAgIHZhbGlkYXRlRmlsZXM6ICgpID0+IHRhcChmb3JtV2l0aFByZWNvZ25pdGlvbiwgKCkgPT4gdmFsaWRhdG9yLnZhbGlkYXRlRmlsZXMoKSksXG4gICAgICAgIHdpdGhvdXRGaWxlVmFsaWRhdGlvbjogKCkgPT4gdGFwKGZvcm1XaXRoUHJlY29nbml0aW9uLCAoKSA9PiB2YWxpZGF0b3Iud2l0aG91dEZpbGVWYWxpZGF0aW9uKCkpLFxuICAgICAgICB0b3VjaDogKGZpZWxkLCAuLi5maWVsZHMpID0+IHtcbiAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShmaWVsZCkpIHtcbiAgICAgICAgICAgIHZhbGlkYXRvci50b3VjaChmaWVsZCk7XG4gICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgZmllbGQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgIHZhbGlkYXRvci50b3VjaChbZmllbGQsIC4uLmZpZWxkc10pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YWxpZGF0b3IudG91Y2goZmllbGQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZm9ybVdpdGhQcmVjb2duaXRpb247XG4gICAgICAgIH0sXG4gICAgICAgIHRvdWNoZWQ6IChmaWVsZCkgPT4gdHlwZW9mIGZpZWxkID09PSBcInN0cmluZ1wiID8gZm9ybVdpdGhQcmVjb2duaXRpb24uX190b3VjaGVkLmluY2x1ZGVzKGZpZWxkKSA6IGZvcm1XaXRoUHJlY29nbml0aW9uLl9fdG91Y2hlZC5sZW5ndGggPiAwLFxuICAgICAgICB2YWxpZGF0ZTogKGZpZWxkLCBjb25maWczKSA9PiB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBmaWVsZCA9PT0gXCJvYmplY3RcIiAmJiAhKFwidGFyZ2V0XCIgaW4gZmllbGQpKSB7XG4gICAgICAgICAgICBjb25maWczID0gZmllbGQ7XG4gICAgICAgICAgICBmaWVsZCA9IHZvaWQgMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGZpZWxkID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgIHZhbGlkYXRvci52YWxpZGF0ZShjb25maWczKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZmllbGROYW1lID0gcmVzb2x2ZU5hbWUoZmllbGQpO1xuICAgICAgICAgICAgY29uc3QgdHJhbnNmb3JtZWREYXRhID0gdHJhbnNmb3JtKHRoaXMuZGF0YSgpKTtcbiAgICAgICAgICAgIHZhbGlkYXRvci52YWxpZGF0ZShmaWVsZE5hbWUsIGdldCh0cmFuc2Zvcm1lZERhdGEsIGZpZWxkTmFtZSksIGNvbmZpZzMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZm9ybVdpdGhQcmVjb2duaXRpb247XG4gICAgICAgIH0sXG4gICAgICAgIHNldEVycm9yczogKGVycm9ycykgPT4gdGFwKGZvcm1XaXRoUHJlY29nbml0aW9uLCAoKSA9PiB0aGlzLnNldEVycm9yKGVycm9ycykpLFxuICAgICAgICBmb3JnZXRFcnJvcjogKGZpZWxkKSA9PiB0YXAoXG4gICAgICAgICAgZm9ybVdpdGhQcmVjb2duaXRpb24sXG4gICAgICAgICAgKCkgPT4gdGhpcy5jbGVhckVycm9ycyhyZXNvbHZlTmFtZShmaWVsZCkpXG4gICAgICAgIClcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGZvcm1XaXRoUHJlY29nbml0aW9uO1xuICAgIH0sXG4gICAgZGF0YSgpIHtcbiAgICAgIHJldHVybiBPYmplY3Qua2V5cyhkZWZhdWx0cykucmVkdWNlKChjYXJyeSwga2V5MikgPT4ge1xuICAgICAgICByZXR1cm4gc2V0KGNhcnJ5LCBrZXkyLCBnZXQodGhpcywga2V5MikpO1xuICAgICAgfSwge30pO1xuICAgIH0sXG4gICAgdHJhbnNmb3JtKGNhbGxiYWNrKSB7XG4gICAgICB0cmFuc2Zvcm0gPSBjYWxsYmFjaztcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH0sXG4gICAgZGVmYXVsdHMoZmllbGRPckZpZWxkcywgbWF5YmVWYWx1ZSkge1xuICAgICAgaWYgKGlzRGF0YUZ1bmN0aW9uKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIllvdSBjYW5ub3QgY2FsbCBgZGVmYXVsdHMoKWAgd2hlbiB1c2luZyBhIGZ1bmN0aW9uIHRvIGRlZmluZSB5b3VyIGZvcm0gZGF0YS5cIik7XG4gICAgICB9XG4gICAgICBkZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzID0gdHJ1ZTtcbiAgICAgIGlmICh0eXBlb2YgZmllbGRPckZpZWxkcyA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBkZWZhdWx0cyA9IGNsb25lRGVlcDIodGhpcy5kYXRhKCkpO1xuICAgICAgICB0aGlzLmlzRGlydHkgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRlZmF1bHRzID0gdHlwZW9mIGZpZWxkT3JGaWVsZHMgPT09IFwic3RyaW5nXCIgPyBzZXQoY2xvbmVEZWVwMihkZWZhdWx0cyksIGZpZWxkT3JGaWVsZHMsIG1heWJlVmFsdWUpIDogT2JqZWN0LmFzc2lnbih7fSwgY2xvbmVEZWVwMihkZWZhdWx0cyksIGZpZWxkT3JGaWVsZHMpO1xuICAgICAgfVxuICAgICAgdmFsaWRhdG9yUmVmPy5kZWZhdWx0cyhkZWZhdWx0cyk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuICAgIHJlc2V0KC4uLmZpZWxkcykge1xuICAgICAgY29uc3QgcmVzb2x2ZWREYXRhID0gaXNEYXRhRnVuY3Rpb24gPyBjbG9uZURlZXAyKHJlc29sdmVEYXRhKCkpIDogZGVmYXVsdHM7XG4gICAgICBjb25zdCBjbG9uZWREYXRhID0gY2xvbmVEZWVwMihyZXNvbHZlZERhdGEpO1xuICAgICAgaWYgKGZpZWxkcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgaWYgKGlzRGF0YUZ1bmN0aW9uKSB7XG4gICAgICAgICAgZGVmYXVsdHMgPSBjbG9uZWREYXRhO1xuICAgICAgICB9XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcywgY2xvbmVkRGF0YSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICA7XG4gICAgICAgIGZpZWxkcy5maWx0ZXIoKGtleTIpID0+IGhhcyhjbG9uZWREYXRhLCBrZXkyKSkuZm9yRWFjaCgoa2V5MikgPT4ge1xuICAgICAgICAgIGlmIChpc0RhdGFGdW5jdGlvbikge1xuICAgICAgICAgICAgc2V0KGRlZmF1bHRzLCBrZXkyLCBnZXQoY2xvbmVkRGF0YSwga2V5MikpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBzZXQodGhpcywga2V5MiwgZ2V0KGNsb25lZERhdGEsIGtleTIpKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB2YWxpZGF0b3JSZWY/LnJlc2V0KC4uLmZpZWxkcyk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuICAgIHNldEVycm9yKGZpZWxkT3JGaWVsZHMsIG1heWJlVmFsdWUpIHtcbiAgICAgIGNvbnN0IGVycm9ycyA9IHR5cGVvZiBmaWVsZE9yRmllbGRzID09PSBcInN0cmluZ1wiID8geyBbZmllbGRPckZpZWxkc106IG1heWJlVmFsdWUgfSA6IGZpZWxkT3JGaWVsZHM7XG4gICAgICBPYmplY3QuYXNzaWduKHRoaXMuZXJyb3JzLCBlcnJvcnMpO1xuICAgICAgdGhpcy5oYXNFcnJvcnMgPSBPYmplY3Qua2V5cyh0aGlzLmVycm9ycykubGVuZ3RoID4gMDtcbiAgICAgIHZhbGlkYXRvclJlZj8uc2V0RXJyb3JzKGVycm9ycyk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuICAgIGNsZWFyRXJyb3JzKC4uLmZpZWxkcykge1xuICAgICAgdGhpcy5lcnJvcnMgPSBPYmplY3Qua2V5cyh0aGlzLmVycm9ycykucmVkdWNlKFxuICAgICAgICAoY2FycnksIGZpZWxkKSA9PiAoe1xuICAgICAgICAgIC4uLmNhcnJ5LFxuICAgICAgICAgIC4uLmZpZWxkcy5sZW5ndGggPiAwICYmICFmaWVsZHMuaW5jbHVkZXMoZmllbGQpID8geyBbZmllbGRdOiB0aGlzLmVycm9yc1tmaWVsZF0gfSA6IHt9XG4gICAgICAgIH0pLFxuICAgICAgICB7fVxuICAgICAgKTtcbiAgICAgIHRoaXMuaGFzRXJyb3JzID0gT2JqZWN0LmtleXModGhpcy5lcnJvcnMpLmxlbmd0aCA+IDA7XG4gICAgICBpZiAodmFsaWRhdG9yUmVmKSB7XG4gICAgICAgIGlmIChmaWVsZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgdmFsaWRhdG9yUmVmLnNldEVycm9ycyh7fSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZmllbGRzLmZvckVhY2godmFsaWRhdG9yUmVmLmZvcmdldEVycm9yKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfSxcbiAgICByZXNldEFuZENsZWFyRXJyb3JzKC4uLmZpZWxkcykge1xuICAgICAgdGhpcy5yZXNldCguLi5maWVsZHMpO1xuICAgICAgdGhpcy5jbGVhckVycm9ycyguLi5maWVsZHMpO1xuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfSxcbiAgICBfX3JlbWVtYmVyYWJsZTogcmVtZW1iZXJLZXkgPT09IG51bGwsXG4gICAgX19yZW1lbWJlcigpIHtcbiAgICAgIGNvbnN0IGZvcm1EYXRhID0gdGhpcy5kYXRhKCk7XG4gICAgICBpZiAocmVtZW1iZXJFeGNsdWRlS2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IGZpbHRlcmVkID0geyAuLi5mb3JtRGF0YSB9O1xuICAgICAgICByZW1lbWJlckV4Y2x1ZGVLZXlzLmZvckVhY2goKGspID0+IGRlbGV0ZSBmaWx0ZXJlZFtrXSk7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IGZpbHRlcmVkLCBlcnJvcnM6IHRoaXMuZXJyb3JzIH07XG4gICAgICB9XG4gICAgICByZXR1cm4geyBkYXRhOiBmb3JtRGF0YSwgZXJyb3JzOiB0aGlzLmVycm9ycyB9O1xuICAgIH0sXG4gICAgX19yZXN0b3JlKHJlc3RvcmVkMikge1xuICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLCByZXN0b3JlZDIuZGF0YSk7XG4gICAgICB0aGlzLnNldEVycm9yKHJlc3RvcmVkMi5lcnJvcnMpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHR5cGVkRm9ybSA9IGZvcm07XG4gIGlmIChyZXN0b3JlZD8uZXJyb3JzKSB7XG4gICAgdHlwZWRGb3JtLnNldEVycm9yKHJlc3RvcmVkLmVycm9ycyk7XG4gIH1cbiAgd2F0Y2goXG4gICAgdHlwZWRGb3JtLFxuICAgICgpID0+IHtcbiAgICAgIHR5cGVkRm9ybS5pc0RpcnR5ID0gIWlzRXF1YWwodHlwZWRGb3JtLmRhdGEoKSwgZGVmYXVsdHMpO1xuICAgIH0sXG4gICAgeyBpbW1lZGlhdGU6IHRydWUsIGRlZXA6IHRydWUgfVxuICApO1xuICB3YXRjaChcbiAgICB0eXBlZEZvcm0sXG4gICAgKG5ld1ZhbHVlKSA9PiB7XG4gICAgICBpZiAoIXJlbWVtYmVyS2V5KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHN0b3JlZERhdGEgPSByb3V0ZXIyLnJlc3RvcmUocmVtZW1iZXJLZXkpO1xuICAgICAgY29uc3QgbmV3RGF0YSA9IGNsb25lRGVlcDIobmV3VmFsdWUuX19yZW1lbWJlcigpKTtcbiAgICAgIGlmICghaXNFcXVhbChzdG9yZWREYXRhLCBuZXdEYXRhKSkge1xuICAgICAgICByb3V0ZXIyLnJlbWVtYmVyKG5ld0RhdGEsIHJlbWVtYmVyS2V5KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlLCBkZWVwOiB0cnVlIH1cbiAgKTtcbiAgaWYgKHByZWNvZ25pdGlvbkVuZHBvaW50KSB7XG4gICAgdHlwZWRGb3JtLndpdGhQcmVjb2duaXRpb24ocHJlY29nbml0aW9uRW5kcG9pbnQpO1xuICB9XG4gIHJldHVybiB7XG4gICAgZm9ybTogdHlwZWRGb3JtLFxuICAgIHNldERlZmF1bHRzOiAobmV3RGVmYXVsdHMpID0+IHtcbiAgICAgIGRlZmF1bHRzID0gbmV3RGVmYXVsdHM7XG4gICAgfSxcbiAgICBnZXRUcmFuc2Zvcm06ICgpID0+IHRyYW5zZm9ybSxcbiAgICBnZXRQcmVjb2duaXRpb25FbmRwb2ludDogKCkgPT4gcHJlY29nbml0aW9uRW5kcG9pbnQgPz8gbnVsbCxcbiAgICBtYXJrQXNTdWNjZXNzZnVsOiAoKSA9PiB7XG4gICAgICB0eXBlZEZvcm0uY2xlYXJFcnJvcnMoKTtcbiAgICAgIHR5cGVkRm9ybS53YXNTdWNjZXNzZnVsID0gdHJ1ZTtcbiAgICAgIHR5cGVkRm9ybS5yZWNlbnRseVN1Y2Nlc3NmdWwgPSB0cnVlO1xuICAgICAgcmVjZW50bHlTdWNjZXNzZnVsVGltZW91dElkID0gc2V0VGltZW91dChcbiAgICAgICAgKCkgPT4gdHlwZWRGb3JtLnJlY2VudGx5U3VjY2Vzc2Z1bCA9IGZhbHNlLFxuICAgICAgICBjb25maWcuZ2V0KFwiZm9ybS5yZWNlbnRseVN1Y2Nlc3NmdWxEdXJhdGlvblwiKVxuICAgICAgKTtcbiAgICB9LFxuICAgIHdhc0RlZmF1bHRzQ2FsbGVkSW5PblN1Y2Nlc3M6ICgpID0+IGRlZmF1bHRzQ2FsbGVkSW5PblN1Y2Nlc3MsXG4gICAgcmVzZXREZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzOiAoKSA9PiB7XG4gICAgICBkZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzID0gZmFsc2U7XG4gICAgfSxcbiAgICBzZXRSZW1lbWJlckV4Y2x1ZGVLZXlzOiAoa2V5cykgPT4ge1xuICAgICAgcmVtZW1iZXJFeGNsdWRlS2V5cyA9IGtleXM7XG4gICAgfSxcbiAgICByZXNldEJlZm9yZVN1Ym1pdDogKCkgPT4ge1xuICAgICAgdHlwZWRGb3JtLndhc1N1Y2Nlc3NmdWwgPSBmYWxzZTtcbiAgICAgIHR5cGVkRm9ybS5yZWNlbnRseVN1Y2Nlc3NmdWwgPSBmYWxzZTtcbiAgICAgIGNsZWFyVGltZW91dChyZWNlbnRseVN1Y2Nlc3NmdWxUaW1lb3V0SWQpO1xuICAgIH0sXG4gICAgZmluaXNoUHJvY2Vzc2luZzogKCkgPT4ge1xuICAgICAgdHlwZWRGb3JtLnByb2Nlc3NpbmcgPSBmYWxzZTtcbiAgICAgIHR5cGVkRm9ybS5wcm9ncmVzcyA9IG51bGw7XG4gICAgfSxcbiAgICB3aXRoQWxsRXJyb3JzOiB7XG4gICAgICBlbmFibGVkOiB3aXRoQWxsRXJyb3JzRW5hYmxlZCxcbiAgICAgIGVuYWJsZTogKCkgPT4ge1xuICAgICAgICB3aXRoQWxsRXJyb3JzID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIHNyYy91c2VGb3JtLnRzXG52YXIgcmVzZXJ2ZWRGb3JtS2V5cyA9IG51bGw7XG52YXIgYm9vdHN0cmFwcGluZyA9IGZhbHNlO1xuZnVuY3Rpb24gdmFsaWRhdGVGb3JtRGF0YUtleXMoZGF0YSkge1xuICBpZiAoYm9vdHN0cmFwcGluZykge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAocmVzZXJ2ZWRGb3JtS2V5cyA9PT0gbnVsbCkge1xuICAgIGJvb3RzdHJhcHBpbmcgPSB0cnVlO1xuICAgIHJlc2VydmVkRm9ybUtleXMgPSBuZXcgU2V0KE9iamVjdC5rZXlzKHVzZUZvcm0oe30pKSk7XG4gICAgYm9vdHN0cmFwcGluZyA9IGZhbHNlO1xuICB9XG4gIGNvbnN0IGNvbmZsaWN0cyA9IE9iamVjdC5rZXlzKGRhdGEpLmZpbHRlcigoa2V5MikgPT4gcmVzZXJ2ZWRGb3JtS2V5cy5oYXMoa2V5MikpO1xuICBpZiAoY29uZmxpY3RzLmxlbmd0aCA+IDApIHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgYFtJbmVydGlhXSB1c2VGb3JtKCkgZGF0YSBjb250YWlucyBmaWVsZChzKSB0aGF0IGNvbmZsaWN0IHdpdGggZm9ybSBwcm9wZXJ0aWVzOiAke2NvbmZsaWN0cy5tYXAoKGspID0+IGBcIiR7a31cImApLmpvaW4oXCIsIFwiKX0uIFRoZXNlIGZpZWxkcyB3aWxsIGJlIG92ZXJ3cml0dGVuIGJ5IGZvcm0gbWV0aG9kcy9wcm9wZXJ0aWVzLiBQbGVhc2UgcmVuYW1lIHRoZXNlIGZpZWxkcy5gXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gdXNlRm9ybSguLi5hcmdzKSB7XG4gIGNvbnN0IHsgcmVtZW1iZXJLZXksIGRhdGEsIHByZWNvZ25pdGlvbkVuZHBvaW50IH0gPSBVc2VGb3JtVXRpbHMyLnBhcnNlVXNlRm9ybUFyZ3VtZW50cyguLi5hcmdzKTtcbiAgY29uc3QgaW5pdGlhbERlZmF1bHRzID0gdHlwZW9mIGRhdGEgPT09IFwiZnVuY3Rpb25cIiA/IGNsb25lRGVlcDMoZGF0YSgpKSA6IGNsb25lRGVlcDMoZGF0YSk7XG4gIHZhbGlkYXRlRm9ybURhdGFLZXlzKGluaXRpYWxEZWZhdWx0cyk7XG4gIGxldCBjYW5jZWxUb2tlbiA9IG51bGw7XG4gIGxldCBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID0gbnVsbDtcbiAgY29uc3Qge1xuICAgIGZvcm06IGJhc2VGb3JtLFxuICAgIHNldERlZmF1bHRzLFxuICAgIGdldFRyYW5zZm9ybSxcbiAgICBnZXRQcmVjb2duaXRpb25FbmRwb2ludCxcbiAgICBtYXJrQXNTdWNjZXNzZnVsLFxuICAgIHdhc0RlZmF1bHRzQ2FsbGVkSW5PblN1Y2Nlc3MsXG4gICAgcmVzZXREZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzLFxuICAgIHNldFJlbWVtYmVyRXhjbHVkZUtleXMsXG4gICAgcmVzZXRCZWZvcmVTdWJtaXQsXG4gICAgZmluaXNoUHJvY2Vzc2luZ1xuICB9ID0gdXNlRm9ybVN0YXRlKHtcbiAgICBkYXRhLFxuICAgIHJlbWVtYmVyS2V5LFxuICAgIHByZWNvZ25pdGlvbkVuZHBvaW50XG4gIH0pO1xuICBjb25zdCBmb3JtID0gYmFzZUZvcm07XG4gIGNvbnN0IGNyZWF0ZVN1Ym1pdE1ldGhvZCA9IChtZXRob2QpID0+ICh1cmwsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgIGZvcm0uc3VibWl0KG1ldGhvZCwgdXJsLCBvcHRpb25zKTtcbiAgfTtcbiAgT2JqZWN0LmFzc2lnbihmb3JtLCB7XG4gICAgc3VibWl0KC4uLmFyZ3MyKSB7XG4gICAgICBjb25zdCB7IG1ldGhvZCwgdXJsLCBvcHRpb25zIH0gPSBVc2VGb3JtVXRpbHMyLnBhcnNlU3VibWl0QXJndW1lbnRzKGFyZ3MyLCBnZXRQcmVjb2duaXRpb25FbmRwb2ludCgpKTtcbiAgICAgIHJlc2V0RGVmYXVsdHNDYWxsZWRJbk9uU3VjY2VzcygpO1xuICAgICAgY29uc3QgX29wdGlvbnMgPSB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIG9uQ2FuY2VsVG9rZW46ICh0b2tlbikgPT4ge1xuICAgICAgICAgIGNhbmNlbFRva2VuID0gdG9rZW47XG4gICAgICAgICAgcmV0dXJuIG9wdGlvbnMub25DYW5jZWxUb2tlbj8uKHRva2VuKTtcbiAgICAgICAgfSxcbiAgICAgICAgb25CZWZvcmU6ICh2aXNpdCkgPT4ge1xuICAgICAgICAgIHJlc2V0QmVmb3JlU3VibWl0KCk7XG4gICAgICAgICAgcmV0dXJuIG9wdGlvbnMub25CZWZvcmU/Lih2aXNpdCk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uU3RhcnQ6ICh2aXNpdCkgPT4ge1xuICAgICAgICAgIGZvcm0ucHJvY2Vzc2luZyA9IHRydWU7XG4gICAgICAgICAgcmV0dXJuIG9wdGlvbnMub25TdGFydD8uKHZpc2l0KTtcbiAgICAgICAgfSxcbiAgICAgICAgb25Qcm9ncmVzczogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgZm9ybS5wcm9ncmVzcyA9IGV2ZW50ID8/IG51bGw7XG4gICAgICAgICAgcmV0dXJuIG9wdGlvbnMub25Qcm9ncmVzcz8uKGV2ZW50KTtcbiAgICAgICAgfSxcbiAgICAgICAgb25TdWNjZXNzOiBhc3luYyAocGFnZTIpID0+IHtcbiAgICAgICAgICBtYXJrQXNTdWNjZXNzZnVsKCk7XG4gICAgICAgICAgY29uc3Qgb25TdWNjZXNzID0gb3B0aW9ucy5vblN1Y2Nlc3MgPyBhd2FpdCBvcHRpb25zLm9uU3VjY2VzcyhwYWdlMikgOiBudWxsO1xuICAgICAgICAgIGlmICghd2FzRGVmYXVsdHNDYWxsZWRJbk9uU3VjY2VzcygpKSB7XG4gICAgICAgICAgICBzZXREZWZhdWx0cyhjbG9uZURlZXAzKGZvcm0uZGF0YSgpKSk7XG4gICAgICAgICAgICBmb3JtLmlzRGlydHkgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG9uU3VjY2VzcztcbiAgICAgICAgfSxcbiAgICAgICAgb25FcnJvcjogKGVycm9ycykgPT4ge1xuICAgICAgICAgIGZvcm0uY2xlYXJFcnJvcnMoKS5zZXRFcnJvcihlcnJvcnMpO1xuICAgICAgICAgIHJldHVybiBvcHRpb25zLm9uRXJyb3I/LihlcnJvcnMpO1xuICAgICAgICB9LFxuICAgICAgICBvbkNhbmNlbDogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiBvcHRpb25zLm9uQ2FuY2VsPy4oKTtcbiAgICAgICAgfSxcbiAgICAgICAgb25GaW5pc2g6ICh2aXNpdCkgPT4ge1xuICAgICAgICAgIGZpbmlzaFByb2Nlc3NpbmcoKTtcbiAgICAgICAgICBjYW5jZWxUb2tlbiA9IG51bGw7XG4gICAgICAgICAgcmV0dXJuIG9wdGlvbnMub25GaW5pc2g/Lih2aXNpdCk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBfb3B0aW9ucy5vcHRpbWlzdGljID0gX29wdGlvbnMub3B0aW1pc3RpYyA/PyBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID8/IHZvaWQgMDtcbiAgICAgIHBlbmRpbmdPcHRpbWlzdGljQ2FsbGJhY2sgPSBudWxsO1xuICAgICAgY29uc3QgdHJhbnNmb3JtZWREYXRhID0gZ2V0VHJhbnNmb3JtKCkoZm9ybS5kYXRhKCkpO1xuICAgICAgaWYgKG1ldGhvZCA9PT0gXCJkZWxldGVcIikge1xuICAgICAgICByb3V0ZXIzLmRlbGV0ZSh1cmwsIHsgLi4uX29wdGlvbnMsIGRhdGE6IHRyYW5zZm9ybWVkRGF0YSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJvdXRlcjNbbWV0aG9kXSh1cmwsIHRyYW5zZm9ybWVkRGF0YSwgX29wdGlvbnMpO1xuICAgICAgfVxuICAgIH0sXG4gICAgZ2V0OiBjcmVhdGVTdWJtaXRNZXRob2QoXCJnZXRcIiksXG4gICAgcG9zdDogY3JlYXRlU3VibWl0TWV0aG9kKFwicG9zdFwiKSxcbiAgICBwdXQ6IGNyZWF0ZVN1Ym1pdE1ldGhvZChcInB1dFwiKSxcbiAgICBwYXRjaDogY3JlYXRlU3VibWl0TWV0aG9kKFwicGF0Y2hcIiksXG4gICAgZGVsZXRlOiBjcmVhdGVTdWJtaXRNZXRob2QoXCJkZWxldGVcIiksXG4gICAgY2FuY2VsKCkge1xuICAgICAgaWYgKGNhbmNlbFRva2VuKSB7XG4gICAgICAgIGNhbmNlbFRva2VuLmNhbmNlbCgpO1xuICAgICAgfVxuICAgIH0sXG4gICAgZG9udFJlbWVtYmVyKC4uLmtleXMpIHtcbiAgICAgIHNldFJlbWVtYmVyRXhjbHVkZUtleXMoa2V5cyk7XG4gICAgICByZXR1cm4gZm9ybTtcbiAgICB9LFxuICAgIG9wdGltaXN0aWMoY2FsbGJhY2spIHtcbiAgICAgIHBlbmRpbmdPcHRpbWlzdGljQ2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICAgIHJldHVybiBmb3JtO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBnZXRQcmVjb2duaXRpb25FbmRwb2ludCgpID8gZm9ybSA6IGZvcm07XG59XG5cbi8vIHNyYy9hcHAudHNcbmZ1bmN0aW9uIGlzQ29tcG9uZW50KHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIikge1xuICAgIGNvbnN0IG9iaiA9IHZhbHVlO1xuICAgIHJldHVybiB0eXBlb2Ygb2JqLnJlbmRlciA9PT0gXCJmdW5jdGlvblwiIHx8IHR5cGVvZiBvYmouc2V0dXAgPT09IFwiZnVuY3Rpb25cIiB8fCB0eXBlb2Ygb2JqLnRlbXBsYXRlID09PSBcInN0cmluZ1wiIHx8IFwiX19maWxlXCIgaW4gb2JqIHx8IFwiX19uYW1lXCIgaW4gb2JqO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzUmVuZGVyRnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IGZuID0gdmFsdWU7XG4gIHJldHVybiBmbi5sZW5ndGggPT09IDIgJiYgdHlwZW9mIGZuLnByb3RvdHlwZSA9PT0gXCJ1bmRlZmluZWRcIjtcbn1cbnZhciBjb21wb25lbnQgPSByZWYyKHZvaWQgMCk7XG52YXIgcGFnZSA9IHJlZjIoKTtcbnZhciBwYWdlQWNjZXNzb3IgPSBudWxsO1xudmFyIGxheW91dCA9IHNoYWxsb3dSZWYobnVsbCk7XG52YXIga2V5ID0gcmVmMih2b2lkIDApO1xudmFyIGhlYWRNYW5hZ2VyO1xudmFyIEFwcCA9IGRlZmluZUNvbXBvbmVudCh7XG4gIG5hbWU6IFwiSW5lcnRpYVwiLFxuICBwcm9wczoge1xuICAgIGluaXRpYWxQYWdlOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICByZXF1aXJlZDogdHJ1ZVxuICAgIH0sXG4gICAgaW5pdGlhbENvbXBvbmVudDoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgcmVxdWlyZWQ6IGZhbHNlXG4gICAgfSxcbiAgICByZXNvbHZlQ29tcG9uZW50OiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIHJlcXVpcmVkOiBmYWxzZVxuICAgIH0sXG4gICAgdGl0bGVDYWxsYmFjazoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICByZXF1aXJlZDogZmFsc2UsXG4gICAgICBkZWZhdWx0OiAodGl0bGUpID0+IHRpdGxlXG4gICAgfSxcbiAgICBvbkhlYWRVcGRhdGU6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgcmVxdWlyZWQ6IGZhbHNlLFxuICAgICAgZGVmYXVsdDogKCkgPT4gKCkgPT4ge1xuICAgICAgfVxuICAgIH0sXG4gICAgZGVmYXVsdExheW91dDoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICByZXF1aXJlZDogZmFsc2VcbiAgICB9LFxuICAgIHNlcnZlckhlYWQ6IHtcbiAgICAgIHR5cGU6IFtCb29sZWFuLCBTdHJpbmcsIEZ1bmN0aW9uXSxcbiAgICAgIHJlcXVpcmVkOiBmYWxzZVxuICAgIH1cbiAgfSxcbiAgc2V0dXAoe1xuICAgIGluaXRpYWxQYWdlLFxuICAgIGluaXRpYWxDb21wb25lbnQsXG4gICAgcmVzb2x2ZUNvbXBvbmVudCxcbiAgICB0aXRsZUNhbGxiYWNrLFxuICAgIG9uSGVhZFVwZGF0ZSxcbiAgICBkZWZhdWx0TGF5b3V0LFxuICAgIHNlcnZlckhlYWRcbiAgfSkge1xuICAgIGNvbXBvbmVudC52YWx1ZSA9IGluaXRpYWxDb21wb25lbnQgPyBtYXJrUmF3KGluaXRpYWxDb21wb25lbnQpIDogdm9pZCAwO1xuICAgIHBhZ2UudmFsdWUgPSB7IC4uLmluaXRpYWxQYWdlLCBmbGFzaDogaW5pdGlhbFBhZ2UuZmxhc2ggPz8ge30gfTtcbiAgICBrZXkudmFsdWUgPSB2b2lkIDA7XG4gICAgY29uc3QgaXNTZXJ2ZXIgPSB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiO1xuICAgIGhlYWRNYW5hZ2VyID0gY3JlYXRlSGVhZE1hbmFnZXIoXG4gICAgICBpc1NlcnZlcixcbiAgICAgICh0aXRsZSkgPT4gdGl0bGVDYWxsYmFjayA/IHRpdGxlQ2FsbGJhY2sodGl0bGUsIHBhZ2UudmFsdWUpIDogdGl0bGUsXG4gICAgICBvbkhlYWRVcGRhdGUgfHwgKCgpID0+IHtcbiAgICAgIH0pLFxuICAgICAgcmVzb2x2ZVNlcnZlckhlYWQoaW5pdGlhbFBhZ2UsIHNlcnZlckhlYWQpXG4gICAgKTtcbiAgICBpZiAoIWlzU2VydmVyKSB7XG4gICAgICByb3V0ZXI0LmluaXQoe1xuICAgICAgICBpbml0aWFsUGFnZSxcbiAgICAgICAgcmVzb2x2ZUNvbXBvbmVudCxcbiAgICAgICAgc3dhcENvbXBvbmVudDogYXN5bmMgKG9wdGlvbnMpID0+IHtcbiAgICAgICAgICBpZiAoIW9wdGlvbnMucHJlc2VydmVTdGF0ZSkge1xuICAgICAgICAgICAgcmVzZXRMYXlvdXRQcm9wcygpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb21wb25lbnQudmFsdWUgPSBtYXJrUmF3KG9wdGlvbnMuY29tcG9uZW50KTtcbiAgICAgICAgICBwYWdlLnZhbHVlID0gb3B0aW9ucy5wYWdlO1xuICAgICAgICAgIGtleS52YWx1ZSA9IG9wdGlvbnMucHJlc2VydmVTdGF0ZSA/IGtleS52YWx1ZSA6IERhdGUubm93KCk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uRmxhc2g6IChmbGFzaCkgPT4ge1xuICAgICAgICAgIHBhZ2UudmFsdWUgPSB7IC4uLnBhZ2UudmFsdWUsIGZsYXNoIH07XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgY29uc3Qgc3luY1NlcnZlckhlYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgaGVhZE1hbmFnZXIudXBkYXRlU2VydmVySGVhZChyZXNvbHZlU2VydmVySGVhZChldmVudC5kZXRhaWwucGFnZSwgc2VydmVySGVhZCkpO1xuICAgICAgfTtcbiAgICAgIHJvdXRlcjQub24oXCJuYXZpZ2F0ZVwiLCBzeW5jU2VydmVySGVhZCk7XG4gICAgICByb3V0ZXI0Lm9uKFwiY2xpZW50VmlzaXRcIiwgc3luY1NlcnZlckhlYWQpO1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKGNvbXBvbmVudC52YWx1ZSkge1xuICAgICAgICBjb21wb25lbnQudmFsdWUuaW5oZXJpdEF0dHJzID0gISFjb21wb25lbnQudmFsdWUuaW5oZXJpdEF0dHJzO1xuICAgICAgICBjb25zdCBjaGlsZCA9IGgoY29tcG9uZW50LnZhbHVlLCB7XG4gICAgICAgICAgLi4ucGFnZS52YWx1ZS5wcm9wcyxcbiAgICAgICAgICBrZXk6IGtleS52YWx1ZVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGxheW91dC52YWx1ZSkge1xuICAgICAgICAgIGNvbXBvbmVudC52YWx1ZS5sYXlvdXQgPSBsYXlvdXQudmFsdWU7XG4gICAgICAgICAgbGF5b3V0LnZhbHVlID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29tcG9uZW50LnZhbHVlLmxheW91dCAmJiBpc1JlbmRlckZ1bmN0aW9uKGNvbXBvbmVudC52YWx1ZS5sYXlvdXQpKSB7XG4gICAgICAgICAgcmV0dXJuIGNvbXBvbmVudC52YWx1ZS5sYXlvdXQoaCwgY2hpbGQpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBlZmZlY3RpdmVMYXlvdXQ7XG4gICAgICAgIGxldCBjYWxsYmFja1Byb3BzID0gbnVsbDtcbiAgICAgICAgY29uc3QgbGF5b3V0VmFsdWUgPSBjb21wb25lbnQudmFsdWUubGF5b3V0O1xuICAgICAgICBpZiAodHlwZW9mIGxheW91dFZhbHVlID09PSBcImZ1bmN0aW9uXCIgJiYgbGF5b3V0VmFsdWUubGVuZ3RoIDw9IDEgJiYgdHlwZW9mIGxheW91dFZhbHVlLnByb3RvdHlwZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGxheW91dFZhbHVlKHBhZ2UudmFsdWUucHJvcHMpO1xuICAgICAgICAgIGlmIChpc1Byb3BzT2JqZWN0T3JDYWxsYmFjayhyZXN1bHQsIGlzQ29tcG9uZW50KSkge1xuICAgICAgICAgICAgZWZmZWN0aXZlTGF5b3V0ID0gZGVmYXVsdExheW91dD8uKHBhZ2UudmFsdWUuY29tcG9uZW50LCBwYWdlLnZhbHVlKTtcbiAgICAgICAgICAgIGNhbGxiYWNrUHJvcHMgPSByZXN1bHQ7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVmZmVjdGl2ZUxheW91dCA9IHJlc3VsdDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoaXNQcm9wc09iamVjdChsYXlvdXRWYWx1ZSwgaXNDb21wb25lbnQpKSB7XG4gICAgICAgICAgZWZmZWN0aXZlTGF5b3V0ID0gZGVmYXVsdExheW91dD8uKHBhZ2UudmFsdWUuY29tcG9uZW50LCBwYWdlLnZhbHVlKTtcbiAgICAgICAgICBjYWxsYmFja1Byb3BzID0gbGF5b3V0VmFsdWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZWZmZWN0aXZlTGF5b3V0ID0gbGF5b3V0VmFsdWUgPz8gZGVmYXVsdExheW91dD8uKHBhZ2UudmFsdWUuY29tcG9uZW50LCBwYWdlLnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZWZmZWN0aXZlTGF5b3V0KSB7XG4gICAgICAgICAgbGV0IGxheW91dHMgPSBub3JtYWxpemVMYXlvdXRzKFxuICAgICAgICAgICAgZWZmZWN0aXZlTGF5b3V0LFxuICAgICAgICAgICAgaXNDb21wb25lbnQsXG4gICAgICAgICAgICBjb21wb25lbnQudmFsdWUubGF5b3V0ICYmICFjYWxsYmFja1Byb3BzID8gaXNSZW5kZXJGdW5jdGlvbiA6IHZvaWQgMFxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKGNhbGxiYWNrUHJvcHMpIHtcbiAgICAgICAgICAgIGxheW91dHMgPSBsYXlvdXRzLm1hcCgobCkgPT4gKHsgLi4ubCwgcHJvcHM6IHsgLi4ubC5wcm9wcywgLi4uY2FsbGJhY2tQcm9wcyB9IH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGxheW91dHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgZHluYW1pY1Byb3BzID0gaXNTZXJ2ZXIgPyB7IHNoYXJlZDoge30sIG5hbWVkOiB7fSB9IDogc3RhdGUudmFsdWU7XG4gICAgICAgICAgICByZXR1cm4gbGF5b3V0cy5yZWR1Y2VSaWdodCgoY2hpbGROb2RlLCBsYXlvdXQyKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGxheW91dENvbXBvbmVudCA9IGxheW91dDIuY29tcG9uZW50O1xuICAgICAgICAgICAgICBsYXlvdXRDb21wb25lbnQuaW5oZXJpdEF0dHJzID0gISFsYXlvdXRDb21wb25lbnQuaW5oZXJpdEF0dHJzO1xuICAgICAgICAgICAgICByZXR1cm4gaChcbiAgICAgICAgICAgICAgICBsYXlvdXRDb21wb25lbnQsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgLi4ucGFnZS52YWx1ZS5wcm9wcyxcbiAgICAgICAgICAgICAgICAgIC4uLmxheW91dDIucHJvcHMsXG4gICAgICAgICAgICAgICAgICAuLi5keW5hbWljUHJvcHMuc2hhcmVkLFxuICAgICAgICAgICAgICAgICAgLi4ubGF5b3V0Mi5uYW1lID8gZHluYW1pY1Byb3BzLm5hbWVkW2xheW91dDIubmFtZV0gfHwge30gOiB7fVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgKCkgPT4gY2hpbGROb2RlXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9LCBjaGlsZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjaGlsZDtcbiAgICAgIH1cbiAgICB9O1xuICB9XG59KTtcbnZhciBhcHBfZGVmYXVsdCA9IEFwcDtcbnZhciBwbHVnaW4gPSB7XG4gIGluc3RhbGwoYXBwKSB7XG4gICAgcm91dGVyNC5mb3JtID0gdXNlRm9ybTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLCBcIiRpbmVydGlhXCIsIHsgZ2V0OiAoKSA9PiByb3V0ZXI0IH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhcHAuY29uZmlnLmdsb2JhbFByb3BlcnRpZXMsIFwiJHBhZ2VcIiwgeyBnZXQ6ICgpID0+IHBhZ2UudmFsdWUgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcywgXCIkaGVhZE1hbmFnZXJcIiwgeyBnZXQ6ICgpID0+IGhlYWRNYW5hZ2VyIH0pO1xuICAgIGFwcC5taXhpbihyZW1lbWJlcl9kZWZhdWx0KTtcbiAgfVxufTtcbmZ1bmN0aW9uIHVzZVBhZ2UoKSB7XG4gIGlmICghcGFnZUFjY2Vzc29yKSB7XG4gICAgcGFnZUFjY2Vzc29yID0gcmVhY3RpdmUyKHtcbiAgICAgIHByb3BzOiBjb21wdXRlZCgoKSA9PiBwYWdlLnZhbHVlPy5wcm9wcyksXG4gICAgICB1cmw6IGNvbXB1dGVkKCgpID0+IHBhZ2UudmFsdWU/LnVybCksXG4gICAgICBjb21wb25lbnQ6IGNvbXB1dGVkKCgpID0+IHBhZ2UudmFsdWU/LmNvbXBvbmVudCksXG4gICAgICB2ZXJzaW9uOiBjb21wdXRlZCgoKSA9PiBwYWdlLnZhbHVlPy52ZXJzaW9uKSxcbiAgICAgIGNsZWFySGlzdG9yeTogY29tcHV0ZWQoKCkgPT4gcGFnZS52YWx1ZT8uY2xlYXJIaXN0b3J5KSxcbiAgICAgIGRlZmVycmVkUHJvcHM6IGNvbXB1dGVkKCgpID0+IHBhZ2UudmFsdWU/LmRlZmVycmVkUHJvcHMpLFxuICAgICAgcmVzY3VlZFByb3BzOiBjb21wdXRlZCgoKSA9PiBwYWdlLnZhbHVlPy5yZXNjdWVkUHJvcHMpLFxuICAgICAgbWVyZ2VQcm9wczogY29tcHV0ZWQoKCkgPT4gcGFnZS52YWx1ZT8ubWVyZ2VQcm9wcyksXG4gICAgICBwcmVwZW5kUHJvcHM6IGNvbXB1dGVkKCgpID0+IHBhZ2UudmFsdWU/LnByZXBlbmRQcm9wcyksXG4gICAgICBkZWVwTWVyZ2VQcm9wczogY29tcHV0ZWQoKCkgPT4gcGFnZS52YWx1ZT8uZGVlcE1lcmdlUHJvcHMpLFxuICAgICAgbWF0Y2hQcm9wc09uOiBjb21wdXRlZCgoKSA9PiBwYWdlLnZhbHVlPy5tYXRjaFByb3BzT24pLFxuICAgICAgcmVtZW1iZXJlZFN0YXRlOiBjb21wdXRlZCgoKSA9PiBwYWdlLnZhbHVlPy5yZW1lbWJlcmVkU3RhdGUpLFxuICAgICAgZW5jcnlwdEhpc3Rvcnk6IGNvbXB1dGVkKCgpID0+IHBhZ2UudmFsdWU/LmVuY3J5cHRIaXN0b3J5KSxcbiAgICAgIHNjcm9sbFByb3BzOiBjb21wdXRlZCgoKSA9PiBwYWdlLnZhbHVlPy5zY3JvbGxQcm9wcyksXG4gICAgICBmbGFzaDogY29tcHV0ZWQoKCkgPT4gcGFnZS52YWx1ZT8uZmxhc2gpXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHBhZ2VBY2Nlc3Nvcjtcbn1cblxuLy8gc3JjL2NyZWF0ZUluZXJ0aWFBcHAudHNcbmltcG9ydCB7XG4gIGJ1aWxkU1NSQm9keSxcbiAgZXhwb3NlSW50ZXJjZXB0b3JzLFxuICBnZXRJbml0aWFsUGFnZUZyb21ET00sXG4gIGh0dHAgYXMgaHR0cE1vZHVsZSxcbiAgcm91dGVyIGFzIHJvdXRlcjUsXG4gIHNldHVwUHJvZ3Jlc3Ncbn0gZnJvbSBcIkBpbmVydGlhanMvY29yZVwiO1xuaW1wb3J0IHsgY3JlYXRlQXBwLCBjcmVhdGVTU1JBcHAsIGggYXMgaDIgfSBmcm9tIFwidnVlXCI7XG5hc3luYyBmdW5jdGlvbiBjcmVhdGVJbmVydGlhQXBwKHtcbiAgaWQgPSBcImFwcFwiLFxuICByZXNvbHZlLFxuICBzZXR1cCxcbiAgdGl0bGUsXG4gIHByb2dyZXNzOiBwcm9ncmVzczIgPSB7fSxcbiAgcGFnZTogcGFnZTIsXG4gIHJlbmRlcixcbiAgZGVmYXVsdHMgPSB7fSxcbiAgbm9uY2UsXG4gIGh0dHA6IGh0dHAzLFxuICBsYXlvdXQ6IGxheW91dDIsXG4gIHNlcnZlckhlYWQsXG4gIHdpdGhBcHAsXG4gIGRldiA9ICEhaW1wb3J0Lm1ldGEuZW52Py5ERVZcbn0gPSB7fSkge1xuICBjb25maWcucmVwbGFjZShkZWZhdWx0cyk7XG4gIGlmIChub25jZSkge1xuICAgIGNvbmZpZy5zZXQoXCJub25jZVwiLCBub25jZSk7XG4gIH1cbiAgaWYgKGh0dHAzKSB7XG4gICAgaHR0cE1vZHVsZS5zZXRDbGllbnQoaHR0cDMpO1xuICB9XG4gIGlmIChkZXYpIHtcbiAgICBleHBvc2VJbnRlcmNlcHRvcnMoKTtcbiAgfVxuICBjb25zdCBpc1NlcnZlciA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCI7XG4gIGNvbnN0IHJlc29sdmVDb21wb25lbnQgPSAobmFtZSwgcGFnZTMpID0+IFByb21pc2UucmVzb2x2ZShyZXNvbHZlKG5hbWUsIHBhZ2UzKSkudGhlbigobW9kdWxlKSA9PiBtb2R1bGUuZGVmYXVsdCB8fCBtb2R1bGUpO1xuICBpZiAoaXNTZXJ2ZXIgJiYgIXBhZ2UyICYmICFyZW5kZXIpIHtcbiAgICByZXR1cm4gYXN5bmMgKHBhZ2UzLCByZW5kZXJUb1N0cmluZykgPT4ge1xuICAgICAgbGV0IGhlYWQyID0gW107XG4gICAgICBjb25zdCBpbml0aWFsQ29tcG9uZW50ID0gYXdhaXQgcmVzb2x2ZUNvbXBvbmVudChwYWdlMy5jb21wb25lbnQsIHBhZ2UzKTtcbiAgICAgIGNvbnN0IHByb3BzID0ge1xuICAgICAgICBpbml0aWFsUGFnZTogcGFnZTMsXG4gICAgICAgIGluaXRpYWxDb21wb25lbnQsXG4gICAgICAgIHJlc29sdmVDb21wb25lbnQsXG4gICAgICAgIHRpdGxlQ2FsbGJhY2s6IHRpdGxlLFxuICAgICAgICBvbkhlYWRVcGRhdGU6IChlbGVtZW50cykgPT4gaGVhZDIgPSBlbGVtZW50cyxcbiAgICAgICAgZGVmYXVsdExheW91dDogbGF5b3V0MixcbiAgICAgICAgc2VydmVySGVhZFxuICAgICAgfTtcbiAgICAgIGxldCB2dWVBcHAyO1xuICAgICAgaWYgKHNldHVwKSB7XG4gICAgICAgIHZ1ZUFwcDIgPSBzZXR1cCh7XG4gICAgICAgICAgZWw6IG51bGwsXG4gICAgICAgICAgQXBwOiBhcHBfZGVmYXVsdCxcbiAgICAgICAgICBwcm9wcyxcbiAgICAgICAgICBwbHVnaW5cbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2dWVBcHAyID0gY3JlYXRlU1NSQXBwKHsgcmVuZGVyOiAoKSA9PiBoMihhcHBfZGVmYXVsdCwgcHJvcHMpIH0pO1xuICAgICAgICB2dWVBcHAyLnVzZShwbHVnaW4pO1xuICAgICAgICBpZiAod2l0aEFwcCkge1xuICAgICAgICAgIHdpdGhBcHAodnVlQXBwMiwgeyBzc3I6IHRydWUsIHBhZ2U6IHBhZ2UzIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCBodG1sID0gYXdhaXQgcmVuZGVyVG9TdHJpbmcodnVlQXBwMik7XG4gICAgICBjb25zdCBib2R5ID0gYnVpbGRTU1JCb2R5KGlkLCBwYWdlMywgaHRtbCk7XG4gICAgICByZXR1cm4geyBoZWFkOiBoZWFkMiwgYm9keSB9O1xuICAgIH07XG4gIH1cbiAgY29uc3QgaW5pdGlhbFBhZ2UgPSBwYWdlMiB8fCBnZXRJbml0aWFsUGFnZUZyb21ET00oaWQpO1xuICBsZXQgaGVhZCA9IFtdO1xuICBjb25zdCB2dWVBcHAgPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgcmVzb2x2ZUNvbXBvbmVudChpbml0aWFsUGFnZS5jb21wb25lbnQsIGluaXRpYWxQYWdlKSxcbiAgICByb3V0ZXI1LmRlY3J5cHRIaXN0b3J5KCkuY2F0Y2goKCkgPT4ge1xuICAgIH0pXG4gIF0pLnRoZW4oKFtpbml0aWFsQ29tcG9uZW50XSkgPT4ge1xuICAgIGNvbnN0IHByb3BzID0ge1xuICAgICAgaW5pdGlhbFBhZ2UsXG4gICAgICBpbml0aWFsQ29tcG9uZW50LFxuICAgICAgcmVzb2x2ZUNvbXBvbmVudCxcbiAgICAgIHRpdGxlQ2FsbGJhY2s6IHRpdGxlLFxuICAgICAgb25IZWFkVXBkYXRlOiBpc1NlcnZlciA/IChlbGVtZW50cykgPT4gaGVhZCA9IGVsZW1lbnRzIDogdm9pZCAwLFxuICAgICAgZGVmYXVsdExheW91dDogbGF5b3V0MixcbiAgICAgIHNlcnZlckhlYWRcbiAgICB9O1xuICAgIGlmIChpc1NlcnZlcikge1xuICAgICAgcmV0dXJuIHNldHVwKHtcbiAgICAgICAgZWw6IG51bGwsXG4gICAgICAgIEFwcDogYXBwX2RlZmF1bHQsXG4gICAgICAgIHByb3BzLFxuICAgICAgICBwbHVnaW5cbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgICBpZiAoc2V0dXApIHtcbiAgICAgIHJldHVybiBzZXR1cCh7XG4gICAgICAgIGVsLFxuICAgICAgICBBcHA6IGFwcF9kZWZhdWx0LFxuICAgICAgICBwcm9wcyxcbiAgICAgICAgcGx1Z2luXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGVsLmhhc0F0dHJpYnV0ZShcImRhdGEtc2VydmVyLXJlbmRlcmVkXCIpKSB7XG4gICAgICBjb25zdCBhcHAgPSBjcmVhdGVTU1JBcHAoeyByZW5kZXI6ICgpID0+IGgyKGFwcF9kZWZhdWx0LCBwcm9wcykgfSk7XG4gICAgICBhcHAudXNlKHBsdWdpbik7XG4gICAgICBpZiAod2l0aEFwcCkge1xuICAgICAgICB3aXRoQXBwKGFwcCwgeyBzc3I6IGZhbHNlLCBwYWdlOiBpbml0aWFsUGFnZSB9KTtcbiAgICAgIH1cbiAgICAgIGFwcC5tb3VudChlbCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGFwcCA9IGNyZWF0ZUFwcCh7IHJlbmRlcjogKCkgPT4gaDIoYXBwX2RlZmF1bHQsIHByb3BzKSB9KTtcbiAgICAgIGFwcC51c2UocGx1Z2luKTtcbiAgICAgIGlmICh3aXRoQXBwKSB7XG4gICAgICAgIHdpdGhBcHAoYXBwLCB7IHNzcjogZmFsc2UsIHBhZ2U6IGluaXRpYWxQYWdlIH0pO1xuICAgICAgfVxuICAgICAgYXBwLm1vdW50KGVsKTtcbiAgICB9XG4gIH0pO1xuICBpZiAoIWlzU2VydmVyICYmIHByb2dyZXNzMikge1xuICAgIHNldHVwUHJvZ3Jlc3MocHJvZ3Jlc3MyKTtcbiAgfVxuICBpZiAoaXNTZXJ2ZXIgJiYgcmVuZGVyICYmIHZ1ZUFwcCkge1xuICAgIGNvbnN0IGh0bWwgPSBhd2FpdCByZW5kZXIodnVlQXBwKTtcbiAgICBjb25zdCBib2R5ID0gYnVpbGRTU1JCb2R5KGlkLCBpbml0aWFsUGFnZSwgaHRtbCk7XG4gICAgcmV0dXJuIHsgaGVhZCwgYm9keSB9O1xuICB9XG59XG5cbi8vIHNyYy9kZWZlcnJlZC50c1xuaW1wb3J0IHsgaXNTYW1lVXJsV2l0aG91dFF1ZXJ5T3JIYXNoLCBwYXJ0aWFsUmVsb2FkUmVxdWVzdHNTb21lUHJvcHMsIHJvdXRlciBhcyByb3V0ZXI2IH0gZnJvbSBcIkBpbmVydGlhanMvY29yZVwiO1xuaW1wb3J0IHsgZ2V0IGFzIGdldDIgfSBmcm9tIFwiZXMtdG9vbGtpdC9jb21wYXRcIjtcbmltcG9ydCB7IGNvbXB1dGVkIGFzIGNvbXB1dGVkMiwgZGVmaW5lQ29tcG9uZW50IGFzIGRlZmluZUNvbXBvbmVudDIsIEZyYWdtZW50LCBoIGFzIGgzLCBvbk1vdW50ZWQsIG9uVW5tb3VudGVkLCByZWYgYXMgcmVmMyB9IGZyb20gXCJ2dWVcIjtcbnZhciBkZWZlcnJlZF9kZWZhdWx0ID0gZGVmaW5lQ29tcG9uZW50Mih7XG4gIG5hbWU6IFwiRGVmZXJyZWRcIixcbiAgcHJvcHM6IHtcbiAgICBkYXRhOiB7XG4gICAgICB0eXBlOiBbU3RyaW5nLCBBcnJheV0sXG4gICAgICByZXF1aXJlZDogdHJ1ZVxuICAgIH1cbiAgfSxcbiAgc2xvdHM6IE9iamVjdCxcbiAgc2V0dXAocHJvcHMsIHsgc2xvdHMgfSkge1xuICAgIGNvbnN0IHJlbG9hZGluZyA9IHJlZjMoZmFsc2UpO1xuICAgIGNvbnN0IGFjdGl2ZVJlbG9hZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgIGNvbnN0IHBhZ2UyID0gdXNlUGFnZSgpO1xuICAgIGNvbnN0IGtleXMgPSBjb21wdXRlZDIoKCkgPT4gQXJyYXkuaXNBcnJheShwcm9wcy5kYXRhKSA/IHByb3BzLmRhdGEgOiBbcHJvcHMuZGF0YV0pO1xuICAgIGNvbnN0IHJlc2N1ZWRLZXlzID0gY29tcHV0ZWQyKCgpID0+IG5ldyBTZXQocGFnZTIucmVzY3VlZFByb3BzKSk7XG4gICAgbGV0IHJlbW92ZVN0YXJ0TGlzdGVuZXIgPSBudWxsO1xuICAgIGxldCByZW1vdmVGaW5pc2hMaXN0ZW5lciA9IG51bGw7XG4gICAgb25Nb3VudGVkKCgpID0+IHtcbiAgICAgIHJlbW92ZVN0YXJ0TGlzdGVuZXIgPSByb3V0ZXI2Lm9uKFwic3RhcnRcIiwgKGUpID0+IHtcbiAgICAgICAgY29uc3QgdmlzaXQgPSBlLmRldGFpbC52aXNpdDtcbiAgICAgICAgaWYgKHZpc2l0LnByZXNlcnZlU3RhdGUgPT09IHRydWUgJiYgaXNTYW1lVXJsV2l0aG91dFF1ZXJ5T3JIYXNoKHZpc2l0LnVybCwgd2luZG93LmxvY2F0aW9uKSAmJiBwYXJ0aWFsUmVsb2FkUmVxdWVzdHNTb21lUHJvcHModmlzaXQsIGtleXMudmFsdWUpKSB7XG4gICAgICAgICAgYWN0aXZlUmVsb2Fkcy5hZGQodmlzaXQpO1xuICAgICAgICAgIHJlbG9hZGluZy52YWx1ZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmVtb3ZlRmluaXNoTGlzdGVuZXIgPSByb3V0ZXI2Lm9uKFwiZmluaXNoXCIsIChlKSA9PiB7XG4gICAgICAgIGNvbnN0IHZpc2l0ID0gZS5kZXRhaWwudmlzaXQ7XG4gICAgICAgIGlmIChhY3RpdmVSZWxvYWRzLmhhcyh2aXNpdCkpIHtcbiAgICAgICAgICBhY3RpdmVSZWxvYWRzLmRlbGV0ZSh2aXNpdCk7XG4gICAgICAgICAgcmVsb2FkaW5nLnZhbHVlID0gYWN0aXZlUmVsb2Fkcy5zaXplID4gMDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gICAgb25Vbm1vdW50ZWQoKCkgPT4ge1xuICAgICAgcmVtb3ZlU3RhcnRMaXN0ZW5lcj8uKCk7XG4gICAgICByZW1vdmVGaW5pc2hMaXN0ZW5lcj8uKCk7XG4gICAgICBhY3RpdmVSZWxvYWRzLmNsZWFyKCk7XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICghc2xvdHMuZmFsbGJhY2spIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYDxEZWZlcnJlZD5gIHJlcXVpcmVzIGEgYDx0ZW1wbGF0ZSAjZmFsbGJhY2s+YCBzbG90XCIpO1xuICAgICAgfVxuICAgICAgY29uc3QgcHJvcHNBcmVEZWZpbmVkID0ga2V5cy52YWx1ZS5ldmVyeSgoa2V5MikgPT4gZ2V0MihwYWdlMi5wcm9wcywga2V5MikgIT09IHZvaWQgMCk7XG4gICAgICBjb25zdCBoYXNSZXNjdWVkUHJvcHMgPSBrZXlzLnZhbHVlLnNvbWUoKGtleTIpID0+IHJlc2N1ZWRLZXlzLnZhbHVlLmhhcyhrZXkyKSk7XG4gICAgICBjb25zdCBzbG90UHJvcHMgPSB7IHJlbG9hZGluZzogcmVsb2FkaW5nLnZhbHVlIH07XG4gICAgICBpZiAocHJvcHNBcmVEZWZpbmVkICYmICFoYXNSZXNjdWVkUHJvcHMpIHtcbiAgICAgICAgcmV0dXJuIGgzKEZyYWdtZW50LCB7IGtleTogXCJkZWZhdWx0XCIgfSwgc2xvdHMuZGVmYXVsdD8uKHNsb3RQcm9wcykgPz8gW10pO1xuICAgICAgfVxuICAgICAgaWYgKGhhc1Jlc2N1ZWRQcm9wcyAmJiBzbG90cy5yZXNjdWUpIHtcbiAgICAgICAgcmV0dXJuIGgzKEZyYWdtZW50LCB7IGtleTogXCJyZXNjdWVcIiB9LCBzbG90cy5yZXNjdWUoc2xvdFByb3BzKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gaDMoRnJhZ21lbnQsIHsga2V5OiBcImZhbGxiYWNrXCIgfSwgc2xvdHMuZmFsbGJhY2soe30pKTtcbiAgICB9O1xuICB9XG59KTtcblxuLy8gc3JjL2Zvcm0udHNcbmltcG9ydCB7XG4gIGNvbmZpZyBhcyBjb25maWcyLFxuICBGb3JtQ29tcG9uZW50UmVzZXRTeW1ib2wsXG4gIGZvcm1EYXRhVG9PYmplY3QsXG4gIGlzVXJsTWV0aG9kUGFpcixcbiAgbWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nLFxuICByZXNldEZvcm1GaWVsZHMsXG4gIHJlc29sdmVVcmxNZXRob2RQYWlyQ29tcG9uZW50LFxuICBVc2VGb3JtVXRpbHMgYXMgVXNlRm9ybVV0aWxzM1xufSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBpc0VxdWFsIGFzIGlzRXF1YWwyIH0gZnJvbSBcImVzLXRvb2xraXRcIjtcbmltcG9ydCB7XG4gIGNvbXB1dGVkIGFzIGNvbXB1dGVkMyxcbiAgZGVmaW5lQ29tcG9uZW50IGFzIGRlZmluZUNvbXBvbmVudDMsXG4gIGggYXMgaDQsXG4gIGluamVjdCxcbiAgb25CZWZvcmVVbm1vdW50LFxuICBvbk1vdW50ZWQgYXMgb25Nb3VudGVkMixcbiAgcHJvdmlkZSxcbiAgcmVmIGFzIHJlZjQsXG4gIHdhdGNoIGFzIHdhdGNoMlxufSBmcm9tIFwidnVlXCI7XG52YXIgbm9vcCA9ICgpID0+IHZvaWQgMDtcbnZhciBGb3JtQ29udGV4dEtleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJJbmVydGlhRm9ybUNvbnRleHRcIik7XG52YXIgRm9ybSA9IGRlZmluZUNvbXBvbmVudDMoe1xuICBuYW1lOiBcIkZvcm1cIixcbiAgc2xvdHM6IE9iamVjdCxcbiAgcHJvcHM6IHtcbiAgICBhY3Rpb246IHtcbiAgICAgIHR5cGU6IFtTdHJpbmcsIE9iamVjdF0sXG4gICAgICBkZWZhdWx0OiBcIlwiXG4gICAgfSxcbiAgICBtZXRob2Q6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGRlZmF1bHQ6IFwiZ2V0XCJcbiAgICB9LFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIGRlZmF1bHQ6ICgpID0+ICh7fSlcbiAgICB9LFxuICAgIHF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGRlZmF1bHQ6IFwiYnJhY2tldHNcIlxuICAgIH0sXG4gICAgZXJyb3JCYWc6IHtcbiAgICAgIHR5cGU6IFtTdHJpbmcsIG51bGxdLFxuICAgICAgZGVmYXVsdDogbnVsbFxuICAgIH0sXG4gICAgc2hvd1Byb2dyZXNzOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogdHJ1ZVxuICAgIH0sXG4gICAgdHJhbnNmb3JtOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IChkYXRhKSA9PiBkYXRhXG4gICAgfSxcbiAgICBvcHRpb25zOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBkZWZhdWx0OiAoKSA9PiAoe30pXG4gICAgfSxcbiAgICByZXNldE9uRXJyb3I6IHtcbiAgICAgIHR5cGU6IFtCb29sZWFuLCBBcnJheV0sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgcmVzZXRPblN1Y2Nlc3M6IHtcbiAgICAgIHR5cGU6IFtCb29sZWFuLCBBcnJheV0sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgc2V0RGVmYXVsdHNPblN1Y2Nlc3M6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgb25DYW5jZWxUb2tlbjoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiBub29wXG4gICAgfSxcbiAgICBvbkJlZm9yZToge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiBub29wXG4gICAgfSxcbiAgICBvblN0YXJ0OiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3BcbiAgICB9LFxuICAgIG9uUHJvZ3Jlc3M6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgZGVmYXVsdDogbm9vcFxuICAgIH0sXG4gICAgb25GaW5pc2g6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgZGVmYXVsdDogbm9vcFxuICAgIH0sXG4gICAgb25DYW5jZWw6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgZGVmYXVsdDogbm9vcFxuICAgIH0sXG4gICAgb25TdWNjZXNzOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3BcbiAgICB9LFxuICAgIG9uRXJyb3I6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgZGVmYXVsdDogbm9vcFxuICAgIH0sXG4gICAgb25TdWJtaXRDb21wbGV0ZToge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiBub29wXG4gICAgfSxcbiAgICBkaXNhYmxlV2hpbGVQcm9jZXNzaW5nOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9LFxuICAgIGNhbmNlbE9uVW5tb3VudDoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgfSxcbiAgICBpbnZhbGlkYXRlQ2FjaGVUYWdzOiB7XG4gICAgICB0eXBlOiBbU3RyaW5nLCBBcnJheV0sXG4gICAgICBkZWZhdWx0OiAoKSA9PiBbXVxuICAgIH0sXG4gICAgdmFsaWRhdGVGaWxlczoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgfSxcbiAgICB2YWxpZGF0aW9uVGltZW91dDoge1xuICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgZGVmYXVsdDogMTUwMFxuICAgIH0sXG4gICAgb3B0aW1pc3RpYzoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiB2b2lkIDBcbiAgICB9LFxuICAgIHdpdGhBbGxFcnJvcnM6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBkZWZhdWx0OiBudWxsXG4gICAgfSxcbiAgICBjb21wb25lbnQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGRlZmF1bHQ6IG51bGxcbiAgICB9LFxuICAgIGluc3RhbnQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH1cbiAgfSxcbiAgc2V0dXAocHJvcHMsIHsgc2xvdHMsIGF0dHJzLCBleHBvc2UgfSkge1xuICAgIGNvbnN0IGdldFRyYW5zZm9ybWVkRGF0YSA9ICgpID0+IHtcbiAgICAgIGNvbnN0IFtfdXJsLCBkYXRhXSA9IGdldFVybEFuZERhdGEoKTtcbiAgICAgIHJldHVybiBwcm9wcy50cmFuc2Zvcm0oZGF0YSk7XG4gICAgfTtcbiAgICBjb25zdCBmb3JtID0gdXNlRm9ybSh7fSkud2l0aFByZWNvZ25pdGlvbihcbiAgICAgICgpID0+IG1ldGhvZC52YWx1ZSxcbiAgICAgICgpID0+IGdldFVybEFuZERhdGEoKVswXVxuICAgICkudHJhbnNmb3JtKGdldFRyYW5zZm9ybWVkRGF0YSkuc2V0VmFsaWRhdGlvblRpbWVvdXQocHJvcHMudmFsaWRhdGlvblRpbWVvdXQpO1xuICAgIGlmIChwcm9wcy52YWxpZGF0ZUZpbGVzKSB7XG4gICAgICBmb3JtLnZhbGlkYXRlRmlsZXMoKTtcbiAgICB9XG4gICAgaWYgKHByb3BzLndpdGhBbGxFcnJvcnMgPz8gY29uZmlnMi5nZXQoXCJmb3JtLndpdGhBbGxFcnJvcnNcIikpIHtcbiAgICAgIGZvcm0ud2l0aEFsbEVycm9ycygpO1xuICAgIH1cbiAgICBjb25zdCBmb3JtRWxlbWVudCA9IHJlZjQoKTtcbiAgICBjb25zdCBtZXRob2QgPSBjb21wdXRlZDMoXG4gICAgICAoKSA9PiBpc1VybE1ldGhvZFBhaXIocHJvcHMuYWN0aW9uKSA/IHByb3BzLmFjdGlvbi5tZXRob2QgOiBwcm9wcy5tZXRob2QudG9Mb3dlckNhc2UoKVxuICAgICk7XG4gICAgY29uc3QgcmVzb2x2ZWRDb21wb25lbnQgPSBjb21wdXRlZDMoKCkgPT4ge1xuICAgICAgaWYgKHByb3BzLmNvbXBvbmVudCkge1xuICAgICAgICByZXR1cm4gcHJvcHMuY29tcG9uZW50O1xuICAgICAgfVxuICAgICAgaWYgKHByb3BzLmluc3RhbnQgJiYgaXNVcmxNZXRob2RQYWlyKHByb3BzLmFjdGlvbikpIHtcbiAgICAgICAgcmV0dXJuIHJlc29sdmVVcmxNZXRob2RQYWlyQ29tcG9uZW50KHByb3BzLmFjdGlvbik7XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9KTtcbiAgICBjb25zdCBpc0RpcnR5ID0gcmVmNChmYWxzZSk7XG4gICAgY29uc3QgZGVmYXVsdERhdGEgPSByZWY0KG5ldyBGb3JtRGF0YSgpKTtcbiAgICBjb25zdCBvbkZvcm1VcGRhdGUgPSAoZXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC50eXBlID09PSBcInJlc2V0XCIgJiYgZXZlbnQuZGV0YWlsPy5bRm9ybUNvbXBvbmVudFJlc2V0U3ltYm9sXSkge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgfVxuICAgICAgaXNEaXJ0eS52YWx1ZSA9IGV2ZW50LnR5cGUgPT09IFwicmVzZXRcIiA/IGZhbHNlIDogIWlzRXF1YWwyKGdldERhdGEoKSwgZm9ybURhdGFUb09iamVjdChkZWZhdWx0RGF0YS52YWx1ZSkpO1xuICAgIH07XG4gICAgY29uc3QgZm9ybUV2ZW50cyA9IFtcImlucHV0XCIsIFwiY2hhbmdlXCIsIFwicmVzZXRcIl07XG4gICAgb25Nb3VudGVkMigoKSA9PiB7XG4gICAgICBkZWZhdWx0RGF0YS52YWx1ZSA9IGdldEZvcm1EYXRhKCk7XG4gICAgICBmb3JtLmRlZmF1bHRzKGdldERhdGEoKSk7XG4gICAgICBmb3JtRXZlbnRzLmZvckVhY2goKGUpID0+IGZvcm1FbGVtZW50LnZhbHVlLmFkZEV2ZW50TGlzdGVuZXIoZSwgb25Gb3JtVXBkYXRlKSk7XG4gICAgfSk7XG4gICAgd2F0Y2gyKFxuICAgICAgKCkgPT4gcHJvcHMudmFsaWRhdGVGaWxlcyxcbiAgICAgICh2YWx1ZSkgPT4gdmFsdWUgPyBmb3JtLnZhbGlkYXRlRmlsZXMoKSA6IGZvcm0ud2l0aG91dEZpbGVWYWxpZGF0aW9uKClcbiAgICApO1xuICAgIHdhdGNoMihcbiAgICAgICgpID0+IHByb3BzLnZhbGlkYXRpb25UaW1lb3V0LFxuICAgICAgKHZhbHVlKSA9PiBmb3JtLnNldFZhbGlkYXRpb25UaW1lb3V0KHZhbHVlKVxuICAgICk7XG4gICAgb25CZWZvcmVVbm1vdW50KCgpID0+IHtcbiAgICAgIGZvcm1FdmVudHMuZm9yRWFjaCgoZSkgPT4gZm9ybUVsZW1lbnQudmFsdWU/LnJlbW92ZUV2ZW50TGlzdGVuZXIoZSwgb25Gb3JtVXBkYXRlKSk7XG4gICAgICBpZiAocHJvcHMuY2FuY2VsT25Vbm1vdW50KSB7XG4gICAgICAgIGZvcm0uY2FuY2VsKCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgZ2V0Rm9ybURhdGEgPSAoc3VibWl0dGVyKSA9PiBuZXcgRm9ybURhdGEoZm9ybUVsZW1lbnQudmFsdWUsIHN1Ym1pdHRlcik7XG4gICAgY29uc3QgZ2V0RGF0YSA9IChzdWJtaXR0ZXIpID0+IGZvcm1EYXRhVG9PYmplY3QoZ2V0Rm9ybURhdGEoc3VibWl0dGVyKSk7XG4gICAgY29uc3QgZ2V0VXJsQW5kRGF0YSA9IChzdWJtaXR0ZXIpID0+IHtcbiAgICAgIHJldHVybiBtZXJnZURhdGFJbnRvUXVlcnlTdHJpbmcoXG4gICAgICAgIG1ldGhvZC52YWx1ZSxcbiAgICAgICAgaXNVcmxNZXRob2RQYWlyKHByb3BzLmFjdGlvbikgPyBwcm9wcy5hY3Rpb24udXJsIDogcHJvcHMuYWN0aW9uLFxuICAgICAgICBnZXREYXRhKHN1Ym1pdHRlciksXG4gICAgICAgIHByb3BzLnF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXRcbiAgICAgICk7XG4gICAgfTtcbiAgICBjb25zdCBzdWJtaXQgPSAoc3VibWl0dGVyKSA9PiB7XG4gICAgICBjb25zdCBbdXJsLCBkYXRhXSA9IGdldFVybEFuZERhdGEoc3VibWl0dGVyKTtcbiAgICAgIGNvbnN0IGZvcm1UYXJnZXQgPSBzdWJtaXR0ZXI/LmdldEF0dHJpYnV0ZShcImZvcm10YXJnZXRcIik7XG4gICAgICBpZiAoZm9ybVRhcmdldCA9PT0gXCJfYmxhbmtcIiAmJiBtZXRob2QudmFsdWUgPT09IFwiZ2V0XCIpIHtcbiAgICAgICAgd2luZG93Lm9wZW4odXJsLCBcIl9ibGFua1wiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgbWF5YmVSZXNldCA9IChyZXNldE9wdGlvbikgPT4ge1xuICAgICAgICBpZiAoIXJlc2V0T3B0aW9uKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXNldE9wdGlvbiA9PT0gdHJ1ZSkge1xuICAgICAgICAgIHJlc2V0KCk7XG4gICAgICAgIH0gZWxzZSBpZiAocmVzZXRPcHRpb24ubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJlc2V0KC4uLnJlc2V0T3B0aW9uKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHN1Ym1pdE9wdGlvbnMgPSB7XG4gICAgICAgIGhlYWRlcnM6IHByb3BzLmhlYWRlcnMsXG4gICAgICAgIHF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXQ6IHByb3BzLnF1ZXJ5U3RyaW5nQXJyYXlGb3JtYXQsXG4gICAgICAgIGVycm9yQmFnOiBwcm9wcy5lcnJvckJhZyxcbiAgICAgICAgc2hvd1Byb2dyZXNzOiBwcm9wcy5zaG93UHJvZ3Jlc3MsXG4gICAgICAgIGludmFsaWRhdGVDYWNoZVRhZ3M6IHByb3BzLmludmFsaWRhdGVDYWNoZVRhZ3MsXG4gICAgICAgIGNvbXBvbmVudDogcmVzb2x2ZWRDb21wb25lbnQudmFsdWUsXG4gICAgICAgIG9wdGltaXN0aWM6IHByb3BzLm9wdGltaXN0aWMgPyAocGFnZVByb3BzKSA9PiBwcm9wcy5vcHRpbWlzdGljKHBhZ2VQcm9wcywgZGF0YSkgOiB2b2lkIDAsXG4gICAgICAgIG9uQ2FuY2VsVG9rZW46IHByb3BzLm9uQ2FuY2VsVG9rZW4sXG4gICAgICAgIG9uQmVmb3JlOiBwcm9wcy5vbkJlZm9yZSxcbiAgICAgICAgb25TdGFydDogcHJvcHMub25TdGFydCxcbiAgICAgICAgb25Qcm9ncmVzczogcHJvcHMub25Qcm9ncmVzcyxcbiAgICAgICAgb25GaW5pc2g6IHByb3BzLm9uRmluaXNoLFxuICAgICAgICBvbkNhbmNlbDogcHJvcHMub25DYW5jZWwsXG4gICAgICAgIG9uU3VjY2VzczogYXN5bmMgKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwcm9wcy5vblN1Y2Nlc3M/LiguLi5hcmdzKTtcbiAgICAgICAgICBwcm9wcy5vblN1Ym1pdENvbXBsZXRlPy4oZXhwb3NlZCk7XG4gICAgICAgICAgbWF5YmVSZXNldChwcm9wcy5yZXNldE9uU3VjY2Vzcyk7XG4gICAgICAgICAgaWYgKHByb3BzLnNldERlZmF1bHRzT25TdWNjZXNzID09PSB0cnVlKSB7XG4gICAgICAgICAgICBkZWZhdWx0cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuICAgICAgICBvbkVycm9yOiAoLi4uYXJncykgPT4ge1xuICAgICAgICAgIHByb3BzLm9uRXJyb3I/LiguLi5hcmdzKTtcbiAgICAgICAgICBtYXliZVJlc2V0KHByb3BzLnJlc2V0T25FcnJvcik7XG4gICAgICAgIH0sXG4gICAgICAgIC4uLnByb3BzLm9wdGlvbnNcbiAgICAgIH07XG4gICAgICBmb3JtLnRyYW5zZm9ybSgoKSA9PiBwcm9wcy50cmFuc2Zvcm0oZGF0YSkpLnN1Ym1pdChtZXRob2QudmFsdWUsIHVybCwgc3VibWl0T3B0aW9ucyk7XG4gICAgICBmb3JtLnRyYW5zZm9ybShnZXRUcmFuc2Zvcm1lZERhdGEpO1xuICAgIH07XG4gICAgY29uc3QgcmVzZXQgPSAoLi4uZmllbGRzKSA9PiB7XG4gICAgICByZXNldEZvcm1GaWVsZHMoZm9ybUVsZW1lbnQudmFsdWUsIGRlZmF1bHREYXRhLnZhbHVlLCBmaWVsZHMpO1xuICAgICAgZm9ybS5yZXNldCguLi5maWVsZHMpO1xuICAgIH07XG4gICAgY29uc3QgY2xlYXJFcnJvcnMgPSAoLi4uZmllbGRzKSA9PiB7XG4gICAgICBmb3JtLmNsZWFyRXJyb3JzKC4uLmZpZWxkcyk7XG4gICAgfTtcbiAgICBjb25zdCByZXNldEFuZENsZWFyRXJyb3JzID0gKC4uLmZpZWxkcykgPT4ge1xuICAgICAgY2xlYXJFcnJvcnMoLi4uZmllbGRzKTtcbiAgICAgIHJlc2V0KC4uLmZpZWxkcyk7XG4gICAgfTtcbiAgICBjb25zdCBkZWZhdWx0cyA9ICgpID0+IHtcbiAgICAgIGRlZmF1bHREYXRhLnZhbHVlID0gZ2V0Rm9ybURhdGEoKTtcbiAgICAgIGlzRGlydHkudmFsdWUgPSBmYWxzZTtcbiAgICB9O1xuICAgIGNvbnN0IGV4cG9zZWQgPSB7XG4gICAgICBnZXQgZXJyb3JzKCkge1xuICAgICAgICByZXR1cm4gZm9ybS5lcnJvcnM7XG4gICAgICB9LFxuICAgICAgZ2V0IGhhc0Vycm9ycygpIHtcbiAgICAgICAgcmV0dXJuIGZvcm0uaGFzRXJyb3JzO1xuICAgICAgfSxcbiAgICAgIGdldCBwcm9jZXNzaW5nKCkge1xuICAgICAgICByZXR1cm4gZm9ybS5wcm9jZXNzaW5nO1xuICAgICAgfSxcbiAgICAgIGdldCBwcm9ncmVzcygpIHtcbiAgICAgICAgcmV0dXJuIGZvcm0ucHJvZ3Jlc3M7XG4gICAgICB9LFxuICAgICAgZ2V0IHdhc1N1Y2Nlc3NmdWwoKSB7XG4gICAgICAgIHJldHVybiBmb3JtLndhc1N1Y2Nlc3NmdWw7XG4gICAgICB9LFxuICAgICAgZ2V0IHJlY2VudGx5U3VjY2Vzc2Z1bCgpIHtcbiAgICAgICAgcmV0dXJuIGZvcm0ucmVjZW50bHlTdWNjZXNzZnVsO1xuICAgICAgfSxcbiAgICAgIGdldCB2YWxpZGF0aW5nKCkge1xuICAgICAgICByZXR1cm4gZm9ybS52YWxpZGF0aW5nO1xuICAgICAgfSxcbiAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgcmVzZXRBbmRDbGVhckVycm9ycyxcbiAgICAgIHNldEVycm9yOiAoZmllbGRPckZpZWxkcywgbWF5YmVWYWx1ZSkgPT4gZm9ybS5zZXRFcnJvcih0eXBlb2YgZmllbGRPckZpZWxkcyA9PT0gXCJzdHJpbmdcIiA/IHsgW2ZpZWxkT3JGaWVsZHNdOiBtYXliZVZhbHVlIH0gOiBmaWVsZE9yRmllbGRzKSxcbiAgICAgIGdldCBpc0RpcnR5KCkge1xuICAgICAgICByZXR1cm4gaXNEaXJ0eS52YWx1ZTtcbiAgICAgIH0sXG4gICAgICByZXNldCxcbiAgICAgIHN1Ym1pdCxcbiAgICAgIGNhbmNlbDogKCkgPT4gZm9ybS5jYW5jZWwoKSxcbiAgICAgIGRlZmF1bHRzLFxuICAgICAgZ2V0RGF0YSxcbiAgICAgIGdldEZvcm1EYXRhLFxuICAgICAgLy8gUHJlY29nbml0aW9uXG4gICAgICB0b3VjaDogZm9ybS50b3VjaCxcbiAgICAgIHZhbGlkOiBmb3JtLnZhbGlkLFxuICAgICAgaW52YWxpZDogZm9ybS5pbnZhbGlkLFxuICAgICAgdG91Y2hlZDogZm9ybS50b3VjaGVkLFxuICAgICAgdmFsaWRhdGU6IChmaWVsZCwgY29uZmlnMykgPT4gZm9ybS52YWxpZGF0ZSguLi5Vc2VGb3JtVXRpbHMzLm1lcmdlSGVhZGVyc0ZvclZhbGlkYXRpb24oZmllbGQsIGNvbmZpZzMsIHByb3BzLmhlYWRlcnMpKSxcbiAgICAgIHZhbGlkYXRvcjogKCkgPT4gZm9ybS52YWxpZGF0b3IoKVxuICAgIH07XG4gICAgZXhwb3NlKGV4cG9zZWQpO1xuICAgIHByb3ZpZGUoRm9ybUNvbnRleHRLZXksIGV4cG9zZWQpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICByZXR1cm4gaDQoXG4gICAgICAgIFwiZm9ybVwiLFxuICAgICAgICB7XG4gICAgICAgICAgLi4uYXR0cnMsXG4gICAgICAgICAgcmVmOiBmb3JtRWxlbWVudCxcbiAgICAgICAgICBhY3Rpb246IGlzVXJsTWV0aG9kUGFpcihwcm9wcy5hY3Rpb24pID8gcHJvcHMuYWN0aW9uLnVybCA6IHByb3BzLmFjdGlvbixcbiAgICAgICAgICBtZXRob2Q6IG1ldGhvZC52YWx1ZSxcbiAgICAgICAgICBvblN1Ym1pdDogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgc3VibWl0KGV2ZW50LnN1Ym1pdHRlcik7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBpbmVydDogcHJvcHMuZGlzYWJsZVdoaWxlUHJvY2Vzc2luZyAmJiBmb3JtLnByb2Nlc3NpbmdcbiAgICAgICAgfSxcbiAgICAgICAgc2xvdHMuZGVmYXVsdCA/IHNsb3RzLmRlZmF1bHQoZXhwb3NlZCkgOiBbXVxuICAgICAgKTtcbiAgICB9O1xuICB9XG59KTtcbmZ1bmN0aW9uIHVzZUZvcm1Db250ZXh0KCkge1xuICByZXR1cm4gaW5qZWN0KEZvcm1Db250ZXh0S2V5KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUZvcm0oKSB7XG4gIHJldHVybiBGb3JtO1xufVxudmFyIGZvcm1fZGVmYXVsdCA9IEZvcm07XG5cbi8vIHNyYy9oZWFkLnRzXG5pbXBvcnQgeyBlc2NhcGUgfSBmcm9tIFwiZXMtdG9vbGtpdC9jb21wYXRcIjtcbmltcG9ydCB7IGRlZmluZUNvbXBvbmVudCBhcyBkZWZpbmVDb21wb25lbnQ0LCBvbkJlZm9yZVVubW91bnQgYXMgb25CZWZvcmVVbm1vdW50MiB9IGZyb20gXCJ2dWVcIjtcbmZ1bmN0aW9uIGlzVW5hcnlUYWcobm9kZSkge1xuICByZXR1cm4gdHlwZW9mIG5vZGUudHlwZSA9PT0gXCJzdHJpbmdcIiAmJiBbXG4gICAgXCJhcmVhXCIsXG4gICAgXCJiYXNlXCIsXG4gICAgXCJiclwiLFxuICAgIFwiY29sXCIsXG4gICAgXCJlbWJlZFwiLFxuICAgIFwiaHJcIixcbiAgICBcImltZ1wiLFxuICAgIFwiaW5wdXRcIixcbiAgICBcImtleWdlblwiLFxuICAgIFwibGlua1wiLFxuICAgIFwibWV0YVwiLFxuICAgIFwicGFyYW1cIixcbiAgICBcInNvdXJjZVwiLFxuICAgIFwidHJhY2tcIixcbiAgICBcIndiclwiXG4gIF0uaW5kZXhPZihub2RlLnR5cGUpID4gLTE7XG59XG5mdW5jdGlvbiByZW5kZXJUYWdTdGFydChub2RlKSB7XG4gIG5vZGUucHJvcHMgPSBub2RlLnByb3BzIHx8IHt9O1xuICBub2RlLnByb3BzW1wiZGF0YS1pbmVydGlhXCJdID0gbm9kZS5wcm9wc1tcImhlYWQta2V5XCJdICE9PSB2b2lkIDAgPyBub2RlLnByb3BzW1wiaGVhZC1rZXlcIl0gOiBcIlwiO1xuICBjb25zdCBhdHRycyA9IE9iamVjdC5rZXlzKG5vZGUucHJvcHMpLnJlZHVjZSgoY2FycnksIG5hbWUpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IFN0cmluZyhub2RlLnByb3BzW25hbWVdKTtcbiAgICBpZiAoW1wia2V5XCIsIFwiaGVhZC1rZXlcIl0uaW5jbHVkZXMobmFtZSkpIHtcbiAgICAgIHJldHVybiBjYXJyeTtcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlwiKSB7XG4gICAgICByZXR1cm4gY2FycnkgKyBgICR7bmFtZX1gO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gY2FycnkgKyBgICR7bmFtZX09XCIke2VzY2FwZSh2YWx1ZSl9XCJgO1xuICAgIH1cbiAgfSwgXCJcIik7XG4gIHJldHVybiBgPCR7U3RyaW5nKG5vZGUudHlwZSl9JHthdHRyc30+YDtcbn1cbmZ1bmN0aW9uIHJlbmRlclRhZ0NoaWxkcmVuKG5vZGUpIHtcbiAgY29uc3QgeyBjaGlsZHJlbiB9ID0gbm9kZTtcbiAgaWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJzdHJpbmdcIikge1xuICAgIHJldHVybiBjaGlsZHJlbjtcbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheShjaGlsZHJlbikpIHtcbiAgICByZXR1cm4gY2hpbGRyZW4ucmVkdWNlKChodG1sLCBjaGlsZCkgPT4ge1xuICAgICAgcmV0dXJuIGh0bWwgKyByZW5kZXJUYWcoY2hpbGQpO1xuICAgIH0sIFwiXCIpO1xuICB9XG4gIHJldHVybiBcIlwiO1xufVxuZnVuY3Rpb24gaXNGdW5jdGlvbk5vZGUobm9kZSkge1xuICByZXR1cm4gdHlwZW9mIG5vZGUudHlwZSA9PT0gXCJmdW5jdGlvblwiO1xufVxuZnVuY3Rpb24gaXNDb21wb25lbnROb2RlKG5vZGUpIHtcbiAgcmV0dXJuIHR5cGVvZiBub2RlLnR5cGUgPT09IFwib2JqZWN0XCI7XG59XG5mdW5jdGlvbiBpc0NvbW1lbnROb2RlKG5vZGUpIHtcbiAgcmV0dXJuIC8oY29tbWVudHxjbXQpL2kudGVzdChub2RlLnR5cGUudG9TdHJpbmcoKSk7XG59XG5mdW5jdGlvbiBpc0ZyYWdtZW50Tm9kZShub2RlKSB7XG4gIHJldHVybiAvKGZyYWdtZW50fGZndHxzeW1ib2xcXChcXCkpL2kudGVzdChub2RlLnR5cGUudG9TdHJpbmcoKSk7XG59XG5mdW5jdGlvbiBpc1RleHROb2RlKG5vZGUpIHtcbiAgcmV0dXJuIC8odGV4dHx0eHQpL2kudGVzdChub2RlLnR5cGUudG9TdHJpbmcoKSk7XG59XG5mdW5jdGlvbiByZW5kZXJUYWcobm9kZSkge1xuICBpZiAoaXNUZXh0Tm9kZShub2RlKSkge1xuICAgIHJldHVybiBTdHJpbmcobm9kZS5jaGlsZHJlbik7XG4gIH0gZWxzZSBpZiAoaXNGcmFnbWVudE5vZGUobm9kZSkpIHtcbiAgICByZXR1cm4gXCJcIjtcbiAgfSBlbHNlIGlmIChpc0NvbW1lbnROb2RlKG5vZGUpKSB7XG4gICAgcmV0dXJuIFwiXCI7XG4gIH1cbiAgbGV0IGh0bWwgPSByZW5kZXJUYWdTdGFydChub2RlKTtcbiAgaWYgKG5vZGUuY2hpbGRyZW4pIHtcbiAgICBodG1sICs9IHJlbmRlclRhZ0NoaWxkcmVuKG5vZGUpO1xuICB9XG4gIGlmICghaXNVbmFyeVRhZyhub2RlKSkge1xuICAgIGh0bWwgKz0gYDwvJHtTdHJpbmcobm9kZS50eXBlKX0+YDtcbiAgfVxuICByZXR1cm4gaHRtbDtcbn1cbmZ1bmN0aW9uIGFkZFRpdGxlRWxlbWVudChlbGVtZW50cywgdGl0bGUpIHtcbiAgaWYgKHRpdGxlICYmICFlbGVtZW50cy5maW5kKCh0YWcpID0+IHRhZy5zdGFydHNXaXRoKFwiPHRpdGxlXCIpKSkge1xuICAgIGVsZW1lbnRzLnB1c2goYDx0aXRsZSBkYXRhLWluZXJ0aWE9XCJcIj4ke2VzY2FwZSh0aXRsZSl9PC90aXRsZT5gKTtcbiAgfVxuICByZXR1cm4gZWxlbWVudHM7XG59XG5mdW5jdGlvbiByZW5kZXJOb2Rlcyhub2RlcywgdGl0bGUpIHtcbiAgY29uc3QgZWxlbWVudHMgPSBub2Rlcy5mbGF0TWFwKChub2RlKSA9PiByZXNvbHZlTm9kZShub2RlKSkubWFwKChub2RlKSA9PiByZW5kZXJUYWcobm9kZSkpLmZpbHRlcigobm9kZSkgPT4gbm9kZSk7XG4gIHJldHVybiBhZGRUaXRsZUVsZW1lbnQoZWxlbWVudHMsIHRpdGxlKTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVOb2RlKG5vZGUpIHtcbiAgaWYgKGlzRnVuY3Rpb25Ob2RlKG5vZGUpKSB7XG4gICAgcmV0dXJuIHJlc29sdmVOb2RlKG5vZGUudHlwZSgpKTtcbiAgfSBlbHNlIGlmIChpc0NvbXBvbmVudE5vZGUobm9kZSkpIHtcbiAgICBjb25zb2xlLndhcm4oYFVzaW5nIGNvbXBvbmVudHMgaW4gdGhlIDxIZWFkPiBjb21wb25lbnQgaXMgbm90IHN1cHBvcnRlZC5gKTtcbiAgICByZXR1cm4gW107XG4gIH0gZWxzZSBpZiAoaXNUZXh0Tm9kZShub2RlKSAmJiBub2RlLmNoaWxkcmVuKSB7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0gZWxzZSBpZiAoaXNGcmFnbWVudE5vZGUobm9kZSkgJiYgbm9kZS5jaGlsZHJlbikge1xuICAgIHJldHVybiBub2RlLmNoaWxkcmVuLmZsYXRNYXAoKGNoaWxkKSA9PiByZXNvbHZlTm9kZShjaGlsZCkpO1xuICB9IGVsc2UgaWYgKGlzQ29tbWVudE5vZGUobm9kZSkpIHtcbiAgICByZXR1cm4gW107XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn1cbnZhciBIZWFkID0gZGVmaW5lQ29tcG9uZW50NCh7XG4gIHByb3BzOiB7XG4gICAgdGl0bGU6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHJlcXVpcmVkOiBmYWxzZVxuICAgIH1cbiAgfSxcbiAgc2V0dXAocHJvcHMsIHsgc2xvdHMgfSkge1xuICAgIGNvbnN0IHByb3ZpZGVyID0gaGVhZE1hbmFnZXIuY3JlYXRlUHJvdmlkZXIoKTtcbiAgICBvbkJlZm9yZVVubW91bnQyKCgpID0+IHtcbiAgICAgIHByb3ZpZGVyLmRpc2Nvbm5lY3QoKTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgcHJvdmlkZXIudXBkYXRlKHJlbmRlck5vZGVzKHNsb3RzLmRlZmF1bHQgPyBzbG90cy5kZWZhdWx0KCkgOiBbXSwgcHJvcHMudGl0bGUpKTtcbiAgICB9O1xuICB9XG59KTtcbnZhciBoZWFkX2RlZmF1bHQgPSBIZWFkO1xuXG4vLyBzcmMvaW5maW5pdGVTY3JvbGwudHNcbmltcG9ydCB7XG4gIGdldFNjcm9sbGFibGVQYXJlbnQsXG4gIHVzZUluZmluaXRlU2Nyb2xsXG59IGZyb20gXCJAaW5lcnRpYWpzL2NvcmVcIjtcbmltcG9ydCB7IGNvbXB1dGVkIGFzIGNvbXB1dGVkNCwgZGVmaW5lQ29tcG9uZW50IGFzIGRlZmluZUNvbXBvbmVudDUsIEZyYWdtZW50IGFzIEZyYWdtZW50MiwgaCBhcyBoNSwgb25Nb3VudGVkIGFzIG9uTW91bnRlZDMsIG9uVW5tb3VudGVkIGFzIG9uVW5tb3VudGVkMiwgcmVmIGFzIHJlZjUsIHdhdGNoIGFzIHdhdGNoMyB9IGZyb20gXCJ2dWVcIjtcbnZhciByZXNvbHZlSFRNTEVsZW1lbnQgPSAodmFsdWUsIGZhbGxiYWNrKSA9PiB7XG4gIGlmICghdmFsdWUpIHtcbiAgICByZXR1cm4gZmFsbGJhY2s7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHZhbHVlKTtcbiAgfVxuICBpZiAodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4gdmFsdWUoKSB8fCBudWxsO1xuICB9XG4gIHJldHVybiBmYWxsYmFjaztcbn07XG52YXIgSW5maW5pdGVTY3JvbGwgPSBkZWZpbmVDb21wb25lbnQ1KHtcbiAgbmFtZTogXCJJbmZpbml0ZVNjcm9sbFwiLFxuICBzbG90czogT2JqZWN0LFxuICBwcm9wczoge1xuICAgIGRhdGE6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHJlcXVpcmVkOiB0cnVlXG4gICAgfSxcbiAgICBidWZmZXI6IHtcbiAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgIGRlZmF1bHQ6IDBcbiAgICB9LFxuICAgIG9ubHlOZXh0OiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9LFxuICAgIG9ubHlQcmV2aW91czoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgfSxcbiAgICBhczoge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgZGVmYXVsdDogXCJkaXZcIlxuICAgIH0sXG4gICAgbWFudWFsOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9LFxuICAgIG1hbnVhbEFmdGVyOiB7XG4gICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICBkZWZhdWx0OiAwXG4gICAgfSxcbiAgICBwcmVzZXJ2ZVVybDoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgfSxcbiAgICByZXZlcnNlOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9LFxuICAgIGF1dG9TY3JvbGw6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBkZWZhdWx0OiB2b2lkIDBcbiAgICB9LFxuICAgIGl0ZW1zRWxlbWVudDoge1xuICAgICAgdHlwZTogW1N0cmluZywgRnVuY3Rpb24sIE9iamVjdF0sXG4gICAgICBkZWZhdWx0OiBudWxsXG4gICAgfSxcbiAgICBzdGFydEVsZW1lbnQ6IHtcbiAgICAgIHR5cGU6IFtTdHJpbmcsIEZ1bmN0aW9uLCBPYmplY3RdLFxuICAgICAgZGVmYXVsdDogbnVsbFxuICAgIH0sXG4gICAgZW5kRWxlbWVudDoge1xuICAgICAgdHlwZTogW1N0cmluZywgRnVuY3Rpb24sIE9iamVjdF0sXG4gICAgICBkZWZhdWx0OiBudWxsXG4gICAgfSxcbiAgICBwYXJhbXM6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIGRlZmF1bHQ6ICgpID0+ICh7fSlcbiAgICB9XG4gIH0sXG4gIGluaGVyaXRBdHRyczogZmFsc2UsXG4gIHNldHVwKHByb3BzLCB7IHNsb3RzLCBhdHRycywgZXhwb3NlIH0pIHtcbiAgICBjb25zdCBpdGVtc0VsZW1lbnRSZWYgPSByZWY1KG51bGwpO1xuICAgIGNvbnN0IHN0YXJ0RWxlbWVudFJlZiA9IHJlZjUobnVsbCk7XG4gICAgY29uc3QgZW5kRWxlbWVudFJlZiA9IHJlZjUobnVsbCk7XG4gICAgY29uc3QgaXRlbXNFbGVtZW50ID0gY29tcHV0ZWQ0KFxuICAgICAgKCkgPT4gcmVzb2x2ZUhUTUxFbGVtZW50KHByb3BzLml0ZW1zRWxlbWVudCwgaXRlbXNFbGVtZW50UmVmLnZhbHVlKVxuICAgICk7XG4gICAgY29uc3Qgc2Nyb2xsYWJsZVBhcmVudCA9IGNvbXB1dGVkNCgoKSA9PiBnZXRTY3JvbGxhYmxlUGFyZW50KGl0ZW1zRWxlbWVudC52YWx1ZSkpO1xuICAgIGNvbnN0IHN0YXJ0RWxlbWVudCA9IGNvbXB1dGVkNChcbiAgICAgICgpID0+IHJlc29sdmVIVE1MRWxlbWVudChwcm9wcy5zdGFydEVsZW1lbnQsIHN0YXJ0RWxlbWVudFJlZi52YWx1ZSlcbiAgICApO1xuICAgIGNvbnN0IGVuZEVsZW1lbnQgPSBjb21wdXRlZDQoKCkgPT4gcmVzb2x2ZUhUTUxFbGVtZW50KHByb3BzLmVuZEVsZW1lbnQsIGVuZEVsZW1lbnRSZWYudmFsdWUpKTtcbiAgICBjb25zdCBsb2FkaW5nUHJldmlvdXMgPSByZWY1KGZhbHNlKTtcbiAgICBjb25zdCBsb2FkaW5nTmV4dCA9IHJlZjUoZmFsc2UpO1xuICAgIGNvbnN0IHJlcXVlc3RDb3VudCA9IHJlZjUoMCk7XG4gICAgY29uc3QgaGFzUHJldmlvdXNQYWdlID0gcmVmNShmYWxzZSk7XG4gICAgY29uc3QgaGFzTmV4dFBhZ2UgPSByZWY1KGZhbHNlKTtcbiAgICBjb25zdCBzeW5jU3RhdGVGcm9tRGF0YU1hbmFnZXIgPSAoKSA9PiB7XG4gICAgICByZXF1ZXN0Q291bnQudmFsdWUgPSBkYXRhTWFuYWdlci5nZXRSZXF1ZXN0Q291bnQoKTtcbiAgICAgIGhhc1ByZXZpb3VzUGFnZS52YWx1ZSA9IGRhdGFNYW5hZ2VyLmhhc1ByZXZpb3VzKCk7XG4gICAgICBoYXNOZXh0UGFnZS52YWx1ZSA9IGRhdGFNYW5hZ2VyLmhhc05leHQoKTtcbiAgICB9O1xuICAgIGNvbnN0IHtcbiAgICAgIGRhdGFNYW5hZ2VyLFxuICAgICAgZWxlbWVudE1hbmFnZXIsXG4gICAgICBmbHVzaDogZmx1c2hJbmZpbml0ZVNjcm9sbFxuICAgIH0gPSB1c2VJbmZpbml0ZVNjcm9sbCh7XG4gICAgICAvLyBEYXRhXG4gICAgICBnZXRQcm9wTmFtZTogKCkgPT4gcHJvcHMuZGF0YSxcbiAgICAgIGluUmV2ZXJzZU1vZGU6ICgpID0+IHByb3BzLnJldmVyc2UsXG4gICAgICBzaG91bGRGZXRjaE5leHQ6ICgpID0+ICFwcm9wcy5vbmx5UHJldmlvdXMsXG4gICAgICBzaG91bGRGZXRjaFByZXZpb3VzOiAoKSA9PiAhcHJvcHMub25seU5leHQsXG4gICAgICBzaG91bGRQcmVzZXJ2ZVVybDogKCkgPT4gcHJvcHMucHJlc2VydmVVcmwsXG4gICAgICBnZXRSZWxvYWRPcHRpb25zOiAoKSA9PiBwcm9wcy5wYXJhbXMsXG4gICAgICAvLyBFbGVtZW50c1xuICAgICAgZ2V0VHJpZ2dlck1hcmdpbjogKCkgPT4gcHJvcHMuYnVmZmVyLFxuICAgICAgZ2V0U3RhcnRFbGVtZW50OiAoKSA9PiBzdGFydEVsZW1lbnQudmFsdWUsXG4gICAgICBnZXRFbmRFbGVtZW50OiAoKSA9PiBlbmRFbGVtZW50LnZhbHVlLFxuICAgICAgZ2V0SXRlbXNFbGVtZW50OiAoKSA9PiBpdGVtc0VsZW1lbnQudmFsdWUsXG4gICAgICBnZXRTY3JvbGxhYmxlUGFyZW50OiAoKSA9PiBzY3JvbGxhYmxlUGFyZW50LnZhbHVlLFxuICAgICAgLy8gUmVxdWVzdCBjYWxsYmFja3NcbiAgICAgIG9uQmVmb3JlUHJldmlvdXNSZXF1ZXN0OiAoKSA9PiBsb2FkaW5nUHJldmlvdXMudmFsdWUgPSB0cnVlLFxuICAgICAgb25CZWZvcmVOZXh0UmVxdWVzdDogKCkgPT4gbG9hZGluZ05leHQudmFsdWUgPSB0cnVlLFxuICAgICAgb25Db21wbGV0ZVByZXZpb3VzUmVxdWVzdDogKHsgY29tcGxldGVkIH0pID0+IHtcbiAgICAgICAgbG9hZGluZ1ByZXZpb3VzLnZhbHVlID0gZmFsc2U7XG4gICAgICAgIGlmIChjb21wbGV0ZWQpIHtcbiAgICAgICAgICBzeW5jU3RhdGVGcm9tRGF0YU1hbmFnZXIoKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uQ29tcGxldGVOZXh0UmVxdWVzdDogKHsgY29tcGxldGVkIH0pID0+IHtcbiAgICAgICAgbG9hZGluZ05leHQudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgaWYgKGNvbXBsZXRlZCkge1xuICAgICAgICAgIHN5bmNTdGF0ZUZyb21EYXRhTWFuYWdlcigpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25EYXRhUmVzZXQ6IHN5bmNTdGF0ZUZyb21EYXRhTWFuYWdlclxuICAgIH0pO1xuICAgIHN5bmNTdGF0ZUZyb21EYXRhTWFuYWdlcigpO1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBjb25zdCBzY3JvbGxQcm9wID0gdXNlUGFnZSgpLnNjcm9sbFByb3BzPy5bcHJvcHMuZGF0YV07XG4gICAgICBpZiAoc2Nyb2xsUHJvcCkge1xuICAgICAgICBoYXNQcmV2aW91c1BhZ2UudmFsdWUgPSAhIXNjcm9sbFByb3AucHJldmlvdXNQYWdlO1xuICAgICAgICBoYXNOZXh0UGFnZS52YWx1ZSA9ICEhc2Nyb2xsUHJvcC5uZXh0UGFnZTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgYXV0b0xvYWQgPSBjb21wdXRlZDQoKCkgPT4gIW1hbnVhbE1vZGUudmFsdWUpO1xuICAgIGNvbnN0IG1hbnVhbE1vZGUgPSBjb21wdXRlZDQoXG4gICAgICAoKSA9PiBwcm9wcy5tYW51YWwgfHwgcHJvcHMubWFudWFsQWZ0ZXIgPiAwICYmIHJlcXVlc3RDb3VudC52YWx1ZSA+PSBwcm9wcy5tYW51YWxBZnRlclxuICAgICk7XG4gICAgY29uc3Qgc2Nyb2xsVG9Cb3R0b20gPSAoKSA9PiB7XG4gICAgICBpZiAoc2Nyb2xsYWJsZVBhcmVudC52YWx1ZSkge1xuICAgICAgICBzY3JvbGxhYmxlUGFyZW50LnZhbHVlLnNjcm9sbFRvKHtcbiAgICAgICAgICB0b3A6IHNjcm9sbGFibGVQYXJlbnQudmFsdWUuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgIGJlaGF2aW9yOiBcImluc3RhbnRcIlxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7XG4gICAgICAgICAgdG9wOiBkb2N1bWVudC5ib2R5LnNjcm9sbEhlaWdodCxcbiAgICAgICAgICBiZWhhdmlvcjogXCJpbnN0YW50XCJcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBvbk1vdW50ZWQzKCgpID0+IHtcbiAgICAgIGVsZW1lbnRNYW5hZ2VyLnNldHVwT2JzZXJ2ZXJzKCk7XG4gICAgICBlbGVtZW50TWFuYWdlci5wcm9jZXNzU2VydmVyTG9hZGVkRWxlbWVudHMoZGF0YU1hbmFnZXIuZ2V0TGFzdExvYWRlZFBhZ2UoKSk7XG4gICAgICBjb25zdCBzaG91bGRBdXRvU2Nyb2xsID0gcHJvcHMuYXV0b1Njcm9sbCAhPT0gdm9pZCAwID8gcHJvcHMuYXV0b1Njcm9sbCA6IHByb3BzLnJldmVyc2U7XG4gICAgICBpZiAoc2hvdWxkQXV0b1Njcm9sbCkge1xuICAgICAgICBzY3JvbGxUb0JvdHRvbSgpO1xuICAgICAgfVxuICAgICAgaWYgKGF1dG9Mb2FkLnZhbHVlKSB7XG4gICAgICAgIGVsZW1lbnRNYW5hZ2VyLmVuYWJsZVRyaWdnZXJzKCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgb25Vbm1vdW50ZWQyKGZsdXNoSW5maW5pdGVTY3JvbGwpO1xuICAgIHdhdGNoMyhcbiAgICAgICgpID0+IFthdXRvTG9hZC52YWx1ZSwgcHJvcHMub25seU5leHQsIHByb3BzLm9ubHlQcmV2aW91c10sXG4gICAgICAoW2VuYWJsZWRdKSA9PiB7XG4gICAgICAgIGVuYWJsZWQgPyBlbGVtZW50TWFuYWdlci5lbmFibGVUcmlnZ2VycygpIDogZWxlbWVudE1hbmFnZXIuZGlzYWJsZVRyaWdnZXJzKCk7XG4gICAgICB9XG4gICAgKTtcbiAgICBleHBvc2Uoe1xuICAgICAgZmV0Y2hOZXh0OiBkYXRhTWFuYWdlci5mZXRjaE5leHQsXG4gICAgICBmZXRjaFByZXZpb3VzOiBkYXRhTWFuYWdlci5mZXRjaFByZXZpb3VzLFxuICAgICAgaGFzUHJldmlvdXM6IGRhdGFNYW5hZ2VyLmhhc1ByZXZpb3VzLFxuICAgICAgaGFzTmV4dDogZGF0YU1hbmFnZXIuaGFzTmV4dFxuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjb25zdCByZW5kZXJFbGVtZW50cyA9IFtdO1xuICAgICAgY29uc3Qgc2hhcmVkRXhwb3NlZCA9IHtcbiAgICAgICAgbG9hZGluZ1ByZXZpb3VzOiBsb2FkaW5nUHJldmlvdXMudmFsdWUsXG4gICAgICAgIGxvYWRpbmdOZXh0OiBsb2FkaW5nTmV4dC52YWx1ZSxcbiAgICAgICAgaGFzUHJldmlvdXM6IGhhc1ByZXZpb3VzUGFnZS52YWx1ZSxcbiAgICAgICAgaGFzTmV4dDogaGFzTmV4dFBhZ2UudmFsdWVcbiAgICAgIH07XG4gICAgICBpZiAoIXByb3BzLnN0YXJ0RWxlbWVudCkge1xuICAgICAgICBjb25zdCBoZWFkZXJBdXRvTW9kZSA9IGF1dG9Mb2FkLnZhbHVlICYmICFwcm9wcy5vbmx5TmV4dDtcbiAgICAgICAgY29uc3QgZXhwb3NlZFByZXZpb3VzID0ge1xuICAgICAgICAgIGxvYWRpbmc6IGxvYWRpbmdQcmV2aW91cy52YWx1ZSxcbiAgICAgICAgICBmZXRjaDogZGF0YU1hbmFnZXIuZmV0Y2hQcmV2aW91cyxcbiAgICAgICAgICBhdXRvTW9kZTogaGVhZGVyQXV0b01vZGUsXG4gICAgICAgICAgbWFudWFsTW9kZTogIWhlYWRlckF1dG9Nb2RlLFxuICAgICAgICAgIGhhc01vcmU6IGhhc1ByZXZpb3VzUGFnZS52YWx1ZSxcbiAgICAgICAgICAuLi5zaGFyZWRFeHBvc2VkXG4gICAgICAgIH07XG4gICAgICAgIHJlbmRlckVsZW1lbnRzLnB1c2goXG4gICAgICAgICAgaDUoXG4gICAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgICAgeyByZWY6IHN0YXJ0RWxlbWVudFJlZiB9LFxuICAgICAgICAgICAgc2xvdHMucHJldmlvdXMgPyBzbG90cy5wcmV2aW91cyhleHBvc2VkUHJldmlvdXMpIDogbG9hZGluZ1ByZXZpb3VzLnZhbHVlID8gc2xvdHMubG9hZGluZz8uKGV4cG9zZWRQcmV2aW91cykgOiB2b2lkIDBcbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZW5kZXJFbGVtZW50cy5wdXNoKFxuICAgICAgICBoNShcbiAgICAgICAgICBwcm9wcy5hcyxcbiAgICAgICAgICB7IC4uLmF0dHJzLCByZWY6IGl0ZW1zRWxlbWVudFJlZiB9LFxuICAgICAgICAgIHNsb3RzLmRlZmF1bHQ/Lih7XG4gICAgICAgICAgICBsb2FkaW5nOiBsb2FkaW5nUHJldmlvdXMudmFsdWUgfHwgbG9hZGluZ05leHQudmFsdWUsXG4gICAgICAgICAgICBsb2FkaW5nUHJldmlvdXM6IGxvYWRpbmdQcmV2aW91cy52YWx1ZSxcbiAgICAgICAgICAgIGxvYWRpbmdOZXh0OiBsb2FkaW5nTmV4dC52YWx1ZVxuICAgICAgICAgIH0pXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgICBpZiAoIXByb3BzLmVuZEVsZW1lbnQpIHtcbiAgICAgICAgY29uc3QgZm9vdGVyQXV0b01vZGUgPSBhdXRvTG9hZC52YWx1ZSAmJiAhcHJvcHMub25seVByZXZpb3VzO1xuICAgICAgICBjb25zdCBleHBvc2VkTmV4dCA9IHtcbiAgICAgICAgICBsb2FkaW5nOiBsb2FkaW5nTmV4dC52YWx1ZSxcbiAgICAgICAgICBmZXRjaDogZGF0YU1hbmFnZXIuZmV0Y2hOZXh0LFxuICAgICAgICAgIGF1dG9Nb2RlOiBmb290ZXJBdXRvTW9kZSxcbiAgICAgICAgICBtYW51YWxNb2RlOiAhZm9vdGVyQXV0b01vZGUsXG4gICAgICAgICAgaGFzTW9yZTogaGFzTmV4dFBhZ2UudmFsdWUsXG4gICAgICAgICAgLi4uc2hhcmVkRXhwb3NlZFxuICAgICAgICB9O1xuICAgICAgICByZW5kZXJFbGVtZW50cy5wdXNoKFxuICAgICAgICAgIGg1KFxuICAgICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICAgIHsgcmVmOiBlbmRFbGVtZW50UmVmIH0sXG4gICAgICAgICAgICBzbG90cy5uZXh0ID8gc2xvdHMubmV4dChleHBvc2VkTmV4dCkgOiBsb2FkaW5nTmV4dC52YWx1ZSA/IHNsb3RzLmxvYWRpbmc/LihleHBvc2VkTmV4dCkgOiB2b2lkIDBcbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gaDUoRnJhZ21lbnQyLCB7fSwgcHJvcHMucmV2ZXJzZSA/IFsuLi5yZW5kZXJFbGVtZW50c10ucmV2ZXJzZSgpIDogcmVuZGVyRWxlbWVudHMpO1xuICAgIH07XG4gIH1cbn0pO1xudmFyIGluZmluaXRlU2Nyb2xsX2RlZmF1bHQgPSBJbmZpbml0ZVNjcm9sbDtcblxuLy8gc3JjL2xpbmsudHNcbmltcG9ydCB7XG4gIGlzVXJsTWV0aG9kUGFpciBhcyBpc1VybE1ldGhvZFBhaXIyLFxuICBtZXJnZURhdGFJbnRvUXVlcnlTdHJpbmcgYXMgbWVyZ2VEYXRhSW50b1F1ZXJ5U3RyaW5nMixcbiAgcmVzb2x2ZVVybE1ldGhvZFBhaXJDb21wb25lbnQgYXMgcmVzb2x2ZVVybE1ldGhvZFBhaXJDb21wb25lbnQyLFxuICByb3V0ZXIgYXMgcm91dGVyNyxcbiAgc2hvdWxkSW50ZXJjZXB0LFxuICBzaG91bGROYXZpZ2F0ZVxufSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBjb21wdXRlZCBhcyBjb21wdXRlZDUsIGRlZmluZUNvbXBvbmVudCBhcyBkZWZpbmVDb21wb25lbnQ2LCBoIGFzIGg2LCBvbk1vdW50ZWQgYXMgb25Nb3VudGVkNCwgb25Vbm1vdW50ZWQgYXMgb25Vbm1vdW50ZWQzLCByZWYgYXMgcmVmNiB9IGZyb20gXCJ2dWVcIjtcbnZhciBub29wMiA9ICgpID0+IHtcbn07XG52YXIgTGluayA9IGRlZmluZUNvbXBvbmVudDYoe1xuICBuYW1lOiBcIkxpbmtcIixcbiAgcHJvcHM6IHtcbiAgICBhczoge1xuICAgICAgdHlwZTogW1N0cmluZywgT2JqZWN0XSxcbiAgICAgIGRlZmF1bHQ6IFwiYVwiXG4gICAgfSxcbiAgICBkYXRhOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBkZWZhdWx0OiAoKSA9PiAoe30pXG4gICAgfSxcbiAgICBocmVmOiB7XG4gICAgICB0eXBlOiBbU3RyaW5nLCBPYmplY3RdLFxuICAgICAgZGVmYXVsdDogXCJcIlxuICAgIH0sXG4gICAgbWV0aG9kOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBkZWZhdWx0OiBcImdldFwiXG4gICAgfSxcbiAgICByZXBsYWNlOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9LFxuICAgIHByZXNlcnZlU2Nyb2xsOiB7XG4gICAgICB0eXBlOiBbQm9vbGVhbiwgU3RyaW5nLCBGdW5jdGlvbl0sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgcHJlc2VydmVTdGF0ZToge1xuICAgICAgdHlwZTogW0Jvb2xlYW4sIFN0cmluZywgRnVuY3Rpb25dLFxuICAgICAgZGVmYXVsdDogbnVsbFxuICAgIH0sXG4gICAgcHJlc2VydmVVcmw6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgb25seToge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICBkZWZhdWx0OiAoKSA9PiBbXVxuICAgIH0sXG4gICAgZXhjZXB0OiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIGRlZmF1bHQ6ICgpID0+IFtdXG4gICAgfSxcbiAgICBoZWFkZXJzOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBkZWZhdWx0OiAoKSA9PiAoe30pXG4gICAgfSxcbiAgICBxdWVyeVN0cmluZ0FycmF5Rm9ybWF0OiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBkZWZhdWx0OiBcImJyYWNrZXRzXCJcbiAgICB9LFxuICAgIGFzeW5jOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9LFxuICAgIHByZWZldGNoOiB7XG4gICAgICB0eXBlOiBbQm9vbGVhbiwgU3RyaW5nLCBBcnJheV0sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgY2FjaGVGb3I6IHtcbiAgICAgIHR5cGU6IFtOdW1iZXIsIFN0cmluZywgQXJyYXldLFxuICAgICAgZGVmYXVsdDogMFxuICAgIH0sXG4gICAgb25TdGFydDoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiBub29wMlxuICAgIH0sXG4gICAgb25Qcm9ncmVzczoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiBub29wMlxuICAgIH0sXG4gICAgb25GaW5pc2g6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgZGVmYXVsdDogbm9vcDJcbiAgICB9LFxuICAgIG9uQmVmb3JlOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3AyXG4gICAgfSxcbiAgICBvbkNhbmNlbDoge1xuICAgICAgdHlwZTogRnVuY3Rpb24sXG4gICAgICBkZWZhdWx0OiBub29wMlxuICAgIH0sXG4gICAgb25TdWNjZXNzOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3AyXG4gICAgfSxcbiAgICBvbkVycm9yOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3AyXG4gICAgfSxcbiAgICBvbkNhbmNlbFRva2VuOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3AyXG4gICAgfSxcbiAgICBvblByZWZldGNoaW5nOiB7XG4gICAgICB0eXBlOiBGdW5jdGlvbixcbiAgICAgIGRlZmF1bHQ6IG5vb3AyXG4gICAgfSxcbiAgICBvblByZWZldGNoZWQ6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgZGVmYXVsdDogbm9vcDJcbiAgICB9LFxuICAgIGNhY2hlVGFnczoge1xuICAgICAgdHlwZTogW1N0cmluZywgQXJyYXldLFxuICAgICAgZGVmYXVsdDogKCkgPT4gW11cbiAgICB9LFxuICAgIHZpZXdUcmFuc2l0aW9uOiB7XG4gICAgICB0eXBlOiBbQm9vbGVhbiwgT2JqZWN0XSxcbiAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgfSxcbiAgICBjb21wb25lbnQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGRlZmF1bHQ6IG51bGxcbiAgICB9LFxuICAgIGluc3RhbnQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgIH0sXG4gICAgcGFnZVByb3BzOiB7XG4gICAgICB0eXBlOiBbT2JqZWN0LCBGdW5jdGlvbl0sXG4gICAgICBkZWZhdWx0OiBudWxsXG4gICAgfVxuICB9LFxuICBzZXR1cChwcm9wcywgeyBzbG90cywgYXR0cnMgfSkge1xuICAgIGNvbnN0IGluRmxpZ2h0Q291bnQgPSByZWY2KDApO1xuICAgIGNvbnN0IGhvdmVyVGltZW91dCA9IHJlZjYoKTtcbiAgICBjb25zdCBwcmVmZXRjaE1vZGVzID0gY29tcHV0ZWQ1KCgpID0+IHtcbiAgICAgIGlmIChwcm9wcy5wcmVmZXRjaCA9PT0gdHJ1ZSkge1xuICAgICAgICByZXR1cm4gW1wiaG92ZXJcIl07XG4gICAgICB9XG4gICAgICBpZiAocHJvcHMucHJlZmV0Y2ggPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHByb3BzLnByZWZldGNoKSkge1xuICAgICAgICByZXR1cm4gcHJvcHMucHJlZmV0Y2g7XG4gICAgICB9XG4gICAgICByZXR1cm4gW3Byb3BzLnByZWZldGNoXTtcbiAgICB9KTtcbiAgICBjb25zdCBjYWNoZUZvclZhbHVlID0gY29tcHV0ZWQ1KCgpID0+IHtcbiAgICAgIGlmIChwcm9wcy5jYWNoZUZvciAhPT0gMCkge1xuICAgICAgICByZXR1cm4gcHJvcHMuY2FjaGVGb3I7XG4gICAgICB9XG4gICAgICBpZiAocHJlZmV0Y2hNb2Rlcy52YWx1ZS5sZW5ndGggPT09IDEgJiYgcHJlZmV0Y2hNb2Rlcy52YWx1ZVswXSA9PT0gXCJjbGlja1wiKSB7XG4gICAgICAgIHJldHVybiAwO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNvbmZpZy5nZXQoXCJwcmVmZXRjaC5jYWNoZUZvclwiKTtcbiAgICB9KTtcbiAgICBvbk1vdW50ZWQ0KCgpID0+IHtcbiAgICAgIGlmIChwcmVmZXRjaE1vZGVzLnZhbHVlLmluY2x1ZGVzKFwibW91bnRcIikpIHtcbiAgICAgICAgcHJlZmV0Y2goKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBvblVubW91bnRlZDMoKCkgPT4ge1xuICAgICAgY2xlYXJUaW1lb3V0KGhvdmVyVGltZW91dC52YWx1ZSk7XG4gICAgfSk7XG4gICAgY29uc3QgbWV0aG9kID0gY29tcHV0ZWQ1KFxuICAgICAgKCkgPT4gaXNVcmxNZXRob2RQYWlyMihwcm9wcy5ocmVmKSA/IHByb3BzLmhyZWYubWV0aG9kIDogKHByb3BzLm1ldGhvZCA/PyBcImdldFwiKS50b0xvd2VyQ2FzZSgpXG4gICAgKTtcbiAgICBjb25zdCBhcyA9IGNvbXB1dGVkNSgoKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIHByb3BzLmFzICE9PSBcInN0cmluZ1wiIHx8IHByb3BzLmFzLnRvTG93ZXJDYXNlKCkgIT09IFwiYVwiKSB7XG4gICAgICAgIHJldHVybiBwcm9wcy5hcztcbiAgICAgIH1cbiAgICAgIHJldHVybiBtZXRob2QudmFsdWUgIT09IFwiZ2V0XCIgPyBcImJ1dHRvblwiIDogcHJvcHMuYXMudG9Mb3dlckNhc2UoKTtcbiAgICB9KTtcbiAgICBjb25zdCBtZXJnZURhdGFBcnJheSA9IGNvbXB1dGVkNShcbiAgICAgICgpID0+IG1lcmdlRGF0YUludG9RdWVyeVN0cmluZzIoXG4gICAgICAgIG1ldGhvZC52YWx1ZSxcbiAgICAgICAgaXNVcmxNZXRob2RQYWlyMihwcm9wcy5ocmVmKSA/IHByb3BzLmhyZWYudXJsIDogcHJvcHMuaHJlZixcbiAgICAgICAgcHJvcHMuZGF0YSB8fCB7fSxcbiAgICAgICAgcHJvcHMucXVlcnlTdHJpbmdBcnJheUZvcm1hdFxuICAgICAgKVxuICAgICk7XG4gICAgY29uc3QgaHJlZiA9IGNvbXB1dGVkNSgoKSA9PiBtZXJnZURhdGFBcnJheS52YWx1ZVswXSk7XG4gICAgY29uc3QgZGF0YSA9IGNvbXB1dGVkNSgoKSA9PiBtZXJnZURhdGFBcnJheS52YWx1ZVsxXSk7XG4gICAgY29uc3QgcmVzb2x2ZWRDb21wb25lbnQgPSBjb21wdXRlZDUoKCkgPT4ge1xuICAgICAgaWYgKHByb3BzLmNvbXBvbmVudCkge1xuICAgICAgICByZXR1cm4gcHJvcHMuY29tcG9uZW50O1xuICAgICAgfVxuICAgICAgaWYgKHByb3BzLmluc3RhbnQgJiYgaXNVcmxNZXRob2RQYWlyMihwcm9wcy5ocmVmKSkge1xuICAgICAgICByZXR1cm4gcmVzb2x2ZVVybE1ldGhvZFBhaXJDb21wb25lbnQyKHByb3BzLmhyZWYpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfSk7XG4gICAgY29uc3QgZWxQcm9wcyA9IGNvbXB1dGVkNSgoKSA9PiB7XG4gICAgICBpZiAoYXMudmFsdWUgPT09IFwiYnV0dG9uXCIpIHtcbiAgICAgICAgcmV0dXJuIHsgdHlwZTogXCJidXR0b25cIiB9O1xuICAgICAgfVxuICAgICAgaWYgKGFzLnZhbHVlID09PSBcImFcIiB8fCB0eXBlb2YgYXMudmFsdWUgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHsgaHJlZjogaHJlZi52YWx1ZSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH0pO1xuICAgIGNvbnN0IGJhc2VQYXJhbXMgPSBjb21wdXRlZDUoKCkgPT4gKHtcbiAgICAgIGRhdGE6IGRhdGEudmFsdWUsXG4gICAgICBtZXRob2Q6IG1ldGhvZC52YWx1ZSxcbiAgICAgIHJlcGxhY2U6IHByb3BzLnJlcGxhY2UsXG4gICAgICBwcmVzZXJ2ZVNjcm9sbDogcHJvcHMucHJlc2VydmVTY3JvbGwsXG4gICAgICBwcmVzZXJ2ZVN0YXRlOiBwcm9wcy5wcmVzZXJ2ZVN0YXRlID8/IG1ldGhvZC52YWx1ZSAhPT0gXCJnZXRcIixcbiAgICAgIHByZXNlcnZlVXJsOiBwcm9wcy5wcmVzZXJ2ZVVybCxcbiAgICAgIG9ubHk6IHByb3BzLm9ubHksXG4gICAgICBleGNlcHQ6IHByb3BzLmV4Y2VwdCxcbiAgICAgIGhlYWRlcnM6IHByb3BzLmhlYWRlcnMsXG4gICAgICBhc3luYzogcHJvcHMuYXN5bmMsXG4gICAgICBjb21wb25lbnQ6IHJlc29sdmVkQ29tcG9uZW50LnZhbHVlLFxuICAgICAgcGFnZVByb3BzOiBwcm9wcy5wYWdlUHJvcHNcbiAgICB9KSk7XG4gICAgY29uc3QgdmlzaXRQYXJhbXMgPSBjb21wdXRlZDUoKCkgPT4gKHtcbiAgICAgIC4uLmJhc2VQYXJhbXMudmFsdWUsXG4gICAgICB2aWV3VHJhbnNpdGlvbjogcHJvcHMudmlld1RyYW5zaXRpb24sXG4gICAgICBvbkNhbmNlbFRva2VuOiBwcm9wcy5vbkNhbmNlbFRva2VuLFxuICAgICAgb25CZWZvcmU6IHByb3BzLm9uQmVmb3JlLFxuICAgICAgb25TdGFydDogKHZpc2l0KSA9PiB7XG4gICAgICAgIGluRmxpZ2h0Q291bnQudmFsdWUrKztcbiAgICAgICAgcHJvcHMub25TdGFydD8uKHZpc2l0KTtcbiAgICAgIH0sXG4gICAgICBvblByb2dyZXNzOiBwcm9wcy5vblByb2dyZXNzLFxuICAgICAgb25GaW5pc2g6ICh2aXNpdCkgPT4ge1xuICAgICAgICBpbkZsaWdodENvdW50LnZhbHVlLS07XG4gICAgICAgIHByb3BzLm9uRmluaXNoPy4odmlzaXQpO1xuICAgICAgfSxcbiAgICAgIG9uQ2FuY2VsOiBwcm9wcy5vbkNhbmNlbCxcbiAgICAgIG9uU3VjY2VzczogcHJvcHMub25TdWNjZXNzLFxuICAgICAgb25FcnJvcjogcHJvcHMub25FcnJvclxuICAgIH0pKTtcbiAgICBjb25zdCBwcmVmZXRjaCA9ICgpID0+IHtcbiAgICAgIHJvdXRlcjcucHJlZmV0Y2goXG4gICAgICAgIGhyZWYudmFsdWUsXG4gICAgICAgIHtcbiAgICAgICAgICAuLi5iYXNlUGFyYW1zLnZhbHVlLFxuICAgICAgICAgIG9uUHJlZmV0Y2hpbmc6IHByb3BzLm9uUHJlZmV0Y2hpbmcsXG4gICAgICAgICAgb25QcmVmZXRjaGVkOiBwcm9wcy5vblByZWZldGNoZWRcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGNhY2hlRm9yOiBjYWNoZUZvclZhbHVlLnZhbHVlLFxuICAgICAgICAgIGNhY2hlVGFnczogcHJvcHMuY2FjaGVUYWdzXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfTtcbiAgICBjb25zdCByZWd1bGFyRXZlbnRzID0ge1xuICAgICAgb25DbGljazogKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChzaG91bGRJbnRlcmNlcHQoZXZlbnQpKSB7XG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICByb3V0ZXI3LnZpc2l0KGhyZWYudmFsdWUsIHZpc2l0UGFyYW1zLnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgcHJlZmV0Y2hIb3ZlckV2ZW50cyA9IHtcbiAgICAgIG9uTW91c2VlbnRlcjogKCkgPT4ge1xuICAgICAgICBob3ZlclRpbWVvdXQudmFsdWUgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBwcmVmZXRjaCgpO1xuICAgICAgICB9LCBjb25maWcuZ2V0KFwicHJlZmV0Y2guaG92ZXJEZWxheVwiKSk7XG4gICAgICB9LFxuICAgICAgb25Nb3VzZWxlYXZlOiAoKSA9PiB7XG4gICAgICAgIGNsZWFyVGltZW91dChob3ZlclRpbWVvdXQudmFsdWUpO1xuICAgICAgfSxcbiAgICAgIG9uQ2xpY2s6IChldmVudCkgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQoaG92ZXJUaW1lb3V0LnZhbHVlKTtcbiAgICAgICAgcmVndWxhckV2ZW50cy5vbkNsaWNrKGV2ZW50KTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHByZWZldGNoQ2xpY2tFdmVudHMgPSB7XG4gICAgICBvbk1vdXNlZG93bjogKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChzaG91bGRJbnRlcmNlcHQoZXZlbnQpKSB7XG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBwcmVmZXRjaCgpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25LZXlkb3duOiAoZXZlbnQpID0+IHtcbiAgICAgICAgaWYgKHNob3VsZE5hdmlnYXRlKGV2ZW50KSkge1xuICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgcHJlZmV0Y2goKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uTW91c2V1cDogKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChzaG91bGRJbnRlcmNlcHQoZXZlbnQpKSB7XG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICByb3V0ZXI3LnZpc2l0KGhyZWYudmFsdWUsIHZpc2l0UGFyYW1zLnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uS2V5dXA6IChldmVudCkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkTmF2aWdhdGUoZXZlbnQpKSB7XG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICByb3V0ZXI3LnZpc2l0KGhyZWYudmFsdWUsIHZpc2l0UGFyYW1zLnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uQ2xpY2s6IChldmVudCkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkSW50ZXJjZXB0KGV2ZW50KSkge1xuICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICByZXR1cm4gaDYoXG4gICAgICAgIGFzLnZhbHVlLFxuICAgICAgICB7XG4gICAgICAgICAgLi4uYXR0cnMsXG4gICAgICAgICAgLi4uZWxQcm9wcy52YWx1ZSxcbiAgICAgICAgICBcImRhdGEtbG9hZGluZ1wiOiBpbkZsaWdodENvdW50LnZhbHVlID4gMCA/IFwiXCIgOiB2b2lkIDAsXG4gICAgICAgICAgLi4uKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChwcmVmZXRjaE1vZGVzLnZhbHVlLmluY2x1ZGVzKFwiaG92ZXJcIikpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHByZWZldGNoSG92ZXJFdmVudHM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJlZmV0Y2hNb2Rlcy52YWx1ZS5pbmNsdWRlcyhcImNsaWNrXCIpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBwcmVmZXRjaENsaWNrRXZlbnRzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlZ3VsYXJFdmVudHM7XG4gICAgICAgICAgfSkoKVxuICAgICAgICB9LFxuICAgICAgICBzbG90c1xuICAgICAgKTtcbiAgICB9O1xuICB9XG59KTtcbnZhciBsaW5rX2RlZmF1bHQgPSBMaW5rO1xuXG4vLyBzcmMvdXNlSHR0cC50c1xuaW1wb3J0IHtcbiAgaGFzRmlsZXMsXG4gIGh0dHAsXG4gIEh0dHBDYW5jZWxsZWRFcnJvcixcbiAgSHR0cFJlc3BvbnNlRXJyb3IsXG4gIG1lcmdlRGF0YUludG9RdWVyeVN0cmluZyBhcyBtZXJnZURhdGFJbnRvUXVlcnlTdHJpbmczLFxuICBvYmplY3RUb0Zvcm1EYXRhLFxuICBVc2VGb3JtVXRpbHMgYXMgVXNlRm9ybVV0aWxzNFxufSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBjbG9uZURlZXAgYXMgY2xvbmVEZWVwNCB9IGZyb20gXCJlcy10b29sa2l0XCI7XG5pbXBvcnQgeyB0b1NpbXBsZVZhbGlkYXRpb25FcnJvcnMgYXMgdG9TaW1wbGVWYWxpZGF0aW9uRXJyb3JzMiB9IGZyb20gXCJsYXJhdmVsLXByZWNvZ25pdGlvblwiO1xuZnVuY3Rpb24gdXNlSHR0cCguLi5hcmdzKSB7XG4gIGNvbnN0IHsgcmVtZW1iZXJLZXksIGRhdGEsIHByZWNvZ25pdGlvbkVuZHBvaW50IH0gPSBVc2VGb3JtVXRpbHM0LnBhcnNlVXNlRm9ybUFyZ3VtZW50cyguLi5hcmdzKTtcbiAgbGV0IGFib3J0Q29udHJvbGxlciA9IG51bGw7XG4gIGxldCBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID0gbnVsbDtcbiAgY29uc3Qge1xuICAgIGZvcm06IGJhc2VGb3JtLFxuICAgIHNldERlZmF1bHRzLFxuICAgIGdldFRyYW5zZm9ybSxcbiAgICBnZXRQcmVjb2duaXRpb25FbmRwb2ludCxcbiAgICBtYXJrQXNTdWNjZXNzZnVsLFxuICAgIHdhc0RlZmF1bHRzQ2FsbGVkSW5PblN1Y2Nlc3MsXG4gICAgcmVzZXREZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzLFxuICAgIHNldFJlbWVtYmVyRXhjbHVkZUtleXMsXG4gICAgcmVzZXRCZWZvcmVTdWJtaXQsXG4gICAgZmluaXNoUHJvY2Vzc2luZyxcbiAgICB3aXRoQWxsRXJyb3JzXG4gIH0gPSB1c2VGb3JtU3RhdGUoe1xuICAgIGRhdGEsXG4gICAgcmVtZW1iZXJLZXksXG4gICAgcHJlY29nbml0aW9uRW5kcG9pbnRcbiAgfSk7XG4gIGNvbnN0IGZvcm0gPSBiYXNlRm9ybTtcbiAgZm9ybS5yZXNwb25zZSA9IG51bGw7XG4gIGNvbnN0IHN1Ym1pdCA9IGFzeW5jIChtZXRob2QsIHVybCwgb3B0aW9ucykgPT4ge1xuICAgIGNvbnN0IG9uQmVmb3JlID0gb3B0aW9ucy5vbkJlZm9yZT8uKCk7XG4gICAgaWYgKG9uQmVmb3JlID09PSBmYWxzZSkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcIlJlcXVlc3QgY2FuY2VsbGVkIGJ5IG9uQmVmb3JlXCIpKTtcbiAgICB9XG4gICAgcmVzZXREZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzKCk7XG4gICAgcmVzZXRCZWZvcmVTdWJtaXQoKTtcbiAgICBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgY29uc3QgY2FuY2VsVG9rZW4gPSB7XG4gICAgICBjYW5jZWw6ICgpID0+IGFib3J0Q29udHJvbGxlcj8uYWJvcnQoKVxuICAgIH07XG4gICAgb3B0aW9ucy5vbkNhbmNlbFRva2VuPy4oY2FuY2VsVG9rZW4pO1xuICAgIG9wdGlvbnMub3B0aW1pc3RpYyA9IG9wdGlvbnMub3B0aW1pc3RpYyA/PyBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID8/IHZvaWQgMDtcbiAgICBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID0gbnVsbDtcbiAgICBsZXQgc25hcHNob3Q7XG4gICAgaWYgKG9wdGlvbnMub3B0aW1pc3RpYykge1xuICAgICAgc25hcHNob3QgPSBjbG9uZURlZXA0KGZvcm0uZGF0YSgpKTtcbiAgICAgIGNvbnN0IG9wdGltaXN0aWNEYXRhID0gb3B0aW9ucy5vcHRpbWlzdGljKGNsb25lRGVlcDQoc25hcHNob3QpKTtcbiAgICAgIGlmIChvcHRpbWlzdGljRGF0YSkge1xuICAgICAgICBPYmplY3Qua2V5cyhvcHRpbWlzdGljRGF0YSkuZm9yRWFjaCgoa2V5MikgPT4ge1xuICAgICAgICAgIDtcbiAgICAgICAgICBmb3JtW2tleTJdID0gb3B0aW1pc3RpY0RhdGFba2V5Ml07XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3JtLnByb2Nlc3NpbmcgPSB0cnVlO1xuICAgIG9wdGlvbnMub25TdGFydD8uKCk7XG4gICAgY29uc3QgdHJhbnNmb3JtID0gZ2V0VHJhbnNmb3JtKCk7XG4gICAgY29uc3QgdHJhbnNmb3JtZWREYXRhID0gdHJhbnNmb3JtKGZvcm0uZGF0YSgpKTtcbiAgICBjb25zdCB1c2VGb3JtRGF0YSA9IGhhc0ZpbGVzKHRyYW5zZm9ybWVkRGF0YSk7XG4gICAgbGV0IHJlcXVlc3RVcmwgPSB1cmw7XG4gICAgbGV0IHJlcXVlc3REYXRhO1xuICAgIGxldCBjb250ZW50VHlwZTtcbiAgICBpZiAobWV0aG9kID09PSBcImdldFwiKSB7XG4gICAgICBjb25zdCBbdXJsV2l0aFBhcmFtc10gPSBtZXJnZURhdGFJbnRvUXVlcnlTdHJpbmczKFxuICAgICAgICBtZXRob2QsXG4gICAgICAgIHVybCxcbiAgICAgICAgdHJhbnNmb3JtZWREYXRhXG4gICAgICApO1xuICAgICAgcmVxdWVzdFVybCA9IHVybFdpdGhQYXJhbXM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh1c2VGb3JtRGF0YSkge1xuICAgICAgICByZXF1ZXN0RGF0YSA9IG9iamVjdFRvRm9ybURhdGEodHJhbnNmb3JtZWREYXRhKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlcXVlc3REYXRhID0gSlNPTi5zdHJpbmdpZnkodHJhbnNmb3JtZWREYXRhKTtcbiAgICAgICAgY29udGVudFR5cGUgPSBcImFwcGxpY2F0aW9uL2pzb25cIjtcbiAgICAgIH1cbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgaHR0cC5nZXRDbGllbnQoKS5yZXF1ZXN0KHtcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICB1cmw6IHJlcXVlc3RVcmwsXG4gICAgICAgIGRhdGE6IHJlcXVlc3REYXRhLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICAuLi5jb250ZW50VHlwZSA/IHsgXCJDb250ZW50LVR5cGVcIjogY29udGVudFR5cGUgfSA6IHt9LFxuICAgICAgICAgIC4uLm9wdGlvbnMuaGVhZGVyc1xuICAgICAgICB9LFxuICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXG4gICAgICAgIG9uVXBsb2FkUHJvZ3Jlc3M6IChldmVudCkgPT4ge1xuICAgICAgICAgIGZvcm0ucHJvZ3Jlc3MgPSBldmVudDtcbiAgICAgICAgICBvcHRpb25zLm9uUHJvZ3Jlc3M/LihldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2UuZGF0YSA/IEpTT04ucGFyc2UocmVzcG9uc2UuZGF0YSkgOiBudWxsO1xuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSAyMDAgJiYgcmVzcG9uc2Uuc3RhdHVzIDwgMzAwKSB7XG4gICAgICAgIG1hcmtBc1N1Y2Nlc3NmdWwoKTtcbiAgICAgICAgZm9ybS5yZXNwb25zZSA9IHJlc3BvbnNlRGF0YTtcbiAgICAgICAgb3B0aW9ucy5vblN1Y2Nlc3M/LihyZXNwb25zZURhdGEsIHJlc3BvbnNlKTtcbiAgICAgICAgaWYgKCF3YXNEZWZhdWx0c0NhbGxlZEluT25TdWNjZXNzKCkpIHtcbiAgICAgICAgICBzZXREZWZhdWx0cyhjbG9uZURlZXA0KGZvcm0uZGF0YSgpKSk7XG4gICAgICAgIH1cbiAgICAgICAgZm9ybS5pc0RpcnR5ID0gZmFsc2U7XG4gICAgICAgIHJldHVybiByZXNwb25zZURhdGE7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgSHR0cFJlc3BvbnNlRXJyb3IoYFJlcXVlc3QgZmFpbGVkIHdpdGggc3RhdHVzICR7cmVzcG9uc2Uuc3RhdHVzfWAsIHJlc3BvbnNlLCB1cmwpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoc25hcHNob3QpIHtcbiAgICAgICAgT2JqZWN0LmtleXMoc25hcHNob3QpLmZvckVhY2goKGtleTIpID0+IHtcbiAgICAgICAgICA7XG4gICAgICAgICAgZm9ybVtrZXkyXSA9IHNuYXBzaG90W2tleTJdO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEh0dHBSZXNwb25zZUVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvci5yZXNwb25zZS5zdGF0dXMgPT09IDQyMikge1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IEpTT04ucGFyc2UoZXJyb3IucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9ycyA9IHJlc3BvbnNlRGF0YS5lcnJvcnMgfHwge307XG4gICAgICAgICAgY29uc3QgcHJvY2Vzc2VkRXJyb3JzID0gd2l0aEFsbEVycm9ycy5lbmFibGVkKCkgPyB2YWxpZGF0aW9uRXJyb3JzIDogdG9TaW1wbGVWYWxpZGF0aW9uRXJyb3JzMih2YWxpZGF0aW9uRXJyb3JzKTtcbiAgICAgICAgICBmb3JtLmNsZWFyRXJyb3JzKCkuc2V0RXJyb3IocHJvY2Vzc2VkRXJyb3JzKTtcbiAgICAgICAgICBvcHRpb25zLm9uRXJyb3I/Lihwcm9jZXNzZWRFcnJvcnMpO1xuICAgICAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgICAgIH1cbiAgICAgICAgb3B0aW9ucy5vbkh0dHBFeGNlcHRpb24/LihlcnJvci5yZXNwb25zZSk7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgSHR0cENhbmNlbGxlZEVycm9yIHx8IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubmFtZSA9PT0gXCJBYm9ydEVycm9yXCIpIHtcbiAgICAgICAgb3B0aW9ucy5vbkNhbmNlbD8uKCk7XG4gICAgICAgIHRocm93IG5ldyBIdHRwQ2FuY2VsbGVkRXJyb3IoXCJSZXF1ZXN0IHdhcyBjYW5jZWxsZWRcIiwgdXJsKTtcbiAgICAgIH1cbiAgICAgIG9wdGlvbnMub25OZXR3b3JrRXJyb3I/LihlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IgOiBuZXcgRXJyb3IoXCJVbmtub3duIGVycm9yXCIpKTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBmaW5pc2hQcm9jZXNzaW5nKCk7XG4gICAgICBhYm9ydENvbnRyb2xsZXIgPSBudWxsO1xuICAgICAgb3B0aW9ucy5vbkZpbmlzaD8uKCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBjcmVhdGVTdWJtaXRNZXRob2QgPSAobWV0aG9kKSA9PiBhc3luYyAodXJsLCBvcHRpb25zID0ge30pID0+IHtcbiAgICByZXR1cm4gc3VibWl0KG1ldGhvZCwgdXJsLCBvcHRpb25zKTtcbiAgfTtcbiAgT2JqZWN0LmFzc2lnbihmb3JtLCB7XG4gICAgc3VibWl0KC4uLmFyZ3MyKSB7XG4gICAgICBjb25zdCBwYXJzZWQgPSBVc2VGb3JtVXRpbHM0LnBhcnNlU3VibWl0QXJndW1lbnRzKGFyZ3MyLCBnZXRQcmVjb2duaXRpb25FbmRwb2ludCgpKTtcbiAgICAgIHJldHVybiBzdWJtaXQocGFyc2VkLm1ldGhvZCwgcGFyc2VkLnVybCwgcGFyc2VkLm9wdGlvbnMpO1xuICAgIH0sXG4gICAgZ2V0OiBjcmVhdGVTdWJtaXRNZXRob2QoXCJnZXRcIiksXG4gICAgcG9zdDogY3JlYXRlU3VibWl0TWV0aG9kKFwicG9zdFwiKSxcbiAgICBwdXQ6IGNyZWF0ZVN1Ym1pdE1ldGhvZChcInB1dFwiKSxcbiAgICBwYXRjaDogY3JlYXRlU3VibWl0TWV0aG9kKFwicGF0Y2hcIiksXG4gICAgZGVsZXRlOiBjcmVhdGVTdWJtaXRNZXRob2QoXCJkZWxldGVcIiksXG4gICAgY2FuY2VsKCkge1xuICAgICAgaWYgKGFib3J0Q29udHJvbGxlcikge1xuICAgICAgICBhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGRvbnRSZW1lbWJlciguLi5rZXlzKSB7XG4gICAgICBzZXRSZW1lbWJlckV4Y2x1ZGVLZXlzKGtleXMpO1xuICAgICAgcmV0dXJuIGZvcm07XG4gICAgfSxcbiAgICBvcHRpbWlzdGljKGNhbGxiYWNrKSB7XG4gICAgICBwZW5kaW5nT3B0aW1pc3RpY0NhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICByZXR1cm4gZm9ybTtcbiAgICB9LFxuICAgIHdpdGhBbGxFcnJvcnMoKSB7XG4gICAgICB3aXRoQWxsRXJyb3JzLmVuYWJsZSgpO1xuICAgICAgcmV0dXJuIGZvcm07XG4gICAgfVxuICB9KTtcbiAgY29uc3Qgb3JpZ2luYWxXaXRoUHJlY29nbml0aW9uID0gZm9ybS53aXRoUHJlY29nbml0aW9uO1xuICBmb3JtLndpdGhQcmVjb2duaXRpb24gPSAoLi4uYXJnczIpID0+IHtcbiAgICBvcmlnaW5hbFdpdGhQcmVjb2duaXRpb24uY2FsbChmb3JtLCAuLi5hcmdzMik7XG4gICAgcmV0dXJuIGZvcm07XG4gIH07XG4gIHJldHVybiBnZXRQcmVjb2duaXRpb25FbmRwb2ludCgpID8gZm9ybSA6IGZvcm07XG59XG5cbi8vIHNyYy91c2VQb2xsLnRzXG5pbXBvcnQgeyByb3V0ZXIgYXMgcm91dGVyOCB9IGZyb20gXCJAaW5lcnRpYWpzL2NvcmVcIjtcbmltcG9ydCB7IG9uTW91bnRlZCBhcyBvbk1vdW50ZWQ1LCBvblVubW91bnRlZCBhcyBvblVubW91bnRlZDQsIHJlZiBhcyByZWY3IH0gZnJvbSBcInZ1ZVwiO1xuZnVuY3Rpb24gdXNlUG9sbChpbnRlcnZhbCwgcmVxdWVzdE9wdGlvbnMgPSB7fSwgb3B0aW9ucyA9IHtcbiAga2VlcEFsaXZlOiBmYWxzZSxcbiAgYXV0b1N0YXJ0OiB0cnVlXG59KSB7XG4gIGNvbnN0IGF1dG9TdGFydCA9IG9wdGlvbnMuYXV0b1N0YXJ0ID8/IHRydWU7XG4gIGNvbnN0IHsgc3RvcCwgc3RhcnQsIGRlc3Ryb3kgfSA9IHJvdXRlcjgucG9sbChpbnRlcnZhbCwgcmVxdWVzdE9wdGlvbnMsIHtcbiAgICAuLi5vcHRpb25zLFxuICAgIGF1dG9TdGFydDogZmFsc2VcbiAgfSk7XG4gIGNvbnN0IHBvbGxpbmcgPSByZWY3KGF1dG9TdGFydCk7XG4gIG9uTW91bnRlZDUoKCkgPT4ge1xuICAgIGlmIChhdXRvU3RhcnQpIHtcbiAgICAgIHN0YXJ0KCk7XG4gICAgfVxuICB9KTtcbiAgb25Vbm1vdW50ZWQ0KCgpID0+IHtcbiAgICBkZXN0cm95KCk7XG4gIH0pO1xuICByZXR1cm4ge1xuICAgIHBvbGxpbmcsXG4gICAgc3RvcDogKCkgPT4ge1xuICAgICAgc3RvcCgpO1xuICAgICAgcG9sbGluZy52YWx1ZSA9IGZhbHNlO1xuICAgIH0sXG4gICAgc3RhcnQ6ICgpID0+IHtcbiAgICAgIHN0YXJ0KCk7XG4gICAgICBwb2xsaW5nLnZhbHVlID0gdHJ1ZTtcbiAgICB9XG4gIH07XG59XG5cbi8vIHNyYy91c2VQcmVmZXRjaC50c1xuaW1wb3J0IHsgcm91dGVyIGFzIHJvdXRlcjkgfSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBvbk1vdW50ZWQgYXMgb25Nb3VudGVkNiwgb25Vbm1vdW50ZWQgYXMgb25Vbm1vdW50ZWQ1LCByZWYgYXMgcmVmOCB9IGZyb20gXCJ2dWVcIjtcbmZ1bmN0aW9uIHVzZVByZWZldGNoKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCBpc1ByZWZldGNoaW5nID0gcmVmOChmYWxzZSk7XG4gIGNvbnN0IGxhc3RVcGRhdGVkQXQgPSByZWY4KG51bGwpO1xuICBjb25zdCBpc1ByZWZldGNoZWQgPSByZWY4KGZhbHNlKTtcbiAgY29uc3QgY2FjaGVkID0gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiA/IG51bGwgOiByb3V0ZXI5LmdldENhY2hlZCh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUsIG9wdGlvbnMpO1xuICBjb25zdCBpbkZsaWdodCA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIgPyBudWxsIDogcm91dGVyOS5nZXRQcmVmZXRjaGluZyh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUsIG9wdGlvbnMpO1xuICBsYXN0VXBkYXRlZEF0LnZhbHVlID0gY2FjaGVkPy5zdGFsZVRpbWVzdGFtcCB8fCBudWxsO1xuICBpc1ByZWZldGNoaW5nLnZhbHVlID0gaW5GbGlnaHQgIT09IG51bGw7XG4gIGlzUHJlZmV0Y2hlZC52YWx1ZSA9IGNhY2hlZCAhPT0gbnVsbDtcbiAgbGV0IG9uUHJlZmV0Y2hlZExpc3RlbmVyO1xuICBsZXQgb25QcmVmZXRjaGluZ0xpc3RlbmVyO1xuICBvbk1vdW50ZWQ2KCgpID0+IHtcbiAgICBvblByZWZldGNoaW5nTGlzdGVuZXIgPSByb3V0ZXI5Lm9uKFwicHJlZmV0Y2hpbmdcIiwgKGUpID0+IHtcbiAgICAgIGlmIChlLmRldGFpbC52aXNpdC51cmwucGF0aG5hbWUgPT09IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSkge1xuICAgICAgICBpc1ByZWZldGNoaW5nLnZhbHVlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBvblByZWZldGNoZWRMaXN0ZW5lciA9IHJvdXRlcjkub24oXCJwcmVmZXRjaGVkXCIsIChlKSA9PiB7XG4gICAgICBpZiAoZS5kZXRhaWwudmlzaXQudXJsLnBhdGhuYW1lID09PSB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUpIHtcbiAgICAgICAgaXNQcmVmZXRjaGluZy52YWx1ZSA9IGZhbHNlO1xuICAgICAgICBpc1ByZWZldGNoZWQudmFsdWUgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbiAgb25Vbm1vdW50ZWQ1KCgpID0+IHtcbiAgICBvblByZWZldGNoZWRMaXN0ZW5lcigpO1xuICAgIG9uUHJlZmV0Y2hpbmdMaXN0ZW5lcigpO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBsYXN0VXBkYXRlZEF0LFxuICAgIGlzUHJlZmV0Y2hpbmcsXG4gICAgaXNQcmVmZXRjaGVkLFxuICAgIGZsdXNoOiAoKSA9PiByb3V0ZXI5LmZsdXNoKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSwgb3B0aW9ucylcbiAgfTtcbn1cblxuLy8gc3JjL3VzZVJlbWVtYmVyLnRzXG5pbXBvcnQgeyByb3V0ZXIgYXMgcm91dGVyMTAgfSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBjbG9uZURlZXAgYXMgY2xvbmVEZWVwNSB9IGZyb20gXCJlcy10b29sa2l0XCI7XG5pbXBvcnQgeyBpc1JlYWN0aXZlLCByZWFjdGl2ZSBhcyByZWFjdGl2ZTMsIHJlZiBhcyByZWY5LCB3YXRjaCBhcyB3YXRjaDQgfSBmcm9tIFwidnVlXCI7XG5mdW5jdGlvbiB1c2VSZW1lbWJlcihkYXRhLCBrZXkyKSB7XG4gIGlmICh0eXBlb2YgZGF0YSA9PT0gXCJvYmplY3RcIiAmJiBkYXRhICE9PSBudWxsICYmIGRhdGEuX19yZW1lbWJlcmFibGUgPT09IGZhbHNlKSB7XG4gICAgcmV0dXJuIGRhdGE7XG4gIH1cbiAgY29uc3QgcmVzdG9yZWQgPSByb3V0ZXIxMC5yZXN0b3JlKGtleTIpO1xuICBjb25zdCB0eXBlID0gaXNSZWFjdGl2ZShkYXRhKSA/IHJlYWN0aXZlMyA6IHJlZjk7XG4gIGNvbnN0IGhhc0NhbGxiYWNrcyA9IHR5cGVvZiBkYXRhLl9fcmVtZW1iZXIgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgZGF0YS5fX3Jlc3RvcmUgPT09IFwiZnVuY3Rpb25cIjtcbiAgY29uc3QgcmVtZW1iZXJlZCA9IHR5cGUoXG4gICAgcmVzdG9yZWQgPT09IHZvaWQgMCA/IGRhdGEgOiBoYXNDYWxsYmFja3MgPyBkYXRhLl9fcmVzdG9yZShjbG9uZURlZXA1KHJlc3RvcmVkKSkgOiBjbG9uZURlZXA1KHJlc3RvcmVkKVxuICApO1xuICB3YXRjaDQoXG4gICAgcmVtZW1iZXJlZCxcbiAgICAobmV3VmFsdWUpID0+IHtcbiAgICAgIHJvdXRlcjEwLnJlbWVtYmVyKGNsb25lRGVlcDUoaGFzQ2FsbGJhY2tzID8gZGF0YS5fX3JlbWVtYmVyKCkgOiBuZXdWYWx1ZSksIGtleTIpO1xuICAgIH0sXG4gICAgeyBpbW1lZGlhdGU6IHRydWUsIGRlZXA6IHRydWUgfVxuICApO1xuICByZXR1cm4gcmVtZW1iZXJlZDtcbn1cblxuLy8gc3JjL3doZW5WaXNpYmxlLnRzXG5pbXBvcnQgeyByb3V0ZXIgYXMgcm91dGVyMTEgfSBmcm9tIFwiQGluZXJ0aWFqcy9jb3JlXCI7XG5pbXBvcnQgeyBnZXQgYXMgZ2V0MyB9IGZyb20gXCJlcy10b29sa2l0L2NvbXBhdFwiO1xuaW1wb3J0IHsgY29tcHV0ZWQgYXMgY29tcHV0ZWQ2LCBkZWZpbmVDb21wb25lbnQgYXMgZGVmaW5lQ29tcG9uZW50NywgaCBhcyBoNywgbmV4dFRpY2ssIG9uVW5tb3VudGVkIGFzIG9uVW5tb3VudGVkNiwgcmVmIGFzIHJlZjEwLCB3YXRjaCBhcyB3YXRjaDUgfSBmcm9tIFwidnVlXCI7XG52YXIgd2hlblZpc2libGVfZGVmYXVsdCA9IGRlZmluZUNvbXBvbmVudDcoe1xuICBuYW1lOiBcIldoZW5WaXNpYmxlXCIsXG4gIHNsb3RzOiBPYmplY3QsXG4gIHByb3BzOiB7XG4gICAgZGF0YToge1xuICAgICAgdHlwZTogW1N0cmluZywgQXJyYXldXG4gICAgfSxcbiAgICBwYXJhbXM6IHtcbiAgICAgIHR5cGU6IE9iamVjdFxuICAgIH0sXG4gICAgYnVmZmVyOiB7XG4gICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICBkZWZhdWx0OiAwXG4gICAgfSxcbiAgICBhczoge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgZGVmYXVsdDogXCJkaXZcIlxuICAgIH0sXG4gICAgYWx3YXlzOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICB9XG4gIH0sXG4gIHNldHVwKHByb3BzLCB7IHNsb3RzIH0pIHtcbiAgICBjb25zdCBsb2FkZWQgPSByZWYxMChmYWxzZSk7XG4gICAgY29uc3QgZmV0Y2hpbmcgPSByZWYxMChmYWxzZSk7XG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSByZWYxMChudWxsKTtcbiAgICBjb25zdCBlbGVtZW50UmVmID0gcmVmMTAobnVsbCk7XG4gICAgY29uc3QgcGFnZTIgPSB1c2VQYWdlKCk7XG4gICAgY29uc3Qga2V5cyA9IGNvbXB1dGVkNigoKSA9PiB7XG4gICAgICByZXR1cm4gcHJvcHMuZGF0YSA/IEFycmF5LmlzQXJyYXkocHJvcHMuZGF0YSkgPyBwcm9wcy5kYXRhIDogW3Byb3BzLmRhdGFdIDogW107XG4gICAgfSk7XG4gICAgZnVuY3Rpb24gZ2V0UmVsb2FkUGFyYW1zKCkge1xuICAgICAgY29uc3QgcmVsb2FkUGFyYW1zID0geyBwcmVzZXJ2ZUVycm9yczogdHJ1ZSwgLi4ucHJvcHMucGFyYW1zIH07XG4gICAgICBpZiAocHJvcHMuZGF0YSkge1xuICAgICAgICByZWxvYWRQYXJhbXMub25seSA9IEFycmF5LmlzQXJyYXkocHJvcHMuZGF0YSkgPyBwcm9wcy5kYXRhIDogW3Byb3BzLmRhdGFdO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlbG9hZFBhcmFtcztcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVnaXN0ZXJPYnNlcnZlcigpIHtcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIG9ic2VydmVyLnZhbHVlPy5kaXNjb25uZWN0KCk7XG4gICAgICBvYnNlcnZlci52YWx1ZSA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICAgICAgKGVudHJpZXMpID0+IHtcbiAgICAgICAgICBpZiAoIWVudHJpZXNbMF0uaXNJbnRlcnNlY3RpbmcpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGZldGNoaW5nLnZhbHVlKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghcHJvcHMuYWx3YXlzICYmIGxvYWRlZC52YWx1ZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBmZXRjaGluZy52YWx1ZSA9IHRydWU7XG4gICAgICAgICAgY29uc3QgcmVsb2FkUGFyYW1zID0gZ2V0UmVsb2FkUGFyYW1zKCk7XG4gICAgICAgICAgcm91dGVyMTEucmVsb2FkKHtcbiAgICAgICAgICAgIC4uLnJlbG9hZFBhcmFtcyxcbiAgICAgICAgICAgIG9uU3RhcnQ6IChlKSA9PiB7XG4gICAgICAgICAgICAgIGZldGNoaW5nLnZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgcmVsb2FkUGFyYW1zLm9uU3RhcnQ/LihlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbkZpbmlzaDogKGUpID0+IHtcbiAgICAgICAgICAgICAgbG9hZGVkLnZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgZmV0Y2hpbmcudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgcmVsb2FkUGFyYW1zLm9uRmluaXNoPy4oZSk7XG4gICAgICAgICAgICAgIGlmICghcHJvcHMuYWx3YXlzKSB7XG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIudmFsdWU/LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgcm9vdE1hcmdpbjogYCR7cHJvcHMuYnVmZmVyfXB4YFxuICAgICAgICB9XG4gICAgICApO1xuICAgICAgaWYgKGVsZW1lbnRSZWYudmFsdWUpIHtcbiAgICAgICAgb2JzZXJ2ZXIudmFsdWUub2JzZXJ2ZShlbGVtZW50UmVmLnZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgd2F0Y2g1KFxuICAgICAgKCkgPT4ga2V5cy52YWx1ZS5tYXAoKGtleTIpID0+IGdldDMocGFnZTIucHJvcHMsIGtleTIpKSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgY29uc3QgZXhpc3RzID0ga2V5cy52YWx1ZS5sZW5ndGggPiAwICYmIGtleXMudmFsdWUuZXZlcnkoKGtleTIpID0+IGdldDMocGFnZTIucHJvcHMsIGtleTIpICE9PSB2b2lkIDApO1xuICAgICAgICBsb2FkZWQudmFsdWUgPSBleGlzdHM7XG4gICAgICAgIGlmIChleGlzdHMgJiYgIXByb3BzLmFsd2F5cykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW9ic2VydmVyLnZhbHVlIHx8ICFleGlzdHMpIHtcbiAgICAgICAgICBuZXh0VGljayhyZWdpc3Rlck9ic2VydmVyKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgICApO1xuICAgIG9uVW5tb3VudGVkNigoKSA9PiB7XG4gICAgICBvYnNlcnZlci52YWx1ZT8uZGlzY29ubmVjdCgpO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjb25zdCBlbHMgPSBbXTtcbiAgICAgIGlmIChwcm9wcy5hbHdheXMgfHwgIWxvYWRlZC52YWx1ZSkge1xuICAgICAgICBlbHMucHVzaChoNyhwcm9wcy5hcywgeyByZWY6IGVsZW1lbnRSZWYgfSkpO1xuICAgICAgfVxuICAgICAgaWYgKCFsb2FkZWQudmFsdWUpIHtcbiAgICAgICAgZWxzLnB1c2goc2xvdHMuZmFsbGJhY2sgPyBzbG90cy5mYWxsYmFjayh7fSkgOiBudWxsKTtcbiAgICAgIH0gZWxzZSBpZiAoc2xvdHMuZGVmYXVsdCkge1xuICAgICAgICBlbHMucHVzaChzbG90cy5kZWZhdWx0KHsgZmV0Y2hpbmc6IGZldGNoaW5nLnZhbHVlIH0pKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBlbHM7XG4gICAgfTtcbiAgfVxufSk7XG5cbi8vIHNyYy9pbmRleC50c1xudmFyIGNvbmZpZyA9IGNvcmVDb25maWcuZXh0ZW5kKHt9KTtcbmV4cG9ydCB7XG4gIGFwcF9kZWZhdWx0IGFzIEFwcCxcbiAgZGVmZXJyZWRfZGVmYXVsdCBhcyBEZWZlcnJlZCxcbiAgZm9ybV9kZWZhdWx0IGFzIEZvcm0sXG4gIGhlYWRfZGVmYXVsdCBhcyBIZWFkLFxuICBpbmZpbml0ZVNjcm9sbF9kZWZhdWx0IGFzIEluZmluaXRlU2Nyb2xsLFxuICBsaW5rX2RlZmF1bHQgYXMgTGluayxcbiAgd2hlblZpc2libGVfZGVmYXVsdCBhcyBXaGVuVmlzaWJsZSxcbiAgY29uZmlnLFxuICBjcmVhdGVGb3JtLFxuICBjcmVhdGVJbmVydGlhQXBwLFxuICBodHRwMiBhcyBodHRwLFxuICBwcm9ncmVzcyxcbiAgcmVzZXRMYXlvdXRQcm9wcyxcbiAgcm91dGVyMTIgYXMgcm91dGVyLFxuICBzZXRMYXlvdXRQcm9wcyxcbiAgdXNlRm9ybSxcbiAgdXNlRm9ybUNvbnRleHQsXG4gIHVzZUh0dHAsXG4gIHVzZVBhZ2UsXG4gIHVzZVBvbGwsXG4gIHVzZVByZWZldGNoLFxuICB1c2VSZW1lbWJlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOztBQUNBLElBQU0sY0FBYyxPQUFPLGVBQWUsWUFBWSxjQUFjLE9BQU8sV0FBVyxZQUFZLFVBQVUsT0FBTyxTQUFTLFlBQVksUUFBUSxPQUFPLFdBQVcsWUFBWSxXQUFXLFdBQVc7Q0FDbk0sT0FBTztBQUNSLEVBQUEsQ0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDa0NILFNBQVNBLFdBQVMsTUFBTSxZQUFZLEVBQUUsUUFBUSxVQUFVLENBQUMsR0FBRztDQUMzRCxJQUFJLGNBQWMsS0FBSztDQUN2QixJQUFJLGNBQWM7Q0FDbEIsTUFBTSxVQUFVLFNBQVMsUUFBUSxNQUFNLFNBQVMsU0FBUztDQUN6RCxNQUFNLFdBQVcsU0FBUyxRQUFRLE1BQU0sU0FBUyxVQUFVO0NBQzNELE1BQU0sZUFBZTtFQUNwQixJQUFJLGdCQUFnQixNQUFNO0dBQ3pCLEtBQUssTUFBTSxhQUFhLFdBQVc7R0FDbkMsY0FBYyxLQUFLO0dBQ25CLGNBQWM7RUFDZjtDQUNEO0NBQ0EsTUFBTSxtQkFBbUI7RUFDeEIsSUFBSSxVQUFVLE9BQU87RUFDckIsT0FBTztDQUNSO0NBQ0EsSUFBSSxZQUFZO0NBQ2hCLE1BQU0saUJBQWlCO0VBQ3RCLElBQUksYUFBYSxNQUFNLGFBQWEsU0FBUztFQUM3QyxZQUFZLGlCQUFpQjtHQUM1QixZQUFZO0dBQ1osV0FBVztFQUNaLEdBQUcsVUFBVTtDQUNkO0NBQ0EsTUFBTSxvQkFBb0I7RUFDekIsSUFBSSxjQUFjLE1BQU07R0FDdkIsYUFBYSxTQUFTO0dBQ3RCLFlBQVk7RUFDYjtDQUNEO0NBQ0EsTUFBTSxlQUFlO0VBQ3BCLFlBQVk7RUFDWixjQUFjLEtBQUs7RUFDbkIsY0FBYztDQUNmO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLE9BQU87Q0FDUjtDQUNBLE1BQU0sWUFBWSxTQUFTLEdBQUcsTUFBTTtFQUNuQyxJQUFJLFFBQVEsU0FBUztFQUNyQixjQUFjO0VBQ2QsY0FBYztFQUNkLE1BQU0sY0FBYyxhQUFhO0VBQ2pDLFNBQVM7RUFDVCxJQUFJLFdBQVcsYUFBYSxPQUFPO0NBQ3BDO0NBQ0EsVUFBVSxXQUFXO0NBQ3JCLFVBQVUsU0FBUztDQUNuQixVQUFVLFFBQVE7Q0FDbEIsUUFBUSxpQkFBaUIsU0FBUyxRQUFRLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDeEQsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7QUM5RUEsU0FBU0MsU0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNZakIsU0FBUyxZQUFZLE9BQU87Q0FDM0IsT0FBTyxTQUFTLFFBQVEsT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVO0FBQ3ZFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSQSxTQUFTQyxlQUFhLEdBQUc7Q0FDeEIsT0FBTyxZQUFZLE9BQU8sQ0FBQyxLQUFLLEVBQUUsYUFBYTtBQUNoRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2FBLFNBQVMsTUFBTSxLQUFLO0NBQ25CLElBQUksWUFBWSxHQUFHLEdBQUcsT0FBTztDQUM3QixJQUFJLE1BQU0sUUFBUSxHQUFHLEtBQUtDLGVBQWEsR0FBRyxLQUFLLGVBQWUsZUFBZSxPQUFPLHNCQUFzQixlQUFlLGVBQWUsbUJBQW1CLE9BQU8sSUFBSSxNQUFNLENBQUM7Q0FDN0ssTUFBTSxZQUFZLE9BQU8sZUFBZSxHQUFHO0NBQzNDLElBQUksYUFBYSxNQUFNLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxTQUFTLEdBQUcsR0FBRztDQUN6RSxNQUFNLGNBQWMsVUFBVTtDQUM5QixJQUFJLGVBQWUsUUFBUSxlQUFlLE9BQU8sZUFBZSxLQUFLLE9BQU8sSUFBSSxZQUFZLEdBQUc7Q0FDL0YsSUFBSSxlQUFlLFFBQVE7RUFDMUIsTUFBTSxZQUFZLElBQUksWUFBWSxHQUFHO0VBQ3JDLFVBQVUsWUFBWSxJQUFJO0VBQzFCLE9BQU87Q0FDUjtDQUNBLElBQUksZUFBZSxVQUFVLE9BQU8sSUFBSSxZQUFZLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQztDQUN2RSxJQUFJLGVBQWUsT0FBTztFQUN6QixJQUFJO0VBQ0osSUFBSSxlQUFlLGdCQUFnQixXQUFXLElBQUksWUFBWSxJQUFJLFFBQVEsSUFBSSxTQUFTLEVBQUUsT0FBTyxJQUFJLE1BQU0sQ0FBQztPQUN0RyxXQUFXLElBQUksWUFBWSxJQUFJLFNBQVMsRUFBRSxPQUFPLElBQUksTUFBTSxDQUFDO0VBQ2pFLFNBQVMsUUFBUSxJQUFJO0VBQ3JCLE9BQU8sT0FBTyxVQUFVLEdBQUc7RUFDM0IsT0FBTztDQUNSO0NBQ0EsSUFBSSxPQUFPLFNBQVMsZUFBZSxlQUFlLE1BQU0sT0FBTyxJQUFJLFlBQVksQ0FBQyxHQUFHLEdBQUcsSUFBSSxNQUFNO0VBQy9GLE1BQU0sSUFBSTtFQUNWLGNBQWMsSUFBSTtDQUNuQixDQUFDO0NBQ0QsSUFBSSxPQUFPLFFBQVEsVUFBVSxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sU0FBUyxHQUFHLEdBQUc7Q0FDL0UsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q0EsU0FBUyxTQUFTLEdBQUc7Q0FDcEIsT0FBTyxPQUFPLFlBQVksV0FBVyxlQUFlLFlBQVksT0FBTyxTQUFTLENBQUM7QUFDbEY7OztBQ3JCQSxTQUFTLFdBQVcsUUFBUTtDQUMzQixPQUFPLE9BQU8sc0JBQXNCLE1BQU0sQ0FBQyxDQUFDLFFBQVEsV0FBVyxPQUFPLFVBQVUscUJBQXFCLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDMUg7Ozs7Ozs7Ozs7QUNLQSxTQUFTLE9BQU8sT0FBTztDQUN0QixJQUFJLFNBQVMsTUFBTSxPQUFPLFVBQVUsS0FBSyxJQUFJLHVCQUF1QjtDQUNwRSxPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssS0FBSztBQUM1Qzs7O0FDVkEsSUFBTSxZQUFZO0FBQ2xCLElBQU0sWUFBWTtBQUNsQixJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sZUFBZTtBQUNyQixJQUFNLFlBQVk7QUFDbEIsSUFBTSxVQUFVO0FBQ2hCLElBQU0sU0FBUztBQUNmLElBQU0sU0FBUztBQUNmLElBQU0sV0FBVztBQUNqQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxZQUFZO0FBQ2xCLElBQU0sV0FBVztBQUNqQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN1QnhCLFNBQVNDLGdCQUFjLEtBQUssWUFBWTtDQUN2QyxPQUFPLGtCQUFrQixLQUFLLEtBQUssR0FBRyxxQkFBcUIsSUFBSSxJQUFJLEdBQUcsVUFBVTtBQUNqRjtBQUNBLFNBQVMsa0JBQWtCLGNBQWMsWUFBWSxlQUFlLHdCQUF3QixJQUFJLElBQUksR0FBRyxhQUFhLEtBQUssR0FBRztDQUMzSCxNQUFNLFNBQVMsYUFBYSxjQUFjLFlBQVksZUFBZSxLQUFLO0NBQzFFLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTztDQUM5QixJQUFJLFlBQVksWUFBWSxHQUFHLE9BQU87Q0FDdEMsSUFBSSxNQUFNLElBQUksWUFBWSxHQUFHLE9BQU8sTUFBTSxJQUFJLFlBQVk7Q0FDMUQsSUFBSSxNQUFNLFFBQVEsWUFBWSxHQUFHO0VBQ2hDLE1BQU0sU0FBUyxJQUFJLE1BQU0sYUFBYSxNQUFNO0VBQzVDLE1BQU0sSUFBSSxjQUFjLE1BQU07RUFDOUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLLE9BQU8sS0FBSyxrQkFBa0IsYUFBYSxJQUFJLEdBQUcsZUFBZSxPQUFPLFVBQVU7RUFDaEksSUFBSSxPQUFPLE9BQU8sY0FBYyxPQUFPLEdBQUcsT0FBTyxRQUFRLGFBQWE7RUFDdEUsSUFBSSxPQUFPLE9BQU8sY0FBYyxPQUFPLEdBQUcsT0FBTyxRQUFRLGFBQWE7RUFDdEUsT0FBTztDQUNSO0NBQ0EsSUFBSSx3QkFBd0IsTUFBTSxPQUFPLElBQUksS0FBSyxhQUFhLFFBQVEsQ0FBQztDQUN4RSxJQUFJLHdCQUF3QixRQUFRO0VBQ25DLE1BQU0sU0FBUyxJQUFJLE9BQU8sYUFBYSxRQUFRLGFBQWEsS0FBSztFQUNqRSxPQUFPLFlBQVksYUFBYTtFQUNoQyxPQUFPO0NBQ1I7Q0FDQSxJQUFJLHdCQUF3QixLQUFLO0VBQ2hDLE1BQU0seUJBQXlCLElBQUksSUFBSTtFQUN2QyxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLEtBQUssTUFBTSxDQUFDLEtBQUssVUFBVSxjQUFjLE9BQU8sSUFBSSxLQUFLLGtCQUFrQixPQUFPLEtBQUssZUFBZSxPQUFPLFVBQVUsQ0FBQztFQUN4SCxPQUFPO0NBQ1I7Q0FDQSxJQUFJLHdCQUF3QixLQUFLO0VBQ2hDLE1BQU0seUJBQXlCLElBQUksSUFBSTtFQUN2QyxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLEtBQUssTUFBTSxTQUFTLGNBQWMsT0FBTyxJQUFJLGtCQUFrQixPQUFPLEtBQUssR0FBRyxlQUFlLE9BQU8sVUFBVSxDQUFDO0VBQy9HLE9BQU87Q0FDUjtDQUNBLElBQUksU0FBUyxZQUFZLEdBQUcsT0FBTyxhQUFhLFNBQVM7Q0FDekQsSUFBSUMsZUFBYSxZQUFZLEdBQUc7RUFDL0IsTUFBTSxTQUFTLEtBQUssT0FBTyxlQUFlLFlBQVksRUFBQSxDQUFHLFlBQVksYUFBYSxNQUFNO0VBQ3hGLE1BQU0sSUFBSSxjQUFjLE1BQU07RUFDOUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLLE9BQU8sS0FBSyxrQkFBa0IsYUFBYSxJQUFJLEdBQUcsZUFBZSxPQUFPLFVBQVU7RUFDaEksT0FBTztDQUNSO0NBQ0EsSUFBSSx3QkFBd0IsZUFBZSxPQUFPLHNCQUFzQixlQUFlLHdCQUF3QixtQkFBbUIsT0FBTyxhQUFhLE1BQU0sQ0FBQztDQUM3SixJQUFJLHdCQUF3QixVQUFVO0VBQ3JDLE1BQU0sU0FBUyxJQUFJLFNBQVMsYUFBYSxPQUFPLE1BQU0sQ0FBQyxHQUFHLGFBQWEsWUFBWSxhQUFhLFVBQVU7RUFDMUcsTUFBTSxJQUFJLGNBQWMsTUFBTTtFQUM5QixlQUFlLFFBQVEsY0FBYyxlQUFlLE9BQU8sVUFBVTtFQUNyRSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLE9BQU8sU0FBUyxlQUFlLHdCQUF3QixNQUFNO0VBQ2hFLE1BQU0sU0FBUyxJQUFJLEtBQUssQ0FBQyxZQUFZLEdBQUcsYUFBYSxNQUFNLEVBQUUsTUFBTSxhQUFhLEtBQUssQ0FBQztFQUN0RixNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLGVBQWUsUUFBUSxjQUFjLGVBQWUsT0FBTyxVQUFVO0VBQ3JFLE9BQU87Q0FDUjtDQUNBLElBQUksT0FBTyxTQUFTLGVBQWUsd0JBQXdCLE1BQU07RUFDaEUsTUFBTSxTQUFTLElBQUksS0FBSyxDQUFDLFlBQVksR0FBRyxFQUFFLE1BQU0sYUFBYSxLQUFLLENBQUM7RUFDbkUsTUFBTSxJQUFJLGNBQWMsTUFBTTtFQUM5QixlQUFlLFFBQVEsY0FBYyxlQUFlLE9BQU8sVUFBVTtFQUNyRSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLHdCQUF3QixPQUFPO0VBQ2xDLE1BQU0sU0FBUyxnQkFBZ0IsWUFBWTtFQUMzQyxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLE9BQU8sVUFBVSxhQUFhO0VBQzlCLE9BQU8sT0FBTyxhQUFhO0VBQzNCLE9BQU8sUUFBUSxhQUFhO0VBQzVCLE9BQU8sUUFBUSxhQUFhO0VBQzVCLE9BQU8sY0FBYyxhQUFhO0VBQ2xDLGVBQWUsUUFBUSxjQUFjLGVBQWUsT0FBTyxVQUFVO0VBQ3JFLE9BQU87Q0FDUjtDQUNBLElBQUksd0JBQXdCLFNBQVM7RUFDcEMsTUFBTSxTQUFTLElBQUksUUFBUSxhQUFhLFFBQVEsQ0FBQztFQUNqRCxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLGVBQWUsUUFBUSxjQUFjLGVBQWUsT0FBTyxVQUFVO0VBQ3JFLE9BQU87Q0FDUjtDQUNBLElBQUksd0JBQXdCLFFBQVE7RUFDbkMsTUFBTSxTQUFTLElBQUksT0FBTyxhQUFhLFFBQVEsQ0FBQztFQUNoRCxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLGVBQWUsUUFBUSxjQUFjLGVBQWUsT0FBTyxVQUFVO0VBQ3JFLE9BQU87Q0FDUjtDQUNBLElBQUksd0JBQXdCLFFBQVE7RUFDbkMsTUFBTSxTQUFTLElBQUksT0FBTyxhQUFhLFFBQVEsQ0FBQztFQUNoRCxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLGVBQWUsUUFBUSxjQUFjLGVBQWUsT0FBTyxVQUFVO0VBQ3JFLE9BQU87Q0FDUjtDQUNBLElBQUksT0FBTyxpQkFBaUIsWUFBWSxrQkFBa0IsWUFBWSxHQUFHO0VBQ3hFLE1BQU0sU0FBUyxPQUFPLE9BQU8sT0FBTyxlQUFlLFlBQVksQ0FBQztFQUNoRSxNQUFNLElBQUksY0FBYyxNQUFNO0VBQzlCLGVBQWUsUUFBUSxjQUFjLGVBQWUsT0FBTyxVQUFVO0VBQ3JFLE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsZUFBZSxRQUFRLFFBQVEsZ0JBQWdCLFFBQVEsT0FBTyxZQUFZO0NBQ2xGLE1BQU0sT0FBTyxDQUFDLEdBQUcsT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHLFdBQVcsTUFBTSxDQUFDO0NBQzNELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztFQUNyQyxNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLGFBQWEsT0FBTyx5QkFBeUIsUUFBUSxHQUFHO0VBQzlELElBQUksY0FBYyxRQUFRLFdBQVcsVUFBVSxPQUFPLE9BQU8sa0JBQWtCLE9BQU8sTUFBTSxLQUFLLGVBQWUsT0FBTyxVQUFVO0NBQ2xJO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2xDLFFBQVEsT0FBTyxNQUFNLEdBQXJCO0VBQ0MsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxnQkFBZ0IsT0FBTztFQUM1QixTQUFTLE9BQU87Q0FDakI7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BJQSxTQUFTQyxZQUFVLEtBQUs7Q0FDdkIsT0FBTyxrQkFBa0IsS0FBSyxLQUFLLEdBQUcscUJBQXFCLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQztBQUM3RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUEEsU0FBU0MsZ0JBQWMsT0FBTztDQUM3QixJQUFJLENBQUMsU0FBUyxPQUFPLFVBQVUsVUFBVSxPQUFPO0NBQ2hELE1BQU0sUUFBUSxPQUFPLGVBQWUsS0FBSztDQUN6QyxJQUFJLEVBQUUsVUFBVSxRQUFRLFVBQVUsT0FBTyxhQUFhLE9BQU8sZUFBZSxLQUFLLE1BQU0sT0FBTyxPQUFPO0NBQ3JHLE9BQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxLQUFLLE1BQU07QUFDbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ0EsU0FBUyxpQkFBaUIsS0FBSztDQUM5QixPQUFPLFFBQVE7QUFDaEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNPQSxTQUFTQyxnQkFBYyxRQUFRO0NBQzlCLElBQUksT0FBTyxXQUFXLFVBQVUsT0FBTztDQUN2QyxJQUFJLFVBQVUsTUFBTSxPQUFPO0NBQzNCLElBQUksT0FBTyxlQUFlLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDbkQsSUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLE1BQU0sTUFBTSxtQkFBbUI7RUFDakUsTUFBTSxNQUFNLE9BQU8sT0FBTztFQUMxQixJQUFJLE9BQU8sTUFBTSxPQUFPO0VBQ3hCLElBQUksQ0FBQyxPQUFPLHlCQUF5QixRQUFRLE9BQU8sV0FBVyxDQUFDLEVBQUUsVUFBVSxPQUFPO0VBQ25GLE9BQU8sT0FBTyxTQUFTLE1BQU0sV0FBVyxJQUFJO0NBQzdDO0NBQ0EsSUFBSSxRQUFRO0NBQ1osT0FBTyxPQUFPLGVBQWUsS0FBSyxNQUFNLE1BQU0sUUFBUSxPQUFPLGVBQWUsS0FBSztDQUNqRixPQUFPLE9BQU8sZUFBZSxNQUFNLE1BQU07QUFDMUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QkEsU0FBUyxHQUFHLE9BQU8sT0FBTztDQUN6QixPQUFPLFVBQVUsU0FBUyxPQUFPLE1BQU0sS0FBSyxLQUFLLE9BQU8sTUFBTSxLQUFLO0FBQ3BFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzBCQSxTQUFTLFlBQVksR0FBRyxHQUFHLGdCQUFnQjtDQUMxQyxPQUFPLGdCQUFnQixHQUFHLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLGNBQWM7QUFDNUU7QUFDQSxTQUFTLGdCQUFnQixHQUFHLEdBQUcsVUFBVSxTQUFTLFNBQVMsT0FBTyxnQkFBZ0I7Q0FDakYsTUFBTSxTQUFTLGVBQWUsR0FBRyxHQUFHLFVBQVUsU0FBUyxTQUFTLEtBQUs7Q0FDckUsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0NBQzlCLElBQUksT0FBTyxNQUFNLE9BQU8sR0FBRyxRQUFRLE9BQU8sR0FBZjtFQUMxQixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxhQUFhLE9BQU8sTUFBTTtFQUMvQixLQUFLLFVBQVUsT0FBTyxNQUFNLEtBQUssT0FBTyxHQUFHLEdBQUcsQ0FBQztFQUMvQyxLQUFLLFlBQVksT0FBTyxNQUFNO0VBQzlCLEtBQUssVUFBVSxPQUFPLGdCQUFnQixHQUFHLEdBQUcsT0FBTyxjQUFjO0NBQ2xFO0NBQ0EsT0FBTyxnQkFBZ0IsR0FBRyxHQUFHLE9BQU8sY0FBYztBQUNuRDtBQUNBLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRyxPQUFPLGdCQUFnQjtDQUNyRCxJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUMsR0FBRyxPQUFPO0NBQzVCLElBQUksT0FBTyxPQUFPLENBQUM7Q0FDbkIsSUFBSSxPQUFPLE9BQU8sQ0FBQztDQUNuQixJQUFJLFNBQVMsc0JBQXNCLE9BQU87Q0FDMUMsSUFBSSxTQUFTLHNCQUFzQixPQUFPO0NBQzFDLElBQUksU0FBUyxNQUFNLE9BQU87Q0FDMUIsUUFBUSxNQUFSO0VBQ0MsS0FBSyxXQUFXLE9BQU8sRUFBRSxTQUFTLE1BQU0sRUFBRSxTQUFTO0VBQ25ELEtBQUssV0FBVyxPQUFPLEdBQUcsRUFBRSxRQUFRLEdBQUcsRUFBRSxRQUFRLENBQUM7RUFDbEQsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLLFdBQVcsT0FBTyxPQUFPLEdBQUcsRUFBRSxRQUFRLEdBQUcsRUFBRSxRQUFRLENBQUM7RUFDekQsS0FBSyxXQUFXLE9BQU8sRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRTtFQUM5RCxLQUFLLGFBQWEsT0FBTyxNQUFNO0NBQ2hDO0NBQ0EsUUFBUSx5QkFBeUIsSUFBSSxJQUFJO0NBQ3pDLE1BQU0sU0FBUyxNQUFNLElBQUksQ0FBQztDQUMxQixNQUFNLFNBQVMsTUFBTSxJQUFJLENBQUM7Q0FDMUIsSUFBSSxVQUFVLFFBQVEsVUFBVSxNQUFNLE9BQU8sV0FBVztDQUN4RCxNQUFNLElBQUksR0FBRyxDQUFDO0NBQ2QsTUFBTSxJQUFJLEdBQUcsQ0FBQztDQUNkLElBQUk7RUFDSCxRQUFRLE1BQVI7R0FDQyxLQUFLO0lBQ0osSUFBSSxFQUFFLFNBQVMsRUFBRSxNQUFNLE9BQU87SUFDOUIsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLEVBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLElBQUksR0FBRyxLQUFLLENBQUMsZ0JBQWdCLE9BQU8sRUFBRSxJQUFJLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxPQUFPLGNBQWMsR0FBRyxPQUFPO0lBQ3pJLE9BQU87R0FDUixLQUFLLFFBQVE7SUFDWixJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU0sT0FBTztJQUM5QixNQUFNLFVBQVUsTUFBTSxLQUFLLEVBQUUsT0FBTyxDQUFDO0lBQ3JDLE1BQU0sVUFBVSxNQUFNLEtBQUssRUFBRSxPQUFPLENBQUM7SUFDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0tBQ3hDLE1BQU0sU0FBUyxRQUFRO0tBQ3ZCLE1BQU0sUUFBUSxRQUFRLFdBQVcsV0FBVztNQUMzQyxPQUFPLGdCQUFnQixRQUFRLFFBQVEsS0FBSyxHQUFHLEdBQUcsR0FBRyxPQUFPLGNBQWM7S0FDM0UsQ0FBQztLQUNELElBQUksVUFBVSxJQUFJLE9BQU87S0FDekIsUUFBUSxPQUFPLE9BQU8sQ0FBQztJQUN4QjtJQUNBLE9BQU87R0FDUjtHQUNBLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztJQUNKLElBQUksU0FBUyxDQUFDLE1BQU0sU0FBUyxDQUFDLEdBQUcsT0FBTztJQUN4QyxJQUFJLEVBQUUsV0FBVyxFQUFFLFFBQVEsT0FBTztJQUNsQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLE9BQU8sY0FBYyxHQUFHLE9BQU87SUFDNUcsT0FBTztHQUNSLEtBQUs7SUFDSixJQUFJLEVBQUUsZUFBZSxFQUFFLFlBQVksT0FBTztJQUMxQyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsT0FBTyxjQUFjO0dBQ25GLEtBQUs7SUFDSixJQUFJLEVBQUUsZUFBZSxFQUFFLGNBQWMsRUFBRSxlQUFlLEVBQUUsWUFBWSxPQUFPO0lBQzNFLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxDQUFDLEdBQUcsSUFBSSxXQUFXLENBQUMsR0FBRyxPQUFPLGNBQWM7R0FDbkYsS0FBSyxVQUFVLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRTtHQUMzRCxLQUFLLFdBQVc7SUFDZixJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLGFBQWEsT0FBTyxjQUFjLEtBQUtDLGdCQUFjLENBQUMsS0FBS0EsZ0JBQWMsQ0FBQyxJQUFJLE9BQU87SUFDNUgsTUFBTSxRQUFRLENBQUMsR0FBRyxPQUFPLEtBQUssQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLENBQUM7SUFDbEQsTUFBTSxRQUFRLENBQUMsR0FBRyxPQUFPLEtBQUssQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLENBQUM7SUFDbEQsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUFRLE9BQU87SUFDMUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0tBQ3RDLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLE1BQU0sUUFBUSxFQUFFO0tBQ2hCLElBQUksQ0FBQyxPQUFPLE9BQU8sR0FBRyxPQUFPLEdBQUcsT0FBTztLQUN2QyxNQUFNLFFBQVEsRUFBRTtLQUNoQixJQUFJLENBQUMsZ0JBQWdCLE9BQU8sT0FBTyxTQUFTLEdBQUcsR0FBRyxPQUFPLGNBQWMsR0FBRyxPQUFPO0lBQ2xGO0lBQ0EsT0FBTztHQUNSO0dBQ0EsU0FBUyxPQUFPO0VBQ2pCO0NBQ0QsVUFBVTtFQUNULE1BQU0sT0FBTyxDQUFDO0VBQ2QsTUFBTSxPQUFPLENBQUM7Q0FDZjtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2hJQSxTQUFTLFFBQVEsR0FBRyxHQUFHO0NBQ3RCLE9BQU8sWUFBWSxHQUFHLEdBQUdDLE1BQUk7QUFDOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0dBLFNBQVMsU0FBUyxPQUFPO0NBQ3hCLE9BQU8sT0FBTyxjQUFjLEtBQUssS0FBSyxTQUFTO0FBQ2hEOzs7QUN2QkEsSUFBTSxjQUFjO0NBQ25CLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixLQUFLO0FBQ047Ozs7Ozs7Ozs7Ozs7O0FBY0EsU0FBU0MsU0FBTyxLQUFLO0NBQ3BCLE9BQU8sSUFBSSxRQUFRLGFBQWEsVUFBVSxZQUFZLE1BQU07QUFDN0Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUEEsU0FBUyxZQUFZLE9BQU87Q0FDM0IsT0FBTyxTQUFTLFFBQVEsT0FBTyxVQUFVLGNBQWMsU0FBUyxNQUFNLE1BQU07QUFDN0U7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSEEsU0FBUyxTQUFTLE9BQU87Q0FDeEIsT0FBTyxPQUFPLFVBQVUsWUFBWSxpQkFBaUI7QUFDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNDQSxTQUFTLFNBQVMsT0FBTztDQUN4QixJQUFJLFNBQVMsTUFBTSxPQUFPO0NBQzFCLE9BQU8sYUFBYSxLQUFLO0FBQzFCO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDNUIsSUFBSSxPQUFPLFVBQVUsVUFBVSxPQUFPO0NBQ3RDLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRyxPQUFPLE1BQU0sSUFBSSxZQUFZLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDakUsSUFBSSxTQUFTLEtBQUssR0FBRyxPQUFPLE1BQU0sU0FBUztDQUMzQyxNQUFNLFNBQVMsUUFBUTtDQUN2QixJQUFJLFdBQVcsT0FBTyxPQUFPLEdBQUcsT0FBTyxLQUFLLEdBQUcsRUFBRSxHQUFHLE9BQU87Q0FDM0QsT0FBTztBQUNSOzs7Ozs7Ozs7O0FDckJBLFNBQVMsTUFBTSxPQUFPO0NBQ3JCLElBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFVBQVUsT0FBTztDQUNuRSxJQUFJLE9BQU8sR0FBRyxPQUFPLFVBQVUsR0FBRyxFQUFFLEdBQUcsT0FBTztDQUM5QyxPQUFPLE9BQU8sS0FBSztBQUNwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNRQSxTQUFTLE9BQU8sU0FBUztDQUN4QixJQUFJLE1BQU0sUUFBUSxPQUFPLEdBQUcsT0FBTyxRQUFRLElBQUksS0FBSztDQUNwRCxJQUFJLE9BQU8sWUFBWSxVQUFVLE9BQU8sQ0FBQyxPQUFPO0NBQ2hELFVBQVUsU0FBUyxPQUFPO0NBQzFCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE1BQU0sU0FBUyxRQUFRO0NBQ3ZCLElBQUksV0FBVyxHQUFHLE9BQU87Q0FDekIsSUFBSSxRQUFRO0NBQ1osSUFBSSxNQUFNO0NBQ1YsSUFBSSxZQUFZO0NBQ2hCLElBQUksVUFBVTtDQUNkLElBQUksa0JBQWtCO0NBQ3RCLE1BQU0scUJBQXFCO0NBQzNCLElBQUksUUFBUSxXQUFXLENBQUMsTUFBTSxJQUFJLE9BQU8sS0FBSyxFQUFFO0NBQ2hELE9BQU8sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sT0FBTyxRQUFRO0VBQ3JCLElBQUksV0FBVyxJQUFJLFNBQVMsUUFBUSxRQUFRLElBQUksUUFBUTtHQUN2RDtHQUNBLE9BQU8sUUFBUTtFQUNoQixPQUFPLElBQUksU0FBUyxXQUFXLFlBQVk7T0FDdEMsT0FBTztPQUNQLElBQUksU0FBUyxJQUFJLFNBQVMsUUFBUSxTQUFTLEtBQUs7R0FDcEQsWUFBWTtHQUNaLGtCQUFrQjtFQUNuQixPQUFPLElBQUksU0FBUyxLQUFLO0dBQ3hCLFVBQVU7R0FDVixJQUFJLENBQUMsbUJBQW1CLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQyxtQkFBbUIsS0FBSyxHQUFHLEdBQUc7SUFDM0UsTUFBTSxXQUFXLElBQUksTUFBTSxHQUFHO0lBQzlCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSyxJQUFJLFNBQVMsT0FBTyxJQUFJLE9BQU8sS0FBSyxTQUFTLEVBQUU7R0FDMUYsT0FBTyxPQUFPLEtBQUssR0FBRztHQUN0QixNQUFNO0VBQ1AsT0FBTyxPQUFPO09BQ1QsSUFBSSxTQUFTLEtBQUs7R0FDdEIsVUFBVTtHQUNWLGtCQUFrQjtHQUNsQixJQUFJLEtBQUs7SUFDUixPQUFPLEtBQUssR0FBRztJQUNmLE1BQU07R0FDUDtFQUNELE9BQU8sSUFBSSxTQUFTLEtBQUs7R0FDeEIsSUFBSSxLQUFLO0lBQ1IsT0FBTyxLQUFLLEdBQUc7SUFDZixNQUFNO0dBQ1A7R0FDQSxNQUFNLE9BQU8sUUFBUSxRQUFRO0dBQzdCLElBQUksU0FBUyxLQUFLLEtBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxFQUFFO0VBQ3BELE9BQU8sT0FBTztFQUNkO0NBQ0Q7Q0FDQSxJQUFJLEtBQUssT0FBTyxLQUFLLEdBQUc7Q0FDeEIsT0FBTztBQUNSOzs7O0FDckVBLElBQU1DLG9CQUFrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEwQnhCLFNBQVMsVUFBVSxLQUFLO0NBQ3ZCLFFBQVEsT0FBTyxLQUFmO0VBQ0MsS0FBSztFQUNMLEtBQUssVUFBVSxPQUFPO0VBQ3RCLEtBQUs7R0FDSixJQUFJLFFBQVEsTUFBTSxJQUFJLFdBQVcsR0FBRyxLQUFLLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTztHQUNuRSxPQUFPQSxrQkFBZ0IsS0FBSyxHQUFHO0VBQ2hDLFNBQVMsT0FBTztDQUNqQjtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYkEsU0FBUyxJQUFJLFFBQVEsTUFBTSxjQUFjO0NBQ3hDLElBQUksVUFBVSxNQUFNLE9BQU87Q0FDM0IsUUFBUSxPQUFPLE1BQWY7RUFDQyxLQUFLLFVBQVU7R0FDZCxJQUFJLGlCQUFpQixJQUFJLEdBQUcsT0FBTztHQUNuQyxNQUFNLFNBQVMsT0FBTztHQUN0QixJQUFJLFdBQVcsS0FBSyxHQUFHLElBQUksVUFBVSxJQUFJLEtBQUssQ0FBQyxPQUFPLE9BQU8sUUFBUSxJQUFJLEdBQUcsT0FBTyxJQUFJLFFBQVEsT0FBTyxJQUFJLEdBQUcsWUFBWTtRQUNwSCxPQUFPO0dBQ1osT0FBTztFQUNSO0VBQ0EsS0FBSztFQUNMLEtBQUssVUFBVTtHQUNkLElBQUksT0FBTyxTQUFTLFVBQVUsT0FBTyxNQUFNLElBQUk7R0FDL0MsTUFBTSxTQUFTLE9BQU87R0FDdEIsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0dBQzlCLE9BQU87RUFDUjtFQUNBLFNBQVM7R0FDUixJQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUcsT0FBTyxZQUFZLFFBQVEsTUFBTSxZQUFZO0dBQ3RFLElBQUksT0FBTyxHQUFHLE1BQU0sUUFBUSxHQUFHLEVBQUUsR0FBRyxPQUFPO1FBQ3RDLE9BQU8sT0FBTyxJQUFJO0dBQ3ZCLElBQUksaUJBQWlCLElBQUksR0FBRyxPQUFPO0dBQ25DLE1BQU0sU0FBUyxPQUFPO0dBQ3RCLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTztHQUM5QixPQUFPO0VBQ1I7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxZQUFZLFFBQVEsTUFBTSxjQUFjO0NBQ2hELElBQUksS0FBSyxXQUFXLEdBQUcsT0FBTztDQUM5QixJQUFJLFVBQVU7Q0FDZCxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsS0FBSyxRQUFRLFNBQVM7RUFDakQsSUFBSSxXQUFXLE1BQU0sT0FBTztFQUM1QixJQUFJLGlCQUFpQixLQUFLLE1BQU0sR0FBRyxPQUFPO0VBQzFDLFVBQVUsUUFBUSxLQUFLO0NBQ3hCO0NBQ0EsSUFBSSxZQUFZLEtBQUssR0FBRyxPQUFPO0NBQy9CLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q0EsU0FBUyxTQUFTLE9BQU87Q0FDeEIsT0FBTyxVQUFVLFNBQVMsT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVO0FBQ3pFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZUEsU0FBUyxjQUFjLEtBQUssWUFBWTtDQUN2QyxPQUFPLGdCQUFnQixNQUFNLE9BQU8sS0FBSyxRQUFRLFVBQVU7RUFDMUQsTUFBTSxTQUFTLGFBQWEsT0FBTyxLQUFLLFFBQVEsS0FBSztFQUNyRCxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87RUFDOUIsSUFBSSxPQUFPLFFBQVEsVUFBVTtFQUM3QixJQUFJLE9BQU8sR0FBRyxNQUFNLHFCQUFxQixPQUFPLElBQUksZ0JBQWdCLFlBQVk7R0FDL0UsTUFBTSxTQUFTLENBQUM7R0FDaEIsTUFBTSxJQUFJLEtBQUssTUFBTTtHQUNyQixlQUFlLFFBQVEsS0FBSyxRQUFRLEtBQUs7R0FDekMsT0FBTztFQUNSO0VBQ0EsUUFBUSxPQUFPLFVBQVUsU0FBUyxLQUFLLEdBQUcsR0FBMUM7R0FDQyxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUssWUFBWTtJQUNoQixNQUFNLFNBQVMsSUFBSSxJQUFJLFlBQVksS0FBSyxRQUFRLENBQUM7SUFDakQsZUFBZSxRQUFRLEdBQUc7SUFDMUIsT0FBTztHQUNSO0dBQ0EsS0FBSyxjQUFjO0lBQ2xCLE1BQU0sU0FBUyxDQUFDO0lBQ2hCLGVBQWUsUUFBUSxHQUFHO0lBQzFCLE9BQU8sU0FBUyxJQUFJO0lBQ3BCLE9BQU8sT0FBTyxZQUFZLElBQUksT0FBTztJQUNyQyxPQUFPO0dBQ1I7R0FDQSxTQUFTO0VBQ1Y7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QkEsU0FBUyxVQUFVLEtBQUs7Q0FDdkIsT0FBTyxjQUFjLEdBQUc7QUFDekI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUJBLFNBQVMsWUFBWSxPQUFPO0NBQzNCLE9BQU8sVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLE9BQU8sS0FBSyxNQUFNO0FBQ3pFOzs7QUN2QkEsSUFBTSxzQkFBc0I7QUFDNUIsU0FBUyxRQUFRLE9BQU8sU0FBUyxPQUFPLGtCQUFrQjtDQUN6RCxRQUFRLE9BQU8sT0FBZjtFQUNDLEtBQUssVUFBVSxPQUFPLE9BQU8sVUFBVSxLQUFLLEtBQUssU0FBUyxLQUFLLFFBQVE7RUFDdkUsS0FBSyxVQUFVLE9BQU87RUFDdEIsS0FBSyxVQUFVLE9BQU8sb0JBQW9CLEtBQUssS0FBSztDQUNyRDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzJCQSxTQUFTLElBQUksUUFBUSxNQUFNO0NBQzFCLElBQUk7Q0FDSixJQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUcsZUFBZTtNQUNuQyxJQUFJLE9BQU8sU0FBUyxZQUFZLFVBQVUsSUFBSSxLQUFLLEVBQUUsUUFBUSxPQUFPLE1BQU0sSUFBSSxlQUFlLE9BQU8sSUFBSTtNQUN4RyxlQUFlLENBQUMsSUFBSTtDQUN6QixJQUFJLGFBQWEsV0FBVyxHQUFHLE9BQU87Q0FDdEMsSUFBSSxVQUFVO0NBQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0VBQzdDLE1BQU0sTUFBTSxNQUFNLGFBQWEsRUFBRTtFQUNqQyxJQUFJLFdBQVcsUUFBUSxDQUFDLE9BQU8sT0FBTyxTQUFTLEdBQUcsR0FDN0M7T0FBQSxHQUFHLE1BQU0sUUFBUSxPQUFPLEtBQUssWUFBWSxPQUFPLE1BQU0sUUFBUSxHQUFHLEtBQUssT0FBTyxHQUFHLElBQUksUUFBUSxTQUFTLE9BQU87RUFBQTtFQUVqSCxVQUFVLFFBQVE7Q0FDbkI7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUJBLFNBQVMsYUFBYSxPQUFPO0NBQzVCLE9BQU8sT0FBTyxVQUFVLFlBQVksVUFBVTtBQUMvQzs7Ozs7Ozs7Ozs7Ozs7O0FDWEEsU0FBUyxrQkFBa0IsT0FBTztDQUNqQyxPQUFPLGFBQWEsS0FBSyxLQUFLLFlBQVksS0FBSztBQUNoRDs7OztBQ2RBLElBQU0sa0JBQWtCOztBQUV4QixJQUFNLG1CQUFtQjs7Ozs7Ozs7Ozs7Ozs7QUFjekIsU0FBUyxNQUFNLE9BQU8sUUFBUTtDQUM3QixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUcsT0FBTztDQUNqQyxJQUFJLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxhQUFhLFNBQVMsUUFBUSxTQUFTLEtBQUssR0FBRyxPQUFPO0NBQ3hHLE9BQU8sT0FBTyxVQUFVLGFBQWEsaUJBQWlCLEtBQUssS0FBSyxLQUFLLENBQUMsZ0JBQWdCLEtBQUssS0FBSyxNQUFNLFVBQVUsUUFBUSxPQUFPLE9BQU8sUUFBUSxLQUFLO0FBQ3BKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOQSxTQUFTLGFBQWEsR0FBRztDQUN4QixPQUFPLGVBQWUsQ0FBQztBQUN4Qjs7O0FDakJBLElBQU0sZUFBZSxRQUFRLEtBQUssVUFBVTtDQUMzQyxNQUFNLFdBQVcsT0FBTztDQUN4QixJQUFJLEVBQUUsT0FBTyxPQUFPLFFBQVEsR0FBRyxLQUFLLEdBQUcsVUFBVSxLQUFLLE1BQU0sVUFBVSxLQUFLLEtBQUssRUFBRSxPQUFPLFNBQVMsT0FBTyxPQUFPO0FBQ2pIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWUEsU0FBUyx3QkFBd0IsS0FBSztDQUNyQyxPQUFPLFFBQVEsZUFBZSxRQUFRLGlCQUFpQixRQUFRO0FBQ2hFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ09BLFNBQVMsV0FBVyxLQUFLLE1BQU0sU0FBUyxZQUFZO0NBQ25ELElBQUksT0FBTyxRQUFRLENBQUMsU0FBUyxHQUFHLEdBQUcsT0FBTztDQUMxQyxJQUFJO0NBQ0osSUFBSSxNQUFNLE1BQU0sR0FBRyxHQUFHLGVBQWUsQ0FBQyxJQUFJO01BQ3JDLElBQUksTUFBTSxRQUFRLElBQUksR0FBRyxlQUFlO01BQ3hDLGVBQWUsT0FBTyxJQUFJO0NBQy9CLE1BQU0sY0FBYyxRQUFRLElBQUksS0FBSyxZQUFZLENBQUM7Q0FDbEQsSUFBSSxVQUFVO0NBQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsVUFBVSxXQUFXLE1BQU0sS0FBSztFQUNoRSxNQUFNLE1BQU0sTUFBTSxhQUFhLEVBQUU7RUFDakMsSUFBSSx3QkFBd0IsR0FBRyxHQUFHLE9BQU87RUFDekMsSUFBSTtFQUNKLElBQUksTUFBTSxhQUFhLFNBQVMsR0FBRyxXQUFXO09BQ3pDO0dBQ0osTUFBTSxXQUFXLFFBQVE7R0FDekIsTUFBTSxtQkFBbUIsYUFBYSxVQUFVLEtBQUssR0FBRztHQUN4RCxXQUFXLHFCQUFxQixLQUFLLElBQUksbUJBQW1CLFNBQVMsUUFBUSxJQUFJLFdBQVcsUUFBUSxhQUFhLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2xJO0VBQ0EsWUFBWSxTQUFTLEtBQUssUUFBUTtFQUNsQyxVQUFVLFFBQVE7Q0FDbkI7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25CQSxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU87Q0FDOUIsT0FBTyxXQUFXLEtBQUssWUFBWSxhQUFhLEtBQUssQ0FBQztBQUN2RDs7O0FDN0JBLFNBQVNDLFdBQVMsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEdBQUc7Q0FDckQsSUFBSSxPQUFPLFlBQVksVUFBVSxVQUFVLENBQUM7Q0FDNUMsTUFBTSxFQUFFLFVBQVUsT0FBTyxXQUFXLE1BQU0sWUFBWTtDQUN0RCxNQUFNLFFBQVEsTUFBTSxDQUFDO0NBQ3JCLElBQUksU0FBUyxNQUFNLEtBQUs7Q0FDeEIsSUFBSSxVQUFVLE1BQU0sS0FBSztDQUN6QixJQUFJLFNBQVMsS0FBSztDQUNsQixJQUFJLFlBQVk7Q0FDaEIsTUFBTSxhQUFhQyxXQUFXLFNBQVMsR0FBRyxNQUFNO0VBQy9DLFNBQVMsS0FBSyxNQUFNLE1BQU0sSUFBSTtFQUM5QixZQUFZO0NBQ2IsR0FBRyxZQUFZLEVBQUUsTUFBTSxDQUFDO0NBQ3hCLE1BQU0sWUFBWSxTQUFTLEdBQUcsTUFBTTtFQUNuQyxJQUFJLFdBQVcsTUFBTTtHQUNwQixJQUFJLGNBQWMsTUFBTSxZQUFZLEtBQUssSUFBSTtHQUM3QyxJQUFJLEtBQUssSUFBSSxJQUFJLGFBQWEsU0FBUztJQUN0QyxJQUFJLFdBQVcsVUFBVSxTQUFTLEtBQUssTUFBTSxNQUFNLElBQUk7SUFDdkQsWUFBWSxLQUFLLElBQUk7SUFDckIsV0FBVyxPQUFPO0lBQ2xCLFdBQVcsU0FBUztJQUNwQixPQUFPO0dBQ1I7RUFDRDtFQUNBLFdBQVcsTUFBTSxNQUFNLElBQUk7RUFDM0IsT0FBTztDQUNSO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLFdBQVcsTUFBTTtFQUNqQixPQUFPO0NBQ1I7Q0FDQSxVQUFVLFNBQVMsV0FBVztDQUM5QixVQUFVLFFBQVE7Q0FDbEIsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdUJBLFNBQVMsVUFBVSxRQUFRLEdBQUcsV0FBVztDQUN4QyxNQUFNLFVBQVUsVUFBVSxNQUFNLEdBQUcsRUFBRTtDQUNyQyxNQUFNLFFBQVEsVUFBVSxVQUFVLFNBQVM7Q0FDM0MsSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sU0FBUyxRQUFRO0VBQ3ZCLFNBQVMsY0FBYyxRQUFRLFFBQVEsdUJBQXVCLElBQUksSUFBSSxDQUFDO0NBQ3hFO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjLFFBQVEsUUFBUSxPQUFPLE9BQU87Q0FDcEQsSUFBSSxZQUFZLE1BQU0sR0FBRyxTQUFTLE9BQU8sTUFBTTtDQUMvQyxJQUFJLFVBQVUsUUFBUSxPQUFPLFdBQVcsVUFBVSxPQUFPO0NBQ3pELElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxPQUFPLE1BQU0sTUFBTSxJQUFJLE1BQU0sQ0FBQztDQUNyRCxNQUFNLElBQUksUUFBUSxNQUFNO0NBQ3hCLElBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztFQUMxQixTQUFTLE9BQU8sTUFBTTtFQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUssSUFBSSxFQUFFLEtBQUssU0FBUyxPQUFPLEtBQUssS0FBSztDQUM5RTtDQUNBLE1BQU0sYUFBYSxDQUFDLEdBQUcsT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHLFdBQVcsTUFBTSxDQUFDO0NBQ2pFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztFQUMzQyxNQUFNLE1BQU0sV0FBVztFQUN2QixJQUFJLGlCQUFpQixHQUFHLEdBQUc7RUFDM0IsSUFBSSxjQUFjLE9BQU87RUFDekIsSUFBSSxjQUFjLE9BQU87RUFDekIsSUFBSSxZQUFZLFdBQVcsR0FBRyxjQUFjLEVBQUUsR0FBRyxZQUFZO0VBQzdELElBQUksWUFBWSxXQUFXLEdBQUcsY0FBYyxFQUFFLEdBQUcsWUFBWTtFQUM3RCxJQUFJLFNBQVMsV0FBVyxHQUFHLGNBQWMsVUFBVSxXQUFXO0VBQzlELElBQUksTUFBTSxRQUFRLFdBQVcsR0FBRyxJQUFJLE1BQU0sUUFBUSxXQUFXLEdBQUc7R0FDL0QsTUFBTSxTQUFTLENBQUM7R0FDaEIsTUFBTSxhQUFhLFFBQVEsUUFBUSxXQUFXO0dBQzlDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztJQUMzQyxNQUFNLFlBQVksV0FBVztJQUM3QixPQUFPLGFBQWEsWUFBWTtHQUNqQztHQUNBLGNBQWM7RUFDZixPQUFPLElBQUksa0JBQWtCLFdBQVcsR0FBRztHQUMxQyxNQUFNLFNBQVMsQ0FBQztHQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEtBQUssT0FBTyxLQUFLLFlBQVk7R0FDckUsY0FBYztFQUNmLE9BQU8sY0FBYyxDQUFDO0VBQ3RCLE1BQU0sU0FBUyxNQUFNLGFBQWEsYUFBYSxLQUFLLFFBQVEsUUFBUSxLQUFLO0VBQ3pFLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxPQUFPO09BQ2hDLElBQUksTUFBTSxRQUFRLFdBQVcsR0FBRyxPQUFPLE9BQU8sY0FBYyxhQUFhLGFBQWEsT0FBTyxLQUFLO09BQ2xHLElBQUksYUFBYSxXQUFXLEtBQUssYUFBYSxXQUFXLE1BQU1DLGdCQUFjLFdBQVcsS0FBS0EsZ0JBQWMsV0FBVyxLQUFLLGFBQWEsV0FBVyxLQUFLLGFBQWEsV0FBVyxJQUFJLE9BQU8sT0FBTyxjQUFjLGFBQWEsYUFBYSxPQUFPLEtBQUs7T0FDdFAsSUFBSSxlQUFlLFFBQVFBLGdCQUFjLFdBQVcsR0FBRyxPQUFPLE9BQU8sY0FBYyxDQUFDLEdBQUcsYUFBYSxPQUFPLEtBQUs7T0FDaEgsSUFBSSxlQUFlLFFBQVEsYUFBYSxXQUFXLEdBQUcsT0FBTyxPQUFPLFVBQVUsV0FBVztPQUN6RixJQUFJLGdCQUFnQixLQUFLLEtBQUssZ0JBQWdCLEtBQUssR0FBRyxPQUFPLE9BQU87Q0FDMUU7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwRUEsU0FBUyxNQUFNLFFBQVEsR0FBRyxTQUFTO0NBQ2xDLE9BQU8sVUFBVSxRQUFRLEdBQUcsU0FBU0MsTUFBSTtBQUMxQzs7Ozs7Ozs7Ozs7Ozs7OztBQzFCQSxTQUFTLE9BQU8sUUFBUTtDQUN2QixPQUFPLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFDakM7Ozs7OztBQ2ZBLElBQWFDLFlBQVUsVUFBVyxPQUFPLFNBQVMsZUFBZSxpQkFBaUIsUUFDM0UsaUJBQWlCLFFBQ2hCLE9BQU8sYUFBYSxlQUFlLGlCQUFpQixZQUFZLE1BQU0sU0FBUzs7Ozs7O0FBTXZGLElBQWFDLGNBQVksU0FBUztDQUM5QixJQUFJLGdCQUFnQixVQUNoQixPQUFPO0NBRVgsT0FBT0QsU0FBTyxJQUFJLEtBQ1YsT0FBTyxTQUFTLFlBQVksU0FBUyxRQUFRLE9BQU8sT0FBTyxJQUFJLENBQUMsQ0FBQyxNQUFNLFVBQVVDLFdBQVMsS0FBSyxDQUFDO0FBQzVHOzs7Ozs7QUNkQSxJQUFhQyxzQkFBYixjQUF1QyxNQUFNO0NBQ3pDO0NBQ0EsWUFBWSxVQUFVO0VBQ2xCLE1BQU0sY0FBYyxTQUFTLFFBQVE7RUFDckMsS0FBSyxPQUFPO0VBQ1osS0FBSyxXQUFXO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhQyx1QkFBYixjQUF3QyxNQUFNO0NBQzFDLFlBQVksVUFBVSx5QkFBeUI7RUFDM0MsTUFBTSxPQUFPO0VBQ2IsS0FBSyxPQUFPO0NBQ2hCO0FBQ0o7Ozs7QUFJQSxJQUFhQyxxQkFBYixjQUFzQyxNQUFNO0NBQ3hDLFlBQVksVUFBVSxpQkFBaUI7RUFDbkMsTUFBTSxPQUFPO0VBQ2IsS0FBSyxPQUFPO0NBQ2hCO0FBQ0o7Ozs7OztBQ3pCQSxTQUFnQixpQkFBaUIsUUFBUTtDQUNyQyxNQUFNLGVBQWUsSUFBSSxnQkFBZ0I7Q0FDekMsT0FBTyxRQUFRLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFdBQVc7RUFDN0MsSUFBSSxVQUFVLEtBQUEsS0FBYSxVQUFVLE1BQ2pDO0VBRUosSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUNuQixNQUFNLFNBQVMsU0FBUyxhQUFhLE9BQU8sR0FBRyxJQUFJLEtBQUssT0FBTyxJQUFJLENBQUMsQ0FBQztPQUVwRSxJQUFJLE9BQU8sVUFBVSxVQUN0QixhQUFhLE9BQU8sS0FBSyxLQUFLLFVBQVUsS0FBSyxDQUFDO09BRzlDLGFBQWEsT0FBTyxLQUFLLE9BQU8sS0FBSyxDQUFDO0NBRTlDLENBQUM7Q0FDRCxPQUFPLGFBQWEsU0FBUztBQUNqQzs7OztBQUlBLFNBQWdCLFNBQVMsS0FBSyxTQUFTLFFBQVE7Q0FDM0MsSUFBSSxXQUFXLENBQUMsSUFBSSxXQUFXLFNBQVMsS0FBSyxDQUFDLElBQUksV0FBVyxVQUFVLEdBQ25FLE1BQU0sUUFBUSxRQUFRLE9BQU8sRUFBRSxJQUFJLE1BQU0sSUFBSSxRQUFRLE9BQU8sRUFBRTtDQUVsRSxJQUFJLFVBQVUsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVMsR0FBRztFQUMxQyxNQUFNLGNBQWMsaUJBQWlCLE1BQU07RUFDM0MsSUFBSSxhQUNBLFFBQVEsSUFBSSxTQUFTLEdBQUcsSUFBSSxNQUFNLE9BQU87Q0FFakQ7Q0FDQSxPQUFPO0FBQ1g7Ozs7OztBQzdCQSxTQUFTLGdCQUFnQjtDQUNyQixJQUFJLE9BQU8sV0FBVyxhQUNsQixPQUFPO0NBRVgsT0FBTyxPQUFPLE9BQU8sVUFBVSxTQUFTLFNBQVMsdUJBQXVCO0FBQzVFOzs7O0FBSUEsU0FBUyxXQUFXLE1BQU0sV0FBVyxJQUFJLFNBQVMsR0FBRyxZQUFZLE1BQU07Q0FDbkUsS0FBSyxNQUFNLE9BQU8sTUFDZCxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssTUFBTSxHQUFHLEdBQzlDLGlCQUFpQixVQUFVLFlBQVksR0FBRyxVQUFVLEdBQUcsSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJO0NBR3RGLE9BQU87QUFDWDtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsS0FBSyxPQUFPO0NBQzVDLElBQUksTUFBTSxRQUFRLEtBQUssR0FDbkIsT0FBTyxNQUFNLFNBQVMsS0FBSyxVQUFVLGlCQUFpQixVQUFVLEdBQUcsSUFBSSxHQUFHLE1BQU0sSUFBSSxHQUFHLENBQUM7TUFFdkYsSUFBSSxpQkFBaUIsTUFDdEIsT0FBTyxTQUFTLE9BQU8sS0FBSyxNQUFNLFlBQVksQ0FBQztNQUU5QyxJQUFJLE9BQU8sU0FBUyxlQUFlLGlCQUFpQixNQUNyRCxPQUFPLFNBQVMsT0FBTyxLQUFLLE9BQU8sTUFBTSxJQUFJO01BRTVDLElBQUksaUJBQWlCLE1BQ3RCLE9BQU8sU0FBUyxPQUFPLEtBQUssS0FBSztNQUVoQyxJQUFJLE9BQU8sVUFBVSxXQUN0QixPQUFPLFNBQVMsT0FBTyxLQUFLLFFBQVEsTUFBTSxHQUFHO01BRTVDLElBQUksT0FBTyxVQUFVLFVBQ3RCLE9BQU8sU0FBUyxPQUFPLEtBQUssS0FBSztNQUVoQyxJQUFJLE9BQU8sVUFBVSxVQUN0QixPQUFPLFNBQVMsT0FBTyxLQUFLLEdBQUcsT0FBTztNQUVyQyxJQUFJLFVBQVUsUUFBUSxVQUFVLEtBQUEsR0FDakMsT0FBTyxTQUFTLE9BQU8sS0FBSyxFQUFFO0NBRWxDLFdBQVcsT0FBTyxVQUFVLEdBQUc7QUFDbkM7Ozs7QUFJQSxTQUFTLFlBQVksTUFBTSxTQUFTO0NBQ2hDLElBQUksU0FBUyxLQUFBLEtBQWEsU0FBUyxNQUMvQjtDQUVKLElBQUksZ0JBQWdCLFVBQ2hCLE9BQU87Q0FFWCxJQUFJLE9BQU8sU0FBUyxZQUFZQyxXQUFTLElBQUksR0FDekMsT0FBTyxXQUFXLElBQUk7Q0FFMUIsSUFBSSxPQUFPLFNBQVMsWUFBWSxRQUFRLGVBQWUsRUFBRSxTQUFTLGtCQUFrQixHQUNoRixPQUFPLEtBQUssVUFBVSxJQUFJO0NBRTlCLE9BQU8sT0FBTyxJQUFJO0FBQ3RCOzs7O0FBSUEsU0FBU0MsZUFBYSxTQUFTO0NBQzNCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLFFBQVEsU0FBUyxPQUFPLFFBQVE7RUFDNUIsT0FBTyxJQUFJLFlBQVksS0FBSztDQUNoQyxDQUFDO0NBQ0QsT0FBTztBQUNYOzs7O0FBSUEsU0FBZ0Isa0JBQWtCLFVBQVUsQ0FBQyxHQUFHO0NBQzVDLElBQUksaUJBQWlCLFFBQVEsa0JBQWtCO0NBQy9DLElBQUksaUJBQWlCLFFBQVEsa0JBQWtCO0NBQy9DLFNBQVMsZUFBZTtFQUNwQixJQUFJLE9BQU8sYUFBYSxhQUNwQixPQUFPO0VBRVgsTUFBTSxRQUFRLFNBQVMsT0FBTyxNQUFNLElBQUksT0FBTyxjQUFjLGlCQUFpQixVQUFVLENBQUM7RUFDekYsT0FBTyxRQUFRLG1CQUFtQixNQUFNLEVBQUUsSUFBSTtDQUNsRDtDQUNBLE9BQU87RUFDSCxrQkFBa0IsTUFBTTtHQUNwQixpQkFBaUI7RUFDckI7RUFDQSxrQkFBa0IsTUFBTTtHQUNwQixpQkFBaUI7RUFDckI7RUFDQSxNQUFNLFFBQVEsUUFBUTtHQUNsQixNQUFNLE1BQU0sU0FBUyxPQUFPLEtBQUssT0FBTyxTQUFTLE9BQU8sTUFBTTtHQUM5RCxNQUFNLFNBQVMsT0FBTyxPQUFPLFlBQVk7R0FDekMsTUFBTSxVQUFVLENBQUM7R0FFakIsTUFBTSxhQUFhLGNBQWM7R0FDakMsSUFBSSxZQUNBLFFBQVEsc0JBQXNCO0dBR2xDLElBQUksT0FBTyxTQUFTLEtBQUEsS0FBYSxDQUFDLENBQUMsT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFTLE1BQU0sR0FDM0Q7UUFBQSxFQUFFLE9BQU8sZ0JBQWdCLGFBQWEsQ0FBQ0QsV0FBUyxPQUFPLElBQUksR0FDM0QsUUFBUSxrQkFBa0I7R0FBQTtHQUlsQyxJQUFJLE9BQU8sU0FDUCxPQUFPLFFBQVEsT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxXQUFXO0lBQ3JELElBQUksVUFBVSxLQUFBLEdBQ1YsUUFBUSxPQUFPLE9BQU8sS0FBSztHQUVuQyxDQUFDO0dBR0wsTUFBTSxZQUFZLGFBQWE7R0FDL0IsSUFBSSxhQUFhLENBQUM7SUFBQztJQUFPO0lBQVE7R0FBUyxDQUFDLENBQUMsU0FBUyxNQUFNLEdBQ3hELFFBQVEsa0JBQWtCO0dBRzlCLElBQUksU0FBUyxPQUFPO0dBQ3BCLElBQUk7R0FDSixNQUFNLFVBQVUsT0FBTyxXQUFXO0dBQ2xDLElBQUksVUFBVSxLQUFLLENBQUMsUUFBUTtJQUN4QixNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7SUFDdkMsU0FBUyxXQUFXO0lBQ3BCLFlBQVksaUJBQWlCLFdBQVcsTUFBTSxHQUFHLE9BQU87R0FDNUQ7R0FFQSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVMsTUFBTSxJQUN4QyxLQUFBLElBQ0EsWUFBWSxPQUFPLE1BQU0sT0FBTztHQUN0QyxJQUFJLGdCQUFnQixVQUNoQixPQUFPLFFBQVE7R0FFbkIsSUFBSTtJQUNBLE1BQU0sV0FBVyxNQUFNLE1BQU0sS0FBSztLQUM5QjtLQUNBO0tBQ0E7S0FDQTtLQUNBLGFBQWEsT0FBTyxlQUFlO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFdBQ0EsYUFBYSxTQUFTO0lBRTFCLElBQUk7SUFFSixJQURvQixTQUFTLFFBQVEsSUFBSSxjQUMzQixDQUFDLEVBQUUsU0FBUyxrQkFBa0IsR0FDeEMsT0FBTyxNQUFNLFNBQVMsS0FBSztTQUczQixPQUFPLE1BQU0sU0FBUyxLQUFLO0lBRS9CLE1BQU0sZUFBZTtLQUNqQixRQUFRLFNBQVM7S0FDakI7S0FDQSxTQUFTQyxlQUFhLFNBQVMsT0FBTztJQUMxQztJQUNBLElBQUksQ0FBQyxTQUFTLElBQ1YsTUFBTSxJQUFJQyxvQkFBa0IsWUFBWTtJQUU1QyxPQUFPO0dBQ1gsU0FDTyxPQUFPO0lBQ1YsSUFBSSxXQUNBLGFBQWEsU0FBUztJQUUxQixJQUFJLGlCQUFpQkEscUJBQ2pCLE1BQU07SUFFVixJQUFJLGlCQUFpQixnQkFBZ0IsTUFBTSxTQUFTLGNBQ2hELE1BQU0sSUFBSUMscUJBQW1CO0lBRWpDLElBQUksaUJBQWlCLFdBQ2pCLE1BQU0sSUFBSUMsbUJBQWlCLE1BQU0sT0FBTztJQUU1QyxNQUFNO0dBQ1Y7RUFDSjtDQUNKO0FBQ0o7Ozs7QUFJQSxJQUFhLGtCQUFrQixrQkFBa0I7Ozs7OztBQ3pMakQsSUFBSUMsZUFBYTs7OztBQUlqQixJQUFJLFVBQVUsS0FBQTs7OztBQUlkLElBQUksVUFBVSxLQUFBOzs7O0FBSWQsSUFBSSxjQUFjOzs7O0FBSWxCLElBQUksOEJBQThCLFdBQVcsR0FBRyxPQUFPLE9BQU8sR0FBRyxPQUFPLFdBQVcsV0FBVyxLQUFLLE9BQU87Ozs7QUFJMUcsSUFBSSxtQkFBbUIsYUFBYSxTQUFTLFdBQVcsT0FBTyxTQUFTLFFBQVEsNEJBQTRCOzs7O0FBSTVHLElBQU0sbUJBQW1CLENBQUM7Ozs7QUFJMUIsSUFBYSxTQUFTO0NBQ2xCLE1BQU0sS0FBSyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTyxLQUFLLE1BQU0sTUFBTSxDQUFDO0NBQ25GLE9BQU8sS0FBSyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxRQUFRLFlBQVksUUFBUSxLQUFLLE1BQU0sTUFBTSxDQUFDO0NBQ3JGLFFBQVEsS0FBSyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxRQUFRLFlBQVksU0FBUyxLQUFLLE1BQU0sTUFBTSxDQUFDO0NBQ3ZGLE1BQU0sS0FBSyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTyxLQUFLLE1BQU0sTUFBTSxDQUFDO0NBQ25GLFNBQVMsS0FBSyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxRQUFRLFlBQVksVUFBVSxLQUFLLE1BQU0sTUFBTSxDQUFDO0NBQ3pGLGNBQWMsZUFBZTtFQUN6QixlQUFhO0VBQ2IsT0FBTztDQUNYO0NBQ0EsWUFBWSxLQUFLO0VBQ2IsVUFBVTtFQUNWLE9BQU87Q0FDWDtDQUNBLFlBQVksVUFBVTtFQUNsQixVQUFVO0VBQ1YsT0FBTztDQUNYO0NBQ0EsZ0JBQWdCLE9BQU87RUFDbkIsY0FBYyxPQUFPLFVBQVUsV0FBVyxRQUFTLFFBQVEsWUFBWTtFQUN2RSxPQUFPO0NBQ1g7Q0FDQSx5QkFBeUIsVUFBVTtFQUMvQiw2QkFBNkIsYUFBYSxhQUM5QixPQUNOO0VBQ04sT0FBTztDQUNYO0NBQ0Esc0JBQXNCLFVBQVU7RUFDNUIsa0JBQWtCO0VBQ2xCLE9BQU87Q0FDWDtDQUNBLG1CQUFtQixNQUFNO0VBQ3JCLGdCQUFnQixrQkFBa0IsSUFBSTtFQUN0QyxPQUFPO0NBQ1g7Q0FDQSxtQkFBbUIsTUFBTTtFQUNyQixnQkFBZ0Isa0JBQWtCLElBQUk7RUFDdEMsT0FBTztDQUNYO0FBQ0o7Ozs7QUFJQSxJQUFNLGVBQWUsUUFBUSxLQUFLLE1BQU0sWUFBWTtDQUNoRDtDQUNBO0NBQ0EsR0FBRztDQUNILEdBQUksQ0FBQyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVMsTUFBTSxJQUFJLEVBQ3JDLFFBQVEsTUFBTSxDQUFDLEdBQUcsTUFBTSxRQUFRLE1BQU0sRUFDMUMsSUFBSSxFQUNBLE1BQU0sTUFBTSxDQUFDLEdBQUcsTUFBTSxRQUFRLElBQUksRUFDdEM7QUFDSjs7OztBQUlBLElBQU0sV0FBVyxhQUFhLENBQUMsTUFBTTtDQUNqQyxNQUFNLFNBQVM7RUFDWDtFQUNBO0VBQ0E7Q0FDSixDQUFDLENBQUMsUUFBUSxRQUFRLGFBQWEsU0FBUyxNQUFNLEdBQUcsVUFBVTtDQUMzRCxLQUFLLE9BQU8sbUJBQW1CLE1BQUEsQ0FBTyxNQUFNLE9BQ3hDLE9BQU8sUUFBUSxRQUFRLElBQUk7Q0FFL0IsQ0FBQyxPQUFPLGtCQUFrQixNQUFBLENBQU87Q0FDakMsT0FBT0EsYUFBVyxRQUFRO0VBQ3RCLFFBQVEsT0FBTztFQUNmLEtBQUssT0FBTztFQUNaLFNBQVMsT0FBTyxXQUFXO0VBQzNCLE1BQU0sT0FBTztFQUNiLFFBQVEsT0FBTztFQUNmLFNBQVMsT0FBTztFQUNoQixRQUFRLE9BQU87RUFDZixTQUFTLE9BQU87RUFDaEI7Q0FDSixDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sYUFBYTtFQUN4QixJQUFJLE9BQU8sY0FDUCw2QkFBNkIsUUFBUTtFQUV6QyxNQUFNLFNBQVMsU0FBUztFQUN4QixJQUFJLFVBQVU7RUFDZCxJQUFJLE9BQU8sZ0JBQWdCLE9BQU8seUJBQXlCLGdCQUFnQixRQUFRLEdBQy9FLFVBQVUsTUFBTSxRQUFRLFFBQVEsT0FBTyxzQkFBc0IsUUFBUSxLQUFLLE9BQU87RUFFckYsSUFBSSxPQUFPLGFBQWEsVUFBVSxNQUFNLEdBQ3BDLFVBQVUsTUFBTSxRQUFRLFFBQVEsT0FBTyxVQUFVLE9BQU8sS0FBSyxPQUFPO0VBSXhFLFFBRnNCLHFCQUFxQixRQUFRLE1BQU0sT0FDaEQsYUFBYSxVQUFBLENBQ0QsT0FBTyxLQUFLO0NBQ3JDLElBQUksVUFBVTtFQUNWLElBQUksMEJBQTBCLEtBQUssR0FDL0IsT0FBTyxRQUFRLE9BQU8sS0FBSztFQUUvQixNQUFNLFlBQVk7RUFDbEIsSUFBSSxPQUFPLGNBQ1AsNkJBQTZCLFVBQVUsUUFBUTtFQUluRCxRQUZzQixxQkFBcUIsUUFBUSxVQUFVLFNBQVMsTUFBTSxPQUNuRSxHQUFHLFVBQVUsUUFBUSxPQUFPLEtBQUssR0FBQSxDQUNyQixVQUFVLFVBQVUsU0FBUztDQUN0RCxDQUFDLENBQUMsQ0FBQyxRQUFRLE9BQU8sbUJBQW1CLEtBQUs7QUFDOUM7Ozs7QUFJQSxJQUFNLGlCQUFpQixXQUFXO0NBQzlCLE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTztDQUNuQyxPQUFPO0VBQ0gsR0FBRztFQUNILFNBQVMsT0FBTyxXQUFXO0VBQzNCLGNBQWMsT0FBTyxpQkFBaUI7RUFDdEMsYUFBYSxPQUFPLE9BQU8sZ0JBQWdCLGNBQ3JDLDJCQUEyQixRQUFRQSxZQUFVLElBQzdDLE9BQU87RUFDYixTQUFTO0dBQ0wsR0FBRyxPQUFPO0dBQ1YsVUFBVTtHQUNWLGdCQUFnQixtQkFBbUIsTUFBTTtHQUN6QyxHQUFHLE9BQU8saUJBQWlCLFFBQVEsRUFDL0IsY0FBYyxLQUNsQixJQUFJLENBQUM7R0FDTCxHQUFHLE9BQU8sRUFDTiw4QkFBOEIsTUFBTSxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssRUFDeEQsSUFBSSxDQUFDO0VBQ1Q7Q0FDSjtBQUNKOzs7O0FBSUEsSUFBTSxhQUFhLFdBQVcsVUFBVSxPQUFPLFNBQVM7Ozs7QUFJeEQsSUFBTSx5QkFBeUIsV0FBVztDQUN0QyxJQUFJLE9BQU8sT0FBTyxnQkFBZ0IsVUFDOUIsT0FBTztDQUVYLGlCQUFpQixPQUFPLFlBQVksRUFBRSxNQUFNO0NBQzVDLE9BQU8saUJBQWlCLE9BQU87Q0FDL0IsT0FBTztBQUNYOzs7O0FBSUEsSUFBTSwwQkFBMEIsV0FBVztDQUN2QyxJQUFJLE9BQU8sT0FBTyxnQkFBZ0IsWUFDM0IsT0FBTyxVQUNQLENBQUMsT0FBTyxjQUNYLE9BQU87Q0FFWCxpQkFBaUIsT0FBTyxlQUFlLElBQUksZ0JBQWM7Q0FDekQsT0FBTztFQUNILEdBQUc7RUFDSCxRQUFRLGlCQUFpQixPQUFPLFlBQVksQ0FBQztDQUNqRDtBQUNKOzs7O0FBSUEsSUFBTSxnQ0FBZ0MsYUFBYTtDQUMvQyxJQUFJLFNBQVMsU0FBUyxpQkFBaUIsUUFDbkMsTUFBTSxNQUFNLDhHQUE4RztBQUVsSTs7OztBQUlBLElBQU0sNkJBQTZCLFVBQVU7Q0FDekMsT0FBTyxFQUFFLGlCQUFpQkMsd0JBQXNCLE9BQU8sTUFBTSxVQUFVLFdBQVc7QUFDdEY7Ozs7QUFJQSxJQUFNLHdCQUF3QixRQUFRLFVBQVU7Q0FDNUMsS0FBSyxPQUFPO0NBQ1osS0FBSyxPQUFPO0NBQ1osS0FBSyxPQUFPO0NBQ1osS0FBSyxPQUFPO0NBQ1osS0FBSyxPQUFPO0NBQ1osS0FBSyxPQUFPO0FBQ2hCLEVBQUEsQ0FBRTs7OztBQUlGLElBQU0sc0JBQXNCLFdBQVksT0FBTyxVQUFVLG1CQUNsRCxPQUFPLFVBQVUsbUJBQ2pCLE9BQU8sVUFBVSxvQkFDaEJDLFdBQVMsT0FBTyxJQUFJLElBQUksd0JBQXdCOzs7Ozs7Ozs7OztBQ3JOeEQsSUFBYSx1QkFBdUIsU0FBUyxTQUFTO0NBQ2xELElBQUksQ0FBQyxRQUFRLFNBQVMsR0FBRyxHQUNyQixPQUFPLENBQUMsT0FBTztDQUVuQixNQUFNLFFBQVEsUUFBUSxNQUFNLEdBQUc7Q0FDL0IsSUFBSSxRQUFRLENBQUMsRUFBRTtDQUNmLEtBQUssTUFBTSxRQUFRLE9BQ2YsSUFBSSxTQUFTLEtBQUs7RUFDZCxNQUFNLFdBQVcsQ0FBQztFQUNsQixLQUFLLE1BQU0sUUFBUSxPQUFPO0dBQ3RCLE1BQU0sUUFBUSxPQUFPLElBQUksTUFBTSxJQUFJLElBQUk7R0FDdkMsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUVuQixLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBTSxRQUFRLFNBQ3RDLFNBQVMsS0FBSyxPQUFPLEdBQUcsS0FBSyxHQUFHLFVBQVUsT0FBTyxLQUFLLENBQUM7UUFHMUQsSUFBSSxVQUFVLFFBQVEsT0FBTyxVQUFVLFVBRXhDLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQy9CLFNBQVMsS0FBSyxPQUFPLEdBQUcsS0FBSyxHQUFHLFFBQVEsR0FBRztFQUt2RDtFQUNBLFFBQVE7Q0FDWixPQUdJLFFBQVEsTUFBTSxLQUFLLFNBQVMsT0FBTyxHQUFHLEtBQUssR0FBRyxTQUFTLElBQUk7Q0FHbkUsT0FBTztBQUNYOzs7O0FBSUEsSUFBTSxxQkFBcUIsS0FBSyxZQUFZO0NBQ3hDLElBQUksQ0FBQyxRQUFRLFNBQVMsR0FBRyxHQUNyQixPQUFPLFFBQVE7Q0FHbkIsT0FBTyxJQURXLE9BQU8sTUFBTSxRQUFRLFFBQVEsT0FBTyxLQUFLLENBQUMsQ0FBQyxRQUFRLE9BQU8sT0FBTyxJQUFJLEdBQzVFLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDekI7Ozs7QUFJQSxJQUFNLGlCQUFpQixLQUFLLGFBQWE7Q0FDckMsT0FBTyxPQUFPLFlBQVksT0FBTyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTO0VBQzVELE9BQU8sQ0FBQyxTQUFTLE1BQU0sWUFBWSxrQkFBa0IsS0FBSyxPQUFPLENBQUM7Q0FDdEUsQ0FBQyxDQUFDO0FBQ047QUFDQSxJQUFhLG1CQUFtQixVQUFVLGNBQWMsQ0FBQyxNQUFNOzs7O0NBSTNELE1BQU0sWUFBWTtFQUNkLGVBQWUsQ0FBQztFQUNoQixnQkFBZ0IsQ0FBQztFQUNqQixtQkFBbUIsQ0FBQztFQUNwQixrQkFBa0IsQ0FBQztDQUN2Qjs7OztDQUlBLElBQUksZ0JBQWdCOzs7O0NBSXBCLElBQUksYUFBYTs7Ozs7OztDQU9qQixNQUFNLGlCQUFpQixVQUFVO0VBQzdCLElBQUksVUFBVSxZQUFZO0dBQ3RCLGFBQWE7R0FDYixPQUFPLFVBQVU7RUFDckI7RUFDQSxPQUFPLENBQUM7Q0FDWjs7OztDQUlBLElBQUksWUFBWSxDQUFDOzs7Ozs7O0NBT2pCLE1BQU0sZ0JBQWdCLFVBQVU7RUFDNUIsTUFBTSxjQUFjLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxDQUFDO0VBQ3RDLElBQUksVUFBVSxXQUFXLFlBQVksVUFBVSxDQUFDLFlBQVksT0FBTyxTQUFTLFVBQVUsU0FBUyxJQUFJLENBQUMsR0FBRztHQUNuRyxZQUFZO0dBQ1osT0FBTyxVQUFVO0VBQ3JCO0VBQ0EsT0FBTyxDQUFDO0NBQ1o7Ozs7Q0FJQSxNQUFNLGNBQWMsVUFBVSxRQUFRLFNBQVMsT0FBTyxPQUFPLFVBQVUsV0FBVzs7OztDQUlsRixJQUFJLFVBQVUsQ0FBQzs7Ozs7OztDQU9mLE1BQU0sY0FBYyxVQUFVO0VBQzFCLE1BQU0sY0FBYyxDQUFDLEdBQUcsSUFBSSxJQUFJLEtBQUssQ0FBQztFQUN0QyxJQUFJLFFBQVEsV0FBVyxZQUFZLFVBQVUsQ0FBQyxZQUFZLE9BQU8sU0FBUyxRQUFRLFNBQVMsSUFBSSxDQUFDLEdBQUc7R0FDL0YsVUFBVTtHQUNWLE9BQU8sVUFBVTtFQUNyQjtFQUNBLE9BQU8sQ0FBQztDQUNaOzs7O0NBSUEsSUFBSSxTQUFTLENBQUM7Ozs7Ozs7Q0FPZCxNQUFNLGFBQWEsVUFBVTtFQUN6QixNQUFNLFdBQVcsbUJBQW1CLEtBQUs7RUFDekMsSUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRLEdBQUc7R0FDNUIsU0FBUztHQUNULE9BQU8sVUFBVTtFQUNyQjtFQUNBLE9BQU8sQ0FBQztDQUNaOzs7Ozs7O0NBT0EsTUFBTSxlQUFlLFNBQVM7RUFDMUIsTUFBTSxZQUFZLEVBQUUsR0FBRyxPQUFPO0VBQzlCLE9BQU8sVUFBVSxZQUFZLElBQUk7RUFDakMsT0FBTyxVQUFVLFNBQVM7Q0FDOUI7Ozs7Q0FJQSxNQUFNLGtCQUFrQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUzs7OztDQUlyRCxJQUFJLDBCQUEwQjtDQUM5QixNQUFNLHNCQUFzQixVQUFVO0VBQ2xDLDBCQUEwQjtFQUMxQixVQUFVLE9BQU87RUFDakIsWUFBWSxnQkFBZ0I7Q0FDaEM7Ozs7Q0FJQSxJQUFJLFVBQVU7Ozs7Q0FJZCxJQUFJLGlCQUFpQjs7OztDQUlyQixJQUFJLGFBQWEsQ0FBQzs7OztDQUlsQixJQUFJLG9CQUFvQjs7OztDQUl4QixNQUFNLHdCQUF3QkMsWUFBVSxtQkFBbUI7RUFDdkQsU0FBUztHQUNMLE1BQU0sS0FBSyxPQUFPLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxPQUFPLElBQUksS0FBSyxVQUFVLElBQUksR0FBRyxjQUFjLGNBQWMsZ0JBQWdCLElBQUksQ0FBQztHQUM5SCxPQUFPLEtBQUssT0FBTyxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sT0FBTyxLQUFLLEtBQUssVUFBVSxJQUFJLEdBQUcsY0FBYyxjQUFjLGdCQUFnQixJQUFJLENBQUM7R0FDaEksUUFBUSxLQUFLLE9BQU8sQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLFVBQVUsSUFBSSxHQUFHLGNBQWMsY0FBYyxnQkFBZ0IsSUFBSSxDQUFDO0dBQ2xJLE1BQU0sS0FBSyxPQUFPLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxPQUFPLElBQUksS0FBSyxVQUFVLElBQUksR0FBRyxjQUFjLGNBQWMsZ0JBQWdCLElBQUksQ0FBQztHQUM5SCxTQUFTLEtBQUssT0FBTyxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sT0FBTyxPQUFPLEtBQUssVUFBVSxJQUFJLEdBQUcsY0FBYyxjQUFjLGdCQUFnQixJQUFJLENBQUM7RUFDeEksQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVO0dBS2hCLElBQUksaUJBQWlCQyxzQkFDakIsT0FBTztHQU9YLElBQUksaUJBQWlCQyx1QkFBcUIsTUFBTSxVQUFVLFdBQVcsS0FDakUsT0FBTztHQUVYLE9BQU8sUUFBUSxPQUFPLEtBQUs7RUFDL0IsQ0FBQztDQUNMLEdBQUcseUJBQXlCO0VBQUUsU0FBUztFQUFNLFVBQVU7Q0FBSyxDQUFDOzs7O0NBSTdELElBQUksWUFBWSxnQkFBZ0I7Ozs7Q0FJaEMsTUFBTSxpQkFBaUIsY0FBYyxnQkFBZ0IsT0FBTyxDQUFDLE1BQU07RUFDL0QsTUFBTSxTQUFTO0dBQ1gsR0FBRztHQUNILEdBQUc7RUFDUDtFQUNBLE1BQU0sT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPO0VBQ2pFLE9BQU87R0FDSCxHQUFHO0dBQ0gsR0FBRyxNQUFNLENBQUMsR0FBRyxjQUFjLGNBQWM7R0FDekM7R0FDQSxTQUFTLE9BQU8sV0FBVztHQUMzQixvQkFBb0IsVUFBVSxVQUFVO0lBQ3BDLENBQ0ksR0FBRyxhQUFhLENBQUMsR0FBRyxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQ3ZDLEdBQUcsVUFBVSxNQUFNLGNBQWMsRUFBRSxHQUFHLE9BQU8sR0FBRyxJQUFJLEdBQUcsU0FBUyxLQUFLLE1BQU0sQ0FBQyxDQUNoRixDQUFDLENBQUMsU0FBUyxhQUFhLFNBQVMsQ0FBQztJQUNsQyxPQUFPLE9BQU8sb0JBQ1IsT0FBTyxrQkFBa0IsVUFBVSxLQUFLLElBQ3hDLFFBQVEsT0FBTyxLQUFLO0dBQzlCO0dBQ0EsWUFBWSxhQUFhO0lBQ3JCLGFBQWEsQ0FBQyxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsYUFBYSxTQUFTLENBQUM7SUFDdEUsT0FBTyxPQUFPLFlBQ1IsT0FBTyxVQUFVLFFBQVEsSUFDekI7R0FDVjtHQUNBLHdCQUF3QixhQUFhO0lBQ2pDLENBQ0ksR0FBRyxhQUFhLENBQUMsR0FBRyxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQ3ZDLEdBQUcsVUFBVSxjQUFjLEVBQUUsR0FBRyxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQ25ELENBQUMsQ0FBQyxTQUFTLGFBQWEsU0FBUyxDQUFDO0lBQ2xDLE9BQU8sT0FBTyx3QkFDUixPQUFPLHNCQUFzQixRQUFRLElBQ3JDO0dBQ1Y7R0FDQSxnQkFBZ0I7SUFHWixNQUFNLGVBQWUsUUFBUSxNQUFNLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQztJQUM5RCxNQUFNLGtCQUFrQixlQUNsQixDQUFDLEdBQUcsSUFBSSxJQUFJLFFBQVEsU0FBUyxTQUFTLG9CQUFvQixNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsSUFDdkU7SUFDTixJQUFJLE9BQU8sc0JBQXNCLE9BQU8sbUJBQW1CO0tBQUU7S0FBTSxTQUFTO0lBQWdCLEdBQUc7S0FBRSxNQUFNO0tBQVMsU0FBUztJQUFXLENBQUMsTUFBTSxPQUN2SSxPQUFPO0lBR1gsS0FEc0IsT0FBTyxtQkFBbUIsTUFBQSxDQUNqQyxNQUFNLE9BQ2pCLE9BQU87SUFFWCxJQUFJLGNBQ0EsV0FBVyxlQUFlLENBQUMsQ0FBQyxTQUFTLGFBQWEsU0FBUyxDQUFDO0lBRWhFLG9CQUFvQjtJQUNwQixpQkFBaUI7SUFDakIsT0FBTztHQUNYO0dBQ0EsZUFBZTtJQUNYLGNBQWMsSUFBSSxDQUFDLENBQUMsU0FBUyxhQUFhLFNBQVMsQ0FBQztJQUNwRCxDQUFDLE9BQU8sa0JBQWtCLE1BQUEsQ0FBTztHQUNyQztHQUNBLGdCQUFnQjtJQUNaLGNBQWMsS0FBSyxDQUFDLENBQUMsU0FBUyxhQUFhLFNBQVMsQ0FBQztJQUNyRCxhQUFhO0lBQ2IsVUFBVTtJQUNWLG9CQUFvQixpQkFBaUI7SUFDckMsQ0FBQyxPQUFPLG1CQUFtQixNQUFBLENBQU87R0FDdEM7RUFDSjtDQUNKOzs7O0NBSUEsTUFBTSxZQUFZLE1BQU0sT0FBTyxXQUFXO0VBQ3RDLElBQUksT0FBTyxTQUFTLGFBQWE7R0FDN0IsTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLFFBQVEsUUFBUSxZQUFZLENBQUMsQ0FBQztHQUM5RCxXQUFXLENBQUMsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLGFBQWEsU0FBUyxDQUFDO0dBQ2xFLFVBQVUsVUFBVSxDQUFDLENBQUM7R0FDdEI7RUFDSjtFQUNBLElBQUlDLFNBQU8sS0FBSyxLQUFLLENBQUMsZUFBZTtHQUNqQyxRQUFRLEtBQUssNEdBQTBHO0dBQ3ZIO0VBQ0o7RUFDQSxPQUFPLFlBQVksSUFBSTtFQUN2QixJQUFJLEtBQUssU0FBUyxHQUFHLEtBQUssSUFBSSxTQUFTLElBQUksTUFBTSxPQUFPO0dBQ3BELFdBQVcsQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLGFBQWEsU0FBUyxDQUFDO0dBQy9ELFVBQVUsVUFBVSxDQUFDLENBQUM7RUFDMUI7Q0FDSjs7OztDQUlBLE1BQU0sYUFBYSxTQUFTLGtCQUFrQixRQUN4QyxZQUFZLElBQUksSUFDaEI7Ozs7Q0FJTixNQUFNLE9BQU87RUFDVCxlQUFlO0VBQ2YsU0FBUyxNQUFNLE9BQU8sUUFBUTtHQUMxQixJQUFJLE9BQU8sU0FBUyxZQUFZLEVBQUUsWUFBWSxPQUFPO0lBQ2pELFNBQVM7SUFDVCxPQUFPLFFBQVEsS0FBQTtHQUNuQjtHQUNBLFNBQVMsTUFBTSxPQUFPLE1BQU07R0FDNUIsT0FBTztFQUNYO0VBQ0EsTUFBTSxPQUFPO0dBQ1QsTUFBTSxTQUFTLE1BQU0sUUFBUSxLQUFLLElBQzVCLFFBQ0EsQ0FBQyxZQUFZLEtBQUssQ0FBQztHQUN6QixXQUFXLENBQUMsR0FBRyxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLGFBQWEsU0FBUyxDQUFDO0dBQ3BFLE9BQU87RUFDWDtFQUNBLGtCQUFrQjtFQUNsQjtFQUNBLGNBQWM7RUFDZDtFQUNBLFVBQVUsT0FBTztHQUNiLFVBQVUsS0FBSyxDQUFDLENBQUMsU0FBUyxhQUFhLFNBQVMsQ0FBQztHQUNqRCxPQUFPO0VBQ1g7RUFDQSxZQUFZLE1BQU07R0FDZCxZQUFZLElBQUksQ0FBQyxDQUFDLFNBQVMsYUFBYSxTQUFTLENBQUM7R0FDbEQsT0FBTztFQUNYO0VBQ0EsU0FBUyxNQUFNO0dBQ1gsY0FBYztHQUNkLFVBQVU7R0FDVixPQUFPO0VBQ1g7RUFDQSxNQUFNLEdBQUcsT0FBTztHQUNaLElBQUksTUFBTSxXQUFXLEdBQ2pCLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLGFBQWEsU0FBUyxDQUFDO1FBRTlDO0lBQ0QsTUFBTSxhQUFhLENBQUMsR0FBRyxPQUFPO0lBQzlCLE1BQU0sU0FBUyxTQUFTO0tBQ3BCLElBQUksV0FBVyxTQUFTLElBQUksR0FDeEIsV0FBVyxPQUFPLFdBQVcsUUFBUSxJQUFJLEdBQUcsQ0FBQztLQUVqRCxJQUFJLFNBQVMsTUFBTSxJQUFJLGFBQWEsSUFBSSxDQUFDO0lBQzdDLENBQUM7SUFDRCxXQUFXLFVBQVUsQ0FBQyxDQUFDLFNBQVMsYUFBYSxTQUFTLENBQUM7R0FDM0Q7R0FDQSxPQUFPO0VBQ1g7RUFDQSxXQUFXLE9BQU87R0FDZCxtQkFBbUIsS0FBSztHQUN4QixPQUFPO0VBQ1g7RUFDQSxHQUFHLE9BQU8sVUFBVTtHQUNoQixVQUFVLE1BQU0sQ0FBQyxLQUFLLFFBQVE7R0FDOUIsT0FBTztFQUNYO0VBQ0EsZ0JBQWdCO0dBQ1osZ0JBQWdCO0dBQ2hCLE9BQU87RUFDWDtFQUNBLHdCQUF3QjtHQUNwQixnQkFBZ0I7R0FDaEIsT0FBTztFQUNYO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7Ozs7QUFJQSxJQUFhLDRCQUE0QixXQUFXO0NBQ2hELE9BQU8sT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTO0VBQy9DLEdBQUc7R0FDRixNQUFNLE1BQU0sUUFBUSxPQUFPLElBQUksSUFDMUIsT0FBTyxJQUFJLENBQUMsS0FDWixPQUFPO0NBQ2pCLElBQUksQ0FBQyxDQUFDO0FBQ1Y7Ozs7QUFJQSxJQUFhLHNCQUFzQixXQUFXO0NBQzFDLE9BQU8sT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTO0VBQy9DLEdBQUc7R0FDRixNQUFNLE9BQU8sT0FBTyxTQUFTLFdBQVcsQ0FBQyxPQUFPLElBQUksSUFBSSxPQUFPO0NBQ3BFLElBQUksQ0FBQyxDQUFDO0FBQ1Y7Ozs7QUFJQSxJQUFhLGVBQWUsU0FBUztDQUNqQyxPQUFPLE9BQU8sU0FBUyxXQUNqQixLQUFLLE9BQU8sT0FDWjtBQUNWOzs7O0FBSUEsSUFBTSxlQUFlLFNBQVM7Q0FDMUIsTUFBTSxVQUFVLEVBQUUsR0FBRyxLQUFLO0NBQzFCLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFNBQVM7RUFDbkMsTUFBTSxRQUFRLFFBQVE7RUFDdEIsSUFBSSxVQUFVLE1BQ1Y7RUFFSixJQUFJQSxTQUFPLEtBQUssR0FBRztHQUNmLE9BQU8sUUFBUTtHQUNmO0VBQ0o7RUFDQSxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7R0FDdEIsUUFBUSxRQUFRLE9BQU8sT0FBTyxZQUFZLEVBQUUsR0FBRyxNQUFNLENBQUMsQ0FBQztHQUN2RDtFQUNKO0VBQ0EsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUUzQixRQUFRLFFBQVEsWUFBWSxRQUFRLEtBQUs7R0FDekM7RUFDSjtDQUNKLENBQUM7Q0FDRCxPQUFPO0FBQ1g7OztBQzdiQSxJQUFJLFNBQVMsTUFBTTtDQUNqQixTQUFTLENBQUM7Q0FDVjtDQUNBLFlBQVksVUFBVTtFQUNwQixLQUFLLFdBQVc7Q0FDbEI7Q0FDQSxPQUFPLFVBQVU7RUFDZixJQUFJLFVBQ0YsS0FBSyxXQUFXO0dBQUUsR0FBRyxLQUFLO0dBQVUsR0FBRztFQUFTO0VBRWxELE9BQU87Q0FDVDtDQUNBLFFBQVEsV0FBVztFQUNqQixLQUFLLFNBQVM7Q0FDaEI7Q0FDQSxJQUFJLEtBQUs7RUFDUCxPQUFPLElBQUksS0FBSyxRQUFRLEdBQUcsSUFBSSxJQUFJLEtBQUssUUFBUSxHQUFHLElBQUksSUFBSSxLQUFLLFVBQVUsR0FBRztDQUMvRTtDQUNBLElBQUksYUFBYSxPQUFPO0VBQ3RCLElBQUksT0FBTyxnQkFBZ0IsVUFDekIsSUFBSSxLQUFLLFFBQVEsYUFBYSxLQUFLO09BRW5DLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxTQUFTO0dBQ2xELElBQUksS0FBSyxRQUFRLEtBQUssR0FBRztFQUMzQixDQUFDO0NBRUw7QUFDRjtBQUNBLElBQUlDLFdBQVMsSUFBSSxPQUFPO0NBQ3RCLE1BQU07RUFDSiw0QkFBNEI7RUFDNUIsbUNBQW1DO0VBQ25DLGVBQWU7Q0FDakI7Q0FDQSxVQUFVO0VBQ1IsVUFBVTtFQUNWLFlBQVk7Q0FDZDtBQUNGLENBQUM7QUFNRCxTQUFTLFNBQVMsSUFBSSxPQUFPO0NBQzNCLElBQUk7Q0FDSixPQUFPLFNBQVMsR0FBRyxNQUFNO0VBQ3ZCLGFBQWEsU0FBUztFQUN0QixZQUFZLGlCQUFpQixHQUFHLE1BQU0sTUFBTSxJQUFJLEdBQUcsS0FBSztDQUMxRDtBQUNGO0FBR0EsU0FBUyxVQUFVLE1BQU0sU0FBUztDQUNoQyxPQUFPLFNBQVMsY0FBYyxJQUFJLFlBQVksV0FBVyxRQUFRLE9BQU8sQ0FBQztBQUMzRTtBQUNBLElBQUksbUJBQW1CLFVBQVU7Q0FDL0IsT0FBTyxVQUFVLFVBQVU7RUFBRSxZQUFZO0VBQU0sUUFBUSxFQUFFLE1BQU07Q0FBRSxDQUFDO0FBQ3BFO0FBQ0EsSUFBSSxrQkFBa0IsUUFBUSxFQUFFLE1BQU0sT0FBTyxZQUFZLENBQUMsTUFBTTtDQUM5RCxPQUFPLFVBQVUsU0FBUyxFQUFFLFFBQVE7RUFBRTtFQUFRLE1BQU07RUFBTztDQUFRLEVBQUUsQ0FBQztBQUN4RTtBQUNBLElBQUkseUJBQXlCLFVBQVU7Q0FDckMsT0FBTyxVQUFVLGdCQUFnQjtFQUFFLFlBQVk7RUFBTSxRQUFRLEVBQUUsTUFBTTtDQUFFLENBQUM7QUFDMUU7QUFDQSxJQUFJLG1CQUFtQixVQUFVO0NBQy9CLE9BQU8sVUFBVSxVQUFVLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO0FBQ2xEO0FBQ0EsSUFBSSwwQkFBMEIsYUFBYTtDQUN6QyxPQUFPLFVBQVUsaUJBQWlCO0VBQUUsWUFBWTtFQUFNLFFBQVEsRUFBRSxTQUFTO0NBQUUsQ0FBQztBQUM5RTtBQUNBLElBQUkseUJBQXlCLFVBQVU7Q0FDckMsT0FBTyxVQUFVLGdCQUFnQixFQUFFLFFBQVEsRUFBRSxNQUFNLE1BQU0sRUFBRSxDQUFDO0FBQzlEO0FBQ0EsSUFBSSxxQkFBcUIsT0FBTyxFQUFFLFNBQVMsT0FBTyxZQUFZLENBQUMsTUFBTTtDQUNuRSxPQUFPLFVBQVUsWUFBWSxFQUFFLFFBQVE7RUFBRSxNQUFNO0VBQU87RUFBUTtDQUFRLEVBQUUsQ0FBQztBQUMzRTtBQUNBLElBQUksd0JBQXdCLE9BQU8sRUFBRSxTQUFTLGNBQWM7Q0FDMUQsT0FBTyxVQUFVLGVBQWUsRUFBRSxRQUFRO0VBQUUsTUFBTTtFQUFPO0VBQVM7Q0FBUSxFQUFFLENBQUM7QUFDL0U7QUFDQSxJQUFJLHFCQUFxQixjQUFjO0NBQ3JDLE9BQU8sVUFBVSxZQUFZLEVBQUUsUUFBUSxFQUFFLFVBQVUsVUFBVSxFQUFFLENBQUM7QUFDbEU7QUFDQSxJQUFJLGtCQUFrQixVQUFVO0NBQzlCLE9BQU8sVUFBVSxTQUFTLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO0FBQ2pEO0FBQ0EsSUFBSSxvQkFBb0IsT0FBTyxFQUFFLFlBQVksQ0FBQyxNQUFNO0NBQ2xELE9BQU8sVUFBVSxXQUFXLEVBQUUsUUFBUTtFQUFFLE1BQU07RUFBTztDQUFRLEVBQUUsQ0FBQztBQUNsRTtBQUNBLElBQUksdUJBQXVCLFVBQVUsVUFBVTtDQUM3QyxPQUFPLFVBQVUsY0FBYyxFQUFFLFFBQVE7RUFBRSxXQUFXLEtBQUssSUFBSTtFQUFHO0VBQVU7Q0FBTSxFQUFFLENBQUM7QUFDdkY7QUFDQSxJQUFJLHdCQUF3QixVQUFVO0NBQ3BDLE9BQU8sVUFBVSxlQUFlLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO0FBQ3ZEO0FBQ0EsSUFBSSxrQkFBa0IsVUFBVTtDQUM5QixPQUFPLFVBQVUsU0FBUyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsQ0FBQztBQUNqRDtBQUNBLElBQUkscUJBQXFCLEtBQUssa0JBQWtCO0NBQzlDLE9BQU8sVUFBVSxZQUFZO0VBQUUsWUFBWTtFQUFNLFFBQVE7R0FBRTtHQUFLO0VBQWM7Q0FBRSxDQUFDO0FBQ25GO0FBTUEsSUFBSSxpQkFBaUIsTUFBTTtDQUN6QixPQUFPLG1CQUFtQjtDQUMxQixPQUFPLElBQUksS0FBSyxPQUFPO0VBQ3JCLElBQUksT0FBTyxXQUFXLGFBQ3BCLE9BQU8sZUFBZSxRQUFRLEtBQUssS0FBSyxVQUFVLEtBQUssQ0FBQztDQUU1RDtDQUNBLE9BQU8sSUFBSSxLQUFLO0VBQ2QsSUFBSSxPQUFPLFdBQVcsYUFDcEIsT0FBTyxLQUFLLE1BQU0sT0FBTyxlQUFlLFFBQVEsR0FBRyxLQUFLLE1BQU07Q0FFbEU7Q0FDQSxPQUFPLE1BQU0sS0FBSyxPQUFPO0VBQ3ZCLE1BQU0sV0FBVyxLQUFLLElBQUksR0FBRztFQUM3QixJQUFJLGFBQWEsTUFDZixLQUFLLElBQUksS0FBSyxLQUFLO09BRW5CLEtBQUssSUFBSSxLQUFLO0dBQUUsR0FBRztHQUFVLEdBQUc7RUFBTSxDQUFDO0NBRTNDO0NBQ0EsT0FBTyxPQUFPLEtBQUs7RUFDakIsSUFBSSxPQUFPLFdBQVcsYUFDcEIsT0FBTyxlQUFlLFdBQVcsR0FBRztDQUV4QztDQUNBLE9BQU8sYUFBYSxLQUFLLFdBQVc7RUFDbEMsTUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHO0VBQzdCLElBQUksYUFBYSxNQUFNO0dBQ3JCLE9BQU8sU0FBUztHQUNoQixLQUFLLElBQUksS0FBSyxRQUFRO0VBQ3hCO0NBQ0Y7Q0FDQSxPQUFPLE9BQU8sS0FBSztFQUNqQixJQUFJO0dBQ0YsT0FBTyxLQUFLLElBQUksR0FBRyxNQUFNO0VBQzNCLFNBQVMsT0FBTztHQUNkLE9BQU87RUFDVDtDQUNGO0NBQ0EsT0FBTyxRQUFRO0VBQ2IsSUFBSSxPQUFPLFdBQVcsYUFDcEIsT0FBTyxlQUFlLE1BQU07Q0FFaEM7QUFDRjtBQUdBLElBQUksaUJBQWlCLE9BQU8sU0FBUztDQUNuQyxJQUFJLE9BQU8sV0FBVyxhQUNwQixNQUFNLElBQUksTUFBTSwyQkFBMkI7Q0FFN0MsTUFBTSxLQUFLLE1BQU07Q0FFakIsTUFBTSxNQUFNLE1BQU0sZUFBZSxNQURULHlCQUF5QixDQUNQO0NBQzFDLElBQUksQ0FBQyxLQUNILE1BQU0sSUFBSSxNQUFNLDJCQUEyQjtDQUc3QyxPQUFPLE1BRGlCLFlBQVksSUFBSSxLQUFLLElBQUk7QUFFbkQ7QUFDQSxJQUFJLDRCQUE0QjtDQUM5QixLQUFLO0NBQ0wsSUFBSTtBQUNOO0FBQ0EsSUFBSSxpQkFBaUIsT0FBTyxTQUFTO0NBQ25DLE1BQU0sS0FBSyxNQUFNO0NBQ2pCLE1BQU0sWUFBWSxNQUFNLHlCQUF5QjtDQUNqRCxJQUFJLENBQUMsV0FDSCxNQUFNLElBQUksTUFBTSwyQkFBMkI7Q0FFN0MsT0FBTyxNQUFNLFlBQVksSUFBSSxXQUFXLElBQUk7QUFDOUM7QUFDQSxJQUFJLGNBQWMsT0FBTyxJQUFJLEtBQUssU0FBUztDQUN6QyxJQUFJLE9BQU8sV0FBVyxhQUNwQixNQUFNLElBQUksTUFBTSwyQkFBMkI7Q0FFN0MsSUFBSSxPQUFPLE9BQU8sT0FBTyxXQUFXLGFBQWE7RUFDL0MsUUFBUSxLQUFLLG1FQUFtRTtFQUNoRixPQUFPLFFBQVEsUUFBUSxJQUFJO0NBQzdCO0NBQ0EsTUFBTSxjQUFjLElBQUksWUFBWTtDQUNwQyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7Q0FDL0IsTUFBTSxVQUFVLElBQUksV0FBVyxJQUFJLFNBQVMsQ0FBQztDQUM3QyxNQUFNLFNBQVMsWUFBWSxXQUFXLEtBQUssT0FBTztDQUNsRCxPQUFPLE9BQU8sT0FBTyxPQUFPLFFBQzFCO0VBQ0UsTUFBTTtFQUNOO0NBQ0YsR0FDQSxLQUNBLFFBQVEsU0FBUyxHQUFHLE9BQU8sT0FBTyxDQUNwQztBQUNGO0FBQ0EsSUFBSSxjQUFjLE9BQU8sSUFBSSxLQUFLLFNBQVM7Q0FDekMsSUFBSSxPQUFPLE9BQU8sT0FBTyxXQUFXLGFBQWE7RUFDL0MsUUFBUSxLQUFLLG1FQUFtRTtFQUNoRixPQUFPLFFBQVEsUUFBUSxJQUFJO0NBQzdCO0NBQ0EsTUFBTSxZQUFZLE1BQU0sT0FBTyxPQUFPLE9BQU8sUUFDM0M7RUFDRSxNQUFNO0VBQ047Q0FDRixHQUNBLEtBQ0EsSUFDRjtDQUNBLE9BQU8sS0FBSyxNQUFNLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxTQUFTLENBQUM7QUFDdkQ7QUFDQSxJQUFJLGNBQWM7Q0FDaEIsTUFBTSxXQUFXLGVBQWUsSUFBSSwwQkFBMEIsRUFBRTtDQUNoRSxJQUFJLFVBQ0YsT0FBTyxJQUFJLFdBQVcsUUFBUTtDQUVoQyxNQUFNLEtBQUssT0FBTyxPQUFPLGdDQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0NBQzNELGVBQWUsSUFBSSwwQkFBMEIsSUFBSSxNQUFNLEtBQUssRUFBRSxDQUFDO0NBQy9ELE9BQU87QUFDVDtBQUNBLElBQUksWUFBWSxZQUFZO0NBQzFCLElBQUksT0FBTyxPQUFPLE9BQU8sV0FBVyxhQUFhO0VBQy9DLFFBQVEsS0FBSyxtRUFBbUU7RUFDaEYsT0FBTyxRQUFRLFFBQVEsSUFBSTtDQUM3QjtDQUNBLE9BQU8sT0FBTyxPQUFPLE9BQU8sWUFDMUI7RUFDRSxNQUFNO0VBQ04sUUFBUTtDQUNWLEdBQ0EsTUFDQSxDQUFDLFdBQVcsU0FBUyxDQUN2QjtBQUNGO0FBQ0EsSUFBSSxVQUFVLE9BQU8sUUFBUTtDQUMzQixJQUFJLE9BQU8sT0FBTyxPQUFPLFdBQVcsYUFBYTtFQUMvQyxRQUFRLEtBQUssbUVBQW1FO0VBQ2hGLE9BQU8sUUFBUSxRQUFRO0NBQ3pCO0NBQ0EsTUFBTSxVQUFVLE1BQU0sT0FBTyxPQUFPLE9BQU8sVUFBVSxPQUFPLEdBQUc7Q0FDL0QsZUFBZSxJQUFJLDBCQUEwQixLQUFLLE1BQU0sS0FBSyxJQUFJLFdBQVcsT0FBTyxDQUFDLENBQUM7QUFDdkY7QUFDQSxJQUFJLGlCQUFpQixPQUFPLFFBQVE7Q0FDbEMsSUFBSSxLQUNGLE9BQU87Q0FFVCxNQUFNLFNBQVMsTUFBTSxVQUFVO0NBQy9CLElBQUksQ0FBQyxRQUNILE9BQU87Q0FFVCxNQUFNLFFBQVEsTUFBTTtDQUNwQixPQUFPO0FBQ1Q7QUFDQSxJQUFJLDJCQUEyQixZQUFZO0NBQ3pDLE1BQU0sWUFBWSxlQUFlLElBQUksMEJBQTBCLEdBQUc7Q0FDbEUsSUFBSSxDQUFDLFdBQ0gsT0FBTztDQVlULE9BQU8sTUFWVyxPQUFPLE9BQU8sT0FBTyxVQUNyQyxPQUNBLElBQUksV0FBVyxTQUFTLEdBQ3hCO0VBQ0UsTUFBTTtFQUNOLFFBQVE7Q0FDVixHQUNBLE1BQ0EsQ0FBQyxXQUFXLFNBQVMsQ0FDdkI7QUFFRjtBQVlBLElBQUksMEJBQTBCLFFBQVE7Q0FDcEMsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUcsR0FDL0IsSUFBSSxJQUFJLFNBQVMsS0FBSyxHQUNwQixPQUFPLE9BQU8sSUFBSTtDQUd0QixPQUFPO0FBQ1Q7QUFDQSxJQUFJLG1CQUFtQixNQUFNLE1BQU0sZ0JBQWdCO0NBQ2pELElBQUksU0FBUyxNQUNYLE9BQU87Q0FFVCxLQUFLLE1BQU0sT0FBTyxNQUFNO0VBQ3RCLElBQUksWUFBWSxTQUFTLEdBQUcsR0FDMUI7RUFFRixJQUFJLEtBQUssU0FBUyxLQUFLLE1BQ3JCO0VBRUYsSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLEtBQUssSUFBSSxHQUNyQyxPQUFPO0NBRVg7Q0FDQSxLQUFLLE1BQU0sT0FBTyxNQUFNO0VBQ3RCLElBQUksWUFBWSxTQUFTLEdBQUcsR0FDMUI7RUFFRixJQUFJLEVBQUUsT0FBTyxPQUNYLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDtBQUNBLElBQUksaUJBQWlCLFFBQVEsV0FBVztDQUN0QyxRQUFRLE9BQU8sUUFBZjtFQUNFLEtBQUssVUFDSCxPQUFPLGdCQUFnQixRQUFRLFFBQVEsQ0FBQyxDQUFDO0VBQzNDLEtBQUssWUFDSCxPQUFPLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUztFQUMvQyxTQUNFLE9BQU8sV0FBVztDQUN0QjtBQUNGO0FBQ0EsSUFBSSw2QkFBNkIsUUFBUSxNQUFNLFVBQVU7Q0FDdkQsTUFBTSxPQUFPLE9BQU8sSUFBSTtDQUN4QixJQUFJLEtBQUssV0FBVyxHQUNsQixPQUFPO0NBRVQsTUFBTSxpQkFBaUIsTUFBTSxVQUFVO0VBQ3JDLElBQUksVUFBVSxLQUFLLFFBQ2pCLE9BQU87RUFFVCxNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLE9BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLFFBQVEsT0FBTyxTQUFTLFdBQVcsRUFBRSxHQUFHLEtBQUssSUFBSSxtQkFBbUIsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDckksS0FBSyxPQUFPLGNBQWMsT0FBTyxNQUFNLFFBQVEsQ0FBQztFQUNoRCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQ2hDO0FBR0EsSUFBSSxnQkFBZ0I7Q0FDbEIsSUFBSTtDQUNKLEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7QUFDTDtBQUNBLElBQUksWUFBWSxTQUFTO0NBQ3ZCLElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU87Q0FFVCxLQUFLLE1BQU0sQ0FBQyxNQUFNLGVBQWUsT0FBTyxRQUFRLGFBQWEsR0FDM0QsSUFBSSxLQUFLLFNBQVMsSUFBSSxHQUNwQixPQUFPLFdBQVcsSUFBSSxJQUFJO0NBRzlCLE9BQU8sU0FBUyxJQUFJO0FBQ3RCO0FBR0EsSUFBSSxxQkFBcUIsTUFBTTtDQUM3QixTQUFTLENBQUM7Q0FDVixtQkFBbUIsQ0FBQztDQUNwQixnQkFBZ0IsQ0FBQztDQUNqQixlQUFlO0NBQ2YsSUFBSSxRQUFRLFVBQVUsRUFBRSxVQUFVLGFBQWE7RUFFN0MsSUFEaUIsS0FBSyxhQUFhLE1BQ3hCLEdBQ1QsT0FBTyxRQUFRLFFBQVE7RUFFekIsTUFBTSxXQUFXLEtBQUssV0FBVyxNQUFNO0VBQ3ZDLElBQUksQ0FBQyxPQUFPLFNBQVMsWUFBWSxTQUFTLGlCQUFpQixLQUFLLElBQUksR0FDbEUsT0FBTyxRQUFRLFFBQVE7RUFFekIsTUFBTSxDQUFDLE9BQU8scUJBQXFCLEtBQUssbUJBQW1CLFFBQVE7RUFDbkUsTUFBTSxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDL0MsU0FBUztJQUNQLEdBQUc7SUFDSCxnQkFBZ0I7S0FDZCxLQUFLLE9BQU8sTUFBTTtLQUNsQixPQUFPLFNBQVM7S0FDaEIsT0FBTztJQUNUO0lBQ0EsVUFBVSxVQUFVO0tBQ2xCLEtBQUssT0FBTyxNQUFNO0tBQ2xCLE9BQU8sUUFBUSxLQUFLO0tBQ3BCLE9BQU87SUFDVDtJQUNBLGNBQWMsYUFBYTtLQUN6QixPQUFPLGNBQWMsV0FBVztJQUNsQztJQUNBLGFBQWEsVUFBVSxPQUFPO0tBQzVCLE9BQU8sYUFBYSxVQUFVLEtBQUs7SUFDckM7SUFDQSxtQkFBbUIsVUFBVTtLQUMzQixRQUFRLFFBQVE7SUFDbEI7SUFDQSxnQkFBZ0IsT0FBTztLQUNyQixtQkFBbUIsbUJBQW1CLE1BQU07S0FDNUMsT0FBTyxLQUFLO0lBQ2Q7R0FDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxhQUFhO0dBQ3BCLEtBQUssT0FBTyxNQUFNO0dBQ2xCLE1BQU0sZUFBZSxTQUFTLGdCQUFnQjtHQUM5QyxPQUFLLDJCQUEyQixZQUFZO0dBQzVDLEtBQUssT0FBTyxLQUFLO0lBQ2YsUUFBUSxFQUFFLEdBQUcsT0FBTztJQUNwQixnQkFBZ0IsS0FBSyxJQUFJLElBQUk7SUFDN0IsV0FBVyxLQUFLLElBQUksSUFBSTtJQUN4QixVQUFVO0lBQ1YsV0FBVyxzQkFBc0I7SUFDakMsV0FBVyxLQUFLLElBQUk7SUFDcEIsVUFBVTtJQUNWLE1BQU0sTUFBTSxRQUFRLFNBQVMsSUFBSSxZQUFZLENBQUMsU0FBUztHQUN6RCxDQUFDO0dBQ0QsTUFBTSxvQkFBb0IsS0FBSyx1QkFBdUIsWUFBWTtHQUNsRSxLQUFLLG1CQUNILFFBQ0Esb0JBQW9CLEtBQUssSUFBSSxtQkFBbUIsaUJBQWlCLElBQUksaUJBQ3ZFO0dBQ0EsS0FBSyxtQkFBbUIsTUFBTTtHQUM5QixTQUFTLGVBQWU7R0FDeEIsT0FBTztFQUNULENBQUM7RUFDRCxLQUFLLGlCQUFpQixLQUFLO0dBQ3pCLFFBQVEsRUFBRSxHQUFHLE9BQU87R0FDcEIsVUFBVTtHQUNWLGdCQUFnQjtHQUNoQixVQUFVO0VBQ1osQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLFlBQVk7RUFDVixLQUFLLFNBQVMsQ0FBQztFQUNmLEtBQUssY0FBYyxTQUFTLGlCQUFpQjtHQUMzQyxhQUFhLGFBQWEsS0FBSztFQUNqQyxDQUFDO0VBQ0QsS0FBSyxnQkFBZ0IsQ0FBQztDQUN4QjtDQUNBLGFBQWEsTUFBTTtFQUNqQixLQUFLLFNBQVMsS0FBSyxPQUFPLFFBQVEsZUFBZTtHQUMvQyxPQUFPLENBQUMsV0FBVyxLQUFLLE1BQU0sUUFBUSxLQUFLLFNBQVMsR0FBRyxDQUFDO0VBQzFELENBQUM7Q0FDSDtDQUNBLE9BQU8sUUFBUTtFQUNiLEtBQUssU0FBUyxLQUFLLE9BQU8sUUFBUSxlQUFlO0dBQy9DLE9BQU8sQ0FBQyxLQUFLLGVBQWUsV0FBVyxRQUFRLE1BQU07RUFDdkQsQ0FBQztFQUNELEtBQUssV0FBVyxNQUFNO0NBQ3hCO0NBQ0EsbUJBQW1CLFFBQVE7RUFDekIsS0FBSyxtQkFBbUIsS0FBSyxpQkFBaUIsUUFBUSxnQkFBZ0I7R0FDcEUsT0FBTyxDQUFDLEtBQUssZUFBZSxZQUFZLFFBQVEsTUFBTTtFQUN4RCxDQUFDO0NBQ0g7Q0FDQSxtQkFBbUIsVUFBVTtFQUMzQixNQUFNLENBQUMsT0FBTyxXQUFXLEtBQUssMEJBQTBCLFFBQVE7RUFDaEUsT0FBTyxDQUFDLFNBQVMsS0FBSyxHQUFHLFNBQVMsT0FBTyxDQUFDO0NBQzVDO0NBQ0EsMEJBQTBCLFVBQVU7RUFDbEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxRQUFRLEdBQ3pCLE9BQU8sQ0FBQyxVQUFVLFFBQVE7RUFFNUIsUUFBUSxTQUFTLFFBQWpCO0dBQ0UsS0FBSyxHQUNILE9BQU8sQ0FBQyxHQUFHLENBQUM7R0FDZCxLQUFLLEdBQ0gsT0FBTyxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUU7R0FDbEMsU0FDRSxPQUFPLENBQUMsU0FBUyxJQUFJLFNBQVMsRUFBRTtFQUNwQztDQUNGO0NBQ0EsV0FBVyxRQUFRO0VBQ2pCLE1BQU0sUUFBUSxLQUFLLGNBQWMsTUFBTSxpQkFBaUI7R0FDdEQsT0FBTyxLQUFLLGVBQWUsYUFBYSxRQUFRLE1BQU07RUFDeEQsQ0FBQztFQUNELElBQUksT0FBTztHQUNULGFBQWEsTUFBTSxLQUFLO0dBQ3hCLEtBQUssZ0JBQWdCLEtBQUssY0FBYyxRQUFRLGlCQUFpQixpQkFBaUIsS0FBSztFQUN6RjtDQUNGO0NBQ0EsbUJBQW1CLFFBQVEsV0FBVztFQUNwQyxJQUFJLE9BQU8sV0FBVyxhQUNwQjtFQUVGLEtBQUssV0FBVyxNQUFNO0VBQ3RCLElBQUksWUFBWSxHQUFHO0dBQ2pCLE1BQU0sUUFBUSxPQUFPLGlCQUFpQixLQUFLLE9BQU8sTUFBTSxHQUFHLFNBQVM7R0FDcEUsS0FBSyxjQUFjLEtBQUs7SUFDdEI7SUFDQTtHQUNGLENBQUM7RUFDSDtDQUNGO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFdBQVcsTUFBTSxLQUFLLEtBQUssYUFBYSxNQUFNO0NBQzVEO0NBQ0EsSUFBSSxZQUFZLFFBQVE7RUFDdEIsTUFBTSxLQUFLLEdBQUcsT0FBTyxJQUFJLFNBQVMsR0FBRyxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUM7RUFDekYsS0FBSyxlQUFlO0VBQ3BCLE1BQU0saUJBQWlCO0dBQ3JCLEdBQUc7R0FDSCxRQUFRO0VBQ1Y7RUFDQSxPQUFPLFdBQVcsU0FBUyxNQUFNLGFBQWE7R0FDNUMsSUFBSSxLQUFLLGlCQUFpQixJQUN4QjtHQUVGLFNBQVMsWUFBWTtJQUFFLEdBQUc7SUFBZ0Isb0JBQW9CLENBQzlEO0dBQUUsQ0FBQztHQUNILEtBQUsscUJBQXFCLE1BQU07R0FDaEMsT0FBTyxTQUFTLE9BQU87RUFDekIsQ0FBQztDQUNIO0NBQ0EscUJBQXFCLFFBQVE7RUFDM0IsS0FBSyxTQUFTLEtBQUssT0FBTyxRQUFRLGVBQWU7R0FDL0MsSUFBSSxDQUFDLEtBQUssZUFBZSxXQUFXLFFBQVEsTUFBTSxHQUNoRCxPQUFPO0dBRVQsT0FBTyxDQUFDLFdBQVc7RUFDckIsQ0FBQztDQUNIO0NBQ0EsV0FBVyxRQUFRO0VBQ2pCLE9BQU8sS0FBSyxPQUFPLE1BQU0sZUFBZTtHQUN0QyxPQUFPLEtBQUssZUFBZSxXQUFXLFFBQVEsTUFBTTtFQUN0RCxDQUFDLEtBQUs7Q0FDUjtDQUNBLGFBQWEsUUFBUTtFQUNuQixPQUFPLEtBQUssaUJBQWlCLE1BQU0sZUFBZTtHQUNoRCxPQUFPLEtBQUssZUFBZSxXQUFXLFFBQVEsTUFBTTtFQUN0RCxDQUFDLEtBQUs7Q0FDUjtDQUNBLDZCQUE2QixRQUFRO0VBQ25DLE1BQU0sWUFBWUMsWUFBVSxNQUFNO0VBQ2xDLElBQUksVUFBVSxRQUFRLGVBQWUsWUFDbkMsT0FBTyxVQUFVLFFBQVE7RUFFM0IsT0FBTztDQUNUO0NBQ0EsZUFBZSxTQUFTLFNBQVM7RUFDL0IsT0FBTyxnQkFDTCxLQUFLLDZCQUE2QixPQUFPLEdBQ3pDLEtBQUssNkJBQTZCLE9BQU8sR0FDekM7R0FDRTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUNGO0NBQ0Y7Q0FDQSx1Q0FBdUM7RUFDckMsS0FBSyxPQUFPLFNBQVMsZUFBZTtHQUNsQyxXQUFXLFNBQVMsTUFBTSxhQUFhO0lBQ3JDLE1BQU0sZUFBZSxTQUFTLGdCQUFnQjtJQUM5QyxPQUFLLDJCQUEyQixjQUFjLEVBQUUsT0FBTyxLQUFLLENBQUM7SUFDN0QsS0FBSyxNQUFNLENBQUMsT0FBTyxrQkFBa0IsT0FBTyxRQUFRLGFBQWEsaUJBQWlCLENBQUMsQ0FBQyxHQUFHO0tBQ3JGLE1BQU0sWUFBWSxjQUFjLFFBQVEsU0FBU0MsSUFBSyxhQUFhLE9BQU8sSUFBSSxNQUFNLEtBQUssQ0FBQztLQUMxRixJQUFJLFVBQVUsU0FBUyxHQUNyQixhQUFhLGNBQWMsU0FBUztVQUVwQyxPQUFPLGFBQWEsY0FBYztJQUV0QztJQUNBLE1BQU0sb0JBQW9CLEtBQUssdUJBQXVCLFlBQVk7SUFDbEUsSUFBSSxzQkFBc0IsTUFDeEI7SUFFRixNQUFNLG9CQUFvQixXQUFXLFlBQVksS0FBSyxJQUFJO0lBQzFELE1BQU0sWUFBWSxLQUFLLElBQUksbUJBQW1CLGlCQUFpQjtJQUMvRCxJQUFJLFlBQVksR0FDZCxLQUFLLG1CQUFtQixXQUFXLFFBQVEsU0FBUztTQUVwRCxLQUFLLE9BQU8sV0FBVyxNQUFNO0dBRWpDLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSx1QkFBdUIsT0FBTztFQUM1QixNQUFNLG1CQUFtQixPQUFPLE9BQU8sTUFBTSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxhQUFhLFNBQVMsU0FBUyxDQUFDLENBQUMsUUFBUSxjQUFjLENBQUMsQ0FBQyxTQUFTO0VBQ3JJLElBQUksaUJBQWlCLFdBQVcsR0FDOUIsT0FBTztFQUVULE9BQU8sS0FBSyxJQUFJLEdBQUcsZ0JBQWdCLElBQUksS0FBSyxJQUFJO0NBQ2xEO0FBQ0Y7QUFDQSxJQUFJLHFCQUFxQixJQUFJLG1CQUFtQjtBQUdoRCxJQUFJLHFCQUFxQixPQUFPO0NBQzlCLElBQUksR0FBRyxpQkFBaUIsTUFDdEIsT0FBTztDQUVULE1BQU0sT0FBTyxHQUFHLHNCQUFzQjtDQUN0QyxNQUFNLG9CQUFvQixLQUFLLE1BQU0sT0FBTyxlQUFlLEtBQUssVUFBVTtDQUMxRSxNQUFNLHNCQUFzQixLQUFLLE9BQU8sT0FBTyxjQUFjLEtBQUssU0FBUztDQUMzRSxPQUFPLHFCQUFxQjtBQUM5QjtBQUNBLElBQUksdUJBQXVCLFlBQVk7Q0FDckMsTUFBTSx3QkFBd0IsT0FBTztFQUNuQyxNQUFNLGdCQUFnQixPQUFPLGlCQUFpQixFQUFFO0VBQ2hELElBQUksY0FBYyxjQUFjLFVBQzlCLE9BQU87RUFFVCxJQUFJLGNBQWMsY0FBYyxRQUM5QixPQUFPO0VBRVQsSUFBSSxDQUFDLFdBQVcsTUFBTSxDQUFDLENBQUMsU0FBUyxjQUFjLFNBQVMsR0FDdEQsT0FBTztFQUVULE9BQU8sdUJBQXVCLGNBQWMsV0FBVyxHQUFHLE1BQU0sTUFBTSxLQUFLLHNCQUFzQixJQUFJLFFBQVE7Q0FDL0c7Q0FDQSxNQUFNLDBCQUEwQixPQUFPO0VBQ3JDLE1BQU0sZ0JBQWdCLE9BQU8saUJBQWlCLEVBQUU7RUFDaEQsSUFBSSxjQUFjLGNBQWMsVUFDOUIsT0FBTztFQUVULElBQUksY0FBYyxjQUFjLFFBQzlCLE9BQU87RUFFVCxJQUFJLENBQUMsV0FBVyxNQUFNLENBQUMsQ0FBQyxTQUFTLGNBQWMsU0FBUyxHQUN0RCxPQUFPO0VBRVQsT0FBTyx1QkFBdUIsY0FBYyxVQUFVLEdBQUcsTUFBTSxLQUFLLEtBQUssc0JBQXNCLElBQUksT0FBTztDQUM1RztDQUNBLE1BQU0sMEJBQTBCLHNCQUFzQix5QkFBeUI7RUFDN0UsSUFBSSx3QkFBd0IseUJBQXlCLFVBQVUseUJBQXlCLE9BQ3RGLE9BQU87RUFFVCxJQUFJLHdCQUF3Qix5QkFBeUIsVUFBVSx5QkFBeUIsS0FDdEYsT0FBTztFQUVULE9BQU87Q0FDVDtDQUNBLE1BQU0seUJBQXlCLElBQUksY0FBYztFQUMvQyxNQUFNLFVBQVUsR0FBRztFQUNuQixJQUFJLENBQUMsU0FDSCxPQUFPO0VBRVQsTUFBTSxjQUFjLE9BQU8saUJBQWlCLE9BQU87RUFDbkQsSUFBSSxDQUFDLFFBQVEsYUFBYSxDQUFDLENBQUMsU0FBUyxZQUFZLE9BQU8sR0FBRztHQUN6RCxNQUFNLGlCQUFpQixDQUFDLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQyxTQUFTLFlBQVksYUFBYTtHQUN0RixPQUFPLGNBQWMsV0FBVyxpQkFBaUIsQ0FBQztFQUNwRDtFQUNBLE9BQU8sQ0FBQyxRQUFRLGFBQWEsQ0FBQyxDQUFDLFNBQVMsWUFBWSxPQUFPO0NBQzdEO0NBQ0EsSUFBSSxTQUFTLFNBQVM7Q0FDdEIsT0FBTyxRQUFRO0VBQ2IsTUFBTSxlQUFlLHFCQUFxQixNQUFNLEtBQUssdUJBQXVCLE1BQU07RUFDbEYsSUFBSSxPQUFPLGlCQUFpQixNQUFNLENBQUMsQ0FBQyxZQUFZLGNBQWMsY0FDNUQsT0FBTztFQUVULFNBQVMsT0FBTztDQUNsQjtDQUNBLE9BQU87QUFDVDtBQUNBLElBQUksdUNBQXVDLFVBQVUscUJBQXFCO0NBQ3hFLElBQUksQ0FBQyxrQkFDSCxPQUFPLFNBQVMsUUFBUSxZQUFZLGtCQUFrQixPQUFPLENBQUM7Q0FFaEUsTUFBTSxpQkFBaUIsU0FBUyxRQUFRLGdCQUFnQjtDQUN4RCxNQUFNLGlCQUFpQixDQUFDO0NBQ3hCLE1BQU0sbUJBQW1CLENBQUM7Q0FDMUIsS0FBSyxJQUFJLElBQUksZ0JBQWdCLEtBQUssR0FBRyxLQUFLO0VBQ3hDLE1BQU0sVUFBVSxTQUFTO0VBQ3pCLElBQUksa0JBQWtCLE9BQU8sR0FDM0IsZUFBZSxLQUFLLE9BQU87T0FFM0I7Q0FFSjtDQUNBLEtBQUssSUFBSSxJQUFJLGlCQUFpQixHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7RUFDekQsTUFBTSxVQUFVLFNBQVM7RUFDekIsSUFBSSxrQkFBa0IsT0FBTyxHQUMzQixpQkFBaUIsS0FBSyxPQUFPO09BRTdCO0NBRUo7Q0FDQSxPQUFPLENBQUMsR0FBRyxlQUFlLFFBQVEsR0FBRyxHQUFHLGdCQUFnQjtBQUMxRDtBQUNBLElBQUkseUJBQXlCLElBQUksUUFBUSxNQUFNO0NBQzdDLE9BQU8sNEJBQTRCO0VBQ2pDLElBQUksUUFBUSxHQUNWLHNCQUFzQixJQUFJLFFBQVEsQ0FBQztPQUVuQyxHQUFHO0NBRVAsQ0FBQztBQUNIO0FBQ0EsSUFBSSx5QkFBeUIsT0FBTztDQUNsQyxJQUFJLE9BQU8sV0FBVyxhQUNwQixPQUFPO0NBRVQsTUFBTSxXQUFXLFNBQVMsY0FBYyxxQkFBcUIsR0FBRyw0QkFBNEI7Q0FDNUYsSUFBSSxVQUFVLGFBQ1osT0FBTyxLQUFLLE1BQU0sU0FBUyxXQUFXO0NBRXhDLE9BQU87QUFDVDtBQUdBLElBQUksV0FBVyxPQUFPLFdBQVc7QUFDakMsSUFBSSxZQUFZLENBQUMsWUFBWSxXQUFXLEtBQUssT0FBTyxVQUFVLFNBQVM7QUFDdkUsSUFBSSxTQUFTLE1BQU07Q0FDakIsT0FBTyxPQUFPO0VBQ1osUUFBUSxvQkFBb0IsS0FBSyxpQkFBaUIsQ0FBQztDQUNyRDtDQUNBLE9BQU8sbUJBQW1CO0VBQ3hCLE9BQU8sTUFBTSxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLFlBQVk7R0FDakQsS0FBSyxPQUFPO0dBQ1osTUFBTSxPQUFPO0VBQ2YsRUFBRTtDQUNKO0NBQ0EsT0FBTyxVQUFVO0VBQ2YsT0FBTyxTQUFTLGlCQUFpQixpQkFBaUI7Q0FDcEQ7Q0FDQSxPQUFPLGNBQWM7RUFDbkIsSUFBSSxhQUFhLGlCQUFpQixTQUFTLGVBQWUsQ0FBQyxDQUFDLG1CQUFtQixVQUM3RSxPQUFPLDRCQUE0QixPQUFPLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUU3RCxPQUFPLFNBQVMsR0FBRyxDQUFDO0NBQ3RCO0NBQ0EsT0FBTyxRQUFRO0VBRWIsSUFBSSxFQURlLFdBQVcsT0FBTyxPQUFPLFNBQVMsT0FFbkQsS0FBSyxZQUFZO0VBRW5CLEtBQUssUUFBUSxDQUFDLENBQUMsU0FBUyxXQUFXO0dBQ2pDLElBQUksT0FBTyxPQUFPLGFBQWEsWUFDN0IsT0FBTyxTQUFTLEdBQUcsQ0FBQztRQUNmO0lBQ0wsT0FBTyxZQUFZO0lBQ25CLE9BQU8sYUFBYTtHQUN0QjtFQUNGLENBQUM7RUFDRCxLQUFLLEtBQUs7RUFDVixLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxPQUFPLGlCQUFpQjtFQUN0QixNQUFNLGFBQWEsV0FBVyxPQUFPLE9BQU8sU0FBUztFQUNyRCxJQUFJLFlBQ0YsaUJBQWlCO0dBQ2YsTUFBTSxnQkFBZ0IsU0FBUyxlQUFlLFdBQVcsTUFBTSxDQUFDLENBQUM7R0FDakUsZ0JBQWdCLGNBQWMsZUFBZSxJQUFJLEtBQUssWUFBWTtFQUNwRSxDQUFDO0NBRUw7Q0FDQSxPQUFPLFFBQVEsZUFBZTtFQUM1QixJQUFJLFVBQ0Y7RUFFRixPQUFPLDRCQUE0QjtHQUNqQyxLQUFLLGdCQUFnQjtHQUNyQixLQUFLLHFCQUFxQixhQUFhO0VBQ3pDLENBQUM7Q0FDSDtDQUNBLE9BQU8scUJBQXFCLGVBQWU7RUFDekMsSUFBSSxVQUNGO0VBRUYsS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFTLFFBQVEsVUFBVTtHQUN4QyxNQUFNLGlCQUFpQixjQUFjO0dBQ3JDLElBQUksQ0FBQyxnQkFDSDtHQUVGLElBQUksT0FBTyxPQUFPLGFBQWEsWUFDN0IsT0FBTyxTQUFTLGVBQWUsTUFBTSxlQUFlLEdBQUc7UUFDbEQ7SUFDTCxPQUFPLFlBQVksZUFBZTtJQUNsQyxPQUFPLGFBQWEsZUFBZTtHQUNyQztFQUNGLENBQUM7Q0FDSDtDQUNBLE9BQU8sa0JBQWtCO0VBQ3ZCLE1BQU0saUJBQWlCLFFBQVEsMEJBQTBCO0VBQ3pELE9BQU8sU0FBUyxlQUFlLE1BQU0sZUFBZSxHQUFHO0NBQ3pEO0NBQ0EsT0FBTyxTQUFTLE9BQU87RUFDckIsTUFBTSxTQUFTLE1BQU07RUFDckIsSUFBSSxPQUFPLE9BQU8saUJBQWlCLGNBQWMsT0FBTyxhQUFhLGVBQWUsR0FDbEYsS0FBSyxLQUFLO0NBRWQ7Q0FDQSxPQUFPLGlCQUFpQjtFQUN0QixRQUFRLDJCQUEyQjtHQUNqQyxLQUFLLE9BQU87R0FDWixNQUFNLE9BQU87RUFDZixDQUFDO0NBQ0g7QUFDRjtBQUdBLElBQUksVUFBVSxVQUFVLE9BQU8sU0FBUyxlQUFlLGlCQUFpQixRQUFRLGlCQUFpQixRQUFRLE9BQU8sYUFBYSxlQUFlLGlCQUFpQixZQUFZLE1BQU0sU0FBUztBQUN4TCxTQUFTLFNBQVMsTUFBTTtDQUN0QixPQUFPLE9BQU8sSUFBSSxLQUFLLGdCQUFnQixZQUFZLE1BQU0sS0FBSyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxVQUFVLFNBQVMsS0FBSyxDQUFDLEtBQUssT0FBTyxTQUFTLFlBQVksU0FBUyxRQUFRLE9BQU8sT0FBTyxJQUFJLENBQUMsQ0FBQyxNQUFNLFVBQVUsU0FBUyxLQUFLLENBQUM7QUFDbk47QUFHQSxJQUFJLGNBQWMsVUFBVSxpQkFBaUI7QUFDN0MsU0FBUyxpQkFBaUIsUUFBUSxPQUFPLElBQUksU0FBUyxHQUFHLFlBQVksTUFBTSx5QkFBeUIsWUFBWTtDQUM5RyxTQUFTLFVBQVUsQ0FBQztDQUNwQixLQUFLLE1BQU0sT0FBTyxRQUNoQixJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxHQUFHLEdBQ2xELE9BQU8sTUFBTSxXQUFXLFdBQVcsS0FBSyxTQUFTLEdBQUcsT0FBTyxNQUFNLHNCQUFzQjtDQUczRixPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsUUFBUSxLQUFLLFFBQVE7Q0FDdkMsSUFBSSxDQUFDLFFBQ0gsT0FBTztDQUVULE9BQU8sV0FBVyxhQUFhLEdBQUcsT0FBTyxNQUFNLEdBQUcsT0FBTyxHQUFHLElBQUk7QUFDbEU7QUFDQSxTQUFTLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUTtDQUN4QyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ3JCLE9BQU8sTUFBTSxLQUFLLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUM3QixVQUFVLE9BQU8sTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLEdBQUcsTUFBTSxHQUFHLE1BQU0sUUFBUSxNQUFNLENBQ3pGO01BQ0ssSUFBSSxpQkFBaUIsTUFDMUIsT0FBTyxLQUFLLE9BQU8sS0FBSyxNQUFNLFlBQVksQ0FBQztNQUN0QyxJQUFJLGlCQUFpQixNQUMxQixPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTSxJQUFJO01BQ3BDLElBQUksaUJBQWlCLE1BQzFCLE9BQU8sS0FBSyxPQUFPLEtBQUssS0FBSztNQUN4QixJQUFJLE9BQU8sVUFBVSxXQUMxQixPQUFPLEtBQUssT0FBTyxLQUFLLFFBQVEsTUFBTSxHQUFHO01BQ3BDLElBQUksT0FBTyxVQUFVLFVBQzFCLE9BQU8sS0FBSyxPQUFPLEtBQUssS0FBSztNQUN4QixJQUFJLE9BQU8sVUFBVSxVQUMxQixPQUFPLEtBQUssT0FBTyxLQUFLLEdBQUcsT0FBTztNQUM3QixJQUFJLFVBQVUsUUFBUSxVQUFVLEtBQUssR0FDMUMsT0FBTyxLQUFLLE9BQU8sS0FBSyxFQUFFO0NBRTVCLGlCQUFpQixPQUFPLE1BQU0sS0FBSyxNQUFNO0FBQzNDO0FBR0EsU0FBUyxXQUFXLEtBQUs7Q0FDdkIsT0FBTyxVQUFVLEtBQUssbUJBQW1CLElBQUksTUFBTSxDQUFDO0FBQ3REO0FBQ0EsU0FBUyxNQUFNLE9BQU87Q0FDcEIsSUFBSSxDQUFDLFNBQVMsVUFBVSxLQUN0QixPQUFPLENBQUM7Q0FFVixNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLFFBQVEsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsU0FBUyxZQUFZO0VBQ3ZFLE1BQU0sQ0FBQyxRQUFRLFlBQVksVUFBVSxPQUFPO0VBQzVDLEtBQUssUUFBUSxPQUFPLE1BQU0sR0FBRyxPQUFPLFFBQVEsQ0FBQztDQUMvQyxDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLE1BQU0sYUFBYTtDQUNwQyxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sTUFBTSxJQUFJLE9BQU8sV0FBVztDQUNsQyxPQUFPLE1BQU0sU0FBUyxNQUFNLE1BQU0sS0FBSyxHQUFHLElBQUk7QUFDaEQ7QUFDQSxTQUFTLFVBQVUsTUFBTTtDQUN2QixNQUFNLFFBQVEsS0FBSyxRQUFRLEdBQUc7Q0FDOUIsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssVUFBVSxHQUFHLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxDQUFDLENBQUM7QUFDekY7QUFDQSxTQUFTLE9BQU8sT0FBTztDQUNyQixPQUFPLG1CQUFtQixNQUFNLFFBQVEsT0FBTyxHQUFHLENBQUM7QUFDckQ7QUFDQSxTQUFTLEtBQUssUUFBUSxLQUFLLE9BQU87Q0FDaEMsTUFBTSxPQUFPLFNBQVMsR0FBRztDQUN6QixJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sV0FBVyxHQUNwQztDQUVGLElBQUksVUFBVTtDQUNkLE9BQU8sS0FBSyxTQUFTLEdBQUc7RUFDdEIsTUFBTSxVQUFVLEtBQUssTUFBTTtFQUMzQixNQUFNLGtCQUFrQixLQUFLLE9BQU87RUFDcEMsSUFBSSxPQUFPLFFBQVEsYUFBYSxZQUFZLFFBQVEsYUFBYSxNQUMvRCxRQUFRLFdBQVcsa0JBQWtCLENBQUMsSUFBSSxDQUFDO0VBRTdDLFVBQVUsUUFBUTtDQUNwQjtDQUNBLE1BQU0sUUFBUSxLQUFLLE1BQU07Q0FDekIsSUFBSSxVQUFVLE1BQU0sTUFBTSxRQUFRLE9BQU8sR0FDdkMsUUFBUSxLQUFLLEtBQUs7TUFFbEIsUUFBUSxTQUFTO0FBRXJCO0FBQ0EsU0FBUyxTQUFTLEtBQUs7Q0FDckIsTUFBTSxXQUFXLENBQUM7Q0FDbEIsTUFBTSxPQUFPLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztDQUM1QixJQUFJLE1BQ0YsU0FBUyxLQUFLLElBQUk7Q0FFcEIsSUFBSTtDQUNKLE1BQU0sVUFBVTtDQUNoQixRQUFRLFFBQVEsUUFBUSxLQUFLLEdBQUcsT0FBTyxNQUNyQyxTQUFTLEtBQUssTUFBTSxFQUFFO0NBRXhCLE9BQU87QUFDVDtBQUNBLFNBQVMsTUFBTSxPQUFPLFFBQVEsT0FBTyxhQUFhO0NBQ2hELElBQUksVUFBVSxLQUFLLEdBQ2pCO0NBRUYsSUFBSSxVQUFVLE1BQU07RUFDbEIsTUFBTSxLQUFLLEdBQUcsT0FBTyxFQUFFO0VBQ3ZCO0NBQ0Y7Q0FDQSxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7RUFDeEIsTUFBTSxTQUFTLE1BQU0sVUFBVTtHQUU3QixNQUFNLE1BRE0sZ0JBQWdCLFlBQVksR0FBRyxPQUFPLEdBQUcsTUFBTSxLQUFLLEdBQUcsT0FBTyxLQUN6RCxPQUFPLFdBQVc7RUFDckMsQ0FBQztFQUNEO0NBQ0Y7Q0FDQSxJQUFJLE9BQU8sVUFBVSxVQUFVO0VBQzdCLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxTQUFTLFFBQVE7R0FDbEMsTUFBTSxNQUFNLE1BQU0sU0FBUyxHQUFHLE9BQU8sR0FBRyxJQUFJLEtBQUssS0FBSyxPQUFPLFdBQVc7RUFDMUUsQ0FBQztFQUNEO0NBQ0Y7Q0FDQSxNQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsbUJBQW1CLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDN0Q7QUFHQSxTQUFTLFVBQVUsTUFBTTtDQUN2QixPQUFPLElBQUksSUFBSSxLQUFLLFNBQVMsR0FBRyxPQUFPLFdBQVcsY0FBYyxLQUFLLElBQUksT0FBTyxTQUFTLFNBQVMsQ0FBQztBQUNyRztBQUNBLElBQUksdUJBQXVCLE1BQU0sTUFBTSxRQUFRLGVBQWUsMkJBQTJCO0NBQ3ZGLElBQUksTUFBTSxPQUFPLFNBQVMsV0FBVyxVQUFVLElBQUksSUFBSTtDQUN2RCxLQUFLLFNBQVMsSUFBSSxLQUFLLGtCQUFrQixDQUFDLFdBQVcsSUFBSSxHQUFHO0VBQzFELElBQUlGLFNBQU8sSUFBSSx3Q0FBd0MsR0FDckQseUJBQXlCO0VBRTNCLE9BQU8saUJBQWlCLE1BQU0sSUFBSSxTQUFTLEdBQUcsTUFBTSxzQkFBc0I7Q0FDNUU7Q0FDQSxJQUFJLFdBQVcsSUFBSSxHQUNqQixPQUFPLENBQUMsS0FBSyxJQUFJO0NBRW5CLE1BQU0sQ0FBQyxPQUFPLFNBQVMseUJBQXlCLFFBQVEsS0FBSyxNQUFNLHNCQUFzQjtDQUN6RixPQUFPLENBQUMsVUFBVSxLQUFLLEdBQUcsS0FBSztBQUNqQztBQUNBLFNBQVMseUJBQXlCLFFBQVEsTUFBTSxNQUFNLGdCQUFnQixZQUFZO0NBQ2hGLE1BQU0sd0JBQXdCLFdBQVcsU0FBUyxDQUFDLFdBQVcsSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLENBQUMsQ0FBQyxTQUFTO0NBQ2xHLE1BQU0sVUFBVSxlQUFlLEtBQUssU0FBUyxDQUFDO0NBQzlDLE1BQU0sa0JBQWtCLFdBQVcsS0FBSyxTQUFTLENBQUMsQ0FBQyxXQUFXLEdBQUcsS0FBSyxLQUFLLFNBQVMsTUFBTTtDQUMxRixNQUFNLGtCQUFrQixDQUFDLG1CQUFtQixDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFdBQVcsR0FBRztDQUMvRyxNQUFNLCtCQUErQixtQkFBbUIsS0FBSyxLQUFLLFNBQVMsQ0FBQztDQUM1RSxNQUFNLFlBQVksS0FBSyxTQUFTLENBQUMsQ0FBQyxTQUFTLEdBQUcsS0FBSztDQUNuRCxNQUFNLFVBQVUsS0FBSyxTQUFTLENBQUMsQ0FBQyxTQUFTLEdBQUc7Q0FDNUMsTUFBTSxNQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsR0FBRyxPQUFPLFdBQVcsY0FBYyxxQkFBcUIsT0FBTyxTQUFTLFNBQVMsQ0FBQztDQUNwSCxJQUFJLHVCQUF1QjtFQUN6QixNQUFNLGNBQWMsV0FBVyxHQUFHLElBQUksWUFBWTtFQUNsRCxJQUFJLFNBQVMsVUFBVTtHQUFFLEdBQUcsTUFBTSxJQUFJLE1BQU07R0FBRyxHQUFHO0VBQUssR0FBRyxXQUFXO0NBQ3ZFO0NBQ0EsT0FBTyxDQUNMO0VBQ0UsVUFBVSxHQUFHLElBQUksU0FBUyxJQUFJLElBQUksU0FBUztFQUMzQyxrQkFBa0IsSUFBSSxXQUFXO0VBQ2pDLGtCQUFrQixJQUFJLFNBQVMsVUFBVSwrQkFBK0IsSUFBSSxDQUFDLElBQUk7RUFDakYsWUFBWSxJQUFJLFNBQVM7RUFDekIsVUFBVSxJQUFJLE9BQU87Q0FDdkIsQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUNULHdCQUF3QixDQUFDLElBQUksSUFDL0I7QUFDRjtBQUNBLFNBQVMsZUFBZSxLQUFLO0NBQzNCLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSTtDQUN0QixJQUFJLE9BQU87Q0FDWCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLG9CQUFvQixXQUFXLG1CQUFtQjtDQUNwRCxJQUFJLFVBQVUsUUFBUSxDQUFDLGVBQWUsUUFBUSxlQUFlLFNBQVMsQ0FBQyxDQUFDLFNBQVMsZUFBZSxNQUM5RixlQUFlLE9BQU8sVUFBVTtBQUVwQztBQUNBLElBQUksd0JBQXdCLE1BQU0sU0FBUztDQUN6QyxPQUFPLGVBQWUsSUFBSSxDQUFDLENBQUMsU0FBUyxlQUFlLElBQUksQ0FBQyxDQUFDO0FBQzVEO0FBQ0EsSUFBSSwrQkFBK0IsTUFBTSxTQUFTO0NBQ2hELE9BQU8sS0FBSyxXQUFXLEtBQUssVUFBVSxLQUFLLGFBQWEsS0FBSztBQUMvRDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDN0IsT0FBTyxTQUFTLFFBQVEsT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFLLEtBQUssU0FBUyxRQUFRLFlBQVk7QUFDdEc7QUFDQSxTQUFTLDhCQUE4QixNQUFNO0NBQzNDLElBQUksQ0FBQyxLQUFLLFdBQ1IsT0FBTztDQUVULElBQUksT0FBTyxLQUFLLGNBQWMsVUFBVTtFQUN0QyxRQUFRLE1BQ04saUZBQWlGLE9BQU8sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLHlJQUMxSDtFQUNBLE9BQU87Q0FDVDtDQUNBLE9BQU8sS0FBSztBQUNkO0FBQ0EsU0FBUyxlQUFlLEtBQUs7Q0FDM0IsT0FBTyxrQ0FBa0MsS0FBSyxHQUFHO0FBQ25EO0FBQ0EsU0FBUyxZQUFZLEtBQUssVUFBVTtDQUNsQyxNQUFNLFNBQVMsT0FBTyxRQUFRLFdBQVcsVUFBVSxHQUFHLElBQUk7Q0FDMUQsT0FBTyxXQUFXLEdBQUcsT0FBTyxTQUFTLElBQUksT0FBTyxPQUFPLE9BQU8sV0FBVyxPQUFPLFNBQVMsT0FBTyxTQUFTLEdBQUcsT0FBTyxXQUFXLE9BQU8sU0FBUyxPQUFPO0FBQ3ZKO0FBR0EsSUFBSSxjQUFjLE1BQU07Q0FDdEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxjQUFjLENBQUM7Q0FDZixZQUFZLENBQUM7Q0FDYixrQkFBa0I7Q0FDbEIsVUFBVTtDQUNWLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIscUJBQXFCLENBQUM7Q0FDdEIscUJBQXFCLENBQUM7Q0FDdEIsb0JBQW9CO0NBQ3BCLEtBQUssRUFDSCxhQUNBLGVBQ0Esa0JBQ0EsV0FDQztFQUNELEtBQUssT0FBTztHQUFFLEdBQUc7R0FBYSxPQUFPLFlBQVksU0FBUyxDQUFDO0dBQUcsY0FBYyxZQUFZLGdCQUFnQixDQUFDO0VBQUU7RUFDM0csS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxrQkFBa0I7RUFDdkIsYUFBYSxHQUFHLDhCQUE4QjtHQUM1QyxLQUFLLHVCQUF1QjtFQUM5QixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPLEVBQ1QsVUFBVSxPQUNWLGlCQUFpQixPQUNqQixnQkFBZ0IsT0FDaEIsaUJBQWlCLE9BQ2pCLFNBQVMsT0FDVCxnQkFBZ0IsT0FDaEIsWUFDRSxDQUFDLEdBQUc7RUFDTixJQUFJLE9BQU8sS0FBSyxNQUFNLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7R0FDakQsS0FBSyx1QkFBdUI7SUFDMUIsZUFBZSxNQUFNO0lBQ3JCLFdBQVcsTUFBTTtJQUNqQixLQUFLLE1BQU07R0FDYjtHQUNBLElBQUksTUFBTSx5QkFBeUIsS0FBSyxHQUN0QyxNQUFNLHVCQUF1QixNQUFNO0VBRXZDO0VBQ0EsS0FBSyxjQUFjLENBQUM7RUFDcEIsTUFBTSxjQUFjLEtBQUs7RUFDekIsSUFBSSxNQUFNLGNBQ1IsUUFBUSxNQUFNO0VBRWhCLE9BQU8sS0FBSyxRQUFRLE1BQU0sV0FBVyxLQUFLLENBQUMsQ0FBQyxNQUFNLGNBQWM7R0FDOUQsSUFBSSxnQkFBZ0IsS0FBSyxhQUN2QjtHQUVGLE1BQU0sb0JBQW9CLENBQUM7R0FDM0IsTUFBTSxZQUFZLE9BQU8sV0FBVztHQUNwQyxNQUFNLFdBQVcsQ0FBQyxZQUFZLE9BQU8sV0FBVyxJQUFJLElBQUksTUFBTSxHQUFHO0dBQ2pFLE1BQU0sZ0JBQWdCLENBQUMsYUFBYSxpQkFBaUIsT0FBTyxpQkFBaUIsSUFBSSxDQUFDO0dBQ2xGLFVBQVUsV0FBVyxxQkFBcUIsVUFBVSxNQUFNLEdBQUcsR0FBRyxRQUFRO0dBQ3hFLE1BQU0saUJBQWlCO0lBQUUsR0FBRztJQUFPLE9BQU8sQ0FBQztHQUFFO0dBQzdDLE9BQU8sSUFBSSxTQUNSLFlBQVksVUFBVSxRQUFRLGFBQWEsZ0JBQWdCLE9BQU8sSUFBSSxRQUFRLFVBQVUsZ0JBQWdCLE9BQU8sQ0FDbEgsQ0FBQyxDQUFDLFdBQVc7SUFDWCxNQUFNLGlCQUFpQixDQUFDLEtBQUssVUFBVSxLQUFLO0lBQzVDLElBQUksQ0FBQyxrQkFBa0IsT0FBTyxLQUFLLE1BQU0sTUFBTSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUNwRSxpQkFBaUI7SUFFbkIsS0FBSyxPQUFPO0lBQ1osS0FBSyxVQUFVO0lBQ2YsSUFBSSxLQUFLLGFBQWEsR0FDcEIsbUJBQW1CLHFDQUFxQztJQUUxRCxJQUFJLGdCQUNGLEtBQUssY0FBYyxjQUFjO0lBRW5DLElBQUksS0FBSyxpQkFDUCxLQUFLLGNBQWMsV0FBVztJQUVoQyxLQUFLLGtCQUFrQjtJQUN2QixJQUFJLEtBQUssc0JBQXNCO0tBQzdCLEtBQUssdUJBQXVCO0tBQzVCO0lBQ0Y7SUFDQSxPQUFPLEtBQUssS0FBSztLQUNmO0tBQ0EsTUFBTTtLQUNOO0tBQ0E7S0FDQTtJQUNGLENBQUMsQ0FBQyxDQUFDLFdBQVc7S0FDWixJQUFJLGdCQUNGLE9BQU8sNEJBQTRCLE9BQU8scUJBQXFCLGFBQWEsQ0FBQztVQUU3RSxPQUFPLE1BQU07S0FFZixJQUFJLEtBQUssd0JBQXdCLEtBQUsscUJBQXFCLGNBQWMsTUFBTSxhQUFhLEtBQUsscUJBQXFCLFFBQVEsTUFBTSxLQUNsSSxhQUFhLGtCQUFrQixxQkFBcUIsS0FBSyxxQkFBcUIsYUFBYTtLQUU3RixLQUFLLHVCQUF1QjtLQUM1QixJQUFJLENBQUMsU0FDSCxrQkFBa0IsT0FBTztNQUFFO01BQVE7S0FBUSxDQUFDO0lBRWhELENBQUM7R0FDSCxDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsV0FBVyxPQUFPLEVBQ2hCLGdCQUFnQixVQUNkLENBQUMsR0FBRztFQUNOLE9BQU8sS0FBSyxRQUFRLE1BQU0sV0FBVyxLQUFLLENBQUMsQ0FBQyxNQUFNLGNBQWM7R0FDOUQsS0FBSyxPQUFPO0dBQ1osS0FBSyxVQUFVO0dBQ2YsUUFBUSxXQUFXLEtBQUs7R0FDeEIsT0FBTyxLQUFLLEtBQUs7SUFBRTtJQUFXLE1BQU07SUFBTztJQUFlLGdCQUFnQjtHQUFNLENBQUM7RUFDbkYsQ0FBQztDQUNIO0NBQ0EsUUFBUTtFQUNOLEtBQUssVUFBVTtDQUNqQjtDQUNBLFlBQVk7RUFDVixPQUFPLEtBQUs7Q0FDZDtDQUNBLE1BQU07RUFDSixPQUFPLEtBQUs7Q0FDZDtDQUNBLHNCQUFzQjtFQUNwQixPQUFPO0dBQUUsR0FBRyxLQUFLO0dBQU0sT0FBTyxDQUFDO0VBQUU7Q0FDbkM7Q0FDQSxlQUFlO0VBQ2IsT0FBTyxPQUFPLEtBQUssS0FBSyxLQUFLLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO0NBQ3pEO0NBQ0EsTUFBTSxNQUFNO0VBQ1YsS0FBSyxPQUFPO0dBQUUsR0FBRyxLQUFLO0dBQU0sR0FBRztFQUFLO0NBQ3RDO0NBQ0EsZ0JBQWdCLE9BQU87RUFDckIsS0FBSyxPQUFPO0dBQUUsR0FBRyxLQUFLO0dBQU07RUFBTTtFQUNsQyxPQUFPLEtBQUssUUFBUSxLQUFLLEtBQUssV0FBVyxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sY0FBYztHQUN0RSxPQUFPLEtBQUssS0FBSztJQUFFO0lBQVcsTUFBTSxLQUFLO0lBQU0sZUFBZTtJQUFNLGdCQUFnQjtHQUFNLENBQUM7RUFDN0YsQ0FBQztDQUNIO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsS0FBSyxPQUFPO0dBQUUsR0FBRyxLQUFLO0dBQU07RUFBTTtFQUNsQyxLQUFLLGtCQUFrQixLQUFLO0NBQzlCO0NBQ0EsV0FBVyxNQUFNO0VBQ2YsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLFNBQVMsSUFBSSxHQUM5QixLQUFLLEtBQUssT0FBTztDQUVyQjtDQUNBLFNBQVMsTUFBTTtFQUNiLEtBQUssS0FBSyxrQkFBa0I7Q0FDOUI7Q0FDQSxLQUFLLEVBQ0gsV0FDQSxNQUFNLE9BQ04sZUFDQSxnQkFDQSxnQkFBZ0IsU0FDZjtFQUNELE1BQU0sZUFBZSxLQUFLLGNBQWM7R0FBRTtHQUFXLE1BQU07R0FBTztHQUFlO0VBQWMsQ0FBQztFQUNoRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSx1QkFBdUIsU0FBUyxvQkFBb0IsVUFDcEYsT0FBTyxPQUFPO0VBRWhCLE1BQU0seUJBQXlCLE9BQU8sbUJBQW1CLGtCQUFrQixPQUFPO0VBQ2xGLE1BQU0sMkJBQTJCLFlBQVk7R0FDM0MsUUFBUSxPQUFPLFVBQVU7SUFDdkIsSUFBSSxFQUFFLGlCQUFpQixlQUNyQixNQUFNO0dBRVYsQ0FBQztFQUNIO0VBQ0EsT0FBTyxJQUFJLFNBQVMsWUFBWTtHQUM5QixNQUFNLG1CQUFtQixTQUFTLDBCQUEwQixPQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQztHQUNsRix3QkFBd0IsaUJBQWlCLEtBQUs7R0FDOUMsd0JBQXdCLGlCQUFpQixRQUFRO0dBQ2pELHdCQUF3QixpQkFBaUIsa0JBQWtCO0dBQzNELHVCQUF1QixnQkFBZ0I7RUFDekMsQ0FBQztDQUNIO0NBQ0EsUUFBUSxXQUFXLE9BQU87RUFDeEIsT0FBTyxRQUFRLFFBQVEsS0FBSyxpQkFBaUIsV0FBVyxLQUFLLENBQUM7Q0FDaEU7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxFQUFFLEtBQUs7Q0FDaEI7Q0FDQSxZQUFZLEtBQUssT0FBTztFQUN0QixJQUFJLEVBQUUsT0FBTyxLQUFLLHFCQUNoQixLQUFLLG1CQUFtQixPQUFPO0NBRW5DO0NBQ0EsZUFBZSxLQUFLLE9BQU87RUFDekIsSUFBSSxPQUFPLEtBQUssb0JBQ2QsS0FBSyxtQkFBbUIsT0FBTztDQUVuQztDQUNBLFlBQVksS0FBSztFQUNmLE9BQU8sT0FBTyxLQUFLO0NBQ3JCO0NBQ0EsbUJBQW1CLElBQUksVUFBVTtFQUMvQixLQUFLLG1CQUFtQixLQUFLO0dBQUU7R0FBSTtFQUFTLENBQUM7Q0FDL0M7Q0FDQSxxQkFBcUIsSUFBSTtFQUN2QixLQUFLLHFCQUFxQixLQUFLLG1CQUFtQixRQUFRLFVBQVUsTUFBTSxPQUFPLEVBQUU7Q0FDckY7Q0FDQSxvQkFBb0I7RUFDbEIsTUFBTSxlQUFlLE9BQU8sS0FBSyxLQUFLLGtCQUFrQjtFQUN4RCxJQUFJLGFBQWEsV0FBVyxHQUMxQixPQUFPLENBQUM7RUFFVixNQUFNLFFBQVFHLFlBQVcsS0FBSyxLQUFLLEtBQUs7RUFDeEMsS0FBSyxNQUFNLE9BQU8sY0FDaEIsTUFBTSxPQUFPQSxZQUFXLEtBQUssbUJBQW1CLElBQUk7RUFFdEQsS0FBSyxNQUFNLEVBQUUsY0FBYyxLQUFLLG9CQUFvQjtHQUNsRCxNQUFNLFNBQVMsU0FBU0EsWUFBVyxLQUFLLENBQUM7R0FDekMsSUFBSSxRQUNGLE9BQU8sT0FBTyxPQUFPLE1BQU07RUFFL0I7RUFDQSxNQUFNLGdCQUFnQixDQUFDO0VBQ3ZCLEtBQUssTUFBTSxPQUFPLGNBQ2hCLGNBQWMsT0FBTyxNQUFNO0VBRTdCLE9BQU87Q0FDVDtDQUNBLHlCQUF5QjtFQUN2QixPQUFPLEtBQUssbUJBQW1CO0NBQ2pDO0NBQ0EsdUJBQXVCO0VBQ3JCLEtBQUsscUJBQXFCLENBQUM7RUFDM0IsS0FBSyxxQkFBcUIsQ0FBQztDQUM3QjtDQUNBLFVBQVUsT0FBTztFQUNmLE9BQU8sS0FBSyxLQUFLLGNBQWMsTUFBTTtDQUN2QztDQUNBLEdBQUcsT0FBTyxVQUFVO0VBQ2xCLEtBQUssVUFBVSxLQUFLO0dBQUU7R0FBTztFQUFTLENBQUM7RUFDdkMsYUFBYTtHQUNYLEtBQUssWUFBWSxLQUFLLFVBQVUsUUFBUSxhQUFhLFNBQVMsVUFBVSxTQUFTLFNBQVMsYUFBYSxRQUFRO0VBQ2pIO0NBQ0Y7Q0FDQSxjQUFjLE9BQU87RUFDbkIsS0FBSyxVQUFVLFFBQVEsYUFBYSxTQUFTLFVBQVUsS0FBSyxDQUFDLENBQUMsU0FBUyxhQUFhLFNBQVMsU0FBUyxDQUFDO0NBQ3pHO0NBQ0EsMkJBQTJCLFVBQVUsRUFBRSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQzNELE9BQU8sUUFBUSxTQUFTLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxjQUFjO0dBQ3BFLE1BQU0sbUJBQW1CLEtBQUssS0FBSyxZQUFZO0dBQy9DLElBQUkscUJBQXFCLEtBQUssR0FDNUI7R0FFRixJQUFJLFNBQVNDLElBQUssU0FBUyxPQUFPLFNBQVMsSUFBSSxNQUFNLEtBQUssR0FBRztJQUMzRCxJQUFLLFNBQVMsT0FBTyxTQUFTLE1BQU1BLElBQUssS0FBSyxLQUFLLE9BQU8saUJBQWlCLElBQUksQ0FBQztJQUNoRixTQUFTLFVBQVUsSUFBSSxDQUFDLFlBQVksaUJBQWlCO0dBQ3ZEO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxJQUFJQyxTQUFPLElBQUksWUFBWTtBQUczQixJQUFJLFFBQVEsTUFBTTtDQUNoQixRQUFRLENBQUM7Q0FDVCxvQkFBb0I7Q0FDcEIsSUFBSSxNQUFNO0VBQ1IsS0FBSyxNQUFNLEtBQUssSUFBSTtFQUNwQixPQUFPLEtBQUssUUFBUTtDQUN0QjtDQUNBLFVBQVU7RUFDUixLQUFLLHNCQUFzQixLQUFLLFlBQVksQ0FBQyxDQUFDLGNBQWM7R0FDMUQsS0FBSyxvQkFBb0I7RUFDM0IsQ0FBQztFQUNELE9BQU8sS0FBSztDQUNkO0NBQ0EsY0FBYztFQUNaLE1BQU0sT0FBTyxLQUFLLE1BQU0sTUFBTTtFQUM5QixJQUFJLE1BQ0YsT0FBTyxRQUFRLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssWUFBWSxDQUFDO0VBRTlELE9BQU8sUUFBUSxRQUFRO0NBQ3pCO0FBQ0Y7QUFHQSxJQUFJLFlBQVksT0FBTyxXQUFXO0FBQ2xDLElBQUksUUFBUSxJQUFJLE1BQU07QUFDdEIsSUFBSSxjQUFjLENBQUMsYUFBYSxRQUFRLEtBQUssT0FBTyxVQUFVLFNBQVM7QUFDdkUsSUFBSSxVQUFVLE1BQU07Q0FDbEIsa0JBQWtCO0NBQ2xCLGdCQUFnQjtDQUNoQixjQUFjO0NBQ2QsVUFBVSxDQUFDO0NBRVgsZUFBZTtDQUNmLFNBQVMsTUFBTSxLQUFLO0VBQ2xCLEtBQUssYUFBYTtHQUNoQixHQUFHQSxPQUFLLG9CQUFvQjtHQUM1QixpQkFBaUI7SUFDZixHQUFHQSxPQUFLLElBQUksQ0FBQyxFQUFFLG1CQUFtQixDQUFDO0tBQ2xDLE1BQU07R0FDVDtFQUNGLENBQUM7Q0FDSDtDQUNBLFFBQVEsS0FBSztFQUNYLElBQUksQ0FBQyxXQUNILE9BQU8sS0FBSyxRQUFRLEtBQUssZ0JBQWdCLEdBQUcsU0FBUyxLQUFLLElBQUksS0FBSyxRQUFRLEtBQUssZ0JBQWdCLEdBQUcsT0FBTyxLQUFLLGVBQWUsS0FBSyxnQkFBZ0IsR0FBRztDQUUxSjtDQUNBLFVBQVUsT0FBTyxLQUFLLE1BQU07RUFDMUIsSUFBSSxXQUNGO0VBRUYsSUFBSSxLQUFLLGFBQWE7R0FDcEIsTUFBTSxHQUFHO0dBQ1Q7RUFDRjtFQUNBLEtBQUssVUFBVTtFQUNmLE1BQU0sVUFBVTtHQUNkLE9BQU8sS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLE1BQU0sU0FBUztJQUM1QyxNQUFNLGVBQWUsS0FBSyxZQUFZLEVBQUUsTUFBTSxLQUFLLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxXQUFXLEtBQUssQ0FBQztJQUNsRixJQUFJLGFBQ0YsT0FBTyxJQUFJLFNBQVMsWUFBWTtLQUM5QixpQkFBaUIsT0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUM7SUFDekMsQ0FBQztJQUVILE9BQU8sT0FBTztHQUNoQixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsZUFBZSxPQUFPO0VBQ3BCLElBQUk7R0FDRixnQkFBZ0IsTUFBTSxLQUFLO0dBQzNCLE9BQU87RUFDVCxRQUFRO0dBQ04sT0FBTztJQUNMLEdBQUc7SUFDSCxPQUFPQyxZQUFXLE1BQU0sS0FBSztHQUMvQjtFQUNGO0NBQ0Y7Q0FDQSxZQUFZLE9BQU87RUFDakIsTUFBTSxzQkFBc0IsS0FBSyxlQUFlLEtBQUs7RUFDckQsT0FBTyxJQUFJLFNBQVMsWUFBWTtHQUM5QixPQUFPLE1BQU0saUJBQWlCLGVBQWUsbUJBQW1CLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxRQUFRLG1CQUFtQjtFQUMvRyxDQUFDO0NBQ0g7Q0FDQSxlQUFlO0VBQ2IsT0FBTyxNQUFNLFFBQVE7Q0FDdkI7Q0FDQSxRQUFRLFFBQVEsTUFBTTtFQUNwQixJQUFJLFdBQ0YsT0FBTyxRQUFRLFFBQVEsU0FBU0QsT0FBSyxJQUFJLENBQUM7RUFFNUMsTUFBTSxXQUFXLFNBQVMsT0FBTyxRQUFRLE9BQU87RUFDaEQsT0FBTyxLQUFLLGdCQUFnQixRQUFRLENBQUMsQ0FBQyxNQUFNLFNBQVM7R0FDbkQsSUFBSSxDQUFDLE1BQ0gsTUFBTSxJQUFJLE1BQU0sMkJBQTJCO0dBRTdDLElBQUksS0FBSyxpQkFBaUIsTUFDeEIsS0FBSyxlQUFlLFFBQVEsS0FBSztRQUVqQyxLQUFLLFVBQVUsUUFBUSxDQUFDO0dBRTFCLE9BQU87RUFDVCxDQUFDO0NBQ0g7Q0FDQSxnQkFBZ0IsVUFBVTtFQUN4QixPQUFPLG9CQUFvQixjQUFjLGVBQWUsUUFBUSxJQUFJLFFBQVEsUUFBUSxRQUFRO0NBQzlGO0NBQ0Esb0JBQW9CLGVBQWU7RUFDakMsTUFBTSxVQUFVO0dBQ2QsT0FBTyxRQUFRLFFBQVEsQ0FBQyxDQUFDLFdBQVc7SUFDbEMsSUFBSSxDQUFDLE9BQU8sUUFBUSxPQUFPLE1BQ3pCO0lBRUYsSUFBSSxRQUFRLEtBQUssaUJBQWlCLEdBQUcsYUFBYSxHQUNoRDtJQUVGLE9BQU8sS0FBSyxlQUFlO0tBQ3pCLE1BQU0sT0FBTyxRQUFRLE1BQU07S0FDM0I7SUFDRixDQUFDO0dBQ0gsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLDJCQUEyQixjQUFjO0VBQ3ZDLE1BQU0sVUFBVTtHQUNkLE9BQU8sUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXO0lBQ2xDLElBQUksQ0FBQyxPQUFPLFFBQVEsT0FBTyxNQUN6QjtJQUVGLElBQUksUUFBUSxLQUFLLDBCQUEwQixHQUFHLFlBQVksR0FDeEQ7SUFFRixPQUFPLEtBQUssZUFBZTtLQUN6QixNQUFNLE9BQU8sUUFBUSxNQUFNO0tBQzNCLHdCQUF3QjtJQUMxQixDQUFDO0dBQ0gsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLG1CQUFtQjtFQUNqQixPQUFPLE9BQU8sUUFBUSxPQUFPLGlCQUFpQixDQUFDO0NBQ2pEO0NBQ0EsNEJBQTRCO0VBQzFCLE9BQU8sT0FBTyxRQUFRLE9BQU8sMEJBQTBCO0dBQUUsS0FBSztHQUFHLE1BQU07RUFBRTtDQUMzRTtDQUNBLGFBQWEsT0FBTyxLQUFLLE1BQU07RUFDN0IsSUFBSSxRQUFRLEtBQUssU0FBUyxLQUFLLEdBQUc7R0FDaEMsTUFBTSxHQUFHO0dBQ1Q7RUFDRjtFQUNBLE1BQU0sRUFBRSxPQUFPLEdBQUcscUJBQXFCO0VBQ3ZDLE9BQUssTUFBTSxnQkFBZ0I7RUFDM0IsSUFBSSxXQUNGO0VBRUYsSUFBSSxLQUFLLGFBQWE7R0FDcEIsTUFBTSxHQUFHO0dBQ1Q7RUFDRjtFQUNBLEtBQUssVUFBVTtFQUNmLE1BQU0sVUFBVTtHQUNkLE9BQU8sS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLE1BQU0sU0FBUztJQUM1QyxNQUFNLGtCQUFrQixLQUFLLGVBQWUsRUFBRSxNQUFNLEtBQUssR0FBRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFdBQVcsS0FBSyxDQUFDO0lBQ3hGLElBQUksYUFDRixPQUFPLElBQUksU0FBUyxZQUFZO0tBQzlCLGlCQUFpQixVQUFVLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQztJQUM1QyxDQUFDO0lBRUgsT0FBTyxVQUFVO0dBQ25CLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSx1QkFBdUIsT0FBTztFQUM1QixPQUFPLGlCQUFpQixTQUFTLE1BQU0sU0FBUyxvQkFBb0IsTUFBTSxRQUFRLFNBQVMsbUJBQW1CLEtBQUssTUFBTSxRQUFRLFNBQVMsc0JBQXNCO0NBQ2xLO0NBQ0EscUJBQXFCLE9BQU87RUFDMUIsT0FBTyxpQkFBaUIsU0FBUyxNQUFNLFNBQVM7Q0FDbEQ7Q0FDQSx1QkFBdUIsSUFBSTtFQUN6QixPQUFPLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVztHQUNsQyxJQUFJO0lBQ0YsT0FBTyxHQUFHO0dBQ1osU0FBUyxPQUFPO0lBQ2QsSUFBSSxDQUFDLEtBQUssdUJBQXVCLEtBQUssR0FDcEMsTUFBTTtJQUVSLFFBQVEsTUFBTSxNQUFNLE9BQU87R0FDN0I7RUFDRixDQUFDO0NBQ0g7Q0FDQSxlQUFlLE1BQU0sS0FBSztFQUN4QixPQUFPLEtBQUssNkJBQTZCO0dBQ3ZDLE9BQU8sUUFBUSxhQUNiO0lBQ0UsR0FBRztJQUNILGVBQWUsS0FBSyxpQkFBaUIsT0FBTyxRQUFRLE9BQU87SUFDM0Qsd0JBQXdCLEtBQUssMEJBQTBCLE9BQU8sUUFBUSxPQUFPO0dBQy9FLEdBQ0EsSUFDQSxHQUNGO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsWUFBWSxNQUFNLEtBQUs7RUFDckIsT0FBTyxLQUFLLDZCQUE2QjtHQUN2QyxJQUFJO0lBQ0YsT0FBTyxRQUFRLFVBQVUsTUFBTSxJQUFJLEdBQUc7R0FDeEMsU0FBUyxPQUFPO0lBQ2QsSUFBSSxDQUFDLEtBQUsscUJBQXFCLEtBQUssR0FDbEMsTUFBTTtJQUVSLGFBQWEsa0JBQWtCLHdCQUF3QixHQUFHO0dBQzVEO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsU0FBUyxLQUFLLGNBQWM7RUFDMUIsT0FBTyxLQUFLLFVBQVUsUUFBUTtDQUNoQztDQUNBLFlBQVksS0FBSztFQUNmLElBQUksS0FBSyxRQUFRLFNBQVMsS0FBSyxHQUFHO0dBQ2hDLE9BQU8sS0FBSyxRQUFRO0dBQ3BCLEtBQUssYUFBYSxLQUFLLE9BQU87RUFDaEM7Q0FDRjtDQUNBLGtCQUFrQixLQUFLO0VBQ3JCLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxhQUFhLFNBQVMsS0FBSyxHQUN2RCxPQUFPLEtBQUssYUFBYTtDQUU3QjtDQUNBLHlCQUF5QjtFQUN2QixPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxRQUFRLE9BQU87Q0FDL0M7Q0FDQSxRQUFRO0VBQ04sZUFBZSxPQUFPLDBCQUEwQixHQUFHO0VBQ25ELGVBQWUsT0FBTywwQkFBMEIsRUFBRTtDQUNwRDtDQUNBLFdBQVcsT0FBTztFQUNoQixLQUFLLFVBQVU7Q0FDakI7Q0FDQSxhQUFhLE9BQU87RUFDbEIsT0FBTyxDQUFDLENBQUMsTUFBTTtDQUNqQjtDQUNBLGNBQWM7RUFDWixPQUFPLEtBQUs7Q0FDZDtBQUNGO0FBQ0EsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLFFBQVEsbUJBQ2xELE9BQU8sUUFBUSxvQkFBb0I7QUFFckMsSUFBSSxVQUFVLElBQUksUUFBUTtBQUcxQixJQUFJLGVBQWUsTUFBTTtDQUN2QixvQkFBb0IsQ0FBQztDQUNyQixPQUFPO0VBQ0wsSUFBSSxPQUFPLFdBQVcsYUFBYTtHQUNqQyxPQUFPLGlCQUFpQixZQUFZLEtBQUssb0JBQW9CLEtBQUssSUFBSSxDQUFDO0dBQ3ZFLE9BQU8saUJBQWlCLFlBQVksS0FBSyxvQkFBb0IsS0FBSyxJQUFJLENBQUM7R0FDdkUsT0FBTyxpQkFBaUIsVUFBVSxTQUFTLE9BQU8sZUFBZSxLQUFLLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSTtFQUMzRjtFQUNBLElBQUksT0FBTyxhQUFhLGFBQ3RCLFNBQVMsaUJBQWlCLFVBQVUsU0FBUyxPQUFPLFNBQVMsS0FBSyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUk7Q0FFekY7Q0FDQSxjQUFjLE1BQU0sVUFBVTtFQUM1QixNQUFNLGFBQWEsVUFBVTtHQUMzQixNQUFNLFdBQVcsU0FBUyxLQUFLO0dBQy9CLElBQUksTUFBTSxjQUFjLENBQUMsTUFBTSxvQkFBb0IsYUFBYSxPQUM5RCxNQUFNLGVBQWU7RUFFekI7RUFDQSxPQUFPLEtBQUssaUJBQWlCLFdBQVcsUUFBUSxRQUFRO0NBQzFEO0NBQ0EsR0FBRyxPQUFPLFVBQVU7RUFDbEIsS0FBSyxrQkFBa0IsS0FBSztHQUFFO0dBQU8sVUFBVTtFQUFTLENBQUM7RUFDekQsYUFBYTtHQUNYLEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLFFBQVEsYUFBYSxTQUFTLGFBQWEsUUFBUTtFQUNyRztDQUNGO0NBQ0EsdUJBQXVCO0VBQ3JCLE9BQUssTUFBTTtFQUNYLEtBQUssa0JBQWtCLG9CQUFvQjtDQUM3QztDQUNBLGtCQUFrQixPQUFPLEdBQUcsTUFBTTtFQUNoQyxLQUFLLGtCQUFrQixRQUFRLGFBQWEsU0FBUyxVQUFVLEtBQUssQ0FBQyxDQUFDLFNBQVMsYUFBYSxTQUFTLFNBQVMsR0FBRyxJQUFJLENBQUM7Q0FDeEg7Q0FDQSxpQkFBaUIsTUFBTSxVQUFVO0VBQy9CLFNBQVMsaUJBQWlCLE1BQU0sUUFBUTtFQUN4QyxhQUFhLFNBQVMsb0JBQW9CLE1BQU0sUUFBUTtDQUMxRDtDQUlBLG9CQUFvQixPQUFPO0VBQ3pCLElBQUksTUFBTSxXQUNSLFFBQVEsUUFBUSxDQUFDLENBQUMsWUFBWSxLQUFLLHFCQUFxQixDQUFDO0NBRTdEO0NBQ0Esb0JBQW9CLE9BQU87RUFDekIsTUFBTSxRQUFRLE1BQU0sU0FBUztFQUM3QixJQUFJLFVBQVUsTUFBTTtHQUNsQixNQUFNLE1BQU0sVUFBVUEsT0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFHO0dBQ3BDLElBQUksT0FBTyxPQUFPLFNBQVM7R0FDM0IsUUFBUSxhQUFhO0lBQUUsR0FBR0EsT0FBSyxvQkFBb0I7SUFBRyxLQUFLLElBQUk7R0FBSyxDQUFDO0dBQ3JFLE9BQU8sTUFBTTtHQUNiO0VBQ0Y7RUFDQSxJQUFJLENBQUMsUUFBUSxhQUFhLEtBQUssR0FDN0IsT0FBTyxLQUFLLHFCQUFxQjtFQUVuQyxRQUFRLFFBQVEsTUFBTSxJQUFJLENBQUMsQ0FBQyxNQUFNLFNBQVM7R0FDekMsSUFBSUEsT0FBSyxJQUFJLENBQUMsQ0FBQyxZQUFZLEtBQUssU0FBUztJQUN2QyxLQUFLLHFCQUFxQjtJQUMxQjtHQUNGO0dBQ0EsT0FBTyxVQUFVLEVBQUUsVUFBVSxNQUFNLENBQUM7R0FDcEMsT0FBSyxXQUFXLE1BQU0sRUFBRSxlQUFlLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVztJQUN6RCxPQUFPLFFBQVEsUUFBUSxpQkFBaUIsQ0FBQztJQUN6QyxrQkFBa0JBLE9BQUssSUFBSSxDQUFDO0lBQzVCLE1BQU0sa0JBQWtCLENBQUM7SUFDekIsTUFBTSxZQUFZQSxPQUFLLElBQUksQ0FBQyxDQUFDO0lBQzdCLEtBQUssTUFBTSxDQUFDLE9BQU8sVUFBVSxPQUFPLFFBQVEsS0FBSyx3QkFBd0IsS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUc7S0FDbEcsTUFBTSxVQUFVLE1BQU0sUUFBUSxTQUFTRSxJQUFLLFdBQVcsSUFBSSxNQUFNLEtBQUssQ0FBQztLQUN2RSxJQUFJLFFBQVEsU0FBUyxHQUNuQixnQkFBZ0IsU0FBUztJQUU3QjtJQUNBLElBQUksT0FBTyxLQUFLLGVBQWUsQ0FBQyxDQUFDLFNBQVMsR0FDeEMsS0FBSyxrQkFBa0IscUJBQXFCLGVBQWU7R0FFL0QsQ0FBQztFQUNILENBQUMsQ0FBQyxDQUFDLFlBQVk7R0FDYixLQUFLLHFCQUFxQjtFQUM1QixDQUFDO0NBQ0g7QUFDRjtBQUNBLElBQUksZUFBZSxJQUFJLGFBQWE7QUFHcEMsSUFBSSxpQkFBaUIsTUFBTTtDQUN6QjtDQUNBLGNBQWM7RUFDWixLQUFLLE9BQU8sS0FBSyxZQUFZO0NBQy9CO0NBQ0EsY0FBYztFQUNaLElBQUksT0FBTyxXQUFXLGFBQ3BCLE9BQU87RUFHVCxRQURjLE9BQU8sYUFBYSxpQkFBaUIsWUFBWSxDQUFDLENBQUMsR0FBQSxFQUNuRCxRQUFRO0NBQ3hCO0NBQ0EsTUFBTTtFQUNKLE9BQU8sS0FBSztDQUNkO0NBQ0EsZ0JBQWdCO0VBQ2QsT0FBTyxLQUFLLFNBQVM7Q0FDdkI7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLLFNBQVM7Q0FDdkI7QUFDRjtBQUNBLElBQUksaUJBQWlCLElBQUksZUFBZTtBQUd4QyxTQUFTLE1BQU07Q0FDYixNQUFNLFlBQVksT0FBTyxXQUFXLGNBQWMsT0FBTyxTQUFTLEtBQUs7Q0FDdkUsSUFBSSxXQUFXLFlBQ2IsT0FBTyxVQUFVLFdBQVc7Q0FFOUIsTUFBTSxtQkFBbUIsV0FBVyxrQkFBa0IsVUFBVSxnQ0FBZ0IsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztDQUN0SSxPQUFPLHVDQUF1QyxRQUM1QyxXQUNDLE9BQU8sQ0FBQyxJQUFJLFdBQVcsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFBLENBQUcsU0FBUyxFQUFFLENBQ3ZEO0FBQ0Y7QUFHQSxJQUFJLGVBQWUsTUFBTTtDQUN2QixPQUFPLFNBQVM7RUFDZCxLQUFLLDZCQUE2QjtFQUVsQztHQURtQixLQUFLO0dBQW1CLEtBQUs7R0FBZ0IsS0FBSztFQUM3RCxDQUFDLENBQUMsTUFBTSxZQUFZLFFBQVEsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO0NBQ2xEO0NBQ0EsT0FBTywrQkFBK0I7RUFDcEMsSUFBSSxlQUFlLFNBQVMsR0FBRztHQUM3QixRQUFRLFlBQVksUUFBUSxlQUFlO0dBQzNDLFFBQVEsa0JBQWtCLFFBQVEsZUFBZTtFQUNuRDtDQUNGO0NBQ0EsT0FBTyxvQkFBb0I7RUFDekIsSUFBSSxDQUFDLGVBQWUsY0FBYyxLQUFLLENBQUMsUUFBUSx1QkFBdUIsR0FDckUsT0FBTztFQUVULE1BQU0sZ0JBQWdCLFFBQVEsaUJBQWlCO0VBQy9DLFFBQVEsUUFBUSxDQUFDLENBQUMsTUFBTSxTQUFTO0dBQy9CLE1BQU0sVUFBVSxJQUFJO0dBQ3BCLE9BQUssSUFBSSxNQUFNO0lBQUUsZ0JBQWdCO0lBQU0sZUFBZTtJQUFNO0dBQVEsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUNoRixPQUFPLFFBQVEsYUFBYTtJQUM1QixrQkFBa0JGLE9BQUssSUFBSSxHQUFHLEVBQUUsUUFBUSxDQUFDO0dBQzNDLENBQUM7RUFDSCxDQUFDLENBQUMsQ0FBQyxZQUFZO0dBQ2IsYUFBYSxxQkFBcUI7RUFDcEMsQ0FBQztFQUNELE9BQU87Q0FDVDs7OztDQUlBLE9BQU8saUJBQWlCO0VBQ3RCLElBQUksQ0FBQyxlQUFlLE9BQU8sZUFBZSxnQkFBZ0IsR0FDeEQsT0FBTztFQUVULE1BQU0sZ0JBQWdCLGVBQWUsSUFBSSxlQUFlLGdCQUFnQixLQUFLLENBQUM7RUFDOUUsZUFBZSxPQUFPLGVBQWUsZ0JBQWdCO0VBQ3JELElBQUksT0FBTyxXQUFXLGFBQ3BCLE9BQUssV0FBVyxPQUFPLFNBQVMsSUFBSTtFQUV0QyxRQUFRLFFBQVFBLE9BQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ3JDLE1BQU0sVUFBVSxJQUFJO0dBQ3BCLE1BQU0sa0JBQWtCLFFBQVEsU0FBUyxRQUFRLGlCQUFpQixDQUFDLENBQUM7R0FDcEUsTUFBTSxnQkFBZ0IsUUFBUSxpQkFBaUI7R0FDL0MsT0FBSyxTQUFTLGVBQWU7R0FDN0IsT0FBSyxJQUFJQSxPQUFLLElBQUksR0FBRztJQUNuQixnQkFBZ0IsY0FBYztJQUM5QixlQUFlO0lBQ2YsZUFBZTtJQUNmO0dBQ0YsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUNaLElBQUksY0FBYyxnQkFDaEIsT0FBTyxRQUFRLGFBQWE7SUFFOUIsS0FBSyxrQkFBa0IsT0FBTztHQUNoQyxDQUFDO0VBQ0gsQ0FBQyxDQUFDLENBQUMsWUFBWTtHQUNiLGFBQWEscUJBQXFCO0VBQ3BDLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLGdCQUFnQjtFQUNyQixJQUFJLE9BQU8sV0FBVyxhQUNwQixPQUFLLFdBQVcsT0FBTyxTQUFTLElBQUk7RUFFdEMsTUFBTSxVQUFVLElBQUk7RUFDcEIsT0FBSyxJQUFJQSxPQUFLLElBQUksR0FBRztHQUFFLGdCQUFnQjtHQUFNLGVBQWU7R0FBTSxlQUFlO0dBQU07RUFBUSxDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQzNHLElBQUksZUFBZSxTQUFTLEdBQzFCLE9BQU8sUUFBUSxRQUFRLGlCQUFpQixDQUFDO1FBRXpDLE9BQU8sZUFBZTtHQUV4QixLQUFLLGtCQUFrQixPQUFPO0VBQ2hDLENBQUM7Q0FDSDtDQUNBLE9BQU8sa0JBQWtCLFNBQVM7RUFDaEMsTUFBTSxRQUFRQSxPQUFLLElBQUk7RUFDdkIsa0JBQWtCLE9BQU8sRUFBRSxRQUFRLENBQUM7RUFDcEMsSUFBSSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTLEdBQ3BDLHFCQUFxQixlQUFlLE1BQU0sS0FBSyxDQUFDO0NBRXBEO0FBQ0Y7QUFHQSxJQUFJLE9BQU8sTUFBTTtDQUNmLGFBQWE7Q0FDYixZQUFZO0NBQ1osV0FBVztDQUNYLFlBQVk7Q0FDWjtDQUNBO0NBQ0EsVUFBVTtDQUNWO0NBQ0EsV0FBVztDQUNYLGdCQUFnQjtDQUNoQixVQUFVO0NBQ1YsYUFBYTtDQUNiLFlBQVksVUFBVSxJQUFJLFNBQVM7RUFDakMsS0FBSyxZQUFZLFFBQVEsYUFBYTtFQUN0QyxLQUFLLE9BQU8sUUFBUSxRQUFRO0VBQzVCLEtBQUssS0FBSztFQUNWLEtBQUssV0FBVztFQUNoQixJQUFJLFFBQVEsYUFBYSxNQUN2QixLQUFLLE1BQU07Q0FFZjtDQUNBLE9BQU87RUFDTCxLQUFLLFVBQVU7RUFDZixLQUFLO0VBQ0wsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZ0JBQWdCO0VBQ3JCLElBQUksS0FBSyxZQUFZO0dBQ25CLGNBQWMsS0FBSyxVQUFVO0dBQzdCLEtBQUssYUFBYTtFQUNwQjtFQUNBLElBQUksS0FBSyxXQUFXO0dBQ2xCLGFBQWEsS0FBSyxTQUFTO0dBQzNCLEtBQUssWUFBWTtFQUNuQjtDQUNGO0NBQ0EsUUFBUTtFQUNOLElBQUksT0FBTyxXQUFXLGFBQ3BCO0VBRUYsS0FBSyxLQUFLO0VBQ1YsS0FBSyxVQUFVO0VBQ2YsSUFBSSxLQUFLLFNBQVMsUUFBUTtHQUN4QixLQUFLLGFBQWE7R0FDbEI7RUFDRjtFQUNBLEtBQUssYUFBYSxPQUFPLGtCQUFrQixLQUFLLEtBQUssR0FBRyxLQUFLLFFBQVE7Q0FDdkU7Q0FDQSxlQUFlLFNBQVM7RUFDdEIsS0FBSyxXQUFXLEtBQUssWUFBWSxRQUFRO0VBQ3pDLElBQUksS0FBSyxVQUNQLEtBQUssVUFBVTtDQUVuQjtDQUNBLGVBQWU7RUFDYixJQUFJLEtBQUssU0FDUDtFQUVGLEtBQUssWUFBWSxPQUFPLGlCQUFpQjtHQUN2QyxLQUFLLFlBQVk7R0FDakIsS0FBSyxLQUFLO0VBQ1osR0FBRyxLQUFLLFFBQVE7Q0FDbEI7Q0FDQSxPQUFPO0VBQ0wsSUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFVBQVUsT0FBTyxHQUMxQyxLQUFLLEtBQUs7T0FDTCxJQUFJLEtBQUssU0FBUyxRQUN2QixLQUFLLGFBQWE7RUFFcEIsSUFBSSxLQUFLLFVBQ1AsS0FBSztDQUVUO0NBQ0EsT0FBTztFQUNMLElBQUksS0FBSyxZQUFZLEtBQUssU0FBUyxVQUNqQyxLQUFLLGdCQUFnQjtFQUV2QixNQUFNLFdBQVcsS0FBSztFQUN0QixLQUFLLEdBQUc7R0FDTixVQUFVLFdBQVc7SUFDbkIsSUFBSSxhQUFhLEtBQUssWUFDcEI7SUFFRixLQUFLLFdBQVc7SUFDaEIsS0FBSyxnQkFBZ0I7R0FDdkI7R0FDQSxnQkFBZ0I7SUFDZCxJQUFJLGFBQWEsS0FBSyxZQUNwQjtJQUVGLEtBQUssV0FBVztJQUNoQixLQUFLLGdCQUFnQjtJQUNyQixJQUFJLEtBQUssU0FBUyxRQUNoQixLQUFLLGFBQWE7R0FFdEI7RUFDRixDQUFDO0NBQ0g7QUFDRjtBQUdBLElBQUksUUFBUSxNQUFNO0NBQ2hCLFFBQVEsQ0FBQztDQUNULGNBQWM7RUFDWixLQUFLLHdCQUF3QjtDQUMvQjtDQUNBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxNQUFNO0NBQ3BCO0NBQ0EsSUFBSSxVQUFVLElBQUksU0FBUztFQUN6QixNQUFNLE9BQU8sSUFBSSxLQUFLLFVBQVUsSUFBSSxPQUFPO0VBQzNDLEtBQUssTUFBTSxLQUFLLElBQUk7RUFDcEIsT0FBTztHQUNMLFlBQVksS0FBSyxLQUFLO0dBQ3RCLGFBQWEsS0FBSyxNQUFNO0dBQ3hCLGVBQWU7SUFDYixLQUFLLEtBQUs7SUFDVixLQUFLLFFBQVEsS0FBSyxNQUFNLFFBQVEsTUFBTSxNQUFNLElBQUk7R0FDbEQ7RUFDRjtDQUNGO0NBQ0EsUUFBUTtFQUNOLEtBQUssTUFBTSxTQUFTLFNBQVMsS0FBSyxLQUFLLENBQUM7RUFDeEMsS0FBSyxRQUFRLENBQUM7Q0FDaEI7Q0FDQSwwQkFBMEI7RUFDeEIsSUFBSSxPQUFPLGFBQWEsYUFDdEI7RUFFRixTQUFTLGlCQUNQLDBCQUNNO0dBQ0osS0FBSyxNQUFNLFNBQVMsU0FBUyxLQUFLLGVBQWUsU0FBUyxNQUFNLENBQUM7RUFDbkUsR0FDQSxLQUNGO0NBQ0Y7QUFDRjtBQUNBLElBQUksUUFBUSxJQUFJLE1BQU07QUFTdEIsSUFBSSxlQUFlLE1BQU07Q0FDdkIsa0JBQWtCLENBQUM7Q0FDbkIsbUJBQW1CLENBQUM7Q0FDcEIsZ0JBQWdCLENBQUM7Q0FDakIsVUFBVSxTQUFTO0VBQ2pCLEtBQUssZ0JBQWdCLEtBQUssT0FBTztFQUNqQyxhQUFhO0dBQ1gsS0FBSyxrQkFBa0IsS0FBSyxnQkFBZ0IsUUFBUSxNQUFNLE1BQU0sT0FBTztFQUN6RTtDQUNGO0NBQ0EsV0FBVyxTQUFTO0VBQ2xCLEtBQUssaUJBQWlCLEtBQUssT0FBTztFQUNsQyxhQUFhO0dBQ1gsS0FBSyxtQkFBbUIsS0FBSyxpQkFBaUIsUUFBUSxNQUFNLE1BQU0sT0FBTztFQUMzRTtDQUNGO0NBQ0EsUUFBUSxTQUFTO0VBQ2YsS0FBSyxjQUFjLEtBQUssT0FBTztFQUMvQixhQUFhO0dBQ1gsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjLFFBQVEsTUFBTSxNQUFNLE9BQU87RUFDckU7Q0FDRjtDQUNBLE1BQU0sZUFBZSxTQUFTO0VBQzVCLElBQUksU0FBUztFQUNiLEtBQUssTUFBTSxXQUFXLEtBQUssaUJBQ3pCLFNBQVMsTUFBTSxRQUFRLE1BQU07RUFFL0IsT0FBTztDQUNUO0NBQ0EsTUFBTSxnQkFBZ0IsVUFBVTtFQUM5QixJQUFJLFNBQVM7RUFDYixLQUFLLE1BQU0sV0FBVyxLQUFLLGtCQUN6QixTQUFTLE1BQU0sUUFBUSxNQUFNO0VBRS9CLE9BQU87Q0FDVDtDQUNBLE1BQU0sYUFBYSxPQUFPO0VBQ3hCLEtBQUssTUFBTSxXQUFXLEtBQUssZUFDekIsTUFBTSxRQUFRLEtBQUs7Q0FFdkI7QUFDRjtBQUNBLElBQUksZUFBZSxJQUFJLGFBQWE7QUFHcEMsSUFBSSxZQUFZLGNBQWMsTUFBTTtDQUNsQztDQUNBO0NBQ0EsWUFBWSxTQUFTLE1BQU0sS0FBSztFQUM5QixNQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksSUFBSSxLQUFLLE9BQU87RUFDM0MsS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxNQUFNO0NBQ2I7QUFDRjtBQUNBLElBQUksb0JBQW9CLGNBQWMsVUFBVTtDQUM5QztDQUNBLFlBQVksU0FBUyxVQUFVLEtBQUs7RUFDbEMsTUFBTSxTQUFTLHFCQUFxQixHQUFHO0VBQ3ZDLEtBQUssT0FBTztFQUNaLEtBQUssV0FBVztDQUNsQjtBQUNGO0FBQ0EsSUFBSSxxQkFBcUIsY0FBYyxVQUFVO0NBQy9DLFlBQVksVUFBVSx5QkFBeUIsS0FBSztFQUNsRCxNQUFNLFNBQVMsaUJBQWlCLEdBQUc7RUFDbkMsS0FBSyxPQUFPO0NBQ2Q7QUFDRjtBQUNBLElBQUksbUJBQW1CLGNBQWMsVUFBVTtDQUM3QztDQUNBLFlBQVksU0FBUyxLQUFLLE9BQU87RUFDL0IsTUFBTSxTQUFTLGVBQWUsR0FBRztFQUNqQyxLQUFLLE9BQU87RUFDWixLQUFLLFFBQVE7Q0FDZjtBQUNGO0FBR0EsU0FBUyxVQUFVLE1BQU07Q0FDdkIsTUFBTSxRQUFRLFNBQVMsT0FBTyxNQUFNLElBQUksT0FBTyxlQUFlLE9BQU8sV0FBVyxDQUFDO0NBQ2pGLE9BQU8sUUFBUSxtQkFBbUIsTUFBTSxFQUFFLElBQUk7QUFDaEQ7QUFDQSxTQUFTLGFBQWEsS0FBSztDQUN6QixNQUFNLFVBQVUsQ0FBQztDQUNqQixJQUFJLHNCQUFzQixDQUFDLENBQUMsTUFBTSxNQUFNLENBQUMsQ0FBQyxTQUFTLFNBQVM7RUFDMUQsTUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHO0VBQzlCLElBQUksUUFBUSxHQUNWLFFBQVEsS0FBSyxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssTUFBTSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUs7Q0FFcEYsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLFNBQVMsc0JBQXNCLE9BQU87Q0FDcEMsT0FBTyxPQUFPLGFBQWEsZUFBZSxpQkFBaUI7QUFDN0Q7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLE9BQU8sT0FBTyxVQUFVLFlBQVksc0JBQXNCLEtBQUssS0FBSyxPQUFPLFNBQVMsZUFBZSxpQkFBaUIsUUFBUSxPQUFPLGdCQUFnQixlQUFlLGlCQUFpQixlQUFlLE9BQU8sZ0JBQWdCLGVBQWUsWUFBWSxPQUFPLEtBQUssS0FBSyxPQUFPLG9CQUFvQixlQUFlLGlCQUFpQjtBQUNsVTtBQUNBLFNBQVMsV0FBVyxLQUFLLFNBQVM7Q0FDaEMsSUFBSSxDQUFDLFFBQVEsU0FDWDtDQUVGLE1BQU0sY0FBYyxzQkFBc0IsUUFBUSxJQUFJO0NBQ3RELE9BQU8sUUFBUSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFdBQVc7RUFDeEQsSUFBSSxJQUFJLFlBQVksTUFBTSxrQkFBa0IsQ0FBQyxhQUMzQyxJQUFJLGlCQUFpQixLQUFLLE9BQU8sS0FBSyxDQUFDO0NBRTNDLENBQUM7QUFDSDtBQUNBLFNBQVMsbUJBQW1CLEtBQUssUUFBUTtDQUN2QyxJQUFJLENBQUMsVUFBVSxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsV0FBVyxHQUM1QyxPQUFPO0NBRVQsTUFBTSxDQUFDLGlCQUFpQix5QkFBeUIsT0FBTyxLQUFLLE1BQU07Q0FDbkUsT0FBTztBQUNUO0FBQ0EsSUFBSSxnQkFBZ0IsTUFBTTtDQUN4QjtDQUNBO0NBQ0EsWUFBWSxVQUFVLENBQUMsR0FBRztFQUN4QixLQUFLLGlCQUFpQixRQUFRLGtCQUFrQjtFQUNoRCxLQUFLLGlCQUFpQixRQUFRLGtCQUFrQjtDQUNsRDtDQUNBLE1BQU0sUUFBUSxTQUFTO0VBQ3JCLE1BQU0sa0JBQWtCLE1BQU0sYUFBYSxlQUFlLE9BQU87RUFDakUsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVSxlQUFlO0dBQ3JELE9BQU8sTUFBTSxhQUFhLGdCQUFnQixRQUFRO0VBQ3BELFNBQVMsT0FBTztHQUNkLElBQUksaUJBQWlCLHFCQUFxQixpQkFBaUIsb0JBQW9CLGlCQUFpQixvQkFDOUYsTUFBTSxhQUFhLGFBQWEsS0FBSztHQUV2QyxNQUFNO0VBQ1I7Q0FDRjtDQUNBLFVBQVUsU0FBUztFQUNqQixPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDdEMsTUFBTSxNQUFNLElBQUksZUFBZTtHQUMvQixNQUFNLE1BQU0sbUJBQW1CLFFBQVEsS0FBSyxRQUFRLE1BQU07R0FDMUQsSUFBSSxLQUFLLFFBQVEsT0FBTyxZQUFZLEdBQUcsS0FBSyxJQUFJO0dBQ2hELE1BQU0sWUFBWSxVQUFVLEtBQUssY0FBYztHQUMvQyxJQUFJLFdBQ0YsSUFBSSxpQkFBaUIsS0FBSyxnQkFBZ0IsU0FBUztHQUtyRCxJQUFJLENBSDJCLE9BQU8sS0FBSyxRQUFRLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUMvRCxRQUFRLElBQUksWUFBWSxNQUFNLGtCQUVQLEdBQ3hCLElBQUksaUJBQWlCLG9CQUFvQixnQkFBZ0I7R0FFM0QsSUFBSSxPQUFPO0dBQ1gsSUFBSSxRQUFRLFNBQVMsUUFBUSxRQUFRLFNBQVMsS0FBSyxHQUFHO0lBQ3BELElBQUksaUJBQWlCLFFBQVEsSUFBSSxHQUMvQixPQUFPLFFBQVE7U0FDVixJQUFJLE9BQU8sUUFBUSxTQUFTLFVBQVU7S0FDM0MsT0FBTyxLQUFLLFVBQVUsUUFBUSxJQUFJO0tBQ2xDLElBQUksQ0FBQyxRQUFRLFVBQVUsbUJBQW1CLENBQUMsUUFBUSxVQUFVLGlCQUMzRCxJQUFJLGlCQUFpQixnQkFBZ0Isa0JBQWtCO0lBRTNELE9BQ0UsT0FBTyxPQUFPLFFBQVEsSUFBSTtHQUU5QjtHQUNBLFdBQVcsS0FBSyxPQUFPO0dBQ3ZCLElBQUksUUFBUSxrQkFDVixJQUFJLE9BQU8sY0FBYyxVQUFVO0lBQ2pDLE1BQU0sWUFBWSxNQUFNLG1CQUFtQixNQUFNLFNBQVMsTUFBTSxRQUFRLEtBQUs7SUFDN0UsUUFBUSxpQkFBaUI7S0FDdkIsVUFBVTtLQUNWLFlBQVksWUFBWSxLQUFLLE1BQU0sWUFBWSxHQUFHLElBQUk7S0FDdEQsUUFBUSxNQUFNO0tBQ2QsT0FBTyxNQUFNLG1CQUFtQixNQUFNLFFBQVEsS0FBSztJQUNyRCxDQUFDO0dBQ0g7R0FFRixJQUFJLFFBQVEsUUFDVixRQUFRLE9BQU8saUJBQWlCLGVBQWUsSUFBSSxNQUFNLENBQUM7R0FFNUQsSUFBSSxnQkFBZ0IsT0FBTyxJQUFJLG1CQUFtQix5QkFBeUIsUUFBUSxHQUFHLENBQUM7R0FDdkYsSUFBSSxnQkFBZ0IsT0FBTyxJQUFJLGlCQUFpQixpQkFBaUIsUUFBUSxHQUFHLENBQUM7R0FDN0UsSUFBSSxlQUFlO0lBQ2pCLE1BQU0sV0FBVztLQUNmLFFBQVEsSUFBSTtLQUNaLE1BQU0sSUFBSTtLQUNWLFNBQVMsYUFBYSxHQUFHO0lBQzNCO0lBQ0EsSUFBSSxJQUFJLFVBQVUsS0FDaEIsT0FBTyxJQUFJLGtCQUFrQiw4QkFBOEIsSUFBSSxVQUFVLFVBQVUsUUFBUSxHQUFHLENBQUM7U0FFL0YsUUFBUSxRQUFRO0dBRXBCO0dBQ0EsSUFBSSxLQUFLLElBQUk7RUFDZixDQUFDO0NBQ0g7QUFDRjtBQUlBLElBQUksYUFBYSxJQUhPLGNBR1A7QUFDakIsU0FBUyxvQkFBb0IsUUFBUTtDQUNuQyxPQUFPLEVBQUUsYUFBYTtBQUN4QjtBQUNBLElBQUksT0FBTzs7OztDQUlULFlBQVk7RUFDVixPQUFPO0NBQ1Q7Ozs7Q0FJQSxVQUFVLGlCQUFpQjtFQUN6QixJQUFJLENBQUMsb0JBQW9CLGVBQWUsR0FBRztHQUN6QyxhQUFhO0dBQ2I7RUFDRjtFQUNBLGFBQWEsSUFBSSxjQUFjLGVBQWU7RUFDOUMsSUFBSSxnQkFBZ0IsZ0JBQ2xCLE9BQW1CLG1CQUFtQixnQkFBZ0IsY0FBYztFQUV0RSxJQUFJLGdCQUFnQixnQkFDbEIsT0FBbUIsbUJBQW1CLGdCQUFnQixjQUFjO0NBRXhFOzs7O0NBSUEsV0FBVyxhQUFhLFVBQVUsS0FBSyxZQUFZOzs7O0NBSW5ELFlBQVksYUFBYSxXQUFXLEtBQUssWUFBWTs7OztDQUlyRCxTQUFTLGFBQWEsUUFBUSxLQUFLLFlBQVk7Ozs7O0NBSy9DLGdCQUFnQixhQUFhLGVBQWUsS0FBSyxZQUFZOzs7OztDQUs3RCxpQkFBaUIsYUFBYSxnQkFBZ0IsS0FBSyxZQUFZOzs7OztDQUsvRCxjQUFjLGFBQWEsYUFBYSxLQUFLLFlBQVk7QUFDM0Q7QUFHQSxJQUFJLG9CQUFvQixNQUFNO0NBQzVCLGtCQUFrQixDQUFDO0NBQ25CLG1CQUFtQixDQUFDO0NBQ3BCLGVBQWUsU0FBUztFQUN0QixLQUFLLGdCQUFnQixLQUFLLE9BQU87RUFDakMsYUFBYTtHQUNYLEtBQUssa0JBQWtCLEtBQUssZ0JBQWdCLFFBQVEsTUFBTSxNQUFNLE9BQU87RUFDekU7Q0FDRjtDQUNBLGdCQUFnQixTQUFTO0VBQ3ZCLEtBQUssaUJBQWlCLEtBQUssT0FBTztFQUNsQyxhQUFhO0dBQ1gsS0FBSyxtQkFBbUIsS0FBSyxpQkFBaUIsUUFBUSxNQUFNLE1BQU0sT0FBTztFQUMzRTtDQUNGO0NBQ0EsTUFBTSxlQUFlLE9BQU8sU0FBUztFQUNuQyxJQUFJLFNBQVM7RUFDYixLQUFLLE1BQU0sV0FBVyxLQUFLLGlCQUN6QixTQUFTLE1BQU0sUUFBUSxPQUFPLE1BQU07RUFFdEMsT0FBTztDQUNUO0NBQ0EsTUFBTSxnQkFBZ0IsT0FBTyxVQUFVO0VBQ3JDLElBQUksU0FBUztFQUNiLEtBQUssTUFBTSxXQUFXLEtBQUssa0JBQ3pCLFNBQVMsTUFBTSxRQUFRLE9BQU8sTUFBTTtFQUV0QyxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQUksZUFBZSxJQUFJLGtCQUFrQjtBQUN6QyxTQUFTLHFCQUFxQjtDQUM1QixJQUFJLE9BQU8sV0FBVyxhQUNwQjtDQUdGLE9BQU8sMkJBQTJCO0FBQ3BDO0FBR0EsSUFBSSxnQkFBZ0IsTUFBTSxlQUFlO0NBQ3ZDLFlBQVksQ0FBQztDQUNiO0NBQ0EsWUFBWSxRQUFRO0VBQ2xCLElBQUksQ0FBQyxPQUFPLFVBQ1YsS0FBSyxTQUFTO09BQ1Q7R0FDTCxNQUFNLG1CQUFtQjtJQUN2QixVQUFVLEtBQUssYUFBYSxRQUFRLFVBQVU7SUFDOUMsZ0JBQWdCLEtBQUssYUFBYSxRQUFRLGdCQUFnQjtJQUMxRCxTQUFTLEtBQUssYUFBYSxRQUFRLFNBQVM7SUFDNUMsWUFBWSxLQUFLLGFBQWEsUUFBUSxZQUFZO0lBQ2xELFVBQVUsS0FBSyxhQUFhLFFBQVEsVUFBVTtJQUM5QyxVQUFVLEtBQUssYUFBYSxRQUFRLFVBQVU7SUFDOUMsV0FBVyxLQUFLLGFBQWEsUUFBUSxXQUFXO0lBQ2hELFNBQVMsS0FBSyxhQUFhLFFBQVEsU0FBUztJQUM1QyxpQkFBaUIsS0FBSyxhQUFhLFFBQVEsaUJBQWlCO0lBQzVELGdCQUFnQixLQUFLLGFBQWEsUUFBUSxnQkFBZ0I7SUFDMUQsU0FBUyxLQUFLLGFBQWEsUUFBUSxTQUFTO0lBQzVDLGVBQWUsS0FBSyxhQUFhLFFBQVEsZUFBZTtJQUN4RCxjQUFjLEtBQUssYUFBYSxRQUFRLGNBQWM7SUFDdEQsZUFBZSxLQUFLLGFBQWEsUUFBUSxlQUFlO0dBQzFEO0dBQ0EsS0FBSyxTQUFTO0lBQ1osR0FBRztJQUNILEdBQUc7SUFDSCxvQkFBb0IsT0FBTyw2QkFBNkIsQ0FDeEQ7SUFDQSxpQkFBaUIsT0FBTywwQkFBMEIsQ0FDbEQ7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxPQUFPLE9BQU8sUUFBUTtFQUNwQixPQUFPLElBQUksZUFBZSxNQUFNO0NBQ2xDO0NBQ0EsT0FBTztFQUNMLE9BQU8sS0FBSyxPQUFPLFdBQVcsUUFBUSxPQUFPLEtBQUssT0FBTztDQUMzRDtDQUNBLGNBQWM7RUFDWixPQUFPLEtBQUssT0FBTyxXQUFXLFFBQVEsS0FBSyxPQUFPLE9BQU8sQ0FBQztDQUM1RDtDQUNBLFlBQVk7RUFDVixPQUFPLEtBQUssT0FBTyxLQUFLLFNBQVMsS0FBSyxLQUFLLE9BQU8sT0FBTyxTQUFTLEtBQUssS0FBSyxPQUFPLE1BQU0sU0FBUztDQUNwRztDQUNBLGFBQWE7RUFDWCxPQUFPLEtBQUssT0FBTyxhQUFhO0NBQ2xDO0NBQ0EseUJBQXlCO0VBQ3ZCLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtDQUN2QztDQUNBLGdCQUFnQjtFQUNkLE9BQU8sS0FBSyxPQUFPLFNBQVM7Q0FDOUI7Q0FDQSxjQUFjLElBQUk7RUFDaEIsS0FBSyxPQUFPLGNBQWMsRUFDeEIsUUFBUSxHQUNWLENBQUM7Q0FDSDtDQUNBLGlCQUFpQjtFQUNmLEtBQUssT0FBTyxZQUFZO0VBQ3hCLEtBQUssT0FBTyxZQUFZO0VBQ3hCLEtBQUssT0FBTyxjQUFjO0NBQzVCO0NBQ0EsZ0JBQWdCLEVBQUUsWUFBWSxNQUFNLGNBQWMsU0FBUztFQUN6RCxLQUFLLE9BQU8sU0FBUztFQUNyQixLQUFLLE9BQU8sWUFBWTtFQUN4QixLQUFLLE9BQU8sWUFBWTtFQUN4QixLQUFLLE9BQU8sY0FBYztDQUM1QjtDQUNBLG9CQUFvQjtFQUNsQixPQUFPLEtBQUssT0FBTyxhQUFhLEtBQUssT0FBTztDQUM5QztDQUNBLFdBQVc7RUFDVCxLQUFLLE9BQU8sU0FBUyxLQUFLLE1BQU07Q0FDbEM7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxPQUFPLFFBQVEsS0FBSyxNQUFNO0NBQ2pDO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyxPQUFPLGNBQWMsS0FBSyxNQUFNO0NBQ3ZDO0NBQ0EsbUJBQW1CLFVBQVU7RUFDM0IsSUFBSSxLQUFLLE9BQU8sb0JBQ2QsS0FBSyxPQUFPLG1CQUFtQixRQUFRO0NBRTNDO0NBQ0EsZ0JBQWdCLE9BQU87RUFDckIsSUFBSSxLQUFLLE9BQU8saUJBQ2QsS0FBSyxPQUFPLGdCQUFnQixLQUFLO0NBRXJDO0NBQ0EsTUFBTTtFQUNKLE9BQU8sS0FBSztDQUNkO0NBQ0EsVUFBVTtFQUNSLE1BQU0sVUFBVSxFQUNkLEdBQUcsS0FBSyxPQUFPLFFBQ2pCO0VBQ0EsSUFBSSxLQUFLLFVBQVUsR0FDakIsUUFBUSxpQ0FBaUNBLE9BQUssSUFBSSxDQUFDLENBQUM7RUFFdEQsTUFBTSxPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUs7RUFDdEQsSUFBSSxLQUFLLFNBQVMsR0FDaEIsUUFBUSw0QkFBNEIsS0FBSyxLQUFLLEdBQUc7RUFFbkQsSUFBSSxLQUFLLE9BQU8sT0FBTyxTQUFTLEdBQzlCLFFBQVEsOEJBQThCLEtBQUssT0FBTyxPQUFPLEtBQUssR0FBRztFQUVuRSxJQUFJLEtBQUssT0FBTyxNQUFNLFNBQVMsR0FDN0IsUUFBUSxxQkFBcUIsS0FBSyxPQUFPLE1BQU0sS0FBSyxHQUFHO0VBRXpELElBQUksS0FBSyxPQUFPLFlBQVksS0FBSyxPQUFPLFNBQVMsU0FBUyxHQUN4RCxRQUFRLHlCQUF5QixLQUFLLE9BQU87RUFFL0MsT0FBTztDQUNUO0NBQ0EsbUJBQW1CLE9BQU87RUFDeEIsS0FBSyxPQUFPLGlCQUFpQixlQUFlLHNCQUFzQixLQUFLLE9BQU8sZ0JBQWdCLEtBQUs7RUFDbkcsS0FBSyxPQUFPLGdCQUFnQixlQUFlLHNCQUFzQixLQUFLLE9BQU8sZUFBZSxLQUFLO0NBQ25HO0NBQ0EsZUFBZTtFQUNiLEtBQUssVUFBVSxTQUFTLEVBQUUsTUFBTSxXQUFXO0dBQ3pDLEtBQUssT0FBTyxLQUFLLENBQUMsR0FBRyxJQUFJO0VBQzNCLENBQUM7Q0FDSDtDQUNBLE1BQU0sU0FBUztFQUNiLEtBQUssU0FBUztHQUNaLEdBQUcsS0FBSztHQUNSLEdBQUc7RUFDTDtDQUNGO0NBQ0EsYUFBYSxRQUFRLE1BQU07RUFDekIsUUFBUSxHQUFHLFNBQVM7R0FDbEIsS0FBSyxlQUFlLE1BQU0sSUFBSTtHQUM5QixPQUFPLEtBQUssQ0FBQyxHQUFHLElBQUk7RUFDdEI7Q0FDRjtDQUNBLGVBQWUsTUFBTSxNQUFNO0VBQ3pCLEtBQUssVUFBVSxLQUFLO0dBQUU7R0FBTTtFQUFLLENBQUM7Q0FDcEM7Q0FDQSxPQUFPLHNCQUFzQixPQUFPLE9BQU87RUFDekMsSUFBSSxPQUFPLFVBQVUsWUFDbkIsT0FBTyxNQUFNLEtBQUs7RUFFcEIsSUFBSSxVQUFVLFVBQ1osT0FBTyxPQUFPLEtBQUssTUFBTSxNQUFNLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO0VBRXhELE9BQU87Q0FDVDtBQUNGO0FBT0EsSUFBSSxpQkFBaUI7Q0FDbkIsb0JBQW9CLE1BQU07RUFDeEIsSUFBSSxPQUFPLFNBQVMsVUFDbEIsT0FBTyw4R0FBOEcsS0FBSyxVQUN4SCxJQUNGO0VBRUYsTUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0VBQzNDLE1BQU0sWUFBWTtFQUNsQixNQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxTQUFTLE1BQU0sRUFBRSxhQUFhLFVBQVUsTUFBTSxDQUFDO0VBQzNFLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtFQUM5QyxPQUFPLE1BQU0sa0JBQWtCO0VBQy9CLE9BQU8sTUFBTSxlQUFlO0VBQzVCLE9BQU8sTUFBTSxRQUFRO0VBQ3JCLE9BQU8sTUFBTSxTQUFTO0VBQ3RCLE9BQU8sYUFBYSxXQUFXLGVBQWU7RUFDOUMsT0FBTztHQUFFO0dBQVEsTUFBTTtFQUFNO0NBQy9CO0NBQ0EsS0FBSyxNQUFNO0VBQ1QsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVLEtBQUssb0JBQW9CLElBQUk7RUFDN0QsT0FBTyxNQUFNLFlBQVk7RUFDekIsT0FBTyxNQUFNLFVBQVU7RUFDdkIsTUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0VBQzlDLE9BQU8sS0FBSztFQUNaLE9BQU8sT0FBTyxPQUFPLE9BQU87R0FDMUIsT0FBTztHQUNQLFFBQVE7R0FDUixTQUFTO0dBQ1QsUUFBUTtHQUNSLFFBQVE7R0FDUixpQkFBaUI7RUFDbkIsQ0FBQztFQUNELE1BQU0scUJBQXFCLFNBQVMsY0FBYyxPQUFPO0VBQ3pELG1CQUFtQixjQUFjOzs7Ozs7Ozs7RUFTakMsTUFBTSxRQUFRTCxTQUFPLElBQUksT0FBTztFQUNoQyxJQUFJLE9BQ0YsbUJBQW1CLFFBQVE7RUFFN0IsU0FBUyxLQUFLLFlBQVksa0JBQWtCO0VBQzVDLE9BQU8saUJBQWlCLFVBQVUsVUFBVTtHQUMxQyxJQUFJLE1BQU0sV0FBVyxRQUNuQixPQUFPLE1BQU07RUFFakIsQ0FBQztFQUNELE9BQU8saUJBQWlCLGVBQWU7R0FDckMsbUJBQW1CLE9BQU87R0FDMUIsT0FBTyxPQUFPO0VBQ2hCLENBQUM7RUFDRCxPQUFPLFlBQVksTUFBTTtFQUN6QixTQUFTLEtBQUssUUFBUSxNQUFNO0VBQzVCLE9BQU8sVUFBVTtFQUNqQixPQUFPLE1BQU07RUFDYixPQUFPLFNBQVMsTUFBTTtDQUN4QjtBQUNGO0FBR0EsSUFBSSxtQkFBbUIsTUFBTSxjQUFjO0NBQ3pDLE9BQU8sU0FBUyxhQUFhLEtBQUssV0FBVyxHQUFHLFVBQVUsRUFBRTtBQUM5RDtBQUNBLElBQUksNkJBQTZCLE9BQU8sU0FBUztDQUMvQyxNQUFNLEVBQUUsTUFBTSxXQUFXO0NBQ3pCLElBQUksS0FBSyxXQUFXLEtBQUssT0FBTyxXQUFXLEdBQ3pDLE9BQU87Q0FFVCxJQUFJLEtBQUssU0FBUyxLQUFLLENBQUMsS0FBSyxNQUFNLGNBQWMsZ0JBQWdCLE1BQU0sU0FBUyxDQUFDLEdBQy9FLE9BQU87Q0FFVCxJQUFJLE9BQU8sU0FBUyxLQUFLLE9BQU8sTUFBTSxjQUFjLGdCQUFnQixNQUFNLFNBQVMsQ0FBQyxHQUNsRixPQUFPO0NBRVQsT0FBTztBQUNUO0FBQ0EsSUFBSSxrQ0FBa0MsT0FBTyxVQUFVO0NBQ3JELE9BQU8sTUFBTSxNQUFNLFNBQVMsMEJBQTBCLE9BQU8sSUFBSSxDQUFDO0FBQ3BFO0FBR0EsSUFBSSxTQUFTLElBQUksTUFBTTtBQUN2QixJQUFJLFdBQVcsTUFBTSxVQUFVO0NBQzdCLFlBQVksZUFBZSxVQUFVLGlCQUFpQjtFQUNwRCxLQUFLLGdCQUFnQjtFQUNyQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxrQkFBa0I7Q0FDekI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxnQkFBZ0I7Q0FDaEIsWUFBWTtDQUNaLE9BQU8sT0FBTyxRQUFRLFVBQVUsaUJBQWlCO0VBQy9DLE9BQU8sSUFBSSxVQUFVLFFBQVEsVUFBVSxlQUFlO0NBQ3hEO0NBQ0EsY0FBYztFQUNaLE9BQU8sS0FBSztDQUNkO0NBQ0EsTUFBTSxpQkFBaUI7RUFDckIsSUFBSSxxQkFBcUIsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLEtBQUssT0FBTyxRQUFRLEdBQ3BFLEtBQUssT0FBTztDQUVoQjtDQUNBLE1BQU0sU0FBUztFQUNiLE9BQU8sT0FBTyxVQUFVLEtBQUssUUFBUSxDQUFDO0NBQ3hDO0NBQ0EsTUFBTSxVQUFVO0VBQ2QsSUFBSSxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsVUFBVTtHQUNyQyxLQUFLLGdCQUFnQjtHQUNyQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsV0FBVztHQUNwQyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsYUFBYSxLQUFLLFVBQVUsS0FBSyxjQUFjLElBQUksQ0FBQztHQUM3RSxvQkFBb0IsS0FBSyxVQUFVLEtBQUssY0FBYyxJQUFJLENBQUM7R0FDM0QsT0FBTyxRQUFRLFFBQVE7RUFDekI7RUFDQSxLQUFLLGNBQWMsYUFBYTtFQUNoQyxLQUFLLFlBQVk7RUFDakIsSUFBSSxDQUFDLEtBQUssa0JBQWtCLEdBQzFCLE9BQU8sS0FBSyx5QkFBeUI7RUFFdkMsSUFBSSxLQUFLLGdCQUFnQixHQUFHO0dBQzFCLE1BQU0sV0FBVztJQUNmLEdBQUcsS0FBSztJQUNSLE1BQU0sS0FBSyxvQkFBb0IsS0FBSyxTQUFTLElBQUk7R0FDbkQ7R0FDQSxJQUFJLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxnQkFBZ0IsUUFBUSxNQUFNLE9BQ3pEO0dBRUYsSUFBSSxDQUFDLHVCQUF1QixRQUFRLEdBQ2xDO0VBRUo7RUFDQSxNQUFNLFFBQVEsYUFBYTtFQUMzQixRQUFRLGNBQWMsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDO0VBQy9DLE1BQU0sS0FBSyxRQUFRO0VBQ25CLE1BQU0sRUFBRSxVQUFVSyxPQUFLLElBQUk7RUFDM0IsSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsU0FBUyxLQUFLLENBQUMsS0FBSyxjQUFjLHVCQUF1QixHQUFHO0dBQ2pGLGVBQWUsS0FBSztHQUNwQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsUUFBUSxLQUFLO0VBQ3hDO0VBQ0EsTUFBTSxTQUFTQSxPQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sVUFBVSxDQUFDO0VBQzNDLElBQUksT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVMsR0FBRztHQUNsQyxNQUFNLGVBQWUsS0FBSyxnQkFBZ0IsTUFBTTtHQUNoRCxlQUFlLGNBQWM7SUFBRSxNQUFNQSxPQUFLLElBQUk7SUFBRyxTQUFTLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQztHQUFHLENBQUM7R0FDdkYsT0FBTyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsUUFBUSxZQUFZO0VBQ3REO0VBQ0EsT0FBTyxpQkFBaUIsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUM7RUFDMUUsSUFBSSxDQUFDLEtBQUssZUFDUixPQUFPLE1BQU1BLE9BQUssSUFBSSxDQUFDLENBQUMsR0FBRztFQUU3QixpQkFBaUJBLE9BQUssSUFBSSxHQUFHLEVBQUUsU0FBUyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO0VBQ3JFLE1BQU0sS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLFVBQVVBLE9BQUssSUFBSSxDQUFDO0VBQ25ELFFBQVEsY0FBYztDQUN4QjtDQUNBLFlBQVksUUFBUTtFQUNsQixLQUFLLGNBQWMsTUFBTSxNQUFNO0NBQ2pDO0NBQ0Esa0JBQWtCO0VBQ2hCLE1BQU0sT0FBTyxLQUFLLG9CQUFvQixLQUFLLFNBQVMsSUFBSTtFQUN4RCxJQUFJLE9BQU8sU0FBUyxVQUNsQixPQUFPLEtBQUssU0FBUyxPQUFPO0dBQUUsR0FBRztHQUFNLE9BQU8sS0FBSyxTQUFTLENBQUM7R0FBRyxjQUFjLEtBQUssZ0JBQWdCLENBQUM7RUFBRTtFQUV4RyxPQUFPLEtBQUssU0FBUyxPQUFPO0NBQzlCO0NBQ0EsTUFBTSwyQkFBMkI7RUFDL0IsSUFBSSxLQUFLLGtCQUFrQixHQUFHO0dBQzVCLE9BQU8sTUFBTSxLQUFLLFVBQVUsb0JBQW9CLEdBQUc7SUFDakQsR0FBRyxLQUFLLGNBQWMsSUFBSTtJQUMxQixRQUFRO0lBQ1IsTUFBTSxDQUFDO0dBQ1QsQ0FBQztHQUNEO0VBQ0Y7RUFDQSxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7R0FDMUIsTUFBTSxjQUFjLFVBQVUsS0FBSyxVQUFVLG9CQUFvQixDQUFDO0dBQ2xFLGlCQUFpQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsS0FBSyxXQUFXO0dBQzFELE9BQU8sS0FBSyxjQUFjLFdBQVc7RUFDdkM7RUFDQSxNQUFNLFdBQVc7R0FDZixHQUFHLEtBQUs7R0FDUixNQUFNLEtBQUssb0JBQW9CLEtBQUssU0FBUyxJQUFJO0VBQ25EO0VBQ0EsSUFBSSxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLFFBQVEsTUFBTSxPQUN6RDtFQUVGLElBQUksdUJBQXVCLFFBQVEsR0FDakMsT0FBTyxlQUFlLEtBQUssU0FBUyxJQUFJO0NBRTVDO0NBQ0Esb0JBQW9CO0VBQ2xCLE9BQU8sS0FBSyxVQUFVLFdBQVc7Q0FDbkM7Q0FDQSxrQkFBa0I7RUFDaEIsT0FBTyxLQUFLLFNBQVMsVUFBVTtDQUNqQztDQUNBLFVBQVUsU0FBUztFQUNqQixPQUFPLEtBQUssU0FBUyxXQUFXO0NBQ2xDO0NBQ0EsVUFBVSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxTQUFTLFFBQVE7Q0FDL0I7Q0FDQSxVQUFVLFFBQVE7RUFDaEIsT0FBTyxLQUFLLFVBQVUsTUFBTSxNQUFNLEtBQUs7Q0FDekM7Q0FDQSxvQkFBb0I7RUFDbEIsT0FBTyxLQUFLLFVBQVUsR0FBRyxLQUFLLEtBQUssVUFBVSxvQkFBb0I7Q0FDbkU7Q0FDQSxrQkFBa0I7RUFDaEIsT0FBTyxLQUFLLFVBQVUsR0FBRyxLQUFLLEtBQUssVUFBVSxvQkFBb0I7Q0FDbkU7Ozs7Q0FJQSxjQUFjLEtBQUs7RUFDakIsSUFBSTtHQUNGLElBQUksT0FBTyxXQUFXLGFBQ3BCO0dBRUYsTUFBTSxrQkFBa0IsS0FBSyxVQUFVLG1CQUFtQjtHQUMxRCxNQUFNLGdCQUFnQixDQUFDLENBQUMsbUJBQW1CLG9CQUFvQkEsT0FBSyxJQUFJLENBQUMsQ0FBQztHQUMxRSxJQUFJLENBQUMsa0JBQWtCLEtBQUssYUFBYSxHQUN2QztHQUVGLElBQUksaUJBQWlCLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxPQUM1QztHQUVGLGVBQWUsSUFBSSxlQUFlLGtCQUFrQixFQUNsRCxnQkFBZ0IsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLG1CQUFtQixLQUM5RCxDQUFDO0dBQ0QsSUFBSSxxQkFBcUIsT0FBTyxVQUFVLEdBQUcsR0FDM0MsT0FBTyxTQUFTLE9BQU87UUFFdkIsT0FBTyxTQUFTLE9BQU8sSUFBSTtFQUUvQixTQUFTLE9BQU87R0FDZCxPQUFPO0VBQ1Q7Q0FDRjtDQUNBLE1BQU0sVUFBVTtFQUNkLE1BQU0sZUFBZSxLQUFLLGdCQUFnQjtFQUMxQyxJQUFJLENBQUMsS0FBSyxjQUFjLFlBQVksR0FDbEMsT0FBTyxRQUFRLFFBQVE7RUFFekIsS0FBSyxXQUFXLE1BQU0sYUFBYSxnQkFBZ0IsS0FBSyxjQUFjLElBQUksR0FBRyxLQUFLLFFBQVE7RUFDMUYsS0FBSyxXQUFXLFlBQVk7RUFDNUIsT0FBSywyQkFBMkIsWUFBWTtFQUM1QyxLQUFLLHdCQUF3QixZQUFZO0VBQ3pDLEtBQUssbUJBQW1CLFlBQVk7RUFDcEMsTUFBTSxLQUFLLG1CQUFtQixZQUFZO0VBQzFDLEtBQUssY0FBYyxtQkFBbUIsWUFBWTtFQUNsRCxhQUFhLE1BQU0sUUFBUSxjQUFjQSxPQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxRQUFRLFlBQVk7RUFDbkYsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLGVBQWUsWUFBWTtFQUNwRCxzQkFBc0IsWUFBWTtFQUNsQyxPQUFPQSxPQUFLLElBQUksY0FBYztHQUM1QixTQUFTLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQztHQUNsQyxnQkFBZ0IsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDO0dBQ3pDLGVBQWUsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDO0dBQ3hDLGdCQUFnQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUM7R0FDekMsUUFBUSxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUM7R0FDakMsU0FBUyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUM7RUFDcEMsQ0FBQztDQUNIO0NBQ0Esb0JBQW9CLFVBQVU7RUFDNUIsSUFBSSxPQUFPLGFBQWEsVUFDdEIsT0FBTztFQUVULElBQUk7R0FDRixPQUFPLEtBQUssTUFBTSxRQUFRO0VBQzVCLFNBQVMsT0FBTztHQUNkLE9BQU87RUFDVDtDQUNGO0NBQ0EsY0FBYyxjQUFjO0VBQzFCLElBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsT0FDNUIsT0FBTztFQUVULElBQUksS0FBSyxnQkFBZ0IsY0FBYyxhQUFhLFdBQ2xELE9BQU87RUFFVCxJQUFJLEtBQUssZ0JBQWdCLGNBQWNBLE9BQUssSUFBSSxDQUFDLENBQUMsV0FDaEQsT0FBTztFQUVULE1BQU0saUJBQWlCLFVBQVUsS0FBSyxnQkFBZ0IsR0FBRztFQUN6RCxNQUFNLGlCQUFpQixVQUFVQSxPQUFLLElBQUksQ0FBQyxDQUFDLEdBQUc7RUFDL0MsT0FBTyxlQUFlLFdBQVcsZUFBZSxVQUFVLGVBQWUsYUFBYSxlQUFlO0NBQ3ZHO0NBQ0EsUUFBUSxjQUFjO0VBQ3BCLE1BQU0sY0FBYyxVQUFVLGFBQWEsR0FBRztFQUM5QyxJQUFJLGFBQWEsa0JBQ2YsWUFBWSxPQUFPLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxJQUFJO09BRWhELGlCQUFpQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsS0FBSyxXQUFXO0VBRTVELE9BQU8sWUFBWSxXQUFXLFlBQVksU0FBUyxZQUFZO0NBQ2pFO0NBQ0Esd0JBQXdCLGNBQWM7RUFDcEMsSUFBSSxDQUFDLE9BQU8scUJBQXFCLEdBQy9CO0VBRUYsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLGFBQWEsS0FBSyxHQUM5QyxJQUFJQSxPQUFLLFlBQVksR0FBRyxHQUFHO0dBQ3pCLE9BQUssZUFBZSxLQUFLLGFBQWEsTUFBTSxJQUFJO0dBQ2hELGFBQWEsTUFBTSxPQUFPQSxPQUFLLElBQUksQ0FBQyxDQUFDLE1BQU07RUFDN0M7Q0FFSjtDQUNBLG1CQUFtQixjQUFjO0VBQy9CLElBQUksYUFBYSxjQUFjQSxPQUFLLElBQUksQ0FBQyxDQUFDLFdBQ3hDO0VBRUYsTUFBTSxtQkFBbUJBLE9BQUssSUFBSSxDQUFDLENBQUM7RUFDcEMsT0FBTyxRQUFRLGFBQWEsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVztHQUMzRCxJQUFJRyxRQUFTLE9BQU8saUJBQWlCLElBQUksR0FDdkMsYUFBYSxNQUFNLE9BQU8saUJBQWlCO0VBRS9DLENBQUM7Q0FDSDtDQUNBLFdBQVcsY0FBYztFQUN2QixJQUFJLENBQUMsS0FBSyxjQUFjLFVBQVUsS0FBSyxhQUFhLGNBQWNILE9BQUssSUFBSSxDQUFDLENBQUMsV0FDM0U7RUFFRixNQUFNLGdCQUFnQixhQUFhLGNBQWMsQ0FBQztFQUNsRCxNQUFNLGlCQUFpQixhQUFhLGdCQUFnQixDQUFDO0VBQ3JELE1BQU0sbUJBQW1CLGFBQWEsa0JBQWtCLENBQUM7RUFDekQsTUFBTSxlQUFlLGFBQWEsZ0JBQWdCLENBQUM7RUFDbkQsTUFBTSxhQUFhLE1BQU0saUJBQWlCO0dBQ3hDLE1BQU0sY0FBY0ksSUFBS0osT0FBSyxJQUFJLENBQUMsQ0FBQyxPQUFPLElBQUk7R0FDL0MsTUFBTSxlQUFlSSxJQUFLLGFBQWEsT0FBTyxJQUFJO0dBQ2xELElBQUksTUFBTSxRQUFRLFlBQVksR0FBRztJQUMvQixNQUFNLFdBQVcsS0FBSyxrQkFDcEIsZUFBZSxDQUFDLEdBQ2hCLGNBQ0EsTUFDQSxjQUNBLFlBQ0Y7SUFDQSxJQUFLLGFBQWEsT0FBTyxNQUFNLFFBQVE7R0FDekMsT0FBTyxJQUFJLE9BQU8saUJBQWlCLFlBQVksaUJBQWlCLE1BQU07SUFDcEUsTUFBTSxZQUFZO0tBQ2hCLEdBQUcsZUFBZSxDQUFDO0tBQ25CLEdBQUc7SUFDTDtJQUNBLElBQUssYUFBYSxPQUFPLE1BQU0sU0FBUztHQUMxQztFQUNGO0VBQ0EsY0FBYyxTQUFTLFNBQVMsVUFBVSxNQUFNLElBQUksQ0FBQztFQUNyRCxlQUFlLFNBQVMsU0FBUyxVQUFVLE1BQU0sS0FBSyxDQUFDO0VBQ3ZELGlCQUFpQixTQUFTLFNBQVM7R0FDakMsTUFBTSxjQUFjQSxJQUFLSixPQUFLLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSTtHQUMvQyxNQUFNLGVBQWVJLElBQUssYUFBYSxPQUFPLElBQUk7R0FDbEQsTUFBTSxhQUFhLFFBQVEsUUFBUSxjQUFjO0lBQy9DLElBQUksTUFBTSxRQUFRLE1BQU0sR0FDdEIsT0FBTyxLQUFLLGtCQUFrQixRQUFRLFFBQVEsV0FBVyxZQUFZO0lBRXZFLElBQUksT0FBTyxXQUFXLFlBQVksV0FBVyxNQUMzQyxPQUFPLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxRQUN4QixLQUFLLFFBQVE7S0FDWixJQUFJLE9BQU8sVUFBVSxTQUFTLE9BQU8sT0FBTyxLQUFLLEdBQUcsT0FBTyxNQUFNLEdBQUcsVUFBVSxHQUFHLEtBQUs7S0FDdEYsT0FBTztJQUNULEdBQ0EsRUFBRSxHQUFHLE9BQU8sQ0FDZDtJQUVGLE9BQU87R0FDVDtHQUNBLElBQUssYUFBYSxPQUFPLE1BQU0sVUFBVSxhQUFhLGNBQWMsSUFBSSxDQUFDO0VBQzNFLENBQUM7RUFDRCxNQUFNLGdCQUFnQixJQUFJLElBQ3hCLENBQUMsR0FBRyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQzlJO0VBQ0EsS0FBSyxNQUFNLE9BQU8sZUFBZTtHQUMvQixNQUFNLGVBQWVKLE9BQUssSUFBSSxDQUFDLENBQUMsTUFBTTtHQUN0QyxJQUFJLEtBQUssU0FBUyxZQUFZLEtBQUssS0FBSyxTQUFTLGFBQWEsTUFBTSxJQUFJLEdBQ3RFLGFBQWEsTUFBTSxPQUFPLEtBQUssaUJBQWlCLGNBQWMsYUFBYSxNQUFNLElBQUk7RUFFekY7RUFDQSxhQUFhLFFBQVE7R0FBRSxHQUFHQSxPQUFLLElBQUksQ0FBQyxDQUFDO0dBQU8sR0FBRyxhQUFhO0VBQU07RUFDbEUsSUFBSSxLQUFLLHFCQUFxQixZQUFZLEdBQ3hDLGFBQWEsTUFBTSxTQUFTQSxPQUFLLElBQUksQ0FBQyxDQUFDLE1BQU07RUFFL0MsSUFBSUEsT0FBSyxJQUFJLENBQUMsQ0FBQyxhQUNiLGFBQWEsY0FBYztHQUN6QixHQUFHQSxPQUFLLElBQUksQ0FBQyxDQUFDLGVBQWUsQ0FBQztHQUM5QixHQUFHLGFBQWEsZUFBZSxDQUFDO0VBQ2xDO0VBRUYsSUFBSUEsT0FBSyxhQUFhLEdBQ3BCLGFBQWEsWUFBWTtHQUN2QixHQUFHQSxPQUFLLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQztHQUM1QixHQUFHLGFBQWEsYUFBYSxDQUFDO0VBQ2hDO0VBRUYsSUFBSSxLQUFLLGNBQWMsdUJBQXVCLEdBQzVDLGFBQWEsUUFBUSxFQUFFLEdBQUdBLE9BQUssSUFBSSxDQUFDLENBQUMsTUFBTTtFQUU3QyxNQUFNLDBCQUEwQkEsT0FBSyxJQUFJLENBQUMsQ0FBQztFQUMzQyxJQUFJLDJCQUEyQixPQUFPLEtBQUssdUJBQXVCLENBQUMsQ0FBQyxTQUFTLEdBQzNFLGFBQWEsdUJBQXVCO0VBRXRDLGFBQWEsZUFBZSxLQUFLLGtCQUFrQixZQUFZO0NBQ2pFO0NBQ0Esa0JBQWtCLGNBQWM7RUFDOUIsTUFBTSxpQkFBaUJBLE9BQUssSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUM7RUFDbkQsTUFBTSxrQkFBa0IsYUFBYSxnQkFBZ0IsQ0FBQztFQUN0RCxNQUFNLGFBQWEsSUFBSSxJQUNyQixlQUFlLFFBQVEsU0FBUyxDQUFDLDBCQUEwQixLQUFLLGNBQWMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUM1RjtFQUNBLGdCQUFnQixTQUFTLFNBQVMsV0FBVyxJQUFJLElBQUksQ0FBQztFQUN0RCxPQUFPLE1BQU0sS0FBSyxVQUFVO0NBQzlCOzs7Ozs7O0NBT0EscUJBQXFCLGNBQWM7RUFDakMsSUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxnQkFDNUIsT0FBTztFQUVULE1BQU0sZ0JBQWdCQSxPQUFLLElBQUksQ0FBQyxDQUFDLE1BQU07RUFDdkMsSUFBSSxDQUFDLGlCQUFpQixPQUFPLEtBQUssYUFBYSxDQUFDLENBQUMsV0FBVyxHQUMxRCxPQUFPO0VBRVQsTUFBTSxpQkFBaUIsYUFBYSxNQUFNO0VBQzFDLElBQUksa0JBQWtCLE9BQU8sS0FBSyxjQUFjLENBQUMsQ0FBQyxTQUFTLEdBQ3pELE9BQU87RUFFVCxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLE1BQU07RUFDYixPQUFPLFFBQVEsT0FBTyxTQUFTLFlBQVksQ0FBQyxNQUFNLFFBQVEsSUFBSTtDQUNoRTtDQUNBLGlCQUFpQixRQUFRLFFBQVE7RUFDL0IsTUFBTSxTQUFTLEVBQUUsR0FBRyxPQUFPO0VBQzNCLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNLEdBQUc7R0FDckMsTUFBTSxjQUFjLE9BQU87R0FDM0IsTUFBTSxjQUFjLE9BQU87R0FDM0IsSUFBSSxLQUFLLFNBQVMsV0FBVyxLQUFLLEtBQUssU0FBUyxXQUFXLEdBQ3pELE9BQU8sT0FBTyxLQUFLLGlCQUFpQixhQUFhLFdBQVc7UUFFNUQsT0FBTyxPQUFPO0VBRWxCO0VBQ0EsT0FBTztDQUNUO0NBQ0Esa0JBQWtCLGVBQWUsVUFBVSxXQUFXLGNBQWMsZUFBZSxNQUFNO0VBQ3ZGLE1BQU0sUUFBUSxNQUFNLFFBQVEsYUFBYSxJQUFJLGdCQUFnQixDQUFDO0VBQzlELE1BQU0sY0FBYyxhQUFhLE1BQU0sUUFBUTtHQUU3QyxPQURnQixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FDcEMsTUFBTTtFQUNyQixDQUFDO0VBQ0QsSUFBSSxDQUFDLGFBQ0gsT0FBTyxlQUFlLENBQUMsR0FBRyxPQUFPLEdBQUcsUUFBUSxJQUFJLENBQUMsR0FBRyxVQUFVLEdBQUcsS0FBSztFQUV4RSxNQUFNLGlCQUFpQixZQUFZLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLO0VBQ3ZELE1BQU0sOEJBQThCLElBQUksSUFBSTtFQUM1QyxTQUFTLFNBQVMsU0FBUztHQUN6QixJQUFJLEtBQUssa0JBQWtCLE1BQU0sY0FBYyxHQUM3QyxZQUFZLElBQUksS0FBSyxpQkFBaUIsSUFBSTtFQUU5QyxDQUFDO0VBQ0QsT0FBTyxlQUFlLEtBQUssbUJBQW1CLE9BQU8sVUFBVSxhQUFhLGNBQWMsSUFBSSxLQUFLLG9CQUFvQixPQUFPLFVBQVUsYUFBYSxjQUFjO0NBQ3JLO0NBQ0EsbUJBQW1CLGVBQWUsVUFBVSxhQUFhLGdCQUFnQjtFQUN2RSxNQUFNLGtCQUFrQixjQUFjLEtBQUssU0FBUztHQUNsRCxJQUFJLEtBQUssa0JBQWtCLE1BQU0sY0FBYyxLQUFLLFlBQVksSUFBSSxLQUFLLGVBQWUsR0FDdEYsT0FBTyxZQUFZLElBQUksS0FBSyxlQUFlO0dBRTdDLE9BQU87RUFDVCxDQUFDO0VBQ0QsTUFBTSxnQkFBZ0IsU0FBUyxRQUFRLFNBQVM7R0FDOUMsSUFBSSxDQUFDLEtBQUssa0JBQWtCLE1BQU0sY0FBYyxHQUM5QyxPQUFPO0dBRVQsT0FBTyxDQUFDLGNBQWMsTUFDbkIsYUFBYSxLQUFLLGtCQUFrQixVQUFVLGNBQWMsS0FBSyxTQUFTLG9CQUFvQixLQUFLLGVBQ3RHO0VBQ0YsQ0FBQztFQUNELE9BQU8sQ0FBQyxHQUFHLGlCQUFpQixHQUFHLGFBQWE7Q0FDOUM7Q0FDQSxvQkFBb0IsZUFBZSxVQUFVLGFBQWEsZ0JBQWdCO0VBQ3hFLE1BQU0sb0JBQW9CLGNBQWMsUUFBUSxTQUFTO0dBQ3ZELElBQUksS0FBSyxrQkFBa0IsTUFBTSxjQUFjLEdBQzdDLE9BQU8sQ0FBQyxZQUFZLElBQUksS0FBSyxlQUFlO0dBRTlDLE9BQU87RUFDVCxDQUFDO0VBQ0QsT0FBTyxDQUFDLEdBQUcsVUFBVSxHQUFHLGlCQUFpQjtDQUMzQztDQUNBLGtCQUFrQixNQUFNLFVBQVU7RUFDaEMsT0FBTyxRQUFRLE9BQU8sU0FBUyxZQUFZLFlBQVk7Q0FDekQ7Q0FDQSxNQUFNLG1CQUFtQixjQUFjO0VBQ3JDLE1BQU0sa0JBQWtCLE1BQU0sUUFBUSxTQUFTLFFBQVEsaUJBQWlCLENBQUMsQ0FBQztFQUMxRSxJQUFJLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsbUJBQW1CLGFBQWEsY0FBY0EsT0FBSyxJQUFJLENBQUMsQ0FBQyxXQUNyRyxhQUFhLGtCQUFrQjtDQUVuQztDQUNBLGdCQUFnQixRQUFRO0VBQ3RCLElBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsVUFDNUIsT0FBTztFQUVULE9BQU8sT0FBTyxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsWUFBWSxPQUFPLENBQUM7Q0FDN0Q7QUFDRjtBQUdBLElBQUksVUFBVSxNQUFNLFNBQVM7Q0FDM0IsWUFBWSxRQUFRLE9BQU8sRUFBRSxhQUFhLFVBQVUsQ0FBQyxHQUFHO0VBQ3RELEtBQUssT0FBTztFQUNaLEtBQUssZ0JBQWdCLGNBQWMsT0FBTyxNQUFNO0VBQ2hELEtBQUssY0FBYyxJQUFJLGdCQUFnQjtFQUN2QyxLQUFLLGFBQWE7Q0FDcEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLHFCQUFxQjtDQUNyQjtDQUNBLE9BQU8sT0FBTyxRQUFRLE9BQU8sU0FBUztFQUNwQyxPQUFPLElBQUksU0FBUyxRQUFRLE9BQU8sT0FBTztDQUM1QztDQUNBLGFBQWE7RUFDWCxPQUFPLEtBQUssY0FBYyxXQUFXO0NBQ3ZDO0NBQ0EsU0FBUztFQUNQLE9BQU8sS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDO0NBQ2xDO0NBQ0EsZUFBZTtFQUNiLE9BQU8sS0FBSztDQUNkO0NBQ0Esc0JBQXNCO0VBQ3BCLE9BQU8sS0FBSyxhQUFhLE1BQU0sQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFNBQVMsWUFBWTtDQUM5RTtDQUNBLE1BQU0sT0FBTztFQUNYLEtBQUssY0FBYyxvQkFBb0I7R0FDckMsSUFBSSxLQUFLLFVBQ1A7R0FFRixLQUFLLE9BQU8sRUFBRSxXQUFXLEtBQUssQ0FBQztFQUNqQyxDQUFDO0VBQ0QsZUFBZSxLQUFLLGNBQWMsSUFBSSxDQUFDO0VBQ3ZDLEtBQUssY0FBYyxRQUFRO0VBQzNCLElBQUksS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLFVBQVU7R0FDckMsS0FBSyxjQUFjLGNBQWM7R0FDakMscUJBQXFCLEtBQUssY0FBYyxJQUFJLENBQUM7RUFDL0M7RUFDQSxNQUFNLHFCQUFxQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUM7RUFDcEQsTUFBTSxVQUFVO0dBQ2QsUUFBUSxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUM7R0FDakMsS0FBSyxlQUFlLEtBQUssY0FBYyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztHQUNsRCxNQUFNLEtBQUssY0FBYyxLQUFLO0dBQzlCLFFBQVEsS0FBSyxZQUFZO0dBQ3pCLFNBQVMsS0FBSyxXQUFXO0dBQ3pCLGtCQUFrQixLQUFLLFdBQVcsS0FBSyxJQUFJO0VBQzdDO0VBQ0EsTUFBTSxrQkFBa0IsTUFBTSxhQUFhLGVBQWUsS0FBSyxjQUFjLElBQUksR0FBRyxPQUFPO0VBQzNGLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRLGVBQWUsQ0FBQyxDQUFDLE1BQU0sYUFBYTtHQUNsRSxLQUFLLFdBQVcsU0FBUyxPQUFPLEtBQUssZUFBZSxVQUFVLEtBQUssSUFBSTtHQUN2RSxPQUFPLEtBQUssU0FBUyxPQUFPO0VBQzlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUNsQixJQUFJLGlCQUFpQixtQkFBbUI7SUFDdEMsS0FBSyxXQUFXLFNBQVMsT0FBTyxLQUFLLGVBQWUsTUFBTSxVQUFVLEtBQUssSUFBSTtJQUM3RSxPQUFPLEtBQUssU0FBUyxPQUFPO0dBQzlCO0dBQ0EsT0FBTyxRQUFRLE9BQU8sS0FBSztFQUM3QixDQUFDLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDbEIsSUFBSSxpQkFBaUIsb0JBQ25CO0dBRUYsSUFBSSxLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsZUFBZSxLQUFLLE1BQU0sT0FDckQ7R0FFRixJQUFJLHNCQUFzQixLQUFLLEdBQUc7SUFDaEMsSUFBSSxvQkFDRixLQUFLLGNBQWMsZ0JBQWdCLEtBQUs7SUFFMUMsT0FBTyxRQUFRLE9BQU8sS0FBSztHQUM3QjtFQUNGLENBQUMsQ0FBQyxDQUFDLGNBQWM7R0FDZixLQUFLLE9BQU87R0FDWixJQUFJLHNCQUFzQixLQUFLLFVBQzdCLEtBQUssY0FBYyxtQkFBbUIsS0FBSyxRQUFRO0VBRXZELENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxJQUFJLEtBQUssY0FBYyxrQkFBa0IsR0FDdkM7RUFFRixLQUFLLGNBQWMsZUFBZTtFQUNsQyxLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLG1CQUFtQjtFQUNqQixJQUFJLEtBQUssb0JBQ1A7RUFFRixLQUFLLHFCQUFxQjtFQUMxQixnQkFBZ0IsS0FBSyxjQUFjLElBQUksQ0FBQztFQUN4QyxLQUFLLGNBQWMsU0FBUztDQUM5QjtDQUNBLE9BQU8sRUFBRSxZQUFZLE9BQU8sY0FBYyxTQUFTO0VBQ2pELElBQUksS0FBSyxvQkFDUDtFQUVGLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssY0FBYyxnQkFBZ0I7R0FBRTtHQUFXO0VBQVksQ0FBQztFQUM3RCxLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLFdBQVcsV0FBVztFQUNwQixJQUFJLEtBQUssY0FBYyxLQUFLLGFBQWEsVUFBVTtHQUNqRCxrQkFBa0IsU0FBUztHQUMzQixLQUFLLGNBQWMsSUFBSSxDQUFDLENBQUMsV0FBVyxTQUFTO0VBQy9DO0NBQ0Y7Q0FDQSxhQUFhO0VBQ1gsTUFBTSxVQUFVO0dBQ2QsR0FBRyxLQUFLLGNBQWMsUUFBUTtHQUM5QixRQUFRO0dBQ1Isb0JBQW9CO0dBQ3BCLGFBQWE7RUFDZjtFQUNBLE1BQU0sUUFBUUEsT0FBSyxJQUFJO0VBQ3ZCLElBQUksTUFBTSxTQUNSLFFBQVEsdUJBQXVCLE1BQU07RUFFdkMsTUFBTSxZQUFZLE9BQU8sUUFBUSxNQUFNLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsY0FBYztHQUMvRSxJQUFJSyxJQUFLLE1BQU0sT0FBTyxTQUFTLElBQUksTUFBTSxLQUFLLEdBQzVDLE9BQU87R0FFVCxPQUFPLENBQUMsU0FBUyxhQUFhLFNBQVMsWUFBWSxLQUFLLElBQUk7RUFDOUQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRztFQUNyQixJQUFJLFVBQVUsU0FBUyxHQUNyQixRQUFRLGlDQUFpQyxVQUFVLEtBQUssR0FBRztFQUU3RCxPQUFPO0NBQ1Q7QUFDRjtBQUdBLElBQUksZ0JBQWdCLE1BQU07Q0FDeEIsV0FBVyxDQUFDO0NBQ1o7Q0FDQTtDQUNBLFlBQVksRUFBRSxlQUFlLGlCQUFpQjtFQUM1QyxLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGdCQUFnQjtDQUN2QjtDQUNBLEtBQUssU0FBUztFQUNaLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDMUIsUUFBUSxLQUFLLENBQUMsQ0FBQyxjQUFjO0dBQzNCLEtBQUssV0FBVyxLQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU0sT0FBTztFQUMzRCxDQUFDO0NBQ0g7Q0FDQSxvQkFBb0I7RUFDbEIsS0FBSyxPQUFPLEVBQUUsYUFBYSxLQUFLLEdBQUcsS0FBSztDQUMxQztDQUNBLGVBQWUsVUFBVSxDQUFDLEdBQUc7RUFDM0IsTUFBTSxlQUFlLE9BQU8sWUFBWSxhQUFhLFdBQVcsWUFBWTtHQUMxRSxNQUFNLEVBQUUsV0FBVyxNQUFNLGFBQWEsU0FBUztHQUMvQyxRQUFRLFlBQVksQ0FBQyxRQUFRLFdBQVcsT0FBTyxjQUFjLENBQUMsUUFBUSxhQUFhO0VBQ3JGO0VBQ0EsS0FBSyxTQUFTLE9BQU8sWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFFBQVEsT0FBTyxFQUFFLFdBQVcsS0FBSyxDQUFDLENBQUM7Q0FDN0Y7Q0FDQSxPQUFPLEVBQUUsWUFBWSxPQUFPLGNBQWMsVUFBVSxDQUFDLEdBQUcsUUFBUSxPQUFPO0VBQ3JFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxhQUFhLEdBQy9CO0VBR0YsS0FEcUIsU0FBUyxNQUN4QixDQUFDLEVBQUUsT0FBTztHQUFFO0dBQVc7RUFBWSxDQUFDO0NBQzVDO0NBQ0EsZUFBZTtFQUNiLE9BQU8sS0FBSyxpQkFBaUIsS0FBSyxTQUFTLFVBQVUsS0FBSztDQUM1RDtDQUNBLHVCQUF1QjtFQUNyQixPQUFPLEtBQUssU0FBUyxNQUFNLFlBQVksUUFBUSxvQkFBb0IsQ0FBQztDQUN0RTtBQUNGO0FBR0EsSUFBSUMsZUFBYSxDQUNqQjtBQUNBLElBQUksU0FBUyxNQUFNO0NBQ2pCLG9CQUFvQixJQUFJLGNBQWM7RUFDcEMsZUFBZTtFQUNmLGVBQWU7Q0FDakIsQ0FBQztDQUNELHFCQUFxQixJQUFJLGNBQWM7RUFDckMsZUFBZTtFQUNmLGVBQWU7Q0FDakIsQ0FBQztDQUNELG1CQUFtQixJQUFJLE1BQU07Q0FDN0IsNEJBQTRCLEtBQUs7Q0FDakMsS0FBSyxFQUNILGFBQ0Esa0JBQ0EsZUFDQSxXQUNDO0VBQ0QsT0FBSyxLQUFLO0dBQ1I7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUFDO0VBQ0QsYUFBYSxPQUFPO0VBQ3BCLGFBQWEsS0FBSztFQUNsQixhQUFhLEdBQUcsNEJBQTRCO0dBQzFDLElBQUksT0FBTyxXQUFXLGFBQ3BCLEtBQUssTUFBTSxPQUFPLFNBQVMsTUFBTTtJQUFFLGVBQWU7SUFBTSxnQkFBZ0I7SUFBTSxTQUFTO0dBQUssQ0FBQztFQUVqRyxDQUFDO0VBQ0QsYUFBYSxHQUFHLHNCQUFzQixrQkFBa0I7R0FDdEQsS0FBSyxrQkFBa0IsYUFBYTtFQUN0QyxDQUFDO0VBQ0QsYUFBYSxHQUFHLHlCQUF5QixRQUFRO0dBQy9DLE9BQU8sU0FBUyxPQUFPO0VBQ3pCLENBQUM7Q0FDSDtDQUNBLFdBQVcsVUFBVTtFQUNuQixLQUFLLDRCQUE0QjtFQUNqQyxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLEtBQUssT0FBTyxDQUFDLEdBQUcsVUFBVSxDQUFDLEdBQUc7RUFDaEMsT0FBTyxLQUFLLE1BQU0sS0FBSztHQUFFLEdBQUc7R0FBUyxRQUFRO0dBQU87RUFBSyxDQUFDO0NBQzVEO0NBQ0EsS0FBSyxLQUFLLE9BQU8sQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHO0VBQ2pDLE9BQU8sS0FBSyxNQUFNLEtBQUs7R0FBRSxlQUFlO0dBQU0sR0FBRztHQUFTLFFBQVE7R0FBUTtFQUFLLENBQUM7Q0FDbEY7Q0FDQSxJQUFJLEtBQUssT0FBTyxDQUFDLEdBQUcsVUFBVSxDQUFDLEdBQUc7RUFDaEMsT0FBTyxLQUFLLE1BQU0sS0FBSztHQUFFLGVBQWU7R0FBTSxHQUFHO0dBQVMsUUFBUTtHQUFPO0VBQUssQ0FBQztDQUNqRjtDQUNBLE1BQU0sS0FBSyxPQUFPLENBQUMsR0FBRyxVQUFVLENBQUMsR0FBRztFQUNsQyxPQUFPLEtBQUssTUFBTSxLQUFLO0dBQUUsZUFBZTtHQUFNLEdBQUc7R0FBUyxRQUFRO0dBQVM7RUFBSyxDQUFDO0NBQ25GO0NBQ0EsT0FBTyxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ3hCLE9BQU8sS0FBSyxNQUFNLEtBQUs7R0FBRSxlQUFlO0dBQU0sR0FBRztHQUFTLFFBQVE7RUFBUyxDQUFDO0NBQzlFO0NBQ0EsT0FBTyxVQUFVLENBQUMsR0FBRztFQUNuQixPQUFPLEtBQUssU0FBUyxPQUFPO0NBQzlCO0NBQ0EsU0FBUyxVQUFVLENBQUMsR0FBRztFQUNyQixJQUFJLE9BQU8sV0FBVyxhQUNwQjtFQUVGLE9BQU8sS0FBSyxNQUFNLE9BQU8sU0FBUyxNQUFNO0dBQ3RDLEdBQUc7R0FDSCxnQkFBZ0I7R0FDaEIsZUFBZTtHQUNmLE9BQU87R0FDUCxTQUFTO0lBQ1AsR0FBRyxRQUFRLFdBQVcsQ0FBQztJQUN2QixpQkFBaUI7R0FDbkI7RUFDRixDQUFDO0NBQ0g7Q0FDQSxTQUFTLE1BQU0sTUFBTSxXQUFXO0VBQzlCLFFBQVEsU0FBUyxNQUFNLEdBQUc7Q0FDNUI7Q0FDQSxRQUFRLE1BQU0sV0FBVztFQUN2QixPQUFPLFFBQVEsUUFBUSxHQUFHO0NBQzVCO0NBQ0EsR0FBRyxNQUFNLFVBQVU7RUFDakIsSUFBSSxPQUFPLFdBQVcsYUFDcEIsYUFBYSxDQUNiO0VBRUYsT0FBTyxhQUFhLGNBQWMsTUFBTSxRQUFRO0NBQ2xEO0NBQ0EsS0FBSyxNQUFNLFVBQVU7RUFDbkIsSUFBSSxPQUFPLFdBQVcsYUFDcEIsYUFBYSxDQUNiO0VBRUYsTUFBTSxVQUFVLEtBQUssR0FBRyxPQUFPLFVBQVU7R0FDdkMsUUFBUTtHQUNSLE9BQU8sU0FBUyxLQUFLO0VBQ3ZCLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSx1QkFBdUI7RUFDckIsT0FBTyxLQUFLLG1CQUFtQixxQkFBcUI7Q0FDdEQ7Q0FDQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxNQUFNO0NBQ2Y7Q0FDQSxVQUFVLEVBQUUsUUFBUSxNQUFNLFdBQVcsTUFBTSxPQUFPLFNBQVMsQ0FBQyxHQUFHO0VBQzdELElBQUksT0FDRixLQUFLLG1CQUFtQixlQUFlLEVBQUUsU0FBUyxDQUFDO0VBRXJELElBQUksTUFDRixLQUFLLGtCQUFrQixlQUFlO0NBRTFDO0NBQ0EsS0FBSyxVQUFVLGlCQUFpQixDQUFDLEdBQUcsVUFBVSxDQUFDLEdBQUc7RUFDaEQsT0FBTyxNQUFNLElBQ1gsV0FDQyxFQUFFLFNBQVMsZUFBZTtHQUN6QixNQUFNLFdBQVcsT0FBTyxtQkFBbUIsYUFBYSxlQUFlLElBQUk7R0FDM0UsS0FBSyxTQUFTO0lBQ1osTUFBTTtJQUNOLGdCQUFnQjtJQUNoQixHQUFHO0lBQ0gsZ0JBQWdCLFVBQVU7S0FDeEIsUUFBUSxNQUFNLE1BQU07S0FDcEIsU0FBUyxnQkFBZ0IsS0FBSztJQUNoQztJQUNBLFdBQVcsVUFBVTtLQUNuQixTQUFTO0tBQ1QsU0FBUyxXQUFXLEtBQUs7SUFDM0I7R0FDRixDQUFDO0VBQ0gsR0FDQTtHQUNFLFdBQVcsUUFBUSxhQUFhO0dBQ2hDLFdBQVcsUUFBUSxhQUFhO0dBQ2hDLE1BQU0sUUFBUTtFQUNoQixDQUNGO0NBQ0Y7Q0FDQSxNQUFNLE1BQU0sVUFBVSxDQUFDLEdBQUc7RUFDeEIsUUFBUSxhQUFhLFFBQVEsY0FBYyxLQUFLO0VBQ2hELEtBQUssNEJBQTRCLEtBQUs7RUFDdEMsSUFBSSxRQUFRLFlBQ1YsUUFBUSxRQUFRLFFBQVEsU0FBUztFQUVuQyxNQUFNLFFBQVEsS0FBSyxnQkFBZ0IsTUFBTTtHQUN2QyxHQUFHO0dBQ0gsY0FBYyxRQUFRLGlCQUFpQixDQUFDLFFBQVEsU0FBUyxDQUFDLENBQUMsUUFBUTtFQUNyRSxDQUFDO0VBQ0QsTUFBTSxTQUFTLEtBQUssZUFBZSxPQUFPO0VBQzFDLElBQUksT0FBTyxTQUFTLEtBQUssTUFBTSxTQUFTLENBQUMsZ0JBQWdCLEtBQUssR0FDNUQ7RUFFRixNQUFNLGlCQUFpQixVQUFVTixPQUFLLElBQUksQ0FBQyxDQUFDLEdBQUc7RUFHL0MsSUFBSSxFQUZvQixNQUFNLEtBQUssU0FBUyxLQUFLLE1BQU0sT0FBTyxTQUFTLEtBQUssTUFBTSxNQUFNLFNBQVMsSUFDNUQsNEJBQTRCLE1BQU0sS0FBSyxjQUFjLElBQUkscUJBQXFCLE1BQU0sS0FBSyxjQUFjLElBRTFJLEtBQUssbUJBQW1CLGdCQUNyQixZQUFZLENBQUMsUUFBUSxXQUFXLEtBQUssQ0FBQyxRQUFRLGFBQWEsS0FBSyw0QkFBNEIsUUFBUSxPQUFPLEdBQUcsY0FBYyxDQUMvSDtFQUVGLElBQUksQ0FBQyxNQUFNLE9BQ1QsS0FBSyxrQkFBa0Isa0JBQWtCO0VBRTNDLElBQUksUUFBUSxZQUNWLEtBQUssc0JBQXNCLFFBQVEsWUFBWSxNQUFNO0VBRXZELElBQUksQ0FBQ0EsT0FBSyxVQUFVLEtBQUssQ0FBQyxNQUFNLGFBQzlCLE9BQU8sS0FBSztFQUVkLE1BQU0sZ0JBQWdCO0dBQ3BCLEdBQUc7R0FDSCxHQUFHO0VBQ0w7RUFDQSxNQUFNLG9CQUFvQjtHQUN4QixNQUFNLGFBQWEsbUJBQW1CLElBQUksYUFBYTtHQUN2RCxJQUFJLFlBQVk7SUFDZCxTQUFTLE9BQU8sV0FBVyxRQUFRO0lBQ25DLG1CQUFtQixJQUFJLFlBQVksYUFBYTtHQUNsRCxPQUFPO0lBQ0wsU0FBUyxPQUFPLElBQUk7SUFFcEIsQ0FEc0IsTUFBTSxRQUFRLEtBQUsscUJBQXFCLEtBQUssa0JBQUEsQ0FDckQsS0FBSyxRQUFRLE9BQU8sZUFBZUEsT0FBSyxJQUFJLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0dBQ3BHO0VBQ0Y7RUFDQSxJQUFJLE1BQU0sUUFBUSxNQUFNLFNBQVMsR0FBRztHQUNsQyxRQUFRLE1BQ04seURBQXlELE1BQU0sVUFBVSxLQUFLLElBQUksRUFBRSxnSEFDdEY7R0FDQSxNQUFNLFlBQVk7RUFDcEI7RUFDQSxJQUFJLE1BQU0sV0FDUixRQUFRLGFBQWEsQ0FBQyxDQUFDLFdBQVc7R0FDaEMsS0FBSyxtQkFBbUIsS0FBSyxDQUFDLENBQUMsV0FBVztJQUN4QyxjQUFjLGlCQUFpQjtJQUMvQixjQUFjLGdCQUFnQjtJQUM5QixjQUFjLFVBQVU7SUFDeEIsY0FBYyxpQkFBaUI7SUFDL0IsWUFBWTtHQUNkLENBQUM7RUFDSCxDQUFDO09BRUQsWUFBWTtDQUVoQjtDQUNBLFVBQVUsTUFBTSxVQUFVLENBQUMsR0FBRztFQUM1QixPQUFPLG1CQUFtQixXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTyxDQUFDO0NBQzVFO0NBQ0EsTUFBTSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQ3hCLG1CQUFtQixPQUFPLEtBQUssa0JBQWtCLE1BQU0sT0FBTyxDQUFDO0NBQ2pFO0NBQ0EsV0FBVztFQUNULG1CQUFtQixVQUFVO0NBQy9CO0NBQ0EsaUJBQWlCLE1BQU07RUFDckIsbUJBQW1CLGFBQWEsTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDO0NBQ3JFO0NBQ0EsZUFBZSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQ2pDLE9BQU8sbUJBQW1CLGFBQWEsS0FBSyxrQkFBa0IsTUFBTSxPQUFPLENBQUM7Q0FDOUU7Q0FDQSxTQUFTLE1BQU0sVUFBVSxDQUFDLEdBQUcsa0JBQWtCLENBQUMsR0FBRztFQUVqRCxLQURlLFFBQVEsV0FBVyxnQkFBZ0IsSUFBSSxJQUFJLEtBQUssU0FBUyxZQUN6RCxPQUNiLE1BQU0sSUFBSSxNQUFNLDJDQUEyQztFQUU3RCxNQUFNLFFBQVEsS0FBSyxnQkFBZ0IsTUFBTTtHQUN2QyxHQUFHO0dBQ0gsT0FBTztHQUNQLGNBQWM7R0FDZCxVQUFVO0dBQ1YsZ0JBQWdCO0VBQ2xCLENBQUM7RUFHRCxJQUZpQixNQUFNLElBQUksU0FBUyxNQUFNLElBQUksV0FBVyxNQUFNLElBQUksV0FDaEQsT0FBTyxTQUFTLFNBQVMsT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLFFBRXJGO0VBRUYsTUFBTSxTQUFTLEtBQUssZUFBZSxPQUFPO0VBQzFDLElBQUksT0FBTyxTQUFTLEtBQUssTUFBTSxTQUFTLENBQUMsZ0JBQWdCLEtBQUssR0FDNUQ7RUFFRixTQUFTLEtBQUs7RUFDZCxLQUFLLG1CQUFtQixrQkFBa0I7RUFDMUMsTUFBTSxnQkFBZ0I7R0FDcEIsR0FBRztHQUNILEdBQUc7RUFDTDtFQUNBLE1BQU0sK0JBQStCO0dBQ25DLE9BQU8sSUFBSSxTQUFTLFlBQVk7SUFDOUIsTUFBTSw2QkFBNkI7S0FDakMsSUFBSUEsT0FBSyxJQUFJLEdBQ1gsUUFBUTtVQUVSLFdBQVcsc0JBQXNCLEVBQUU7SUFFdkM7SUFDQSxxQkFBcUI7R0FDdkIsQ0FBQztFQUNIO0VBQ0EsdUJBQXVCLENBQUMsQ0FBQyxXQUFXO0dBQ2xDLG1CQUFtQixJQUNqQixnQkFDQyxXQUFXO0lBQ1YsS0FBSyxtQkFBbUIsS0FBSyxRQUFRLE9BQU8sUUFBUUEsT0FBSyxJQUFJLENBQUMsQ0FBQztHQUNqRSxHQUNBO0lBQ0UsVUFBVUwsU0FBTyxJQUFJLG1CQUFtQjtJQUN4QyxXQUFXLENBQUM7SUFDWixHQUFHO0dBQ0wsQ0FDRjtFQUNGLENBQUM7Q0FDSDtDQUNBLGVBQWU7RUFDYixRQUFRLE1BQU07Q0FDaEI7Q0FDQSxpQkFBaUI7RUFDZixPQUFPLFFBQVEsUUFBUTtDQUN6QjtDQUNBLGlCQUFpQixXQUFXLE9BQU87RUFDakMsT0FBT0ssT0FBSyxRQUFRLFdBQVcsS0FBSztDQUN0QztDQUNBLFFBQVEsUUFBUTtFQUNkLEtBQUssWUFBWSxRQUFRLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDNUM7Q0FDQSxZQUFZLE1BQU0sT0FBTyxTQUFTO0VBQ2hDLEtBQUssUUFBUTtHQUNYLGdCQUFnQjtHQUNoQixlQUFlO0dBQ2YsTUFBTSxjQUFjO0lBRWxCLE9BQU8sMEJBQTBCLGNBQWMsTUFEOUIsT0FBTyxVQUFVLGFBQWEsTUFBTU8sSUFBSyxjQUFjLElBQUksR0FBRyxZQUFZLElBQUksS0FDbEM7R0FDL0Q7R0FDQSxHQUFHLFdBQVcsQ0FBQztFQUNqQixDQUFDO0NBQ0g7Q0FDQSxhQUFhLE1BQU0sT0FBTyxTQUFTO0VBQ2pDLEtBQUssWUFDSCxPQUNDLGNBQWMsaUJBQWlCO0dBQzlCLE1BQU0sV0FBVyxPQUFPLFVBQVUsYUFBYSxNQUFNLGNBQWMsWUFBWSxJQUFJO0dBQ25GLElBQUksQ0FBQyxNQUFNLFFBQVEsWUFBWSxHQUM3QixlQUFlLGlCQUFpQixLQUFLLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQztHQUU3RCxPQUFPLENBQUMsR0FBRyxjQUFjLFFBQVE7RUFDbkMsR0FDQSxPQUNGO0NBQ0Y7Q0FDQSxjQUFjLE1BQU0sT0FBTyxTQUFTO0VBQ2xDLEtBQUssWUFDSCxPQUNDLGNBQWMsaUJBQWlCO0dBQzlCLE1BQU0sV0FBVyxPQUFPLFVBQVUsYUFBYSxNQUFNLGNBQWMsWUFBWSxJQUFJO0dBQ25GLElBQUksQ0FBQyxNQUFNLFFBQVEsWUFBWSxHQUM3QixlQUFlLGlCQUFpQixLQUFLLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQztHQUU3RCxPQUFPLENBQUMsVUFBVSxHQUFHLFlBQVk7RUFDbkMsR0FDQSxPQUNGO0NBQ0Y7Q0FDQSxLQUFLLFFBQVE7RUFDWCxLQUFLLFlBQVksTUFBTTtDQUN6QjtDQUNBLE1BQU0sV0FBVyxPQUFPO0VBQ3RCLE1BQU0sVUFBVVAsT0FBSyxJQUFJLENBQUMsQ0FBQztFQUMzQixJQUFJO0VBQ0osSUFBSSxPQUFPLGNBQWMsWUFDdkIsUUFBUSxVQUFVLE9BQU87T0FDcEIsSUFBSSxPQUFPLGNBQWMsVUFDOUIsUUFBUTtHQUFFLEdBQUc7SUFBVSxZQUFZO0VBQU07T0FDcEMsSUFBSSxhQUFhLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxRQUM3QyxRQUFRO0dBQUUsR0FBRztHQUFTLEdBQUc7RUFBVTtPQUVuQztFQUVGLE9BQUssU0FBUyxLQUFLO0VBQ25CLElBQUksT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLFFBQ3JCLGVBQWUsS0FBSztDQUV4QjtDQUNBLFlBQVksUUFBUSxFQUFFLFVBQVUsVUFBVSxDQUFDLEdBQUc7RUFDNUMsS0FBSyxpQkFBaUIsVUFBVSxLQUFLLG1CQUFtQixRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7Q0FDOUU7Q0FDQSxtQkFBbUIsUUFBUSxFQUFFLFVBQVUsVUFBVSxDQUFDLEdBQUc7RUFDbkQsTUFBTSxVQUFVQSxPQUFLLElBQUk7RUFDekIsTUFBTSxZQUFZLE9BQU8sT0FBTyxVQUFVLGFBQWEsT0FBTyxZQUM1RCxPQUFPLE9BQU8sUUFBUSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxhQUFhLENBQ3ZELFNBQVMsTUFDVE8sSUFBSyxRQUFRLE9BQU8sU0FBUyxJQUFJLENBQ25DLENBQUMsQ0FDSCxJQUFJLENBQUM7RUFDTCxNQUFNLFFBQVEsT0FBTyxPQUFPLFVBQVUsYUFBYSxPQUFPLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFNBQVMsUUFBUTtFQUNwSCxNQUFNLFFBQVEsT0FBTyxPQUFPLFVBQVUsYUFBYSxPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksT0FBTztFQUN4RixNQUFNLEVBQUUsZ0JBQWdCLFNBQVMsVUFBVSxTQUFTLFdBQVcsR0FBRyxlQUFlO0VBQ2pGLE1BQU0sUUFBUTtHQUNaLEdBQUc7R0FDSCxHQUFHO0dBQ0gsT0FBTyxTQUFTLENBQUM7R0FDakI7RUFDRjtFQUNBLE1BQU0saUJBQWlCLGNBQWMsc0JBQXNCLE9BQU8sa0JBQWtCLE9BQU8sS0FBSztFQUNoRyxNQUFNLGdCQUFnQixjQUFjLHNCQUFzQixPQUFPLGlCQUFpQixPQUFPLEtBQUs7RUFDOUYsTUFBTSxVQUFVLEtBQUssY0FBYztFQUNuQyxPQUFPUCxPQUFLLElBQUksT0FBTztHQUNyQjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNaLHFCQUFxQkEsT0FBSyxJQUFJLEdBQUc7SUFBRTtJQUFTO0dBQVEsQ0FBQztHQUNyRCxNQUFNLGVBQWVBLE9BQUssSUFBSSxDQUFDLENBQUM7R0FDaEMsSUFBSSxPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxHQUFHO0lBQ3hDLGVBQWUsWUFBWTtJQUMzQixVQUFVLFlBQVk7R0FDeEI7R0FDQSxNQUFNLFNBQVNBLE9BQUssSUFBSSxDQUFDLENBQUMsTUFBTSxVQUFVLENBQUM7R0FDM0MsSUFBSSxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsV0FBVyxHQUFHO0lBQ3BDLFlBQVlBLE9BQUssSUFBSSxDQUFDO0lBQ3RCO0dBQ0Y7R0FDQSxNQUFNLGVBQWUsT0FBTyxXQUFXLE9BQU8sT0FBTyxZQUFZLE9BQU8sQ0FBQyxJQUFJO0dBQzdFLFVBQVUsWUFBWTtFQUN4QixDQUFDLENBQUMsQ0FBQyxjQUFjLFdBQVcsTUFBTSxDQUFDO0NBQ3JDO0NBQ0EsbUJBQW1CLE9BQU87RUFDeEIsTUFBTSxVQUFVQSxPQUFLLElBQUk7RUFDekIsTUFBTSxjQUFjLE9BQU8sYUFDeEIsUUFBUSxlQUFlLENBQUMsRUFBQSxDQUFHLFFBQVEsUUFBUSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsS0FBSyxRQUFRLE1BQU0sSUFBSSxDQUFDLENBQzFHO0VBQ0EsTUFBTSxvQkFBb0IsT0FBTyxNQUFNLGNBQWMsYUFBYSxNQUFNLFVBQVVRLFlBQVcsUUFBUSxLQUFLLEdBQUdBLFlBQVcsV0FBVyxDQUFDLElBQUksTUFBTTtFQUM5SSxNQUFNLG9CQUFvQixzQkFBc0IsT0FBTyxFQUFFLEdBQUcsa0JBQWtCLElBQUksRUFBRSxHQUFHLFlBQVk7RUFDbkcsTUFBTSxZQUFZLEtBQUssZ0NBQWdDLFNBQVMsaUJBQWlCO0VBQ2pGLE1BQU0sbUJBQW1CO0dBQ3ZCLFdBQVcsTUFBTTtHQUNqQixLQUFLLE1BQU0sSUFBSSxXQUFXLE1BQU0sSUFBSSxTQUFTLE1BQU0sSUFBSTtHQUN2RCxTQUFTLFFBQVE7R0FDakIsT0FBTztJQUNMLEdBQUc7SUFDSCxRQUFRLENBQUM7R0FDWDtHQUNBLE9BQU8sQ0FBQztHQUNSLGNBQWMsQ0FBQztHQUNmLGNBQWM7R0FDZCxnQkFBZ0IsUUFBUTtHQUN4QixhQUFhLFFBQVE7R0FDckI7R0FDQSxpQkFBaUIsQ0FBQztFQUNwQjtFQUNBLE9BQU9SLE9BQUssSUFBSSxrQkFBa0I7R0FDaEMsU0FBUyxNQUFNO0dBQ2YsZ0JBQWdCLGNBQWMsc0JBQXNCLE1BQU0sZ0JBQWdCLGdCQUFnQjtHQUMxRixlQUFlO0dBQ2YsZ0JBQWdCLE1BQU07R0FDdEIsU0FBUyxNQUFNO0VBQ2pCLENBQUM7Q0FDSDs7Ozs7O0NBTUEsZ0NBQWdDLFNBQVMsT0FBTztFQUM5QyxNQUFNLFlBQVksQ0FBQztFQUNuQixPQUFPLFFBQVEsUUFBUSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssY0FBYztHQUNuRSxJQUFJTyxJQUFLLE9BQU8sU0FBUyxJQUFJLE1BQU0sS0FBSyxHQUN0QztHQUVGLE1BQU0sZUFBZUEsSUFBSyxRQUFRLE9BQU8sU0FBUyxJQUFJO0dBQ3RELElBQUksaUJBQWlCLEtBQUssR0FDeEI7R0FFRixJQUFLLE9BQU8sU0FBUyxNQUFNLFlBQVk7R0FDdkMsVUFBVSxPQUFPO0VBQ25CLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxrQkFBa0IsTUFBTSxTQUFTO0VBQy9CLE9BQU87R0FDTCxHQUFHLEtBQUssZ0JBQWdCLE1BQU07SUFDNUIsR0FBRztJQUNILE9BQU87SUFDUCxjQUFjO0lBQ2QsVUFBVTtJQUNWLGdCQUFnQjtHQUNsQixDQUFDO0dBQ0QsR0FBRyxLQUFLLGVBQWUsT0FBTztFQUNoQztDQUNGO0NBQ0EsZ0JBQWdCO0VBQ2QsT0FBTyxJQUFJO0NBQ2I7Q0FDQSxnQkFBZ0IsTUFBTSxTQUFTO0VBQzdCLElBQUksZ0JBQWdCLElBQUksR0FBRztHQUN6QixNQUFNLGdCQUFnQjtHQUN0QixPQUFPLGNBQWM7R0FDckIsUUFBUSxTQUFTLFFBQVEsVUFBVSxjQUFjO0VBQ25EO0VBQ0EsTUFBTSw4QkFBOEJaLFNBQU8sSUFBSSxjQUFjO0VBQzdELE1BQU0sb0JBQW9CLDhCQUE4Qiw0QkFBNEIsS0FBSyxTQUFTLEdBQUdhLFlBQVcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7RUFDbkksTUFBTSxnQkFBZ0I7R0FDcEIsUUFBUTtHQUNSLE1BQU0sQ0FBQztHQUNQLFNBQVM7R0FDVCxnQkFBZ0I7R0FDaEIsZUFBZTtHQUNmLE1BQU0sQ0FBQztHQUNQLFFBQVEsQ0FBQztHQUNULFNBQVMsQ0FBQztHQUNWLFVBQVU7R0FDVixlQUFlO0dBQ2Ysd0JBQXdCO0dBQ3hCLE9BQU87R0FDUCxjQUFjO0dBQ2QsT0FBTztHQUNQLE9BQU8sQ0FBQztHQUNSLGFBQWE7R0FDYixnQkFBZ0I7R0FDaEIsVUFBVTtHQUNWLHFCQUFxQixDQUFDO0dBQ3RCLGdCQUFnQjtHQUNoQixXQUFXO0dBQ1gsV0FBVztHQUNYLFFBQVE7R0FDUixHQUFHLHVCQUF1QixPQUFPO0dBQ2pDLEdBQUcsdUJBQXVCLGlCQUFpQjtFQUM3QztFQUNBLE1BQU0sQ0FBQyxLQUFLLFNBQVMsb0JBQ25CLE1BQ0EsY0FBYyxNQUNkLGNBQWMsUUFDZCxjQUFjLGVBQ2QsY0FBYyxzQkFDaEI7RUFDQSxNQUFNLFFBQVE7R0FDWixJQUFJLEtBQUssY0FBYztHQUN2QixXQUFXO0dBQ1gsV0FBVztHQUNYLGFBQWE7R0FDYixHQUFHO0dBQ0g7R0FDQSxNQUFNO0VBQ1I7RUFDQSxJQUFJLE1BQU0sVUFDUixNQUFNLFFBQVEsYUFBYTtFQUU3QixPQUFPO0NBQ1Q7Q0FDQSxlQUFlLFNBQVM7RUFDdEIsT0FBTztHQUNMLGVBQWUsUUFBUSxpQkFBaUJGO0dBQ3hDLFVBQVUsUUFBUSxZQUFZQTtHQUM5QixnQkFBZ0IsUUFBUSxrQkFBa0JBO0dBQzFDLFNBQVMsUUFBUSxXQUFXQTtHQUM1QixZQUFZLFFBQVEsY0FBY0E7R0FDbEMsVUFBVSxRQUFRLFlBQVlBO0dBQzlCLFVBQVUsUUFBUSxZQUFZQTtHQUM5QixXQUFXLFFBQVEsYUFBYUE7R0FDaEMsU0FBUyxRQUFRLFdBQVdBO0dBQzVCLGlCQUFpQixRQUFRLG1CQUFtQkE7R0FDNUMsZ0JBQWdCLFFBQVEsa0JBQWtCQTtHQUMxQyxTQUFTLFFBQVEsV0FBV0E7R0FDNUIsY0FBYyxRQUFRLGdCQUFnQkE7R0FDdEMsZUFBZSxRQUFRLGlCQUFpQkE7RUFDMUM7Q0FDRjtDQUNBLHNCQUFzQixZQUFZLFFBQVE7RUFDeEMsTUFBTSxlQUFlTixPQUFLLElBQUksQ0FBQyxDQUFDO0VBQ2hDLE1BQU0sa0JBQWtCLFdBQVdRLFlBQVcsWUFBWSxDQUFDO0VBQzNELElBQUksQ0FBQyxpQkFDSDtFQUVGLE1BQU0sY0FBYyxDQUFDO0VBQ3JCLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxlQUFlLEdBQzNDLElBQUksQ0FBQ0MsUUFBUyxhQUFhLE1BQU0sZ0JBQWdCLElBQUksR0FDbkQsWUFBWSxLQUFLLEdBQUc7RUFHeEIsSUFBSSxZQUFZLFdBQVcsR0FDekI7RUFFRixNQUFNLEtBQUtULE9BQUssaUJBQWlCO0VBQ2pDLE1BQU0sWUFBWUEsT0FBSyxJQUFJLENBQUMsQ0FBQztFQUM3QixLQUFLLE1BQU0sT0FBTyxhQUNoQixPQUFLLFlBQVksS0FBS1EsWUFBVyxhQUFhLElBQUksQ0FBQztFQUVyRCxPQUFLLG1CQUFtQixJQUFJLFVBQVU7RUFDdEMsT0FBSyxnQkFBZ0I7R0FBRSxHQUFHO0dBQWMsR0FBRztFQUFnQixDQUFDO0VBQzVELElBQUksZ0JBQWdCO0VBQ3BCLE1BQU0sb0JBQW9CLE9BQU87RUFDakMsT0FBTyxhQUFhLFVBQVU7R0FDNUIsZ0JBQWdCO0dBQ2hCLE9BQU8sa0JBQWtCLEtBQUs7RUFDaEM7RUFDQSxNQUFNLG1CQUFtQixPQUFPO0VBQ2hDLE9BQU8sWUFBWSxVQUFVO0dBQzNCLE9BQUsscUJBQXFCLEVBQUU7R0FDNUIsSUFBSSxpQkFBaUJSLE9BQUssSUFBSSxDQUFDLENBQUMsY0FBYyxXQUFXO0lBQ3ZELE1BQU0sZ0JBQWdCQSxPQUFLLGtCQUFrQjtJQUM3QyxJQUFJLE9BQU8sS0FBSyxhQUFhLENBQUMsQ0FBQyxTQUFTLEdBQ3RDLE9BQUssZ0JBQWdCO0tBQUUsR0FBR0EsT0FBSyxJQUFJLENBQUMsQ0FBQztLQUFPLEdBQUc7SUFBYyxDQUFDO0dBRWxFO0dBQ0EsSUFBSUEsT0FBSyx1QkFBdUIsTUFBTSxHQUNwQyxPQUFLLHFCQUFxQjtHQUU1QixPQUFPLGlCQUFpQixLQUFLO0VBQy9CO0NBQ0Y7Q0FDQSxrQkFBa0IsVUFBVTtFQUMxQixJQUFJLFVBQ0YsT0FBTyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVMsVUFBVTtHQUN6QyxLQUFLLFNBQVM7SUFBRSxNQUFNO0lBQU8sZUFBZTtJQUFNLGdCQUFnQjtHQUFLLENBQUM7RUFDMUUsQ0FBQztDQUVMO0FBQ0Y7QUFHQSxJQUFJLGVBQWUsTUFBTTs7Ozs7Ozs7O0NBU3ZCLE9BQU8sd0JBQXdCLEdBQUcsTUFBTTtFQUN0QyxhQUFhO0dBQ1gsSUFBSSxLQUFLLFdBQVcsR0FDbEIsT0FBTyxnQkFBZ0IsS0FBSyxFQUFFLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRSxDQUFDO0dBRXRELE9BQU87SUFDTCxRQUFRLE9BQU8sS0FBSyxPQUFPLGFBQWEsS0FBSyxFQUFFLENBQUMsSUFBSSxLQUFLO0lBQ3pELEtBQUssT0FBTyxLQUFLLE9BQU8sYUFBYSxLQUFLLEVBQUUsQ0FBQyxJQUFJLEtBQUs7R0FDeEQ7RUFDRjtDQUNGOzs7Ozs7Ozs7OztDQVdBLE9BQU8sc0JBQXNCLEdBQUcsTUFBTTtFQUNwQyxJQUFJLEtBQUssV0FBVyxHQUNsQixPQUFPO0dBQ0wsYUFBYTtHQUNiLE1BQU0sQ0FBQztHQUNQLHNCQUFzQjtFQUN4QjtFQUVGLElBQUksS0FBSyxXQUFXLEdBQ2xCLE9BQU87R0FDTCxhQUFhO0dBQ2IsTUFBTSxLQUFLO0dBQ1gsc0JBQXNCO0VBQ3hCO0VBRUYsSUFBSSxLQUFLLFdBQVcsR0FBRztHQUNyQixJQUFJLE9BQU8sS0FBSyxPQUFPLFVBQ3JCLE9BQU87SUFDTCxhQUFhLEtBQUs7SUFDbEIsTUFBTSxLQUFLO0lBQ1gsc0JBQXNCO0dBQ3hCO0dBRUYsT0FBTztJQUNMLGFBQWE7SUFDYixNQUFNLEtBQUs7SUFDWCxzQkFBc0IsS0FBSyx3QkFBd0IsS0FBSyxFQUFFO0dBQzVEO0VBQ0Y7RUFDQSxPQUFPO0dBQ0wsYUFBYTtHQUNiLE1BQU0sS0FBSztHQUNYLHNCQUFzQixLQUFLLHdCQUF3QixLQUFLLElBQUksS0FBSyxFQUFFO0VBQ3JFO0NBQ0Y7Ozs7Ozs7Ozs7OztDQVlBLE9BQU8scUJBQXFCLE1BQU0sc0JBQXNCO0VBQ3RELElBQUksS0FBSyxXQUFXLEtBQUssS0FBSyxXQUFXLEtBQUssT0FBTyxLQUFLLE9BQU8sVUFDL0QsT0FBTztHQUFFLFFBQVEsS0FBSztHQUFJLEtBQUssS0FBSztHQUFJLFNBQVMsS0FBSyxNQUFNLENBQUM7RUFBRTtFQUVqRSxJQUFJLGdCQUFnQixLQUFLLEVBQUUsR0FDekIsT0FBTztHQUFFLEdBQUcsS0FBSztHQUFJLFNBQVMsS0FBSyxNQUFNLENBQUM7RUFBRTtFQUU5QyxPQUFPO0dBQUUsR0FBRyxxQkFBcUI7R0FBRyxTQUFTLEtBQUssTUFBTSxDQUFDO0VBQUU7Q0FDN0Q7Ozs7Q0FJQSxPQUFPLDBCQUEwQixPQUFPLFNBQVMsU0FBUztFQUN4RCxNQUFNLFNBQVMsWUFBWTtHQUN6QixRQUFRLFVBQVU7SUFDaEIsR0FBRyxXQUFXLENBQUM7SUFDZixHQUFHLFFBQVEsV0FBVyxDQUFDO0dBQ3pCO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxTQUFTLE9BQU8sVUFBVSxZQUFZLEVBQUUsWUFBWSxRQUN0RCxRQUFRLE1BQU0sS0FBSztPQUNkLElBQUksV0FBVyxPQUFPLFlBQVksVUFDdkMsVUFBVSxNQUFNLE9BQU87T0FDbEIsSUFBSSxPQUFPLFVBQVUsVUFDMUIsVUFBVSxNQUFNLFdBQVcsQ0FBQyxDQUFDO09BRTdCLFFBQVEsTUFBTSxTQUFTLENBQUMsQ0FBQztFQUUzQixPQUFPLENBQUMsT0FBTyxPQUFPO0NBQ3hCO0FBQ0Y7QUFvSEEsU0FBUyxTQUFTLEtBQUs7Q0FDckIsSUFBSSxDQUFDLElBQUksU0FBUyxHQUFHLEdBQ25CLE9BQU87Q0FFVCxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLElBQUksUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxHQUNqRCxPQUFPO0VBRVQsT0FBTyxRQUFRLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxRQUFRLE1BQU0sVUFBVSxVQUFVLElBQUksT0FBTyxHQUFHLE9BQU8sR0FBRyxLQUFLLEVBQUU7Q0FDckc7Q0FDQSxPQUFPLElBQUksUUFBUSxTQUFTLGlCQUFpQixDQUFDLENBQUMsTUFBTSxjQUFjLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLElBQUksZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLFFBQVEsb0JBQW9CLEdBQUc7QUFDcko7QUFDQSxTQUFTLFVBQVUsS0FBSztDQUN0QixNQUFNLE9BQU8sQ0FBQztDQUNkLE1BQU0sVUFBVTtDQUNoQixJQUFJO0NBQ0osUUFBUSxRQUFRLFFBQVEsS0FBSyxHQUFHLE9BQU8sTUFDckMsSUFBSSxNQUFNLE9BQU8sS0FBSyxHQUNwQixLQUFLLEtBQUssTUFBTSxFQUFFO01BQ2IsSUFBSSxNQUFNLE9BQU8sS0FBSyxHQUMzQixLQUFLLEtBQUssTUFBTSxPQUFPLEtBQUssS0FBSyxPQUFPLE1BQU0sRUFBRSxDQUFDO0NBR3JELE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLEtBQUssTUFBTSxPQUFPO0NBQ3pDLElBQUksVUFBVTtDQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLO0VBQ3hDLElBQUksRUFBRSxLQUFLLE1BQU0sVUFDZixRQUFRLEtBQUssTUFBTSxDQUFDO0VBRXRCLFVBQVUsUUFBUSxLQUFLO0NBQ3pCO0NBQ0EsUUFBUSxLQUFLLEtBQUssU0FBUyxNQUFNO0FBQ25DO0FBQ0EsU0FBUywrQkFBK0IsT0FBTztDQUM3QyxNQUFNLE9BQU8sT0FBTyxLQUFLLEtBQUs7Q0FDOUIsTUFBTSxjQUFjLEtBQUssUUFBUSxNQUFNLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDO0NBQ3hGLE9BQU8sS0FBSyxXQUFXLFlBQVksVUFBVSxZQUFZLFNBQVMsS0FBSyxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sR0FBRyxNQUFNLE1BQU0sQ0FBQztBQUNwSTtBQUNBLFNBQVMsaUNBQWlDLE9BQU87Q0FDL0MsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUNyQixPQUFPLE1BQU0sSUFBSSxnQ0FBZ0M7Q0FFbkQsSUFBSSxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsT0FBTyxLQUFLLEdBQzdELE9BQU87Q0FFVCxJQUFJLCtCQUErQixLQUFLLEdBQUc7RUFDekMsTUFBTSxVQUFVLENBQUM7RUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxRQUFRLEtBQzdDLFFBQVEsS0FBSyxpQ0FBaUMsTUFBTSxFQUFFO0VBRXhELE9BQU87Q0FDVDtDQUNBLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxPQUFPLE9BQ2hCLE9BQU8sT0FBTyxpQ0FBaUMsTUFBTSxJQUFJO0NBRTNELE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLFFBQVE7Q0FDaEMsTUFBTSxPQUFPLENBQUM7Q0FDZCxLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLEdBQUc7RUFDM0MsSUFBSSxpQkFBaUIsUUFBUSxNQUFNLFNBQVMsS0FBSyxNQUFNLFNBQVMsSUFDOUQ7RUFFRixNQUFNLE9BQU8sVUFBVSxTQUFTLEdBQUcsQ0FBQztFQUNwQyxJQUFJLEtBQUssS0FBSyxTQUFTLE9BQU8sSUFBSTtHQUNoQyxNQUFNLFlBQVksS0FBSyxNQUFNLEdBQUcsRUFBRTtHQUNsQyxNQUFNLFdBQVdVLElBQUssTUFBTSxTQUFTO0dBQ3JDLElBQUksTUFBTSxRQUFRLFFBQVEsR0FDeEIsU0FBUyxLQUFLLEtBQUs7UUFDZCxJQUFJLFlBQVksT0FBTyxhQUFhLFlBQVksQ0FBQyxPQUFPLFFBQVEsR0FBRztJQUN4RSxNQUFNLGNBQWMsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFFBQVEsTUFBTSxRQUFRLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztJQUN6RyxJQUFLLE1BQU0sV0FBVyxZQUFZLFNBQVMsSUFBSSxDQUFDLEdBQUcsWUFBWSxLQUFLLE1BQU0sU0FBUyxFQUFFLEdBQUcsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO0dBQzFHLE9BQ0UsSUFBSyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7R0FFL0I7RUFDRjtFQUNBLGdCQUFnQixNQUFNLEtBQUssSUFBSSxNQUFNLEdBQUcsS0FBSztDQUMvQztDQUNBLE9BQU8saUNBQWlDLElBQUk7QUFDOUM7QUFHQSxJQUFJLHVCQUF1QjtBQUMzQixTQUFTLGlDQUFpQyxTQUFTLE9BQU87Q0FDeEQsSUFBSSxRQUFRLE1BQU0sd0JBQXdCLEdBQ3hDLE9BQU87Q0FFVCxPQUFPLFFBQVEsUUFBUSx3QkFBd0IsaUNBQWlDLE1BQU0sRUFBRTtBQUMxRjtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sWUFBWTtDQUM1QyxJQUFJLENBQUMsWUFDSCxPQUFPLENBQUM7Q0FFVixNQUFNLFdBQVcsT0FBTyxlQUFlLGFBQWEsV0FBVyxLQUFLLElBQUksTUFBTSxNQUFNLGVBQWUsT0FBTyxTQUFTO0NBQ25ILElBQUksQ0FBQyxNQUFNLFFBQVEsUUFBUSxHQUN6QixPQUFPLENBQUM7Q0FFVixPQUFPLFNBQVMsS0FBSyxZQUFZLE9BQU8sWUFBWSxXQUFXLFFBQVEsS0FBSyxJQUFJLE9BQU8sQ0FBQyxDQUFDLFFBQVEsWUFBWSxPQUFPLFlBQVksWUFBWSxRQUFRLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxnQ0FBZ0M7QUFDdE07QUFDQSxJQUFJLFdBQVc7Q0FDYixnQkFBZ0IsS0FBSztFQUNuQixNQUFNLFdBQVcsU0FBUyxjQUFjLFVBQVU7RUFDbEQsU0FBUyxZQUFZO0VBQ3JCLE1BQU0sT0FBTyxTQUFTLFFBQVE7RUFDOUIsSUFBSSxDQUFDLElBQUksV0FBVyxVQUFVLEdBQzVCLE9BQU87RUFFVCxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7RUFDOUMsT0FBTyxZQUFZLEtBQUs7RUFDeEIsS0FBSyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVMsU0FBUztHQUN6QyxPQUFPLGFBQWEsTUFBTSxLQUFLLGFBQWEsSUFBSSxLQUFLLEVBQUU7RUFDekQsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLHdCQUF3QixTQUFTO0VBQy9CLE9BQU8sUUFBUSxhQUFhLEtBQUssZ0JBQWdCLFFBQVEsYUFBYSxjQUFjLE1BQU07Q0FDNUY7Q0FDQSx5QkFBeUIsU0FBUyxVQUFVO0VBQzFDLE1BQU0sTUFBTSxRQUFRLGFBQWEsY0FBYztFQUMvQyxJQUFJLFFBQVEsTUFDVixPQUFPLFNBQVMsV0FBVyxhQUFhLFNBQVMsYUFBYSxjQUFjLE1BQU0sR0FBRztFQUV2RixPQUFPO0NBQ1Q7Q0FDQSxRQUFRLFNBQVMsU0FBUyxVQUFVO0VBQ2xDLE1BQU0saUJBQWlCLFNBQVMsS0FBSyxZQUFZLEtBQUssZ0JBQWdCLE9BQU8sQ0FBQztFQUM5RSxNQUFNLGlCQUFpQixNQUFNLEtBQUssU0FBUyxLQUFLLFVBQVUsQ0FBQyxDQUFDLFFBQ3pELFlBQVksS0FBSyx3QkFBd0IsT0FBTyxDQUNuRDtFQUNBLElBQUksZUFBZSxNQUFNLFlBQVksbUJBQW1CLGdCQUFnQixHQUN0RSxTQUFTLEtBQUssaUJBQWlCLDJCQUEyQixDQUFDLENBQUMsU0FBUyxVQUFVLE1BQU0sT0FBTyxDQUFDO0VBRS9GLGVBQWUsU0FBUyxrQkFBa0I7R0FDeEMsTUFBTSxRQUFRLEtBQUsseUJBQXlCLGVBQWUsY0FBYztHQUN6RSxJQUFJLFVBQVUsSUFBSTtJQUNoQixjQUFjLE9BQU87SUFDckI7R0FDRjtHQUNBLE1BQU0sZ0JBQWdCLGVBQWUsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDO0dBQ3RELElBQUksaUJBQWlCLENBQUMsY0FBYyxZQUFZLGFBQWEsR0FDM0QsY0FBYyxZQUFZLGFBQWE7RUFFM0MsQ0FBQztFQUNELGVBQWUsU0FBUyxZQUFZO0dBQ2xDLFNBQVMsS0FBSyxZQUFZLE9BQU87RUFDbkMsQ0FBQztDQUNILEdBQUcsQ0FBQztBQUNOO0FBQ0EsU0FBUyxrQkFBa0IsV0FBVyxlQUFlLFVBQVUsb0JBQW9CLENBQUMsR0FBRztDQUNyRixNQUFNLFNBQVMsa0JBQWtCLFNBQVMsR0FBRyx1QkFBdUIsa0JBQWtCLElBQUksQ0FBQztDQUMzRixJQUFJLGlCQUFpQjtDQUNyQixTQUFTLFVBQVU7RUFDakIsTUFBTSxLQUFLLGtCQUFrQjtFQUM3QixPQUFPLE1BQU0sQ0FBQztFQUNkLE9BQU8sR0FBRyxTQUFTO0NBQ3JCO0NBQ0EsU0FBUyxXQUFXLElBQUk7RUFDdEIsSUFBSSxPQUFPLFFBQVEsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxNQUFNLElBQ3JEO0VBRUYsT0FBTyxPQUFPO0VBQ2QsT0FBTztDQUNUO0NBQ0EsU0FBUyxVQUFVLElBQUk7RUFDckIsSUFBSSxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFLE1BQU0sSUFDdEMsT0FBTyxNQUFNLENBQUM7Q0FFbEI7Q0FDQSxTQUFTLE9BQU8sSUFBSSxXQUFXLENBQUMsR0FBRztFQUNqQyxJQUFJLE9BQU8sUUFBUSxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksSUFDbkQsT0FBTyxNQUFNO0VBRWYsT0FBTztDQUNUO0NBQ0EsU0FBUyxpQkFBaUIsV0FBVyxDQUFDLEdBQUc7RUFDdkMsSUFBSSxTQUFTLFFBQ1gsT0FBTyx3QkFBd0I7T0FFL0IsT0FBTyxPQUFPO0VBRWhCLE9BQU87Q0FDVDtDQUNBLFNBQVMsVUFBVTtFQUNqQixNQUFNLFFBQVEsY0FBYyxFQUFFO0VBQzlCLE1BQU0sYUFBYSxPQUFPLHlCQUF5QixDQUFDO0VBQ3BELE1BQU0sZUFBZSxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsUUFBUSxPQUFPLE9BQU8sb0JBQW9CLENBQUMsQ0FBQyxTQUFTLE9BQU8sT0FBTyxHQUFHO0VBQy9HLE1BQU0sV0FBVyxFQUNmLEdBQUcsUUFBUSxFQUFFLE9BQU8sMEJBQTBCLE1BQU0sVUFBVSxJQUFJLENBQUMsRUFDckU7RUFDQSxNQUFNLFdBQVcsV0FBVyxPQUFPLFlBQVksQ0FBQyxDQUFDLFFBQVEsT0FBTyxZQUFZO0dBQzFFLElBQUksUUFBUSxRQUFRLEdBQUcsTUFBTSxJQUMzQixPQUFPO0dBRVQsSUFBSSxRQUFRLFFBQVEsU0FBUyxNQUFNLEdBQUc7SUFDcEMsTUFBTSxTQUFTLFFBQVEsTUFBTSxrQ0FBa0M7SUFDL0QsTUFBTSxRQUFRLFNBQVMsR0FBRyxPQUFPLEtBQUssY0FBYyxPQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU87SUFDL0UsT0FBTztHQUNUO0dBQ0EsTUFBTSxRQUFRLFFBQVEsTUFBTSw4QkFBOEI7R0FDMUQsSUFBSSxPQUNGLE1BQU0sTUFBTSxNQUFNO1FBRWxCLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLFVBQVU7R0FFckMsT0FBTztFQUNULEdBQUcsUUFBUTtFQUNYLE9BQU8sT0FBTyxPQUFPLFFBQVE7Q0FDL0I7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsWUFBWSxTQUFTLFFBQVEsQ0FBQyxJQUFJLFNBQVMsT0FBTyxRQUFRLENBQUM7Q0FDN0Q7Q0FDQSxPQUFPO0NBQ1AsT0FBTztFQUNMLGFBQWE7RUFDYjtFQUNBLGdCQUFnQixXQUFXO0dBQ3pCLE1BQU0sS0FBSyxRQUFRO0dBQ25CLE9BQU87SUFDTCxpQkFBaUIsVUFBVSxFQUFFO0lBQzdCLFNBQVMsYUFBYSxPQUFPLElBQUksUUFBUTtJQUN6QyxrQkFBa0IsV0FBVyxFQUFFO0dBQ2pDO0VBQ0Y7Q0FDRjtBQUNGO0FBR0EsSUFBSSxzQkFBc0I7QUFDMUIsSUFBSSx5QkFBeUIsWUFBWTtDQUN2QyxNQUFNLHFDQUFxQztFQUN6QyxNQUFNLGFBQWFWLE9BQUssSUFBSSxDQUFDLENBQUMsY0FBYyxRQUFRLFlBQVk7RUFDaEUsSUFBSSxZQUNGLE9BQU87RUFFVCxNQUFNLElBQUksTUFBTSx5REFBeUQsUUFBUSxZQUFZLEVBQUUsR0FBRztDQUNwRztDQUNBLE1BQU0sUUFBUTtFQUNaLFdBQVc7RUFDWCxTQUFTO0VBQ1QsY0FBYztFQUNkLFVBQVU7RUFDVixnQkFBZ0I7RUFDaEIsY0FBYztDQUNoQjtDQUNBLE1BQU0sbUJBQW1CO0VBQ3ZCLE1BQU0sYUFBYSw2QkFBNkI7RUFDaEQsTUFBTSxZQUFZQSxPQUFLLElBQUksQ0FBQyxDQUFDO0VBQzdCLE1BQU0sVUFBVTtFQUNoQixNQUFNLGVBQWUsV0FBVztFQUNoQyxNQUFNLFdBQVcsV0FBVztFQUM1QixNQUFNLGlCQUFpQixXQUFXO0VBQ2xDLE1BQU0sZUFBZTtDQUN2QjtDQUNBLE1BQU0sdUJBQXVCLGdDQUFnQyxRQUFRLFlBQVk7Q0FDakYsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUNqQyxXQUFXO0VBQ1gsTUFBTSxrQkFBa0IsT0FBTyxRQUFRLGVBQWUsQ0FBQztFQUN2RCxJQUFJLG1CQUFtQixPQUFPLG9CQUFvQixZQUFZLGdCQUFnQixtQkFBbUIsNkJBQTZCLENBQUMsQ0FBQyxhQUFhO0dBQzNJLE1BQU0sZUFBZSxnQkFBZ0I7R0FDckMsTUFBTSxXQUFXLGdCQUFnQjtHQUNqQyxNQUFNLGlCQUFpQixnQkFBZ0I7R0FDdkMsTUFBTSxlQUFlLGdCQUFnQixnQkFBZ0I7RUFDdkQ7Q0FDRjtDQUNBLE1BQU0sc0JBQXNCLE9BQU8sR0FBRyxZQUFZLFVBQVU7RUFDMUQsSUFBSSxNQUFNLGNBQWMsTUFBTSxPQUFPLEtBQUssYUFBYSw2QkFBNkIsQ0FBQyxDQUFDLE9BQU87R0FDM0YsV0FBVztHQUNYLFFBQVEsVUFBVTtFQUNwQjtDQUNGLENBQUM7Q0FDRCxNQUFNLDJCQUEyQixTQUFTO0VBQ3hDLE9BQU8sU0FBUyxTQUFTLGFBQWE7Q0FDeEM7Q0FDQSxNQUFNLGtCQUFrQixTQUFTO0VBQy9CLE1BQU0sZUFBZSx3QkFBd0IsSUFBSTtFQUNqRCxPQUFPLE1BQU07Q0FDZjtDQUNBLE1BQU0sc0JBQXNCLFNBQVM7RUFDbkMsTUFBTSxhQUFhLDZCQUE2QjtFQUNoRCxNQUFNLGlCQUFpQix3QkFBd0IsSUFBSTtFQUNuRCxNQUFNLGlCQUFpQixXQUFXO0VBQ2xDLE1BQU0sa0JBQWtCLFdBQVc7RUFDbkMsTUFBTSxnQkFBZ0I7RUFDdEIsT0FBTyxTQUNMO0dBQ0UsY0FBYyxNQUFNO0dBQ3BCLFVBQVUsTUFBTTtHQUNoQixnQkFBZ0IsTUFBTTtHQUN0QixjQUFjLE1BQU07RUFDdEIsR0FDQSxlQUFlLENBQ2pCO0NBQ0Y7Q0FDQSxNQUFNLG9CQUFvQiw2QkFBNkIsQ0FBQyxDQUFDO0NBQ3pELE1BQU0sd0JBQXdCLE1BQU07Q0FDcEMsTUFBTSxhQUFhLE1BQU0sZ0JBQWdCLENBQUMsTUFBTTtFQUM5QyxNQUFNLFFBQVEsZUFBZSxJQUFJO0VBQ2pDLElBQUksTUFBTSxXQUFXLFVBQVUsTUFDN0I7RUFFRixNQUFNLFVBQVU7RUFDaEIsT0FBTyxPQUFPO0dBQ1osZ0JBQWdCO0dBQ2hCLEdBQUc7R0FDSCxNQUFNO0lBQUUsR0FBRyxjQUFjLFFBQVEsQ0FBQztLQUFJLFlBQVksSUFBSTtHQUFNO0dBQzVELE1BQU0sQ0FBQyxHQUFHLGNBQWMsUUFBUSxDQUFDLEdBQUcsUUFBUSxZQUFZLENBQUM7R0FDekQsYUFBYTtHQUViLFNBQVM7S0FDTixzQkFBc0IsU0FBUyxhQUFhLFlBQVk7SUFDekQsR0FBRyxjQUFjO0dBQ25CO0dBQ0EsV0FBVyxVQUFVO0lBQ25CLFNBQVMsU0FBUyxRQUFRLG9CQUFvQixJQUFJLFFBQVEsd0JBQXdCO0lBQ2xGLGNBQWMsV0FBVyxLQUFLO0dBQ2hDO0dBQ0EsaUJBQWlCLFVBQVU7SUFDekIsUUFBUSxlQUFlO0lBQ3ZCLGNBQWMsaUJBQWlCLEtBQUs7R0FDdEM7R0FDQSxZQUFZLFVBQVU7SUFDcEIsbUJBQW1CLElBQUk7SUFDdkIsY0FBYyxZQUFZLEtBQUs7R0FDakM7R0FDQSxXQUFXLFVBQVU7SUFDbkIsTUFBTSxVQUFVO0lBQ2hCLE1BQU0sWUFBWSxNQUFNO0lBQ3hCLE1BQU0sUUFBUSxZQUFZLE1BQU0saUJBQWlCO0lBQ2pELFNBQVMsU0FBUyxRQUFRLHNCQUFzQixPQUFPO0tBQUUsTUFBTTtLQUFPO0lBQVUsQ0FBQyxJQUFJLFFBQVEsMEJBQTBCLE9BQU87S0FBRSxNQUFNO0tBQU87SUFBVSxDQUFDO0lBQ3hKLGNBQWMsV0FBVyxLQUFLO0dBQ2hDO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsTUFBTSwwQkFBMEIsTUFBTTtDQUN0QyxNQUFNLG9CQUFvQixDQUFDLENBQUMsTUFBTTtDQUNsQyxNQUFNLGdCQUFnQixDQUFDLENBQUMsTUFBTTtDQUM5QixNQUFNLGlCQUFpQixrQkFBa0IsVUFBVSxZQUFZLGFBQWE7Q0FDNUUsTUFBTSxhQUFhLGtCQUFrQixVQUFVLFFBQVEsYUFBYTtDQUNwRSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFHQSxJQUFJLGlDQUFpQztDQUNuQyxNQUFNLHdCQUF3QixDQUFDO0NBQy9CLE1BQU0sMkJBQTJCLFVBQVUsVUFBVSxDQUFDLE1BQU07RUFDMUQsTUFBTSxXQUFXLElBQUksc0JBQXNCLFlBQVk7R0FDckQsS0FBSyxNQUFNLFNBQVMsU0FDbEIsSUFBSSxNQUFNLGdCQUNSLFNBQVMsS0FBSztFQUdwQixHQUFHLE9BQU87RUFDVixzQkFBc0IsS0FBSyxRQUFRO0VBQ25DLE9BQU87Q0FDVDtDQUNBLE1BQU0saUJBQWlCO0VBQ3JCLHNCQUFzQixTQUFTLGFBQWEsU0FBUyxXQUFXLENBQUM7RUFDakUsc0JBQXNCLFNBQVM7Q0FDakM7Q0FDQSxPQUFPO0VBQ0wsS0FBSztFQUNMO0NBQ0Y7QUFDRjtBQUdBLElBQUksMkJBQTJCO0FBQy9CLElBQUksNkJBQTZCO0FBQ2pDLElBQUksc0JBQXNCLFlBQVksUUFBUSxRQUFRO0FBQ3RELElBQUksbUNBQW1DLFlBQVk7Q0FDakQsTUFBTSx3QkFBd0IseUJBQXlCO0NBQ3ZELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLGtCQUFrQjtDQUN0QixNQUFNLHVCQUF1QjtFQUMzQix3QkFBd0IsSUFBSSxrQkFBa0IsY0FBYztHQUMxRCxVQUFVLFNBQVMsYUFBYTtJQUM5QixTQUFTLFdBQVcsU0FBUyxTQUFTO0tBQ3BDLElBQUksS0FBSyxhQUFhLEtBQUssY0FDekI7S0FFRixjQUFjLElBQUksSUFBSTtJQUN4QixDQUFDO0dBQ0gsQ0FBQztHQUNELDBCQUEwQjtFQUM1QixDQUFDO0VBQ0Qsc0JBQXNCLFFBQVEsUUFBUSxnQkFBZ0IsR0FBRyxFQUFFLFdBQVcsS0FBSyxDQUFDO0VBQzVFLGdCQUFnQixzQkFBc0IsS0FDbkMsVUFBVSxRQUFRLGtCQUFrQixNQUFNLE1BQU0sQ0FDbkQ7RUFDQSxNQUFNLGtCQUFrQjtHQUN0QixNQUFNLFFBQVEsb0JBQW9CO0dBQ2xDLFlBQVksR0FBRyxLQUFLLElBQUksR0FBRyxRQUFRLGlCQUFpQixDQUFDLEVBQUU7RUFDekQ7RUFDQSx1QkFBdUIsc0JBQXNCLElBQUksUUFBUSxxQkFBcUIsZUFBZTtFQUM3RixxQkFBcUIsc0JBQXNCLElBQUksUUFBUSxpQkFBaUIsZUFBZTtDQUN6RjtDQUNBLE1BQU0sdUJBQXVCO0VBQzNCLElBQUksaUJBQ0YsZ0JBQWdCO0VBRWxCLE1BQU0sZUFBZSxRQUFRLGdCQUFnQjtFQUM3QyxNQUFNLGFBQWEsUUFBUSxjQUFjO0VBQ3pDLElBQUksZ0JBQWdCLFFBQVEsb0JBQW9CLEdBQzlDLHFCQUFxQixRQUFRLFlBQVk7RUFFM0MsSUFBSSxjQUFjLFFBQVEsZ0JBQWdCLEdBQ3hDLG1CQUFtQixRQUFRLFVBQVU7RUFFdkMsa0JBQWtCO0NBQ3BCO0NBQ0EsTUFBTSx3QkFBd0I7RUFDNUIsSUFBSSxDQUFDLGlCQUNIO0VBRUYscUJBQXFCLFdBQVc7RUFDaEMsbUJBQW1CLFdBQVc7RUFDOUIsa0JBQWtCO0NBQ3BCO0NBQ0EsTUFBTSx3QkFBd0I7RUFDNUIsSUFBSSxpQkFDRixlQUFlO0NBRW5CO0NBQ0EsTUFBTSxpQkFBaUI7RUFDckIsZ0JBQWdCO0VBQ2hCLHNCQUFzQixTQUFTO0VBQy9CLHVCQUF1QixXQUFXO0NBQ3BDO0NBQ0EsTUFBTSxnQ0FBZ0MsSUFBSSxJQUFJO0NBQzlDLE1BQU0scUJBQXFCLFlBQVksRUFBRSw0QkFBNEIsUUFBUSxZQUFZLEVBQUUsOEJBQThCLFFBQVE7Q0FDakksTUFBTSxxQ0FBcUM7RUFDekMsTUFBTSxLQUFLLGFBQWEsQ0FBQyxDQUFDLFNBQVMsWUFBWTtHQUM3QyxJQUFJLGtCQUFrQixPQUFPLEdBQzNCLFFBQVEsUUFBUSw4QkFBOEI7R0FFaEQsY0FBYyxRQUFRLE9BQU87RUFDL0IsQ0FBQztFQUNELGNBQWMsTUFBTTtDQUN0QjtDQUNBLE1BQU0sd0JBQXdCLHFCQUFxQjtFQUNqRCxPQUFPLE1BQU0sS0FDWCxpQkFBaUIsaUJBQ2YsZ0ZBQ0YsQ0FDRjtDQUNGO0NBQ0EsSUFBSSxzQkFBc0I7Q0FDMUIsTUFBTSwrQkFBK0IsZUFBZTtFQUNsRCxJQUFJLENBQUMscUJBQXFCO0dBQ3hCLHNCQUFzQjtHQUN0QixJQUFJLGdCQUFnQixHQUNsQjtFQUVKO0VBQ0EscUJBQXFCLFFBQVEsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFNBQVMsWUFBWTtHQUNuRSxJQUFJLGtCQUFrQixPQUFPLEdBQzNCLFFBQVEsUUFBUSw0QkFBNEIsWUFBWSxTQUFTLEtBQUs7R0FFeEUsY0FBYyxRQUFRLE9BQU87RUFDL0IsQ0FBQztFQUNELGlCQUFpQjtDQUNuQjtDQUNBLE1BQU0sK0JBQStCLG9DQUFvQyxRQUFRLFlBQVk7Q0FDN0YsTUFBTSx5QkFBeUI7RUFDN0IsTUFBTSxtQkFBbUIsQ0FBQztFQUMxQixNQUFNLGFBQWEsUUFBUSxnQkFBZ0IsQ0FBQyxDQUFDO0VBQzdDLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxXQUFXLFFBQVEsU0FBUztHQUN0RCxNQUFNLE9BQU8sV0FBVztHQUN4QixJQUFJLEtBQUssYUFBYSxLQUFLLGNBQ3pCO0dBRUYsTUFBTSxRQUFRLG1CQUFtQixJQUFJO0dBQ3JDLElBQUksT0FBTyxVQUFVLGFBQ25CO0dBRUYsSUFBSSxFQUFFLFNBQVMsbUJBQ2IsaUJBQWlCLFNBQVM7SUFBRSxNQUFNO0lBQU8sSUFBSTtHQUFNO1FBRW5ELGlCQUFpQixNQUFNLENBQUMsS0FBSztFQUVqQztFQUNBLE9BQU8sU0FBUyxrQkFBa0IsdUJBQXVCLENBQUM7Q0FDNUQ7Q0FDQSxNQUFNLDRCQUE0QixTQUFTLGtCQUFrQixHQUFHO0NBQ2hFLE1BQU0sd0JBQXdCO0VBQzVCLE1BQU0sbUJBQW1CLE9BQU8sUUFBUSx1QkFBdUIsQ0FBQztFQUNoRSxJQUFJLENBQUMsb0JBQW9CLE9BQU8scUJBQXFCLFVBQ25ELE9BQU87RUFFVCxNQUFNLGFBQWEsUUFBUSxnQkFBZ0IsQ0FBQyxDQUFDO0VBQzdDLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxXQUFXLFFBQVEsU0FBUztHQUN0RCxNQUFNLE9BQU8sV0FBVztHQUN4QixJQUFJLEtBQUssYUFBYSxLQUFLLGNBQ3pCO0dBRUYsTUFBTSxVQUFVO0dBQ2hCLElBQUk7R0FDSixLQUFLLE1BQU0sQ0FBQyxPQUFPLFVBQVUsT0FBTyxRQUFRLGdCQUFnQixHQUMxRCxJQUFJLFNBQVMsTUFBTSxRQUFRLFNBQVMsTUFBTSxJQUFJO0lBQzVDLGNBQWM7SUFDZDtHQUNGO0dBRUYsSUFBSSxhQUNGLFFBQVEsUUFBUSw0QkFBNEI7UUFDdkMsSUFBSSxDQUFDLGtCQUFrQixPQUFPLEdBQ25DO1FBRUEsUUFBUSxRQUFRLDhCQUE4QjtHQUVoRCxjQUFjLFFBQVEsT0FBTztFQUMvQjtFQUNBLE9BQU87Q0FDVDtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFHQSxJQUFJLFNBQVMsSUFBSSxNQUFNO0FBQ3ZCLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSSx3QkFBd0I7QUFDNUIsSUFBSSxnQ0FBZ0MsWUFBWTtDQUM5QyxJQUFJLFVBQVU7Q0FDZCxNQUFNLG1CQUFtQixVQUFVO0VBQ2pDLE9BQU8sVUFBVTtHQUNmLE9BQU8sSUFBSSxTQUFTLFlBQVk7SUFDOUIsSUFBSSxDQUFDLFNBQVM7S0FDWixhQUFhLGFBQWE7S0FDMUIsT0FBTyxRQUFRO0lBQ2pCO0lBQ0EsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZO0tBQzlCLE1BQU0saUJBQWlCQSxPQUFLLElBQUksQ0FBQyxDQUFDO0tBQ2xDLGFBQWEsVUFBVSxjQUFjO0tBQ3JDLGFBQWEsVUFBVSxjQUFjO0tBQ3JDLHdCQUF3QixlQUFlLGNBQWM7SUFDdkQ7SUFDQSxNQUFNLFdBQVcsUUFBUSxZQUFZO0lBQ3JDLE1BQU0sZUFBZSxXQUFXO0lBQ2hDLElBQUksVUFBVSxLQUNaLGFBQWEsT0FBTyxRQUFRO1NBRTVCLGFBQWEsSUFBSSxVQUFVLEtBQUs7SUFFbEMsaUJBQWlCLFFBQVEsQ0FBQztHQUM1QixDQUFDO0VBQ0gsQ0FBQyxDQUFDLENBQUMsY0FBYztHQUNmLElBQUksV0FBVyxjQUFjLGNBQWMsV0FBVyxTQUFTLFdBQVcsUUFBUSwwQkFBMEIsTUFDMUcsT0FBTyxRQUFRO0lBQ2IsS0FBSyxZQUFZLFlBQVkscUJBQXFCO0lBQ2xELGdCQUFnQjtJQUNoQixlQUFlO0dBQ2pCLENBQUM7R0FFSCxhQUFhLGFBQWEsd0JBQXdCO0VBQ3BELENBQUM7Q0FDSDtDQXNCQSxPQUFPO0VBQ0wsbUJBdEJ3QixVQUFVLGdCQUFnQjtHQUNsRCxNQUFNLGVBQWUsUUFBUSxnQkFBZ0I7R0FDN0MsSUFBSSxDQUFDLFdBQVcsUUFBUSxrQkFBa0IsS0FBSyxDQUFDLGVBQWUsQ0FBQyxjQUM5RDtHQUVGLE1BQU0sMEJBQTBCLElBQUksSUFBSTtHQUV4QyxvQ0FBb0MsQ0FEbEIsR0FBRyxhQUFhLFFBQ1MsR0FBRyxXQUFXLENBQUMsQ0FBQyxTQUFTLFlBQVk7SUFDOUUsTUFBTSxRQUFRLG1CQUFtQixPQUFPLEtBQUs7SUFDN0MsSUFBSSxRQUFRLElBQUksS0FBSyxHQUNuQixRQUFRLElBQUksT0FBTyxRQUFRLElBQUksS0FBSyxJQUFJLENBQUM7U0FFekMsUUFBUSxJQUFJLE9BQU8sQ0FBQztHQUV4QixDQUFDO0dBRUQsTUFBTSxrQkFEYyxNQUFNLEtBQUssUUFBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQ3hDLENBQUMsQ0FBQyxFQUFFLEdBQUc7R0FDekMsSUFBSSxvQkFBb0IsS0FBSyxHQUMzQixnQkFBZ0IsZUFBZTtFQUVuQyxHQUFHLEdBRWU7RUFDaEIsY0FBYyxVQUFVO0NBQzFCO0FBQ0Y7QUFHQSxJQUFJLGlDQUFpQyxZQUFZO0NBQy9DLE1BQU0sd0JBQXdCO0VBQzVCLElBQUk7RUFDSixJQUFJLG1CQUFtQjtFQUN2QixJQUFJLHNCQUFzQjtFQUMxQixNQUFNLDhCQUE4QjtHQUNsQyxNQUFNLHNCQUFzQixRQUFRLG9CQUFvQjtHQUN4RCxNQUFNLGVBQWUsUUFBUSxnQkFBZ0I7R0FDN0MsbUJBQW1CLHFCQUFxQixhQUFhLE9BQU87R0FDNUQsTUFBTSxrQkFBa0Isb0NBQW9DLENBQUMsR0FBRyxhQUFhLFFBQVEsQ0FBQztHQUN0RixJQUFJLGdCQUFnQixTQUFTLEdBQUc7SUFDOUIsbUJBQW1CLGdCQUFnQjtJQUNuQyxNQUFNLGdCQUFnQixxQkFBcUIsc0JBQXNCLEtBQUssRUFBRSxLQUFLLEVBQUU7SUFDL0UsTUFBTSxlQUFlLHNCQUFzQixjQUFjLE1BQU07SUFFL0Qsc0JBRGEsaUJBQWlCLHNCQUNMLENBQUMsQ0FBQyxNQUFNO0dBQ25DO0VBQ0Y7RUFDQSxNQUFNLDhCQUE4QjtHQUNsQyxJQUFJLENBQUMsa0JBQ0g7R0FFRixJQUFJLFdBQVc7R0FDZixJQUFJLFdBQVc7R0FDZixNQUFNLGdCQUFnQjtJQUNwQjtJQUNBLElBQUksWUFBWSxXQUFXLElBQ3pCLE9BQU87SUFFVCxNQUFNLHNCQUFzQixRQUFRLG9CQUFvQjtJQUN4RCxNQUFNLGdCQUFnQixxQkFBcUIsc0JBQXNCLEtBQUssRUFBRSxLQUFLLEVBQUU7SUFDL0UsTUFBTSxlQUFlLHNCQUFzQixjQUFjLE1BQU07SUFHL0QsTUFBTSxhQUZVLGlCQUFpQixzQkFDTCxDQUFDLENBQUMsTUFBTSxlQUNEO0lBQ25DLElBQUksZUFBZSxHQUFHO0tBQ3BCLE9BQU8sc0JBQXNCLE9BQU87S0FDcEM7SUFDRjtJQUNBLElBQUkscUJBQ0Ysb0JBQW9CLFNBQVMsRUFBRSxLQUFLLG1CQUFtQixXQUFXLENBQUM7U0FFbkUsT0FBTyxTQUFTLEdBQUcsT0FBTyxVQUFVLFVBQVU7SUFFaEQsV0FBVztHQUNiO0dBQ0EsT0FBTyxzQkFBc0IsT0FBTztFQUN0QztFQUNBLE9BQU87R0FDTDtHQUNBO0VBQ0Y7Q0FDRjtDQUNBLE9BQU8sRUFDTCxnQkFDRjtBQUNGO0FBR0EsU0FBUyxrQkFBa0IsU0FBUztDQUNsQyxNQUFNLHFCQUFxQiw2QkFBNkI7RUFBRSxHQUFHO0VBQVMsbUJBQW1CLFlBQVksWUFBWTtDQUFFLENBQUM7Q0FDcEgsTUFBTSxxQkFBcUIsOEJBQThCLE9BQU87Q0FDaEUsTUFBTSxpQkFBaUIsZ0NBQWdDO0VBQ3JELEdBQUc7RUFFSCxtQkFBbUIsbUJBQW1CO0VBQ3RDLDJCQUEyQixZQUFZLGNBQWM7RUFDckQsdUJBQXVCLFlBQVksVUFBVTtDQUMvQyxDQUFDO0NBQ0QsTUFBTSxjQUFjLHNCQUFzQjtFQUN4QyxHQUFHO0VBR0gsZ0JBQWdCLGVBQWU7RUFFL0IsNEJBQTRCLEdBQUcsWUFBWTtHQUN6QyxRQUFRLDBCQUEwQixPQUFPO0dBQ3pDLElBQUksUUFBUSxXQUNWLDRCQUE0QixlQUFlLDRCQUE0QixRQUFRLElBQUksR0FBRyxDQUFDO0VBRTNGO0VBQ0Esd0JBQXdCLEdBQUcsWUFBWTtHQUNyQyxRQUFRLHNCQUFzQixPQUFPO0dBQ3JDLElBQUksUUFBUSxXQUNWLDRCQUE0QixlQUFlLDRCQUE0QixRQUFRLElBQUksR0FBRyxDQUFDO0VBRTNGO0VBQ0EsU0FBUyxRQUFRO0NBQ25CLENBQUM7Q0FDRCxNQUFNLGtDQUFrQyxrQkFBa0I7RUFDeEQsTUFBTSxFQUFFLHVCQUF1QiwwQkFBMEIsbUJBQW1CLGdCQUFnQjtFQUM1RixNQUFNLHlCQUF5QixjQUFjLHlCQUF5QixDQUN0RTtFQUNBLE1BQU0sb0JBQW9CLGNBQWMsb0JBQW9CLENBQzVEO0VBQ0EsY0FBYyxrQkFBa0IsVUFBVTtHQUN4Qyx1QkFBdUIsS0FBSztHQUM1QixzQkFBc0I7RUFDeEI7RUFDQSxjQUFjLGFBQWEsVUFBVTtHQUNuQyxrQkFBa0IsS0FBSztHQUN2QixzQkFBc0I7RUFDeEI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLG9CQUFvQixZQUFZO0NBQ3RDLFlBQVksYUFBYSxnQkFBZ0IsQ0FBQyxNQUFNO0VBQzlDLGdCQUFnQjtHQUFFLEdBQUcsUUFBUSxtQkFBbUI7R0FBRyxHQUFHO0VBQWM7RUFDcEUsSUFBSSxRQUFRLGNBQWMsR0FDeEIsZ0JBQWdCLCtCQUErQixhQUFhO0VBRTlELGtCQUFrQixhQUFhO0NBQ2pDO0NBQ0EsTUFBTSx3QkFBd0IsWUFBWTtDQUMxQyxZQUFZLGlCQUFpQixnQkFBZ0IsQ0FBQyxNQUFNO0VBQ2xELGdCQUFnQjtHQUFFLEdBQUcsUUFBUSxtQkFBbUI7R0FBRyxHQUFHO0VBQWM7RUFDcEUsSUFBSSxDQUFDLFFBQVEsY0FBYyxHQUN6QixnQkFBZ0IsK0JBQStCLGFBQWE7RUFFOUQsc0JBQXNCLGFBQWE7Q0FDckM7Q0FDQSxNQUFNLHNCQUFzQixPQUFPLEdBQUcsaUJBQWlCLHNCQUFzQixlQUFlLGlCQUFpQixDQUFDLENBQUM7Q0FDL0csT0FBTztFQUNMO0VBQ0E7RUFDQSxhQUFhO0dBQ1gsb0JBQW9CO0dBQ3BCLFlBQVksb0JBQW9CO0dBQ2hDLGVBQWUsU0FBUztHQUN4QixtQkFBbUIsT0FBTztFQUM1QjtDQUNGO0FBQ0Y7QUFJQSxTQUFTLHlCQUF5QjtDQUNoQyxJQUFJLFNBQVMsQ0FBQztDQUNkLElBQUksUUFBUSxDQUFDO0NBQ2IsSUFBSSxXQUFXO0VBQUU7RUFBUTtDQUFNO0NBQy9CLE1BQU0sNEJBQTRCLElBQUksSUFBSTtDQUMxQyxJQUFJLGdCQUFnQjtDQUNwQixNQUFNLHVCQUF1QjtFQUMzQixXQUFXO0dBQUU7R0FBUTtFQUFNO0NBQzdCO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLElBQUksZUFDRjtFQUVGLGdCQUFnQjtFQUNoQixxQkFBcUI7R0FDbkIsZ0JBQWdCO0dBQ2hCLFVBQVUsU0FBUyxPQUFPLEdBQUcsQ0FBQztFQUNoQyxDQUFDO0NBQ0g7Q0FDQSxPQUFPO0VBQ0wsSUFBSSxPQUFPO0dBQ1QsTUFBTSxTQUFTO0lBQUUsR0FBRztJQUFRLEdBQUc7R0FBTTtHQUNyQyxJQUFJVyxRQUFTLFFBQVEsTUFBTSxHQUN6QjtHQUVGLFNBQVM7R0FDVCxlQUFlO0dBQ2YsT0FBTztFQUNUO0VBQ0EsT0FBTyxNQUFNLE9BQU87R0FDbEIsTUFBTSxVQUFVLE1BQU0sU0FBUyxDQUFDO0dBQ2hDLE1BQU0sU0FBUztJQUFFLEdBQUc7SUFBUyxHQUFHO0dBQU07R0FDdEMsSUFBSUEsUUFBUyxTQUFTLE1BQU0sR0FDMUI7R0FFRixRQUFRO0lBQUUsR0FBRztLQUFRLE9BQU87R0FBTztHQUNuQyxlQUFlO0dBQ2YsT0FBTztFQUNUO0VBQ0EsUUFBUTtHQUNOLFNBQVMsQ0FBQztHQUNWLFFBQVEsQ0FBQztHQUNULGVBQWU7R0FDZixPQUFPO0VBQ1Q7RUFDQSxVQUFVLFVBQVU7R0FDbEIsVUFBVSxJQUFJLFFBQVE7R0FDdEIsYUFBYSxVQUFVLE9BQU8sUUFBUTtFQUN4QztFQUNBLFdBQVc7Q0FDYjtBQUNGO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsT0FBTyxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsQ0FBQyxNQUFNLFFBQVEsS0FBSztBQUM1RTtBQUNBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDOUIsT0FBTyxjQUFjLEtBQUssS0FBSyxlQUFlO0FBQ2hEO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxhQUFhO0NBQzdDLE9BQU8sZUFBZSxTQUFTLFlBQVksTUFBTSxTQUFTO0FBQzVEO0FBQ0EsU0FBUyxlQUFlLE9BQU8sYUFBYTtDQUMxQyxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssWUFBWSxLQUFLLEtBQUssa0JBQWtCLE9BQU8sV0FBVyxHQUNyRixPQUFPO0NBRVQsT0FBTyxPQUFPLE9BQU8sS0FBSyxDQUFDLENBQUMsT0FDekIsTUFBTSxZQUFZLENBQUMsS0FBSyxNQUFNLFFBQVEsQ0FBQyxLQUFLLFlBQVksRUFBRSxFQUFFLEtBQUssZ0JBQWdCLENBQUMsS0FBSyxZQUFZLEVBQUUsU0FBUyxDQUNqSDtBQUNGO0FBQ0EsU0FBUyxjQUFjLE9BQU8sYUFBYTtDQUN6QyxPQUFPLGNBQWMsS0FBSyxLQUFLLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxrQkFBa0IsT0FBTyxXQUFXLEtBQUssQ0FBQyxlQUFlLE9BQU8sV0FBVztBQUNwSTtBQUNBLFNBQVMsd0JBQXdCLE9BQU8sYUFBYTtDQUNuRCxJQUFJLGNBQWMsT0FBTyxXQUFXLEdBQ2xDLE9BQU87Q0FFVCxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssWUFBWSxLQUFLLEtBQUssa0JBQWtCLE9BQU8sV0FBVyxHQUNyRixPQUFPO0NBRVQsTUFBTSxTQUFTLE9BQU8sT0FBTyxLQUFLO0NBQ2xDLE9BQU8sT0FBTyxTQUFTLEtBQUssT0FBTyxPQUFPLE1BQU0sT0FBTyxNQUFNLFVBQVU7QUFDekU7QUFDQSxTQUFTLFFBQVEsT0FBTyxhQUFhO0NBQ25DLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLFdBQVcsS0FBSyxZQUFZLE1BQU0sRUFBRSxLQUFLLGNBQWMsTUFBTSxFQUFFLEtBQUssQ0FBQyxZQUFZLE1BQU0sRUFBRTtBQUNoSTtBQUNBLFNBQVMsUUFBUSxNQUFNLGFBQWE7Q0FDbEMsSUFBSSxNQUFNLFFBQVEsSUFBSSxLQUFLLFlBQVksS0FBSyxFQUFFLEdBQzVDLE9BQU87RUFBRSxXQUFXLEtBQUs7RUFBSSxPQUFPLEtBQUssTUFBTSxDQUFDO0NBQUU7Q0FFcEQsSUFBSSxnQkFBZ0IsSUFBSSxLQUFLLFlBQVksS0FBSyxTQUFTLEdBQ3JELE9BQU87RUFBRSxXQUFXLEtBQUs7RUFBVyxPQUFPLEtBQUssU0FBUyxDQUFDO0NBQUU7Q0FFOUQsSUFBSSxZQUFZLElBQUksR0FDbEIsT0FBTztFQUFFLFdBQVc7RUFBTSxPQUFPLENBQUM7Q0FBRTtDQUV0QyxNQUFNLElBQUksTUFBTSx1Q0FBdUMsT0FBTyxNQUFNO0FBQ3RFO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxhQUFhLGtCQUFrQjtDQUMvRCxJQUFJLENBQUMsVUFBVSxvQkFBb0IsaUJBQWlCLE1BQU0sR0FDeEQsT0FBTyxDQUFDO0NBRVYsSUFBSSxlQUFlLFFBQVEsV0FBVyxHQUNwQyxPQUFPLE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxZQUFZO0VBQUUsR0FBRyxRQUFRLE9BQU8sV0FBVztFQUFHO0NBQUssRUFBRTtDQUVqRyxJQUFJLFFBQVEsUUFBUSxXQUFXLEdBQzdCLE9BQU8sQ0FBQztFQUFFLFdBQVcsT0FBTztFQUFJLE9BQU8sT0FBTyxNQUFNLENBQUM7Q0FBRSxDQUFDO0NBRTFELElBQUksTUFBTSxRQUFRLE1BQU0sR0FDdEIsT0FBTyxPQUFPLEtBQUssU0FBUyxRQUFRLE1BQU0sV0FBVyxDQUFDO0NBRXhELElBQUksZ0JBQWdCLE1BQU0sS0FBSyxZQUFZLE9BQU8sU0FBUyxHQUN6RCxPQUFPLENBQUM7RUFBRSxXQUFXLE9BQU87RUFBVyxPQUFPLE9BQU8sU0FBUyxDQUFDO0NBQUUsQ0FBQztDQUVwRSxJQUFJLFlBQVksTUFBTSxHQUNwQixPQUFPLENBQUM7RUFBRSxXQUFXO0VBQVEsT0FBTyxDQUFDO0NBQUUsQ0FBQztDQUUxQyxPQUFPLENBQUM7QUFDVjtBQUdBLFNBQVMsNkJBQTZCLE9BQU87Q0FDM0MsT0FBTyxNQUFNLGtCQUFrQixlQUFlLE1BQU0sT0FBTyxxQkFBcUIsTUFBTTtBQUN4RjtBQUNBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDOUIsTUFBTSxTQUFTLE1BQU0sY0FBYyxRQUFRLFlBQVksTUFBTTtDQUM3RCxNQUFNLFNBQVMsU0FBUyxNQUFNLGNBQWMsU0FBUztDQUNyRCxPQUFPLEVBQUUsNkJBQTZCLEtBQUssS0FBSyxVQUFVLE1BQU0sVUFBVSxVQUFVLE1BQU0sV0FBVyxVQUFVLE1BQU0sV0FBVyxVQUFVLE1BQU0sWUFBWSxVQUFVLFdBQVcsTUFBTSxXQUFXLFdBQVcsVUFBVSxZQUFZLFNBQVMsTUFBTSxXQUFXO0FBQy9QO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsTUFBTSxXQUFXLE1BQU0sY0FBYyxRQUFRLFlBQVksTUFBTTtDQUMvRCxPQUFPLENBQUMsNkJBQTZCLEtBQUssTUFBTSxNQUFNLFFBQVEsV0FBVyxZQUFZLE1BQU0sUUFBUTtBQUNyRztBQUdBLElBQUksd0JBQXdCO0FBQzVCLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSSxXQUFXO0NBQ2IsU0FBUztDQUNULFFBQVE7Q0FDUixPQUFPO0NBQ1AsU0FBUztDQUNULGNBQWM7Q0FDZCxhQUFhO0NBQ2IsYUFBYTtDQUNiLGlCQUFpQjtDQUNqQixRQUFRO0NBQ1IsT0FBTztDQUNQLFlBQVk7Q0FDWixTQUFTO0NBQ1QsVUFBVTtFQUNSO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUMsQ0FBQyxLQUFLLEVBQUU7QUFDWDtBQUNBLElBQUksU0FBUztBQUNiLElBQUksU0FBUztBQUNiLElBQUksYUFBYSxZQUFZO0NBQzNCLE9BQU8sT0FBTyxVQUFVLE9BQU87Q0FDL0IsYUFBYSxTQUFTLFdBQVcsYUFBYSxZQUFZO0NBQzFELElBQUksU0FBUyxZQUNYLFVBQVUsU0FBUyxLQUFLO0NBRTFCLFlBQVksU0FBUyxjQUFjLEtBQUs7Q0FDeEMsVUFBVSxLQUFLO0NBQ2YsVUFBVSxhQUFhLGVBQWUsTUFBTTtDQUM1QyxVQUFVLFlBQVksU0FBUztDQUMvQixJQUFJLFlBQ0YsVUFBVSxVQUFVO0FBRXhCO0FBQ0EsSUFBSSxRQUFRLE1BQU07Q0FDaEIsTUFBTSxVQUFVLFVBQVU7Q0FDMUIsSUFBSSxNQUFNLEdBQUcsU0FBUyxTQUFTLENBQUM7Q0FDaEMsU0FBUyxNQUFNLElBQUksT0FBTztDQUMxQixNQUFNLFlBQVksT0FBTyxDQUFDLE9BQU87Q0FDakMsTUFBTSxNQUFNLFVBQVUsY0FBYyxTQUFTLFdBQVc7Q0FDeEQsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsTUFBTSxPQUFPLFNBQVM7Q0FDdEIsVUFBVTtDQUNWLFFBQVEsU0FBUztFQUNmLE1BQU0sWUFBWTtHQUNoQixZQUFZLE9BQU8sTUFBTSxLQUFLO0dBQzlCLFdBQVcsZUFBZSxnQkFBZ0IsQ0FBQyxFQUFFO0VBQy9DO0VBQ0EsS0FBSyxNQUFNLE9BQU8sV0FDaEIsSUFBSSxNQUFNLE9BQU8sVUFBVTtFQUU3QixJQUFJLE1BQU0sR0FDUixPQUFPLFdBQVcsTUFBTSxLQUFLO0VBRS9CLFVBQVUsTUFBTSxhQUFhO0VBQzdCLFVBQVUsTUFBTSxVQUFVO0VBQzFCLFVBQVU7RUFDVixpQkFBaUI7R0FDZixVQUFVLE1BQU0sYUFBYSxPQUFPLE1BQU07R0FDMUMsVUFBVSxNQUFNLFVBQVU7R0FDMUIsaUJBQWlCO0lBQ2YsT0FBTztJQUNQLFVBQVUsTUFBTSxhQUFhO0lBQzdCLFVBQVUsTUFBTSxVQUFVO0lBQzFCLEtBQUs7R0FDUCxHQUFHLEtBQUs7RUFDVixHQUFHLEtBQUs7Q0FDVixDQUFDO0FBQ0g7QUFDQSxJQUFJLGtCQUFrQixPQUFPLFdBQVc7QUFDeEMsSUFBSSxjQUFjO0NBQ2hCLElBQUksQ0FBQyxRQUNILEtBQUssQ0FBQztDQUVSLE1BQU0sT0FBTyxXQUFXO0VBQ3RCLFdBQVcsV0FBVztHQUNwQixJQUFJLENBQUMsUUFDSDtHQUVGLGlCQUFpQjtHQUNqQixLQUFLO0VBQ1AsR0FBRyxTQUFTLFlBQVk7Q0FDMUI7Q0FDQSxJQUFJLFNBQVMsU0FDWCxLQUFLO0FBRVQ7QUFDQSxJQUFJLFFBQVEsVUFBVTtDQUNwQixJQUFJLENBQUMsU0FBUyxDQUFDLFFBQ2I7Q0FFRixpQkFBaUIsS0FBTSxLQUFNLEtBQUssT0FBTyxDQUFDO0NBQzFDLEtBQUssQ0FBQztBQUNSO0FBQ0EsSUFBSSxvQkFBb0IsV0FBVztDQUNqQyxNQUFNLElBQUk7Q0FDVixJQUFJLE1BQU0sTUFDUixPQUFPLE1BQU07Q0FFZixJQUFJLElBQUksR0FDTjtDQUVGLFNBQVMsT0FBTyxXQUFXLFdBQVcsZ0JBQWdCO0VBQ3BELE1BQU0sU0FBUztHQUNiLElBQUssQ0FBQyxHQUFHLEVBQUc7R0FDWixLQUFNLENBQUMsSUFBSyxFQUFHO0dBQ2YsS0FBTSxDQUFDLElBQUssRUFBRztHQUNmLE1BQU0sQ0FBQyxJQUFLLEdBQUk7RUFDbEI7RUFDQSxLQUFLLE1BQU0sS0FBSyxRQUNkLElBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQyxNQUFNLElBQUksT0FBTyxFQUFFLENBQUMsSUFDckMsT0FBTyxXQUFXLENBQUM7RUFHdkIsT0FBTztDQUNULEVBQUEsQ0FBRztDQUNILE9BQU8sS0FBSyxNQUFNLElBQUksUUFBUSxHQUFHLElBQUssQ0FBQztBQUN6QztBQUNBLElBQUksVUFBVSxjQUFjO0NBQzFCLElBQUksV0FBVyxHQUNiLE9BQU8sU0FBUyxlQUFlLHFCQUFxQjtDQUV0RCxTQUFTLGdCQUFnQixVQUFVLElBQUksR0FBRyxzQkFBc0IsTUFBTTtDQUN0RSxNQUFNLE1BQU0sVUFBVSxjQUFjLFNBQVMsV0FBVztDQUN4RCxNQUFNLE9BQU8sWUFBWSxTQUFTLGdCQUFnQixVQUFVLENBQUM7Q0FDN0QsSUFBSSxNQUFNLGFBQWE7Q0FDdkIsSUFBSSxNQUFNLFlBQVksZUFBZSxLQUFLO0NBQzFDLElBQUksQ0FBQyxTQUFTLGFBQ1osVUFBVSxjQUFjLFNBQVMsZUFBZSxDQUFDLEVBQUUsT0FBTztDQUU1RCxJQUFJLFlBQVk7RUFDZCxTQUFTLEtBQUssWUFBWSxTQUFTO0VBQ25DLElBQUksQ0FBQyxRQUNILFVBQVUsWUFBWTtDQUUxQixPQUFPO0VBQ0wsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxXQUFXLFNBQVMsTUFDdEIsT0FBTyxVQUFVLElBQUksR0FBRyxzQkFBc0IsZUFBZTtFQUUvRCxPQUFPLFlBQVksU0FBUztFQUM1QixJQUFJLFFBQ0YsVUFBVSxNQUFNLFVBQVU7Q0FFOUI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFJLGtCQUFrQjtDQUNwQixPQUFPLFNBQVMsY0FBYyxTQUFTLE1BQU07QUFDL0M7QUFDQSxJQUFJLGVBQWU7Q0FDakIsU0FBUyxnQkFBZ0IsVUFBVSxPQUFPLEdBQUcsc0JBQXNCLE1BQU07Q0FDekUsSUFBSSxjQUFjLFdBQVcsYUFDM0IsSUFBSTtFQUNGLFVBQVUsWUFBWTtDQUN4QixRQUFRLENBQ1I7Q0FFRixJQUFJLENBQUMsWUFDSCxVQUFVLENBQUMsQ0FBQyxVQUFVLE9BQU8sR0FBRyxzQkFBc0IsZUFBZTtDQUV2RSxXQUFXLE9BQU87QUFDcEI7QUFDQSxJQUFJLG1CQUFtQjtDQUNyQixPQUFPLFNBQVMsZUFBZSxxQkFBcUIsTUFBTTtBQUM1RDtBQUNBLFNBQVMsTUFBTSxHQUFHLEtBQUssS0FBSztDQUMxQixJQUFJLElBQUksS0FDTixPQUFPO0NBRVQsSUFBSSxJQUFJLEtBQ04sT0FBTztDQUVULE9BQU87QUFDVDtBQUNBLElBQUksbUJBQW1CLE9BQU8sS0FBSyxLQUFLO0FBQ3hDLElBQUksU0FBeUIsdUJBQU87Q0FDbEMsTUFBTSxVQUFVLENBQUM7Q0FDakIsTUFBTSxhQUFhO0VBQ2pCLE1BQU0sS0FBSyxRQUFRLE1BQU07RUFDekIsSUFBSSxJQUNGLEdBQUcsSUFBSTtDQUVYO0NBQ0EsUUFBUSxPQUFPO0VBQ2IsUUFBUSxLQUFLLEVBQUU7RUFDZixJQUFJLFFBQVEsV0FBVyxHQUNyQixLQUFLO0NBRVQ7QUFDRixFQUFBLENBQUc7QUFDSCxJQUFJLGFBQWEsVUFBVTtDQUN6QixNQUFNLFVBQVUsU0FBUyxjQUFjLE9BQU87Q0FDOUMsTUFBTSxRQUFRaEIsU0FBTyxJQUFJLE9BQU87Q0FDaEMsSUFBSSxPQUNGLFFBQVEsUUFBUTtDQUVsQixRQUFRLGNBQWM7T0FDakIsc0JBQXNCOzs7Ozs7Ozs7Ozs7Ozs7T0FldEIsc0JBQXNCOzs7O09BSXRCLHNCQUFzQjtvQkFDVCxNQUFNOzs7Ozs7Ozs7OztPQVduQixzQkFBc0I7Ozs7Ozs2QkFNQSxNQUFNLFlBQVksTUFBTTs7Ozs7O09BTTlDLHNCQUFzQjs7Ozs7Ozs7T0FRdEIsc0JBQXNCOzs7Ozs7MEJBTUgsTUFBTTsyQkFDTCxNQUFNOzs7bUJBR2Qsc0JBQXNCOzs7T0FHbEMsc0JBQXNCOzs7OztPQUt0QixzQkFBc0Isa0JBQWtCLHNCQUFzQjtPQUM5RCxzQkFBc0Isa0JBQWtCLHNCQUFzQjs7OztpQkFJcEQsc0JBQXNCOzs7OztDQUtyQyxTQUFTLEtBQUssWUFBWSxPQUFPO0FBQ25DO0FBQ0EsSUFBSSxhQUFhO0NBQ2YsU0FBUztDQUNULElBQUksQ0FBQyxXQUFXLGFBQ2Q7Q0FFRixJQUFJLFlBQ0YsSUFBSTtFQUNGLFVBQVUsWUFBWTtDQUN4QixRQUFRLENBQ1I7TUFFQSxVQUFVLE1BQU0sVUFBVTtBQUU5QjtBQUNBLElBQUksYUFBYTtDQUNmLFNBQVM7Q0FDVCxJQUFJLENBQUMsV0FBVyxhQUNkO0NBRUYsSUFBSSxZQUNGLElBQUk7RUFDRixVQUFVLFlBQVk7Q0FDeEIsUUFBUSxDQUNSO01BRUEsVUFBVSxNQUFNLFVBQVU7QUFFOUI7QUFDQSxJQUFJLDZCQUE2QjtDQUMvQjtDQUNBO0NBQ0E7Q0FDQSxLQUFLO0NBQ0w7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBR0EsSUFBSSxXQUFXLE1BQU07Q0FDbkIsWUFBWTtDQUNaLFFBQVE7RUFDTiwyQkFBMkIsTUFBTTtDQUNuQztDQUNBLE9BQU8sUUFBUSxPQUFPO0VBQ3BCLEtBQUssWUFBWSxLQUFLLElBQUksR0FBRyxLQUFLLFlBQVksQ0FBQztFQUMvQyxJQUFJLFNBQVMsS0FBSyxjQUFjLEdBQzlCLDJCQUEyQixLQUFLO0NBRXBDO0NBQ0EsT0FBTztFQUNMLEtBQUs7RUFDTCwyQkFBMkIsS0FBSztDQUNsQztDQUNBLElBQUksU0FBUztFQUNYLDJCQUEyQixJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDO0NBQ2xFO0NBQ0EsU0FBUztFQUNQLDJCQUEyQixLQUFLO0NBQ2xDO0NBQ0EsUUFBUTtFQUNOLDJCQUEyQixJQUFJLENBQUM7Q0FDbEM7Q0FDQSxTQUFTO0VBQ1AsMkJBQTJCLEtBQUs7RUFDaEMsMkJBQTJCLE9BQU87Q0FDcEM7Q0FDQSxZQUFZO0VBQ1YsT0FBTywyQkFBMkIsVUFBVTtDQUM5QztDQUNBLFlBQVk7RUFDVixPQUFPLDJCQUEyQjtDQUNwQztBQUNGO0FBQ0EsSUFBSSxXQUFXLElBQUksU0FBUztBQUM1QixTQUFTLGtCQUFrQixPQUFPO0NBQ2hDLFNBQVMsaUJBQWlCLGtCQUFrQixNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQztDQUM1RSxTQUFTLGlCQUFpQixvQkFBb0IsbUJBQW1CO0FBQ25FO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxPQUFPO0NBQ3RDLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxjQUN0QixTQUFTLEtBQUs7Q0FFaEIsTUFBTSxVQUFVLGlCQUFpQixTQUFTLE1BQU0sR0FBRyxLQUFLO0NBQ3hELFNBQVMsaUJBQWlCLG1CQUFtQixNQUFNLE9BQU8sR0FBRyxPQUFPLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUN2RjtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsSUFBSSxTQUFTLFVBQVUsS0FBSyxNQUFNLE9BQU8sVUFBVSxZQUNqRCxTQUFTLElBQUksS0FBSyxJQUFJLFNBQVMsVUFBVSxHQUFHLE1BQU0sT0FBTyxTQUFTLGFBQWEsTUFBTSxFQUFHLENBQUM7QUFFN0Y7QUFDQSxTQUFTLE9BQU8sT0FBTyxTQUFTO0NBQzlCLGFBQWEsT0FBTztDQUNwQixJQUFJLENBQUMsU0FBUyxVQUFVLEdBQ3RCO0NBRUYsSUFBSSxNQUFNLE9BQU8sTUFBTSxXQUNyQixTQUFTLE9BQU87TUFDWCxJQUFJLE1BQU0sT0FBTyxNQUFNLGFBQzVCLFNBQVMsTUFBTTtNQUNWLElBQUksTUFBTSxPQUFPLE1BQU0sV0FDNUIsU0FBUyxPQUFPO0FBRXBCO0FBQ0EsU0FBUyxjQUFjLEVBQ3JCLFFBQVEsS0FDUixRQUFRLFFBQ1IsYUFBYSxNQUNiLGNBQWMsT0FDZCxVQUFVLFNBQ1IsQ0FBQyxHQUFHO0NBQ04sa0JBQWtCLEtBQUs7Q0FDdkIsMkJBQTJCLFVBQVU7RUFDbkM7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0FBQ0g7QUFHQSxJQUFJLDJCQUEyQyx1QkFBTyxvQkFBb0I7QUFDMUUsU0FBUyxjQUFjLFNBQVM7Q0FDOUIsT0FBTyxtQkFBbUIsb0JBQW9CLG1CQUFtQixxQkFBcUIsbUJBQW1CO0FBQzNHO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxlQUFlO0NBQy9DLE1BQU0sV0FBVyxNQUFNO0NBQ3ZCLE1BQU0sYUFBYSxNQUFNO0NBQ3pCLFFBQVEsTUFBTSxLQUFLLFlBQVksR0FBL0I7RUFDRSxLQUFLO0dBQ0gsTUFBTSxVQUFVLGNBQWMsU0FBUyxNQUFNLEtBQUs7R0FDbEQ7RUFDRixLQUFLO0dBQ0gsTUFBTSxVQUFVLGNBQWMsT0FBTyxNQUFNO0dBQzNDO0VBQ0YsS0FBSztHQUNILE1BQU0sUUFBUTtHQUNkO0VBQ0YsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxTQUNIO0VBQ0YsU0FDRSxNQUFNLFFBQVEsY0FBYyxPQUFPLFFBQVEsY0FBYyxPQUFPLEtBQUssSUFBSSxPQUFPLGNBQWMsRUFBRSxJQUFJO0NBQ3hHO0NBQ0EsT0FBTyxNQUFNLFVBQVUsWUFBWSxNQUFNLFlBQVk7QUFDdkQ7QUFDQSxTQUFTLG1CQUFtQixRQUFRLGVBQWU7Q0FDakQsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sZUFBZSxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksS0FBSztDQUNwRixJQUFJLE9BQU8sVUFBVTtFQUNuQixNQUFNLGlCQUFpQixjQUFjLEtBQUssVUFBVSxPQUFPLEtBQUssQ0FBQztFQUNqRSxNQUFNLEtBQUssT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFTLFdBQVc7R0FDN0MsT0FBTyxXQUFXLGVBQWUsU0FBUyxPQUFPLEtBQUs7RUFDeEQsQ0FBQztDQUNILE9BQ0UsT0FBTyxRQUFRLGNBQWMsT0FBTyxLQUFLLElBQUksT0FBTyxjQUFjLEVBQUUsSUFBSTtDQUUxRSxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxlQUFlLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxLQUFLO0NBRXBGLE9BRG1CLE9BQU8sV0FBVyxLQUFLLFVBQVUsbUJBQW1CLEtBQUssQ0FBQyxNQUFNLEtBQUssVUFBVSxtQkFBbUIsS0FBSyxDQUFDLElBQUksT0FBTyxVQUFVO0FBRWxKO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxlQUFlO0NBQ2hELElBQUksUUFBUSxVQUFVO0VBQ3BCLElBQUksbUJBQW1CLGtCQUFrQjtHQUN2QyxNQUFNLFdBQVcsUUFBUTtHQUN6QixNQUFNLGFBQWEsUUFBUTtHQUMzQixRQUFRLFFBQVEsS0FBSyxZQUFZLEdBQWpDO0lBQ0UsS0FBSztJQUNMLEtBQUs7S0FDSCxRQUFRLFVBQVUsUUFBUTtLQUMxQixPQUFPLFFBQVEsWUFBWTtJQUM3QixLQUFLO0tBQ0gsUUFBUSxRQUFRO0tBQ2hCLE9BQU8sYUFBYTtJQUN0QixLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLLFNBQ0gsT0FBTztJQUNUO0tBQ0UsUUFBUSxRQUFRLFFBQVE7S0FDeEIsT0FBTyxRQUFRLFVBQVU7R0FDN0I7RUFDRixPQUFPLElBQUksbUJBQW1CLG1CQUFtQjtHQUMvQyxNQUFNLHFCQUFxQixNQUFNLEtBQUssUUFBUSxlQUFlLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxLQUFLO0dBQ3JGLE1BQU0sS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsV0FBVztJQUM5QyxPQUFPLFdBQVcsT0FBTztHQUMzQixDQUFDO0dBQ0QsTUFBTSxxQkFBcUIsTUFBTSxLQUFLLFFBQVEsZUFBZSxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksS0FBSztHQUNyRixPQUFPLEtBQUssVUFBVSxtQkFBbUIsS0FBSyxDQUFDLE1BQU0sS0FBSyxVQUFVLG1CQUFtQixLQUFLLENBQUM7RUFDL0YsT0FBTyxJQUFJLG1CQUFtQixxQkFBcUI7R0FDakQsTUFBTSxXQUFXLFFBQVE7R0FDekIsUUFBUSxRQUFRLFFBQVE7R0FDeEIsT0FBTyxRQUFRLFVBQVU7RUFDM0I7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLG1CQUFtQixrQkFDckIsT0FBTyxrQkFBa0IsU0FBUyxhQUFhO01BQzFDLElBQUksbUJBQW1CLG1CQUM1QixPQUFPLG1CQUFtQixTQUFTLGFBQWE7TUFDM0MsSUFBSSxtQkFBbUIscUJBQXFCO0VBQ2pELE1BQU0sV0FBVyxRQUFRO0VBQ3pCLFFBQVEsUUFBUSxjQUFjLE9BQU8sS0FBSyxJQUFJLE9BQU8sY0FBYyxFQUFFLElBQUk7RUFDekUsT0FBTyxRQUFRLFVBQVU7Q0FDM0I7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixVQUFVLGVBQWU7Q0FDbkQsSUFBSSxhQUFhO0NBQ2pCLElBQUksb0JBQW9CLGlCQUFpQixvQkFBb0IsZ0JBQzNELE1BQU0sS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFTLE1BQU0sVUFBVTtFQUM1QyxJQUFJLGdCQUFnQixXQUFXLGNBQWMsSUFBSSxHQUFHO0dBQ2xELElBQUksZ0JBQWdCLG9CQUFvQixDQUFDLFlBQVksT0FBTyxDQUFDLENBQUMsU0FBUyxLQUFLLEtBQUssWUFBWSxDQUFDLEdBQ3hGO1FBQUEsaUJBQWlCLE1BQU0sYUFBYSxHQUN0QyxhQUFhO0dBQUEsT0FJZixJQUFJLGlCQUFpQixNQURRLGNBQWMsV0FBVyxLQUFLLElBQUksQ0FBQyxjQUFjLE1BQU0sSUFBSSxDQUFDLGNBQWMsTUFBTSxJQUFJLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FDbEYsR0FDN0MsYUFBYTtFQUduQjtDQUNGLENBQUM7TUFDSSxJQUFJLGNBQWMsUUFBUSxHQUMvQixhQUFhLGlCQUFpQixVQUFVLGFBQWE7Q0FFdkQsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsYUFBYSxVQUFVLFlBQVk7Q0FDMUQsSUFBSSxDQUFDLGFBQ0g7Q0FFRixNQUFNLGtCQUFrQixDQUFDLGNBQWMsV0FBVyxXQUFXO0NBQzdELElBQUksaUJBQWlCO0VBQ25CLE1BQU0sV0FBVyxJQUFJLFNBQVMsV0FBVztFQUN6QyxNQUFNLG1CQUFtQixNQUFNLEtBQUssWUFBWSxRQUFRLENBQUMsQ0FBQyxLQUFLLE9BQU8sY0FBYyxFQUFFLElBQUksR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTztFQUN0SCxhQUFhLENBQUMsbUJBQW1CLElBQUksSUFBSTtHQUFDLEdBQUcsU0FBUyxLQUFLO0dBQUcsR0FBRyxTQUFTLEtBQUs7R0FBRyxHQUFHO0VBQWdCLENBQUMsQ0FBQztDQUN6RztDQUNBLElBQUksYUFBYTtDQUNqQixXQUFXLFNBQVMsY0FBYztFQUNoQyxNQUFNLFdBQVcsWUFBWSxTQUFTLFVBQVUsU0FBUztFQUN6RCxJQUFJLFVBQ0U7T0FBQSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sU0FBUyxDQUFDLEdBQ3pELGFBQWE7RUFBQTtDQUduQixDQUFDO0NBQ0QsSUFBSSxjQUFjLGlCQUNoQixZQUFZLGNBQ1YsSUFBSSxZQUFZLFNBQVM7RUFBRSxTQUFTO0VBQU0sWUFBWTtFQUFNLFFBQVEsR0FBRywyQkFBMkIsS0FBSztDQUFFLENBQUMsQ0FDNUc7QUFFSjtBQUdBLFNBQVMsYUFBYSxJQUFJLE9BQU8sTUFBTTtDQUVyQyxPQUFPLHNCQUFzQixHQUFHLDRCQURuQixLQUFLLFVBQVUsS0FBSyxDQUFDLENBQUMsUUFBUSxPQUFPLEtBQUssQ0FBQyxDQUFDLFFBQVEsTUFBTSxTQUNSLEVBQUUsaURBQWlELEdBQUcsSUFBSSxLQUFLO0FBQ2hJO0FBR0EsSUFBSSxTQUFTLElBQUksT0FBTzs7Ozs7QUMvb0t4QixJQUFJLFFBQVEsdUJBQXVCO0FBQ25DLElBQUksUUFBUSxJQUFJLE1BQU0sSUFBSSxDQUFDO0FBQzNCLE1BQU0sZ0JBQWdCO0NBQ3BCLE1BQU0sUUFBUSxNQUFNLElBQUk7QUFDMUIsQ0FBQztBQUNELFNBQVMsZUFBZSxhQUFhLE9BQU87Q0FDMUMsSUFBSSxPQUFPLGdCQUFnQixVQUN6QixNQUFNLE9BQU8sYUFBYSxLQUFLO01BRS9CLE1BQU0sSUFBSSxXQUFXO0FBRXpCO0FBQ0EsU0FBUyxtQkFBbUI7Q0FDMUIsTUFBTSxNQUFNO0NBQ1osTUFBTSxRQUFRLE1BQU0sSUFBSTtBQUMxQjtBQWtEQSxJQUFJLG1CQUFtQixFQTVDckIsVUFBVTtDQUNSLElBQUksQ0FBQyxLQUFLLFNBQVMsVUFDakI7Q0FFRixJQUFJLE1BQU0sUUFBUSxLQUFLLFNBQVMsUUFBUSxHQUN0QyxLQUFLLFNBQVMsV0FBVyxFQUFFLE1BQU0sS0FBSyxTQUFTLFNBQVM7Q0FFMUQsSUFBSSxPQUFPLEtBQUssU0FBUyxhQUFhLFVBQ3BDLEtBQUssU0FBUyxXQUFXLEVBQUUsTUFBTSxDQUFDLEtBQUssU0FBUyxRQUFRLEVBQUU7Q0FFNUQsSUFBSSxPQUFPLEtBQUssU0FBUyxTQUFTLFNBQVMsVUFDekMsS0FBSyxTQUFTLFdBQVcsRUFBRSxNQUFNLENBQUMsS0FBSyxTQUFTLFNBQVMsSUFBSSxFQUFFO0NBRWpFLE1BQU0sY0FBYyxLQUFLLFNBQVMsU0FBUyxlQUFlLFdBQVcsS0FBSyxTQUFTLFNBQVMsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsU0FBUztDQUNwSSxNQUFNLFdBQVcsT0FBTyxRQUFRLFdBQVc7Q0FDM0MsTUFBTSxlQUFlLEtBQUssU0FBUyxTQUFTLEtBQUssUUFBUSxTQUFTO0VBQ2hFLE9BQU8sRUFBRSxLQUFLLFVBQVUsUUFBUSxPQUFPLEtBQUssVUFBVSxZQUFZLEtBQUssS0FBSyxDQUFDLG1CQUFtQjtDQUNsRyxDQUFDO0NBQ0QsTUFBTSxnQkFBZ0IsU0FBUztFQUM3QixPQUFPLEtBQUssVUFBVSxRQUFRLE9BQU8sS0FBSyxVQUFVLFlBQVksT0FBTyxLQUFLLEtBQUssQ0FBQyxlQUFlLGNBQWMsT0FBTyxLQUFLLEtBQUssQ0FBQyxjQUFjO0NBQ2pKO0NBQ0EsYUFBYSxTQUFTLFNBQVM7RUFDN0IsSUFBSSxLQUFLLFVBQVUsS0FBSyxLQUFLLGFBQWEsS0FBSyxLQUFLLFNBQVMsVUFBVSxLQUFLLEdBQzFFLGFBQWEsSUFBSSxJQUFJLEtBQUssS0FBSyxDQUFDLFVBQVUsU0FBUyxLQUFLLElBQUksS0FBSyxRQUFRLFNBQVM7RUFFcEYsS0FBSyxPQUNILFlBQ007R0FDSixPQUFPLFNBQ0wsYUFBYSxRQUNWLE1BQU0sVUFBVTtJQUNmLEdBQUc7S0FDRixPQUFPaUIsWUFBVSxhQUFhLElBQUksSUFBSSxLQUFLLEtBQUssQ0FBQyxXQUFXLElBQUksS0FBSyxLQUFLO0dBQzdFLElBQ0EsQ0FBQyxDQUNILEdBQ0EsV0FDRjtFQUNGLEdBQ0E7R0FBRSxXQUFXO0dBQU0sTUFBTTtFQUFLLENBQ2hDO0NBQ0YsQ0FBQztBQUNILEVBRTRCO0FBc0I5QixTQUFTLGFBQWEsU0FBUztDQUM3QixNQUFNLEVBQUUsTUFBTSxZQUFZLGdCQUFnQjtDQUMxQyxJQUFJLEVBQUUseUJBQXlCO0NBQy9CLE1BQU0saUJBQWlCLE9BQU8sZUFBZTtDQUM3QyxNQUFNLG9CQUFvQixpQkFBaUIsV0FBVyxJQUFJO0NBQzFELE1BQU0sV0FBVyxjQUFjQyxPQUFRLFFBQVEsV0FBVyxJQUFJO0NBRTlELElBQUksV0FBV0MsWUFESyxVQUFVLFFBQVFBLFlBQVcsWUFBWSxDQUFDLENBQ3pCO0NBQ3JDLElBQUksYUFBYSxTQUFTO0NBQzFCLElBQUksZUFBZTtDQUNuQixJQUFJLGdCQUFnQjtDQUNwQixNQUFNLDZCQUE2QixpQkFBaUIsT0FBTyxJQUFJLG9CQUFvQjtDQUNuRixJQUFJO0NBQ0osSUFBSSw0QkFBNEI7Q0FDaEMsSUFBSSxzQkFBc0IsQ0FBQztDQTBLM0IsTUFBTSxZQXpLTyxTQUFTO0VBQ3BCLEdBQUdBLFlBQVcsUUFBUTtFQUN0QixTQUFTO0VBQ1QsUUFBUSxDQUFDO0VBQ1QsV0FBVztFQUNYLFlBQVk7RUFDWixVQUFVO0VBQ1YsZUFBZTtFQUNmLG9CQUFvQjtFQUNwQixpQkFBaUIsR0FBRyxNQUFNO0dBQ3hCLHVCQUF1QixhQUFhLHdCQUF3QixHQUFHLElBQUk7R0FDbkUsTUFBTSx1QkFBdUI7R0FDN0IsTUFBTSxZQUFZLGlCQUNmLFdBQVc7SUFDVixNQUFNLEVBQUUsUUFBUSxRQUFRLHFCQUFxQjtJQUM3QyxNQUFNLGtCQUFrQkEsWUFBVyxVQUFVLEtBQUssS0FBSyxDQUFDLENBQUM7SUFDekQsT0FBTyxPQUFPLE9BQU8sQ0FBQyxLQUFLLGVBQWU7R0FDNUMsR0FDQUEsWUFBVyxRQUFRLENBQ3JCO0dBQ0EsZUFBZTtHQUNmLFVBQVUsR0FBRywyQkFBMkI7SUFDdEMscUJBQXFCLGFBQWEsVUFBVSxXQUFXO0dBQ3pELENBQUMsQ0FBQyxDQUFDLEdBQUcsMEJBQTBCO0lBQzlCLHFCQUFxQixVQUFVLFVBQVUsTUFBTTtHQUNqRCxDQUFDLENBQUMsQ0FBQyxHQUFHLHdCQUF3QjtJQUM1QixxQkFBcUIsWUFBWSxVQUFVLFFBQVE7R0FDckQsQ0FBQyxDQUFDLENBQUMsR0FBRyx1QkFBdUI7SUFDM0IsTUFBTSxtQkFBbUIscUJBQXFCLElBQUksVUFBVSxPQUFPLElBQUkseUJBQXlCLFVBQVUsT0FBTyxDQUFDO0lBQ2xILEtBQUssU0FBUyxDQUFDO0lBQ2YsS0FBSyxTQUFTLGdCQUFnQjtJQUM5QixxQkFBcUIsVUFBVSxVQUFVLE1BQU07R0FDakQsQ0FBQztHQUNELE1BQU0sT0FBTyxPQUFPLGFBQWE7SUFDL0IsU0FBUyxLQUFLO0lBQ2QsT0FBTztHQUNUO0dBQ0EsT0FBTyxPQUFPLHNCQUFzQjtJQUNsQyxXQUFXLENBQUM7SUFDWixTQUFTLENBQUM7SUFDVixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLHFCQUFxQixJQUFJLDRCQUE0QixnQkFBZ0IsSUFBSTtJQUN6RSxRQUFRLFVBQVUscUJBQXFCLFFBQVEsU0FBUyxLQUFLO0lBQzdELFVBQVUsVUFBVSxTQUFTLEtBQUs7SUFDbEMsdUJBQXVCLGFBQWEsSUFBSSw0QkFBNEIsVUFBVSxXQUFXLFFBQVEsQ0FBQztJQUNsRyxxQkFBcUIsSUFBSSw0QkFBNEIsVUFBVSxjQUFjLENBQUM7SUFDOUUsNkJBQTZCLElBQUksNEJBQTRCLFVBQVUsc0JBQXNCLENBQUM7SUFDOUYsUUFBUSxPQUFPLEdBQUcsV0FBVztLQUMzQixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ3JCLFVBQVUsTUFBTSxLQUFLO1VBQ2hCLElBQUksT0FBTyxVQUFVLFVBQzFCLFVBQVUsTUFBTSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7VUFFbEMsVUFBVSxNQUFNLEtBQUs7S0FFdkIsT0FBTztJQUNUO0lBQ0EsVUFBVSxVQUFVLE9BQU8sVUFBVSxXQUFXLHFCQUFxQixVQUFVLFNBQVMsS0FBSyxJQUFJLHFCQUFxQixVQUFVLFNBQVM7SUFDekksV0FBVyxPQUFPLFlBQVk7S0FDNUIsSUFBSSxPQUFPLFVBQVUsWUFBWSxFQUFFLFlBQVksUUFBUTtNQUNyRCxVQUFVO01BQ1YsUUFBUSxLQUFLO0tBQ2Y7S0FDQSxJQUFJLFVBQVUsS0FBSyxHQUNqQixVQUFVLFNBQVMsT0FBTztVQUNyQjtNQUNMLE1BQU0sWUFBWSxZQUFZLEtBQUs7TUFDbkMsTUFBTSxrQkFBa0IsVUFBVSxLQUFLLEtBQUssQ0FBQztNQUM3QyxVQUFVLFNBQVMsV0FBVyxJQUFJLGlCQUFpQixTQUFTLEdBQUcsT0FBTztLQUN4RTtLQUNBLE9BQU87SUFDVDtJQUNBLFlBQVksV0FBVyxJQUFJLDRCQUE0QixLQUFLLFNBQVMsTUFBTSxDQUFDO0lBQzVFLGNBQWMsVUFBVSxJQUN0Qiw0QkFDTSxLQUFLLFlBQVksWUFBWSxLQUFLLENBQUMsQ0FDM0M7R0FDRixDQUFDO0dBQ0QsT0FBTztFQUNUO0VBQ0EsT0FBTztHQUNMLE9BQU8sT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTO0lBQ25ELE9BQU8sSUFBSSxPQUFPLE1BQU0sSUFBSSxNQUFNLElBQUksQ0FBQztHQUN6QyxHQUFHLENBQUMsQ0FBQztFQUNQO0VBQ0EsVUFBVSxVQUFVO0dBQ2xCLFlBQVk7R0FDWixPQUFPO0VBQ1Q7RUFDQSxTQUFTLGVBQWUsWUFBWTtHQUNsQyxJQUFJLGdCQUNGLE1BQU0sSUFBSSxNQUFNLDhFQUE4RTtHQUVoRyw0QkFBNEI7R0FDNUIsSUFBSSxPQUFPLGtCQUFrQixhQUFhO0lBQ3hDLFdBQVdBLFlBQVcsS0FBSyxLQUFLLENBQUM7SUFDakMsS0FBSyxVQUFVO0dBQ2pCLE9BQ0UsV0FBVyxPQUFPLGtCQUFrQixXQUFXLElBQUlBLFlBQVcsUUFBUSxHQUFHLGVBQWUsVUFBVSxJQUFJLE9BQU8sT0FBTyxDQUFDLEdBQUdBLFlBQVcsUUFBUSxHQUFHLGFBQWE7R0FFN0osY0FBYyxTQUFTLFFBQVE7R0FDL0IsT0FBTztFQUNUO0VBQ0EsTUFBTSxHQUFHLFFBQVE7R0FFZixNQUFNLGFBQWFBLFlBREUsaUJBQWlCQSxZQUFXLFlBQVksQ0FBQyxJQUFJLFFBQ3hCO0dBQzFDLElBQUksT0FBTyxXQUFXLEdBQUc7SUFDdkIsSUFBSSxnQkFDRixXQUFXO0lBRWIsT0FBTyxPQUFPLE1BQU0sVUFBVTtHQUNoQyxPQUVFLE9BQU8sUUFBUSxTQUFTLElBQUksWUFBWSxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsU0FBUztJQUMvRCxJQUFJLGdCQUNGLElBQUksVUFBVSxNQUFNLElBQUksWUFBWSxJQUFJLENBQUM7SUFFM0MsSUFBSSxNQUFNLE1BQU0sSUFBSSxZQUFZLElBQUksQ0FBQztHQUN2QyxDQUFDO0dBRUgsY0FBYyxNQUFNLEdBQUcsTUFBTTtHQUM3QixPQUFPO0VBQ1Q7RUFDQSxTQUFTLGVBQWUsWUFBWTtHQUNsQyxNQUFNLFNBQVMsT0FBTyxrQkFBa0IsV0FBVyxHQUFHLGdCQUFnQixXQUFXLElBQUk7R0FDckYsT0FBTyxPQUFPLEtBQUssUUFBUSxNQUFNO0dBQ2pDLEtBQUssWUFBWSxPQUFPLEtBQUssS0FBSyxNQUFNLENBQUMsQ0FBQyxTQUFTO0dBQ25ELGNBQWMsVUFBVSxNQUFNO0dBQzlCLE9BQU87RUFDVDtFQUNBLFlBQVksR0FBRyxRQUFRO0dBQ3JCLEtBQUssU0FBUyxPQUFPLEtBQUssS0FBSyxNQUFNLENBQUMsQ0FBQyxRQUNwQyxPQUFPLFdBQVc7SUFDakIsR0FBRztJQUNILEdBQUcsT0FBTyxTQUFTLEtBQUssQ0FBQyxPQUFPLFNBQVMsS0FBSyxJQUFJLEdBQUcsUUFBUSxLQUFLLE9BQU8sT0FBTyxJQUFJLENBQUM7R0FDdkYsSUFDQSxDQUFDLENBQ0g7R0FDQSxLQUFLLFlBQVksT0FBTyxLQUFLLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUztHQUNuRCxJQUFJLGNBQWM7SUFDaEIsSUFBSSxPQUFPLFdBQVcsR0FDcEIsYUFBYSxVQUFVLENBQUMsQ0FBQztTQUV6QixPQUFPLFFBQVEsYUFBYSxXQUFXO0dBRTNDO0dBQ0EsT0FBTztFQUNUO0VBQ0Esb0JBQW9CLEdBQUcsUUFBUTtHQUM3QixLQUFLLE1BQU0sR0FBRyxNQUFNO0dBQ3BCLEtBQUssWUFBWSxHQUFHLE1BQU07R0FDMUIsT0FBTztFQUNUO0VBQ0EsZ0JBQWdCLGdCQUFnQjtFQUNoQyxhQUFhO0dBQ1gsTUFBTSxXQUFXLEtBQUssS0FBSztHQUMzQixJQUFJLG9CQUFvQixTQUFTLEdBQUc7SUFDbEMsTUFBTSxXQUFXLEVBQUUsR0FBRyxTQUFTO0lBQy9CLG9CQUFvQixTQUFTLE1BQU0sT0FBTyxTQUFTLEVBQUU7SUFDckQsT0FBTztLQUFFLE1BQU07S0FBVSxRQUFRLEtBQUs7SUFBTztHQUMvQztHQUNBLE9BQU87SUFBRSxNQUFNO0lBQVUsUUFBUSxLQUFLO0dBQU87RUFDL0M7RUFDQSxVQUFVLFdBQVc7R0FDbkIsT0FBTyxPQUFPLE1BQU0sVUFBVSxJQUFJO0dBQ2xDLEtBQUssU0FBUyxVQUFVLE1BQU07RUFDaEM7Q0FDRixDQUNxQjtDQUNyQixJQUFJLFVBQVUsUUFDWixVQUFVLFNBQVMsU0FBUyxNQUFNO0NBRXBDLE1BQ0UsaUJBQ007RUFDSixVQUFVLFVBQVUsQ0FBQyxRQUFRLFVBQVUsS0FBSyxHQUFHLFFBQVE7Q0FDekQsR0FDQTtFQUFFLFdBQVc7RUFBTSxNQUFNO0NBQUssQ0FDaEM7Q0FDQSxNQUNFLFlBQ0MsYUFBYTtFQUNaLElBQUksQ0FBQyxhQUNIO0VBRUYsTUFBTSxhQUFhRCxPQUFRLFFBQVEsV0FBVztFQUM5QyxNQUFNLFVBQVVDLFlBQVcsU0FBUyxXQUFXLENBQUM7RUFDaEQsSUFBSSxDQUFDLFFBQVEsWUFBWSxPQUFPLEdBQzlCLE9BQVEsU0FBUyxTQUFTLFdBQVc7Q0FFekMsR0FDQTtFQUFFLFdBQVc7RUFBTSxNQUFNO0NBQUssQ0FDaEM7Q0FDQSxJQUFJLHNCQUNGLFVBQVUsaUJBQWlCLG9CQUFvQjtDQUVqRCxPQUFPO0VBQ0wsTUFBTTtFQUNOLGNBQWMsZ0JBQWdCO0dBQzVCLFdBQVc7RUFDYjtFQUNBLG9CQUFvQjtFQUNwQiwrQkFBK0Isd0JBQXdCO0VBQ3ZELHdCQUF3QjtHQUN0QixVQUFVLFlBQVk7R0FDdEIsVUFBVSxnQkFBZ0I7R0FDMUIsVUFBVSxxQkFBcUI7R0FDL0IsOEJBQThCLGlCQUN0QixVQUFVLHFCQUFxQixPQUNyQyxPQUFPLElBQUksaUNBQWlDLENBQzlDO0VBQ0Y7RUFDQSxvQ0FBb0M7RUFDcEMsc0NBQXNDO0dBQ3BDLDRCQUE0QjtFQUM5QjtFQUNBLHlCQUF5QixTQUFTO0dBQ2hDLHNCQUFzQjtFQUN4QjtFQUNBLHlCQUF5QjtHQUN2QixVQUFVLGdCQUFnQjtHQUMxQixVQUFVLHFCQUFxQjtHQUMvQixhQUFhLDJCQUEyQjtFQUMxQztFQUNBLHdCQUF3QjtHQUN0QixVQUFVLGFBQWE7R0FDdkIsVUFBVSxXQUFXO0VBQ3ZCO0VBQ0EsZUFBZTtHQUNiLFNBQVM7R0FDVCxjQUFjO0lBQ1osZ0JBQWdCO0dBQ2xCO0VBQ0Y7Q0FDRjtBQUNGO0FBR0EsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSxnQkFBZ0I7QUFDcEIsU0FBUyxxQkFBcUIsTUFBTTtDQUNsQyxJQUFJLGVBQ0Y7Q0FFRixJQUFJLHFCQUFxQixNQUFNO0VBQzdCLGdCQUFnQjtFQUNoQixtQkFBbUIsSUFBSSxJQUFJLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDbkQsZ0JBQWdCO0NBQ2xCO0NBQ0EsTUFBTSxZQUFZLE9BQU8sS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsaUJBQWlCLElBQUksSUFBSSxDQUFDO0NBQy9FLElBQUksVUFBVSxTQUFTLEdBQ3JCLFFBQVEsTUFDTixrRkFBa0YsVUFBVSxLQUFLLE1BQU0sSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLDJGQUM5SDtBQUVKO0FBQ0EsU0FBUyxRQUFRLEdBQUcsTUFBTTtDQUN4QixNQUFNLEVBQUUsYUFBYSxNQUFNLHlCQUF5QkMsYUFBYyxzQkFBc0IsR0FBRyxJQUFJO0NBRS9GLHFCQUR3QixPQUFPLFNBQVMsYUFBYUMsWUFBVyxLQUFLLENBQUMsSUFBSUEsWUFBVyxJQUFJLENBQ3JEO0NBQ3BDLElBQUksY0FBYztDQUNsQixJQUFJLDRCQUE0QjtDQUNoQyxNQUFNLEVBQ0osTUFBTSxVQUNOLGFBQ0EsY0FDQSx5QkFDQSxrQkFDQSw4QkFDQSxnQ0FDQSx3QkFDQSxtQkFDQSxxQkFDRSxhQUFhO0VBQ2Y7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sT0FBTztDQUNiLE1BQU0sc0JBQXNCLFlBQVksS0FBSyxVQUFVLENBQUMsTUFBTTtFQUM1RCxLQUFLLE9BQU8sUUFBUSxLQUFLLE9BQU87Q0FDbEM7Q0FDQSxPQUFPLE9BQU8sTUFBTTtFQUNsQixPQUFPLEdBQUcsT0FBTztHQUNmLE1BQU0sRUFBRSxRQUFRLEtBQUssWUFBWUQsYUFBYyxxQkFBcUIsT0FBTyx3QkFBd0IsQ0FBQztHQUNwRywrQkFBK0I7R0FDL0IsTUFBTSxXQUFXO0lBQ2YsR0FBRztJQUNILGdCQUFnQixVQUFVO0tBQ3hCLGNBQWM7S0FDZCxPQUFPLFFBQVEsZ0JBQWdCLEtBQUs7SUFDdEM7SUFDQSxXQUFXLFVBQVU7S0FDbkIsa0JBQWtCO0tBQ2xCLE9BQU8sUUFBUSxXQUFXLEtBQUs7SUFDakM7SUFDQSxVQUFVLFVBQVU7S0FDbEIsS0FBSyxhQUFhO0tBQ2xCLE9BQU8sUUFBUSxVQUFVLEtBQUs7SUFDaEM7SUFDQSxhQUFhLFVBQVU7S0FDckIsS0FBSyxXQUFXLFNBQVM7S0FDekIsT0FBTyxRQUFRLGFBQWEsS0FBSztJQUNuQztJQUNBLFdBQVcsT0FBTyxVQUFVO0tBQzFCLGlCQUFpQjtLQUNqQixNQUFNLFlBQVksUUFBUSxZQUFZLE1BQU0sUUFBUSxVQUFVLEtBQUssSUFBSTtLQUN2RSxJQUFJLENBQUMsNkJBQTZCLEdBQUc7TUFDbkMsWUFBWUMsWUFBVyxLQUFLLEtBQUssQ0FBQyxDQUFDO01BQ25DLEtBQUssVUFBVTtLQUNqQjtLQUNBLE9BQU87SUFDVDtJQUNBLFVBQVUsV0FBVztLQUNuQixLQUFLLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTTtLQUNsQyxPQUFPLFFBQVEsVUFBVSxNQUFNO0lBQ2pDO0lBQ0EsZ0JBQWdCO0tBQ2QsT0FBTyxRQUFRLFdBQVc7SUFDNUI7SUFDQSxXQUFXLFVBQVU7S0FDbkIsaUJBQWlCO0tBQ2pCLGNBQWM7S0FDZCxPQUFPLFFBQVEsV0FBVyxLQUFLO0lBQ2pDO0dBQ0Y7R0FDQSxTQUFTLGFBQWEsU0FBUyxjQUFjLDZCQUE2QixLQUFLO0dBQy9FLDRCQUE0QjtHQUM1QixNQUFNLGtCQUFrQixhQUFhLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQztHQUNsRCxJQUFJLFdBQVcsVUFDYixPQUFRLE9BQU8sS0FBSztJQUFFLEdBQUc7SUFBVSxNQUFNO0dBQWdCLENBQUM7UUFFMUQsT0FBUSxPQUFPLENBQUMsS0FBSyxpQkFBaUIsUUFBUTtFQUVsRDtFQUNBLEtBQUssbUJBQW1CLEtBQUs7RUFDN0IsTUFBTSxtQkFBbUIsTUFBTTtFQUMvQixLQUFLLG1CQUFtQixLQUFLO0VBQzdCLE9BQU8sbUJBQW1CLE9BQU87RUFDakMsUUFBUSxtQkFBbUIsUUFBUTtFQUNuQyxTQUFTO0dBQ1AsSUFBSSxhQUNGLFlBQVksT0FBTztFQUV2QjtFQUNBLGFBQWEsR0FBRyxNQUFNO0dBQ3BCLHVCQUF1QixJQUFJO0dBQzNCLE9BQU87RUFDVDtFQUNBLFdBQVcsVUFBVTtHQUNuQiw0QkFBNEI7R0FDNUIsT0FBTztFQUNUO0NBQ0YsQ0FBQztDQUNELE9BQU8sd0JBQXdCLElBQUksT0FBTztBQUM1QztBQUdBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLElBQUksQ0FBQyxPQUNILE9BQU87Q0FFVCxJQUFJLE9BQU8sVUFBVSxZQUNuQixPQUFPO0NBRVQsSUFBSSxPQUFPLFVBQVUsVUFBVTtFQUM3QixNQUFNLE1BQU07RUFDWixPQUFPLE9BQU8sSUFBSSxXQUFXLGNBQWMsT0FBTyxJQUFJLFVBQVUsY0FBYyxPQUFPLElBQUksYUFBYSxZQUFZLFlBQVksT0FBTyxZQUFZO0NBQ25KO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUMvQixJQUFJLE9BQU8sVUFBVSxZQUNuQixPQUFPO0NBRVQsTUFBTSxLQUFLO0NBQ1gsT0FBTyxHQUFHLFdBQVcsS0FBSyxPQUFPLEdBQUcsY0FBYztBQUNwRDtBQUNBLElBQUksWUFBWUMsSUFBSyxLQUFLLENBQUM7QUFDM0IsSUFBSSxPQUFPQSxJQUFLO0FBQ2hCLElBQUksZUFBZTtBQUNuQixJQUFJLFNBQVMsV0FBVyxJQUFJO0FBQzVCLElBQUksTUFBTUEsSUFBSyxLQUFLLENBQUM7QUFDckIsSUFBSTtBQTZJSixJQUFJLGNBNUlNLGdCQUFnQjtDQUN4QixNQUFNO0NBQ04sT0FBTztFQUNMLGFBQWE7R0FDWCxNQUFNO0dBQ04sVUFBVTtFQUNaO0VBQ0Esa0JBQWtCO0dBQ2hCLE1BQU07R0FDTixVQUFVO0VBQ1o7RUFDQSxrQkFBa0I7R0FDaEIsTUFBTTtHQUNOLFVBQVU7RUFDWjtFQUNBLGVBQWU7R0FDYixNQUFNO0dBQ04sVUFBVTtHQUNWLFVBQVUsVUFBVTtFQUN0QjtFQUNBLGNBQWM7R0FDWixNQUFNO0dBQ04sVUFBVTtHQUNWLHFCQUFxQixDQUNyQjtFQUNGO0VBQ0EsZUFBZTtHQUNiLE1BQU07R0FDTixVQUFVO0VBQ1o7RUFDQSxZQUFZO0dBQ1YsTUFBTTtJQUFDO0lBQVM7SUFBUTtHQUFRO0dBQ2hDLFVBQVU7RUFDWjtDQUNGO0NBQ0EsTUFBTSxFQUNKLGFBQ0Esa0JBQ0Esa0JBQ0EsZUFDQSxjQUNBLGVBQ0EsY0FDQztFQUNELFVBQVUsUUFBUSxtQkFBbUIsUUFBUSxnQkFBZ0IsSUFBSSxLQUFLO0VBQ3RFLEtBQUssUUFBUTtHQUFFLEdBQUc7R0FBYSxPQUFPLFlBQVksU0FBUyxDQUFDO0VBQUU7RUFDOUQsSUFBSSxRQUFRLEtBQUs7RUFDakIsTUFBTSxXQUFXLE9BQU8sV0FBVztFQUNuQyxjQUFjLGtCQUNaLFdBQ0MsVUFBVSxnQkFBZ0IsY0FBYyxPQUFPLEtBQUssS0FBSyxJQUFJLE9BQzlELHVCQUF1QixDQUN2QixJQUNBLGtCQUFrQixhQUFhLFVBQVUsQ0FDM0M7RUFDQSxJQUFJLENBQUMsVUFBVTtHQUNiLE9BQVEsS0FBSztJQUNYO0lBQ0E7SUFDQSxlQUFlLE9BQU8sWUFBWTtLQUNoQyxJQUFJLENBQUMsUUFBUSxlQUNYLGlCQUFpQjtLQUVuQixVQUFVLFFBQVEsUUFBUSxRQUFRLFNBQVM7S0FDM0MsS0FBSyxRQUFRLFFBQVE7S0FDckIsSUFBSSxRQUFRLFFBQVEsZ0JBQWdCLElBQUksUUFBUSxLQUFLLElBQUk7SUFDM0Q7SUFDQSxVQUFVLFVBQVU7S0FDbEIsS0FBSyxRQUFRO01BQUUsR0FBRyxLQUFLO01BQU87S0FBTTtJQUN0QztHQUNGLENBQUM7R0FDRCxNQUFNLGtCQUFrQixVQUFVO0lBQ2hDLFlBQVksaUJBQWlCLGtCQUFrQixNQUFNLE9BQU8sTUFBTSxVQUFVLENBQUM7R0FDL0U7R0FDQSxPQUFRLEdBQUcsWUFBWSxjQUFjO0dBQ3JDLE9BQVEsR0FBRyxlQUFlLGNBQWM7RUFDMUM7RUFDQSxhQUFhO0dBQ1gsSUFBSSxVQUFVLE9BQU87SUFDbkIsVUFBVSxNQUFNLGVBQWUsQ0FBQyxDQUFDLFVBQVUsTUFBTTtJQUNqRCxNQUFNLFFBQVEsRUFBRSxVQUFVLE9BQU87S0FDL0IsR0FBRyxLQUFLLE1BQU07S0FDZCxLQUFLLElBQUk7SUFDWCxDQUFDO0lBQ0QsSUFBSSxPQUFPLE9BQU87S0FDaEIsVUFBVSxNQUFNLFNBQVMsT0FBTztLQUNoQyxPQUFPLFFBQVE7SUFDakI7SUFDQSxJQUFJLFVBQVUsTUFBTSxVQUFVLGlCQUFpQixVQUFVLE1BQU0sTUFBTSxHQUNuRSxPQUFPLFVBQVUsTUFBTSxPQUFPLEdBQUcsS0FBSztJQUV4QyxJQUFJO0lBQ0osSUFBSSxnQkFBZ0I7SUFDcEIsTUFBTSxjQUFjLFVBQVUsTUFBTTtJQUNwQyxJQUFJLE9BQU8sZ0JBQWdCLGNBQWMsWUFBWSxVQUFVLEtBQUssT0FBTyxZQUFZLGNBQWMsYUFBYTtLQUNoSCxNQUFNLFNBQVMsWUFBWSxLQUFLLE1BQU0sS0FBSztLQUMzQyxJQUFJLHdCQUF3QixRQUFRLFdBQVcsR0FBRztNQUNoRCxrQkFBa0IsZ0JBQWdCLEtBQUssTUFBTSxXQUFXLEtBQUssS0FBSztNQUNsRSxnQkFBZ0I7S0FDbEIsT0FDRSxrQkFBa0I7SUFFdEIsT0FBTyxJQUFJLGNBQWMsYUFBYSxXQUFXLEdBQUc7S0FDbEQsa0JBQWtCLGdCQUFnQixLQUFLLE1BQU0sV0FBVyxLQUFLLEtBQUs7S0FDbEUsZ0JBQWdCO0lBQ2xCLE9BQ0Usa0JBQWtCLGVBQWUsZ0JBQWdCLEtBQUssTUFBTSxXQUFXLEtBQUssS0FBSztJQUVuRixJQUFJLGlCQUFpQjtLQUNuQixJQUFJLFVBQVUsaUJBQ1osaUJBQ0EsYUFDQSxVQUFVLE1BQU0sVUFBVSxDQUFDLGdCQUFnQixtQkFBbUIsS0FBSyxDQUNyRTtLQUNBLElBQUksZUFDRixVQUFVLFFBQVEsS0FBSyxPQUFPO01BQUUsR0FBRztNQUFHLE9BQU87T0FBRSxHQUFHLEVBQUU7T0FBTyxHQUFHO01BQWM7S0FBRSxFQUFFO0tBRWxGLElBQUksUUFBUSxTQUFTLEdBQUc7TUFDdEIsTUFBTSxlQUFlLFdBQVc7T0FBRSxRQUFRLENBQUM7T0FBRyxPQUFPLENBQUM7TUFBRSxJQUFJLE1BQU07TUFDbEUsT0FBTyxRQUFRLGFBQWEsV0FBVyxZQUFZO09BQ2pELE1BQU0sa0JBQWtCLFFBQVE7T0FDaEMsZ0JBQWdCLGVBQWUsQ0FBQyxDQUFDLGdCQUFnQjtPQUNqRCxPQUFPLEVBQ0wsaUJBQ0E7UUFDRSxHQUFHLEtBQUssTUFBTTtRQUNkLEdBQUcsUUFBUTtRQUNYLEdBQUcsYUFBYTtRQUNoQixHQUFHLFFBQVEsT0FBTyxhQUFhLE1BQU0sUUFBUSxTQUFTLENBQUMsSUFBSSxDQUFDO09BQzlELFNBQ00sU0FDUjtNQUNGLEdBQUcsS0FBSztLQUNWO0lBQ0Y7SUFDQSxPQUFPO0dBQ1Q7RUFDRjtDQUNGO0FBQ0YsQ0FDb0I7QUFDcEIsSUFBSSxTQUFTLEVBQ1gsUUFBUSxLQUFLO0NBQ1gsT0FBUSxPQUFPO0NBQ2YsT0FBTyxlQUFlLElBQUksT0FBTyxrQkFBa0IsWUFBWSxFQUFFLFdBQVdDLE9BQVEsQ0FBQztDQUNyRixPQUFPLGVBQWUsSUFBSSxPQUFPLGtCQUFrQixTQUFTLEVBQUUsV0FBVyxLQUFLLE1BQU0sQ0FBQztDQUNyRixPQUFPLGVBQWUsSUFBSSxPQUFPLGtCQUFrQixnQkFBZ0IsRUFBRSxXQUFXLFlBQVksQ0FBQztDQUM3RixJQUFJLE1BQU0sZ0JBQWdCO0FBQzVCLEVBQ0Y7QUFDQSxTQUFTLFVBQVU7Q0FDakIsSUFBSSxDQUFDLGNBQ0gsZUFBZUMsU0FBVTtFQUN2QixPQUFPLGVBQWUsS0FBSyxPQUFPLEtBQUs7RUFDdkMsS0FBSyxlQUFlLEtBQUssT0FBTyxHQUFHO0VBQ25DLFdBQVcsZUFBZSxLQUFLLE9BQU8sU0FBUztFQUMvQyxTQUFTLGVBQWUsS0FBSyxPQUFPLE9BQU87RUFDM0MsY0FBYyxlQUFlLEtBQUssT0FBTyxZQUFZO0VBQ3JELGVBQWUsZUFBZSxLQUFLLE9BQU8sYUFBYTtFQUN2RCxjQUFjLGVBQWUsS0FBSyxPQUFPLFlBQVk7RUFDckQsWUFBWSxlQUFlLEtBQUssT0FBTyxVQUFVO0VBQ2pELGNBQWMsZUFBZSxLQUFLLE9BQU8sWUFBWTtFQUNyRCxnQkFBZ0IsZUFBZSxLQUFLLE9BQU8sY0FBYztFQUN6RCxjQUFjLGVBQWUsS0FBSyxPQUFPLFlBQVk7RUFDckQsaUJBQWlCLGVBQWUsS0FBSyxPQUFPLGVBQWU7RUFDM0QsZ0JBQWdCLGVBQWUsS0FBSyxPQUFPLGNBQWM7RUFDekQsYUFBYSxlQUFlLEtBQUssT0FBTyxXQUFXO0VBQ25ELE9BQU8sZUFBZSxLQUFLLE9BQU8sS0FBSztDQUN6QyxDQUFDO0NBRUgsT0FBTztBQUNUO0FBWUEsZUFBZSxpQkFBaUIsRUFDOUIsS0FBSyxPQUNMLFNBQ0EsT0FDQSxPQUNBLFVBQVUsWUFBWSxDQUFDLEdBQ3ZCLE1BQU0sT0FDTixRQUNBLFdBQVcsQ0FBQyxHQUNaLE9BQ0EsTUFBTSxPQUNOLFFBQVEsU0FDUixZQUNBLFNBQ0EsTUFBTSxDQUFDLENBQUMsWUFBWSxLQUFLLFFBQ3ZCLENBQUMsR0FBRztDQUNOLE9BQU8sUUFBUSxRQUFRO0NBQ3ZCLElBQUksT0FDRixPQUFPLElBQUksU0FBUyxLQUFLO0NBRTNCLElBQUksT0FDRixLQUFXLFVBQVUsS0FBSztDQUU1QixJQUFJLEtBQ0YsbUJBQW1CO0NBRXJCLE1BQU0sV0FBVyxPQUFPLFdBQVc7Q0FDbkMsTUFBTSxvQkFBb0IsTUFBTSxVQUFVLFFBQVEsUUFBUSxRQUFRLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVcsT0FBTyxXQUFXLE1BQU07Q0FDekgsSUFBSSxZQUFZLENBQUMsU0FBUyxDQUFDLFFBQ3pCLE9BQU8sT0FBTyxPQUFPLG1CQUFtQjtFQUN0QyxJQUFJLFFBQVEsQ0FBQztFQUViLE1BQU0sUUFBUTtHQUNaLGFBQWE7R0FDYixrQkFBQSxNQUg2QixpQkFBaUIsTUFBTSxXQUFXLEtBQUs7R0FJcEU7R0FDQSxlQUFlO0dBQ2YsZUFBZSxhQUFhLFFBQVE7R0FDcEMsZUFBZTtHQUNmO0VBQ0Y7RUFDQSxJQUFJO0VBQ0osSUFBSSxPQUNGLFVBQVUsTUFBTTtHQUNkLElBQUk7R0FDSixLQUFLO0dBQ0w7R0FDQTtFQUNGLENBQUM7T0FDSTtHQUNMLFVBQVUsYUFBYSxFQUFFLGNBQWNDLEVBQUcsYUFBYSxLQUFLLEVBQUUsQ0FBQztHQUMvRCxRQUFRLElBQUksTUFBTTtHQUNsQixJQUFJLFNBQ0YsUUFBUSxTQUFTO0lBQUUsS0FBSztJQUFNLE1BQU07R0FBTSxDQUFDO0VBRS9DO0VBRUEsTUFBTSxPQUFPLGFBQWEsSUFBSSxPQUFPLE1BRGxCLGVBQWUsT0FBTyxDQUNBO0VBQ3pDLE9BQU87R0FBRSxNQUFNO0dBQU87RUFBSztDQUM3QjtDQUVGLE1BQU0sY0FBYyxTQUFTLHNCQUFzQixFQUFFO0NBQ3JELElBQUksT0FBTyxDQUFDO0NBQ1osTUFBTSxTQUFTLE1BQU0sUUFBUSxJQUFJLENBQy9CLGlCQUFpQixZQUFZLFdBQVcsV0FBVyxHQUNuREMsT0FBUSxlQUFlLENBQUMsQ0FBQyxZQUFZLENBQ3JDLENBQUMsQ0FDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsc0JBQXNCO0VBQzlCLE1BQU0sUUFBUTtHQUNaO0dBQ0E7R0FDQTtHQUNBLGVBQWU7R0FDZixjQUFjLFlBQVksYUFBYSxPQUFPLFdBQVcsS0FBSztHQUM5RCxlQUFlO0dBQ2Y7RUFDRjtFQUNBLElBQUksVUFDRixPQUFPLE1BQU07R0FDWCxJQUFJO0dBQ0osS0FBSztHQUNMO0dBQ0E7RUFDRixDQUFDO0VBRUgsTUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0VBQ3JDLElBQUksT0FDRixPQUFPLE1BQU07R0FDWDtHQUNBLEtBQUs7R0FDTDtHQUNBO0VBQ0YsQ0FBQztFQUVILElBQUksR0FBRyxhQUFhLHNCQUFzQixHQUFHO0dBQzNDLE1BQU0sTUFBTSxhQUFhLEVBQUUsY0FBY0QsRUFBRyxhQUFhLEtBQUssRUFBRSxDQUFDO0dBQ2pFLElBQUksSUFBSSxNQUFNO0dBQ2QsSUFBSSxTQUNGLFFBQVEsS0FBSztJQUFFLEtBQUs7SUFBTyxNQUFNO0dBQVksQ0FBQztHQUVoRCxJQUFJLE1BQU0sRUFBRTtFQUNkLE9BQU87R0FDTCxNQUFNLE1BQU0sVUFBVSxFQUFFLGNBQWNBLEVBQUcsYUFBYSxLQUFLLEVBQUUsQ0FBQztHQUM5RCxJQUFJLElBQUksTUFBTTtHQUNkLElBQUksU0FDRixRQUFRLEtBQUs7SUFBRSxLQUFLO0lBQU8sTUFBTTtHQUFZLENBQUM7R0FFaEQsSUFBSSxNQUFNLEVBQUU7RUFDZDtDQUNGLENBQUM7Q0FDRCxJQUFJLENBQUMsWUFBWSxXQUNmLGNBQWMsU0FBUztDQUV6QixJQUFJLFlBQVksVUFBVSxRQUFRO0VBRWhDLE1BQU0sT0FBTyxhQUFhLElBQUksYUFBYSxNQUR4QixPQUFPLE1BQU0sQ0FDZTtFQUMvQyxPQUFPO0dBQUU7R0FBTTtFQUFLO0NBQ3RCO0FBQ0Y7QUFNQSxJQUFJLG1CQUFtQkUsZ0JBQWlCO0NBQ3RDLE1BQU07Q0FDTixPQUFPLEVBQ0wsTUFBTTtFQUNKLE1BQU0sQ0FBQyxRQUFRLEtBQUs7RUFDcEIsVUFBVTtDQUNaLEVBQ0Y7Q0FDQSxPQUFPO0NBQ1AsTUFBTSxPQUFPLEVBQUUsU0FBUztFQUN0QixNQUFNLFlBQVlDLElBQUssS0FBSztFQUM1QixNQUFNLGdDQUFnQyxJQUFJLElBQUk7RUFDOUMsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxPQUFPQyxlQUFnQixNQUFNLFFBQVEsTUFBTSxJQUFJLElBQUksTUFBTSxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUM7RUFDbEYsTUFBTSxjQUFjQSxlQUFnQixJQUFJLElBQUksTUFBTSxZQUFZLENBQUM7RUFDL0QsSUFBSSxzQkFBc0I7RUFDMUIsSUFBSSx1QkFBdUI7RUFDM0IsZ0JBQWdCO0dBQ2Qsc0JBQXNCQyxPQUFRLEdBQUcsVUFBVSxNQUFNO0lBQy9DLE1BQU0sUUFBUSxFQUFFLE9BQU87SUFDdkIsSUFBSSxNQUFNLGtCQUFrQixRQUFRLDRCQUE0QixNQUFNLEtBQUssT0FBTyxRQUFRLEtBQUssK0JBQStCLE9BQU8sS0FBSyxLQUFLLEdBQUc7S0FDaEosY0FBYyxJQUFJLEtBQUs7S0FDdkIsVUFBVSxRQUFRO0lBQ3BCO0dBQ0YsQ0FBQztHQUNELHVCQUF1QkEsT0FBUSxHQUFHLFdBQVcsTUFBTTtJQUNqRCxNQUFNLFFBQVEsRUFBRSxPQUFPO0lBQ3ZCLElBQUksY0FBYyxJQUFJLEtBQUssR0FBRztLQUM1QixjQUFjLE9BQU8sS0FBSztLQUMxQixVQUFVLFFBQVEsY0FBYyxPQUFPO0lBQ3pDO0dBQ0YsQ0FBQztFQUNILENBQUM7RUFDRCxrQkFBa0I7R0FDaEIsc0JBQXNCO0dBQ3RCLHVCQUF1QjtHQUN2QixjQUFjLE1BQU07RUFDdEIsQ0FBQztFQUNELGFBQWE7R0FDWCxJQUFJLENBQUMsTUFBTSxVQUNULE1BQU0sSUFBSSxNQUFNLHFEQUFxRDtHQUV2RSxNQUFNLGtCQUFrQixLQUFLLE1BQU0sT0FBTyxTQUFTQyxJQUFLLE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxDQUFDO0dBQ3JGLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxNQUFNLFNBQVMsWUFBWSxNQUFNLElBQUksSUFBSSxDQUFDO0dBQzdFLE1BQU0sWUFBWSxFQUFFLFdBQVcsVUFBVSxNQUFNO0dBQy9DLElBQUksbUJBQW1CLENBQUMsaUJBQ3RCLE9BQU9DLEVBQUcsVUFBVSxFQUFFLEtBQUssVUFBVSxHQUFHLE1BQU0sVUFBVSxTQUFTLEtBQUssQ0FBQyxDQUFDO0dBRTFFLElBQUksbUJBQW1CLE1BQU0sUUFDM0IsT0FBT0EsRUFBRyxVQUFVLEVBQUUsS0FBSyxTQUFTLEdBQUcsTUFBTSxPQUFPLFNBQVMsQ0FBQztHQUVoRSxPQUFPQSxFQUFHLFVBQVUsRUFBRSxLQUFLLFdBQVcsR0FBRyxNQUFNLFNBQVMsQ0FBQyxDQUFDLENBQUM7RUFDN0Q7Q0FDRjtBQUNGLENBQUM7QUF5QkQsSUFBSSxhQUFhLEtBQUs7QUFDdEIsSUFBSSxpQkFBaUMsdUJBQU8sb0JBQW9CO0FBQ2hFLElBQUksT0FBT0MsZ0JBQWlCO0NBQzFCLE1BQU07Q0FDTixPQUFPO0NBQ1AsT0FBTztFQUNMLFFBQVE7R0FDTixNQUFNLENBQUMsUUFBUSxNQUFNO0dBQ3JCLFNBQVM7RUFDWDtFQUNBLFFBQVE7R0FDTixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsU0FBUztHQUNQLE1BQU07R0FDTixnQkFBZ0IsQ0FBQztFQUNuQjtFQUNBLHdCQUF3QjtHQUN0QixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsVUFBVTtHQUNSLE1BQU0sQ0FBQyxRQUFRLElBQUk7R0FDbkIsU0FBUztFQUNYO0VBQ0EsY0FBYztHQUNaLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxXQUFXO0dBQ1QsTUFBTTtHQUNOLFVBQVUsU0FBUztFQUNyQjtFQUNBLFNBQVM7R0FDUCxNQUFNO0dBQ04sZ0JBQWdCLENBQUM7RUFDbkI7RUFDQSxjQUFjO0dBQ1osTUFBTSxDQUFDLFNBQVMsS0FBSztHQUNyQixTQUFTO0VBQ1g7RUFDQSxnQkFBZ0I7R0FDZCxNQUFNLENBQUMsU0FBUyxLQUFLO0dBQ3JCLFNBQVM7RUFDWDtFQUNBLHNCQUFzQjtHQUNwQixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsZUFBZTtHQUNiLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxVQUFVO0dBQ1IsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFNBQVM7R0FDUCxNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsWUFBWTtHQUNWLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxVQUFVO0dBQ1IsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFVBQVU7R0FDUixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsV0FBVztHQUNULE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxTQUFTO0dBQ1AsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLGtCQUFrQjtHQUNoQixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0Esd0JBQXdCO0dBQ3RCLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxpQkFBaUI7R0FDZixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EscUJBQXFCO0dBQ25CLE1BQU0sQ0FBQyxRQUFRLEtBQUs7R0FDcEIsZUFBZSxDQUFDO0VBQ2xCO0VBQ0EsZUFBZTtHQUNiLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxtQkFBbUI7R0FDakIsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFlBQVk7R0FDVixNQUFNO0dBQ04sU0FBUyxLQUFLO0VBQ2hCO0VBQ0EsZUFBZTtHQUNiLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxXQUFXO0dBQ1QsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFNBQVM7R0FDUCxNQUFNO0dBQ04sU0FBUztFQUNYO0NBQ0Y7Q0FDQSxNQUFNLE9BQU8sRUFBRSxPQUFPLE9BQU8sVUFBVTtFQUNyQyxNQUFNLDJCQUEyQjtHQUMvQixNQUFNLENBQUMsTUFBTSxRQUFRLGNBQWM7R0FDbkMsT0FBTyxNQUFNLFVBQVUsSUFBSTtFQUM3QjtFQUNBLE1BQU0sT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQ2pCLE9BQU8sYUFDUCxjQUFjLENBQUMsQ0FBQyxFQUN4QixDQUFDLENBQUMsVUFBVSxrQkFBa0IsQ0FBQyxDQUFDLHFCQUFxQixNQUFNLGlCQUFpQjtFQUM1RSxJQUFJLE1BQU0sZUFDUixLQUFLLGNBQWM7RUFFckIsSUFBSSxNQUFNLGlCQUFpQkMsU0FBUSxJQUFJLG9CQUFvQixHQUN6RCxLQUFLLGNBQWM7RUFFckIsTUFBTSxjQUFjQyxJQUFLO0VBQ3pCLE1BQU0sU0FBU0MsZUFDUCxnQkFBZ0IsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLFNBQVMsTUFBTSxPQUFPLFlBQVksQ0FDdkY7RUFDQSxNQUFNLG9CQUFvQkEsZUFBZ0I7R0FDeEMsSUFBSSxNQUFNLFdBQ1IsT0FBTyxNQUFNO0dBRWYsSUFBSSxNQUFNLFdBQVcsZ0JBQWdCLE1BQU0sTUFBTSxHQUMvQyxPQUFPLDhCQUE4QixNQUFNLE1BQU07R0FFbkQsT0FBTztFQUNULENBQUM7RUFDRCxNQUFNLFVBQVVELElBQUssS0FBSztFQUMxQixNQUFNLGNBQWNBLElBQUssSUFBSSxTQUFTLENBQUM7RUFDdkMsTUFBTSxnQkFBZ0IsVUFBVTtHQUM5QixJQUFJLE1BQU0sU0FBUyxXQUFXLE1BQU0sU0FBUywyQkFDM0MsTUFBTSxlQUFlO0dBRXZCLFFBQVEsUUFBUSxNQUFNLFNBQVMsVUFBVSxRQUFRLENBQUNFLFFBQVMsUUFBUSxHQUFHLGlCQUFpQixZQUFZLEtBQUssQ0FBQztFQUMzRztFQUNBLE1BQU0sYUFBYTtHQUFDO0dBQVM7R0FBVTtFQUFPO0VBQzlDLGdCQUFpQjtHQUNmLFlBQVksUUFBUSxZQUFZO0dBQ2hDLEtBQUssU0FBUyxRQUFRLENBQUM7R0FDdkIsV0FBVyxTQUFTLE1BQU0sWUFBWSxNQUFNLGlCQUFpQixHQUFHLFlBQVksQ0FBQztFQUMvRSxDQUFDO0VBQ0QsWUFDUSxNQUFNLGdCQUNYLFVBQVUsUUFBUSxLQUFLLGNBQWMsSUFBSSxLQUFLLHNCQUFzQixDQUN2RTtFQUNBLFlBQ1EsTUFBTSxvQkFDWCxVQUFVLEtBQUsscUJBQXFCLEtBQUssQ0FDNUM7RUFDQSxzQkFBc0I7R0FDcEIsV0FBVyxTQUFTLE1BQU0sWUFBWSxPQUFPLG9CQUFvQixHQUFHLFlBQVksQ0FBQztHQUNqRixJQUFJLE1BQU0saUJBQ1IsS0FBSyxPQUFPO0VBRWhCLENBQUM7RUFDRCxNQUFNLGVBQWUsY0FBYyxJQUFJLFNBQVMsWUFBWSxPQUFPLFNBQVM7RUFDNUUsTUFBTSxXQUFXLGNBQWMsaUJBQWlCLFlBQVksU0FBUyxDQUFDO0VBQ3RFLE1BQU0saUJBQWlCLGNBQWM7R0FDbkMsT0FBTyx5QkFDTCxPQUFPLE9BQ1AsZ0JBQWdCLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxNQUFNLE1BQU0sUUFDekQsUUFBUSxTQUFTLEdBQ2pCLE1BQU0sc0JBQ1I7RUFDRjtFQUNBLE1BQU0sVUFBVSxjQUFjO0dBQzVCLE1BQU0sQ0FBQyxLQUFLLFFBQVEsY0FBYyxTQUFTO0dBRTNDLElBRG1CLFdBQVcsYUFBYSxZQUFZLE1BQ3BDLFlBQVksT0FBTyxVQUFVLE9BQU87SUFDckQsT0FBTyxLQUFLLEtBQUssUUFBUTtJQUN6QjtHQUNGO0dBQ0EsTUFBTSxjQUFjLGdCQUFnQjtJQUNsQyxJQUFJLENBQUMsYUFDSDtJQUVGLElBQUksZ0JBQWdCLE1BQ2xCLE1BQU07U0FDRCxJQUFJLFlBQVksU0FBUyxHQUM5QixNQUFNLEdBQUcsV0FBVztHQUV4QjtHQUNBLE1BQU0sZ0JBQWdCO0lBQ3BCLFNBQVMsTUFBTTtJQUNmLHdCQUF3QixNQUFNO0lBQzlCLFVBQVUsTUFBTTtJQUNoQixjQUFjLE1BQU07SUFDcEIscUJBQXFCLE1BQU07SUFDM0IsV0FBVyxrQkFBa0I7SUFDN0IsWUFBWSxNQUFNLGNBQWMsY0FBYyxNQUFNLFdBQVcsV0FBVyxJQUFJLElBQUksS0FBSztJQUN2RixlQUFlLE1BQU07SUFDckIsVUFBVSxNQUFNO0lBQ2hCLFNBQVMsTUFBTTtJQUNmLFlBQVksTUFBTTtJQUNsQixVQUFVLE1BQU07SUFDaEIsVUFBVSxNQUFNO0lBQ2hCLFdBQVcsT0FBTyxHQUFHLFNBQVM7S0FDNUIsTUFBTSxTQUFTLE1BQU0sTUFBTSxZQUFZLEdBQUcsSUFBSTtLQUM5QyxNQUFNLG1CQUFtQixPQUFPO0tBQ2hDLFdBQVcsTUFBTSxjQUFjO0tBQy9CLElBQUksTUFBTSx5QkFBeUIsTUFDakMsU0FBUztLQUVYLE9BQU87SUFDVDtJQUNBLFVBQVUsR0FBRyxTQUFTO0tBQ3BCLE1BQU0sVUFBVSxHQUFHLElBQUk7S0FDdkIsV0FBVyxNQUFNLFlBQVk7SUFDL0I7SUFDQSxHQUFHLE1BQU07R0FDWDtHQUNBLEtBQUssZ0JBQWdCLE1BQU0sVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxPQUFPLEtBQUssYUFBYTtHQUNuRixLQUFLLFVBQVUsa0JBQWtCO0VBQ25DO0VBQ0EsTUFBTSxTQUFTLEdBQUcsV0FBVztHQUMzQixnQkFBZ0IsWUFBWSxPQUFPLFlBQVksT0FBTyxNQUFNO0dBQzVELEtBQUssTUFBTSxHQUFHLE1BQU07RUFDdEI7RUFDQSxNQUFNLGVBQWUsR0FBRyxXQUFXO0dBQ2pDLEtBQUssWUFBWSxHQUFHLE1BQU07RUFDNUI7RUFDQSxNQUFNLHVCQUF1QixHQUFHLFdBQVc7R0FDekMsWUFBWSxHQUFHLE1BQU07R0FDckIsTUFBTSxHQUFHLE1BQU07RUFDakI7RUFDQSxNQUFNLGlCQUFpQjtHQUNyQixZQUFZLFFBQVEsWUFBWTtHQUNoQyxRQUFRLFFBQVE7RUFDbEI7RUFDQSxNQUFNLFVBQVU7R0FDZCxJQUFJLFNBQVM7SUFDWCxPQUFPLEtBQUs7R0FDZDtHQUNBLElBQUksWUFBWTtJQUNkLE9BQU8sS0FBSztHQUNkO0dBQ0EsSUFBSSxhQUFhO0lBQ2YsT0FBTyxLQUFLO0dBQ2Q7R0FDQSxJQUFJLFdBQVc7SUFDYixPQUFPLEtBQUs7R0FDZDtHQUNBLElBQUksZ0JBQWdCO0lBQ2xCLE9BQU8sS0FBSztHQUNkO0dBQ0EsSUFBSSxxQkFBcUI7SUFDdkIsT0FBTyxLQUFLO0dBQ2Q7R0FDQSxJQUFJLGFBQWE7SUFDZixPQUFPLEtBQUs7R0FDZDtHQUNBO0dBQ0E7R0FDQSxXQUFXLGVBQWUsZUFBZSxLQUFLLFNBQVMsT0FBTyxrQkFBa0IsV0FBVyxHQUFHLGdCQUFnQixXQUFXLElBQUksYUFBYTtHQUMxSSxJQUFJLFVBQVU7SUFDWixPQUFPLFFBQVE7R0FDakI7R0FDQTtHQUNBO0dBQ0EsY0FBYyxLQUFLLE9BQU87R0FDMUI7R0FDQTtHQUNBO0dBRUEsT0FBTyxLQUFLO0dBQ1osT0FBTyxLQUFLO0dBQ1osU0FBUyxLQUFLO0dBQ2QsU0FBUyxLQUFLO0dBQ2QsV0FBVyxPQUFPLFlBQVksS0FBSyxTQUFTLEdBQUdDLGFBQWMsMEJBQTBCLE9BQU8sU0FBUyxNQUFNLE9BQU8sQ0FBQztHQUNySCxpQkFBaUIsS0FBSyxVQUFVO0VBQ2xDO0VBQ0EsT0FBTyxPQUFPO0VBQ2QsUUFBUSxnQkFBZ0IsT0FBTztFQUMvQixhQUFhO0dBQ1gsT0FBT0MsRUFDTCxRQUNBO0lBQ0UsR0FBRztJQUNILEtBQUs7SUFDTCxRQUFRLGdCQUFnQixNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sTUFBTSxNQUFNO0lBQ2pFLFFBQVEsT0FBTztJQUNmLFdBQVcsVUFBVTtLQUNuQixNQUFNLGVBQWU7S0FDckIsT0FBTyxNQUFNLFNBQVM7SUFDeEI7SUFDQSxPQUFPLE1BQU0sMEJBQTBCLEtBQUs7R0FDOUMsR0FDQSxNQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sSUFBSSxDQUFDLENBQzVDO0VBQ0Y7Q0FDRjtBQUNGLENBQUM7QUFDRCxTQUFTLGlCQUFpQjtDQUN4QixPQUFPLE9BQU8sY0FBYztBQUM5QjtBQUNBLFNBQVMsYUFBYTtDQUNwQixPQUFPO0FBQ1Q7QUFDQSxJQUFJLGVBQWU7QUFLbkIsU0FBUyxXQUFXLE1BQU07Q0FDeEIsT0FBTyxPQUFPLEtBQUssU0FBUyxZQUFZO0VBQ3RDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUMsQ0FBQyxRQUFRLEtBQUssSUFBSSxJQUFJO0FBQ3pCO0FBQ0EsU0FBUyxlQUFlLE1BQU07Q0FDNUIsS0FBSyxRQUFRLEtBQUssU0FBUyxDQUFDO0NBQzVCLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxNQUFNLGdCQUFnQixLQUFLLElBQUksS0FBSyxNQUFNLGNBQWM7Q0FDMUYsTUFBTSxRQUFRLE9BQU8sS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTO0VBQzVELE1BQU0sUUFBUSxPQUFPLEtBQUssTUFBTSxLQUFLO0VBQ3JDLElBQUksQ0FBQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxHQUNuQyxPQUFPO09BQ0YsSUFBSSxVQUFVLElBQ25CLE9BQU8sUUFBUSxJQUFJO09BRW5CLE9BQU8sUUFBUSxJQUFJLEtBQUssSUFBSSxPQUFPLEtBQUssRUFBRTtDQUU5QyxHQUFHLEVBQUU7Q0FDTCxPQUFPLElBQUksT0FBTyxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ3ZDO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUMvQixNQUFNLEVBQUUsYUFBYTtDQUNyQixJQUFJLE9BQU8sYUFBYSxVQUN0QixPQUFPO0NBRVQsSUFBSSxNQUFNLFFBQVEsUUFBUSxHQUN4QixPQUFPLFNBQVMsUUFBUSxNQUFNLFVBQVU7RUFDdEMsT0FBTyxPQUFPLFVBQVUsS0FBSztDQUMvQixHQUFHLEVBQUU7Q0FFUCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsTUFBTTtDQUM1QixPQUFPLE9BQU8sS0FBSyxTQUFTO0FBQzlCO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTTtDQUM3QixPQUFPLE9BQU8sS0FBSyxTQUFTO0FBQzlCO0FBQ0EsU0FBUyxjQUFjLE1BQU07Q0FDM0IsT0FBTyxpQkFBaUIsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDO0FBQ25EO0FBQ0EsU0FBUyxlQUFlLE1BQU07Q0FDNUIsT0FBTyw2QkFBNkIsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDO0FBQy9EO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDeEIsT0FBTyxjQUFjLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQztBQUNoRDtBQUNBLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUksV0FBVyxJQUFJLEdBQ2pCLE9BQU8sT0FBTyxLQUFLLFFBQVE7TUFDdEIsSUFBSSxlQUFlLElBQUksR0FDNUIsT0FBTztNQUNGLElBQUksY0FBYyxJQUFJLEdBQzNCLE9BQU87Q0FFVCxJQUFJLE9BQU8sZUFBZSxJQUFJO0NBQzlCLElBQUksS0FBSyxVQUNQLFFBQVEsa0JBQWtCLElBQUk7Q0FFaEMsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUNsQixRQUFRLEtBQUssT0FBTyxLQUFLLElBQUksRUFBRTtDQUVqQyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixVQUFVLE9BQU87Q0FDeEMsSUFBSSxTQUFTLENBQUMsU0FBUyxNQUFNLFFBQVEsSUFBSSxXQUFXLFFBQVEsQ0FBQyxHQUMzRCxTQUFTLEtBQUssMEJBQTBCLE9BQU8sS0FBSyxFQUFFLFNBQVM7Q0FFakUsT0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLE9BQU8sT0FBTztDQUVqQyxPQUFPLGdCQURVLE1BQU0sU0FBUyxTQUFTLFlBQVksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxJQUM5RSxHQUFHLEtBQUs7QUFDeEM7QUFDQSxTQUFTLFlBQVksTUFBTTtDQUN6QixJQUFJLGVBQWUsSUFBSSxHQUNyQixPQUFPLFlBQVksS0FBSyxLQUFLLENBQUM7TUFDekIsSUFBSSxnQkFBZ0IsSUFBSSxHQUFHO0VBQ2hDLFFBQVEsS0FBSyw0REFBNEQ7RUFDekUsT0FBTyxDQUFDO0NBQ1YsT0FBTyxJQUFJLFdBQVcsSUFBSSxLQUFLLEtBQUssVUFDbEMsT0FBTztNQUNGLElBQUksZUFBZSxJQUFJLEtBQUssS0FBSyxVQUN0QyxPQUFPLEtBQUssU0FBUyxTQUFTLFVBQVUsWUFBWSxLQUFLLENBQUM7TUFDckQsSUFBSSxjQUFjLElBQUksR0FDM0IsT0FBTyxDQUFDO01BRVIsT0FBTztBQUVYO0FBa0JBLElBQUksZUFqQk9DLGdCQUFpQjtDQUMxQixPQUFPLEVBQ0wsT0FBTztFQUNMLE1BQU07RUFDTixVQUFVO0NBQ1osRUFDRjtDQUNBLE1BQU0sT0FBTyxFQUFFLFNBQVM7RUFDdEIsTUFBTSxXQUFXLFlBQVksZUFBZTtFQUM1QyxzQkFBdUI7R0FDckIsU0FBUyxXQUFXO0VBQ3RCLENBQUM7RUFDRCxhQUFhO0dBQ1gsU0FBUyxPQUFPLFlBQVksTUFBTSxVQUFVLE1BQU0sUUFBUSxJQUFJLENBQUMsR0FBRyxNQUFNLEtBQUssQ0FBQztFQUNoRjtDQUNGO0FBQ0YsQ0FDc0I7QUFRdEIsSUFBSSxzQkFBc0IsT0FBTyxhQUFhO0NBQzVDLElBQUksQ0FBQyxPQUNILE9BQU87Q0FFVCxJQUFJLE9BQU8sVUFBVSxVQUNuQixPQUFPLFNBQVMsY0FBYyxLQUFLO0NBRXJDLElBQUksT0FBTyxVQUFVLFlBQ25CLE9BQU8sTUFBTSxLQUFLO0NBRXBCLE9BQU87QUFDVDtBQW9PQSxJQUFJLHlCQW5PaUJDLGdCQUFpQjtDQUNwQyxNQUFNO0NBQ04sT0FBTztDQUNQLE9BQU87RUFDTCxNQUFNO0dBQ0osTUFBTTtHQUNOLFVBQVU7RUFDWjtFQUNBLFFBQVE7R0FDTixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsVUFBVTtHQUNSLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxjQUFjO0dBQ1osTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLElBQUk7R0FDRixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsUUFBUTtHQUNOLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxhQUFhO0dBQ1gsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLGFBQWE7R0FDWCxNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsU0FBUztHQUNQLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxZQUFZO0dBQ1YsTUFBTTtHQUNOLFNBQVMsS0FBSztFQUNoQjtFQUNBLGNBQWM7R0FDWixNQUFNO0lBQUM7SUFBUTtJQUFVO0dBQU07R0FDL0IsU0FBUztFQUNYO0VBQ0EsY0FBYztHQUNaLE1BQU07SUFBQztJQUFRO0lBQVU7R0FBTTtHQUMvQixTQUFTO0VBQ1g7RUFDQSxZQUFZO0dBQ1YsTUFBTTtJQUFDO0lBQVE7SUFBVTtHQUFNO0dBQy9CLFNBQVM7RUFDWDtFQUNBLFFBQVE7R0FDTixNQUFNO0dBQ04sZ0JBQWdCLENBQUM7RUFDbkI7Q0FDRjtDQUNBLGNBQWM7Q0FDZCxNQUFNLE9BQU8sRUFBRSxPQUFPLE9BQU8sVUFBVTtFQUNyQyxNQUFNLGtCQUFrQkMsSUFBSyxJQUFJO0VBQ2pDLE1BQU0sa0JBQWtCQSxJQUFLLElBQUk7RUFDakMsTUFBTSxnQkFBZ0JBLElBQUssSUFBSTtFQUMvQixNQUFNLGVBQWVDLGVBQ2IsbUJBQW1CLE1BQU0sY0FBYyxnQkFBZ0IsS0FBSyxDQUNwRTtFQUNBLE1BQU0sbUJBQW1CQSxlQUFnQixvQkFBb0IsYUFBYSxLQUFLLENBQUM7RUFDaEYsTUFBTSxlQUFlQSxlQUNiLG1CQUFtQixNQUFNLGNBQWMsZ0JBQWdCLEtBQUssQ0FDcEU7RUFDQSxNQUFNLGFBQWFBLGVBQWdCLG1CQUFtQixNQUFNLFlBQVksY0FBYyxLQUFLLENBQUM7RUFDNUYsTUFBTSxrQkFBa0JELElBQUssS0FBSztFQUNsQyxNQUFNLGNBQWNBLElBQUssS0FBSztFQUM5QixNQUFNLGVBQWVBLElBQUssQ0FBQztFQUMzQixNQUFNLGtCQUFrQkEsSUFBSyxLQUFLO0VBQ2xDLE1BQU0sY0FBY0EsSUFBSyxLQUFLO0VBQzlCLE1BQU0saUNBQWlDO0dBQ3JDLGFBQWEsUUFBUSxZQUFZLGdCQUFnQjtHQUNqRCxnQkFBZ0IsUUFBUSxZQUFZLFlBQVk7R0FDaEQsWUFBWSxRQUFRLFlBQVksUUFBUTtFQUMxQztFQUNBLE1BQU0sRUFDSixhQUNBLGdCQUNBLE9BQU8sd0JBQ0wsa0JBQWtCO0dBRXBCLG1CQUFtQixNQUFNO0dBQ3pCLHFCQUFxQixNQUFNO0dBQzNCLHVCQUF1QixDQUFDLE1BQU07R0FDOUIsMkJBQTJCLENBQUMsTUFBTTtHQUNsQyx5QkFBeUIsTUFBTTtHQUMvQix3QkFBd0IsTUFBTTtHQUU5Qix3QkFBd0IsTUFBTTtHQUM5Qix1QkFBdUIsYUFBYTtHQUNwQyxxQkFBcUIsV0FBVztHQUNoQyx1QkFBdUIsYUFBYTtHQUNwQywyQkFBMkIsaUJBQWlCO0dBRTVDLCtCQUErQixnQkFBZ0IsUUFBUTtHQUN2RCwyQkFBMkIsWUFBWSxRQUFRO0dBQy9DLDRCQUE0QixFQUFFLGdCQUFnQjtJQUM1QyxnQkFBZ0IsUUFBUTtJQUN4QixJQUFJLFdBQ0YseUJBQXlCO0dBRTdCO0dBQ0Esd0JBQXdCLEVBQUUsZ0JBQWdCO0lBQ3hDLFlBQVksUUFBUTtJQUNwQixJQUFJLFdBQ0YseUJBQXlCO0dBRTdCO0dBQ0EsYUFBYTtFQUNmLENBQUM7RUFDRCx5QkFBeUI7RUFDekIsSUFBSSxPQUFPLFdBQVcsYUFBYTtHQUNqQyxNQUFNLGFBQWEsUUFBUSxDQUFDLENBQUMsY0FBYyxNQUFNO0dBQ2pELElBQUksWUFBWTtJQUNkLGdCQUFnQixRQUFRLENBQUMsQ0FBQyxXQUFXO0lBQ3JDLFlBQVksUUFBUSxDQUFDLENBQUMsV0FBVztHQUNuQztFQUNGO0VBQ0EsTUFBTSxXQUFXQyxlQUFnQixDQUFDLFdBQVcsS0FBSztFQUNsRCxNQUFNLGFBQWFBLGVBQ1gsTUFBTSxVQUFVLE1BQU0sY0FBYyxLQUFLLGFBQWEsU0FBUyxNQUFNLFdBQzdFO0VBQ0EsTUFBTSx1QkFBdUI7R0FDM0IsSUFBSSxpQkFBaUIsT0FDbkIsaUJBQWlCLE1BQU0sU0FBUztJQUM5QixLQUFLLGlCQUFpQixNQUFNO0lBQzVCLFVBQVU7R0FDWixDQUFDO1FBRUQsT0FBTyxTQUFTO0lBQ2QsS0FBSyxTQUFTLEtBQUs7SUFDbkIsVUFBVTtHQUNaLENBQUM7RUFFTDtFQUNBLGdCQUFpQjtHQUNmLGVBQWUsZUFBZTtHQUM5QixlQUFlLDRCQUE0QixZQUFZLGtCQUFrQixDQUFDO0dBRTFFLElBRHlCLE1BQU0sZUFBZSxLQUFLLElBQUksTUFBTSxhQUFhLE1BQU0sU0FFOUUsZUFBZTtHQUVqQixJQUFJLFNBQVMsT0FDWCxlQUFlLGVBQWU7RUFFbEMsQ0FBQztFQUNELFlBQWEsbUJBQW1CO0VBQ2hDLFlBQ1E7R0FBQyxTQUFTO0dBQU8sTUFBTTtHQUFVLE1BQU07RUFBWSxJQUN4RCxDQUFDLGFBQWE7R0FDYixVQUFVLGVBQWUsZUFBZSxJQUFJLGVBQWUsZ0JBQWdCO0VBQzdFLENBQ0Y7RUFDQSxPQUFPO0dBQ0wsV0FBVyxZQUFZO0dBQ3ZCLGVBQWUsWUFBWTtHQUMzQixhQUFhLFlBQVk7R0FDekIsU0FBUyxZQUFZO0VBQ3ZCLENBQUM7RUFDRCxhQUFhO0dBQ1gsTUFBTSxpQkFBaUIsQ0FBQztHQUN4QixNQUFNLGdCQUFnQjtJQUNwQixpQkFBaUIsZ0JBQWdCO0lBQ2pDLGFBQWEsWUFBWTtJQUN6QixhQUFhLGdCQUFnQjtJQUM3QixTQUFTLFlBQVk7R0FDdkI7R0FDQSxJQUFJLENBQUMsTUFBTSxjQUFjO0lBQ3ZCLE1BQU0saUJBQWlCLFNBQVMsU0FBUyxDQUFDLE1BQU07SUFDaEQsTUFBTSxrQkFBa0I7S0FDdEIsU0FBUyxnQkFBZ0I7S0FDekIsT0FBTyxZQUFZO0tBQ25CLFVBQVU7S0FDVixZQUFZLENBQUM7S0FDYixTQUFTLGdCQUFnQjtLQUN6QixHQUFHO0lBQ0w7SUFDQSxlQUFlLEtBQ2JDLEVBQ0UsT0FDQSxFQUFFLEtBQUssZ0JBQWdCLEdBQ3ZCLE1BQU0sV0FBVyxNQUFNLFNBQVMsZUFBZSxJQUFJLGdCQUFnQixRQUFRLE1BQU0sVUFBVSxlQUFlLElBQUksS0FBSyxDQUNySCxDQUNGO0dBQ0Y7R0FDQSxlQUFlLEtBQ2JBLEVBQ0UsTUFBTSxJQUNOO0lBQUUsR0FBRztJQUFPLEtBQUs7R0FBZ0IsR0FDakMsTUFBTSxVQUFVO0lBQ2QsU0FBUyxnQkFBZ0IsU0FBUyxZQUFZO0lBQzlDLGlCQUFpQixnQkFBZ0I7SUFDakMsYUFBYSxZQUFZO0dBQzNCLENBQUMsQ0FDSCxDQUNGO0dBQ0EsSUFBSSxDQUFDLE1BQU0sWUFBWTtJQUNyQixNQUFNLGlCQUFpQixTQUFTLFNBQVMsQ0FBQyxNQUFNO0lBQ2hELE1BQU0sY0FBYztLQUNsQixTQUFTLFlBQVk7S0FDckIsT0FBTyxZQUFZO0tBQ25CLFVBQVU7S0FDVixZQUFZLENBQUM7S0FDYixTQUFTLFlBQVk7S0FDckIsR0FBRztJQUNMO0lBQ0EsZUFBZSxLQUNiQSxFQUNFLE9BQ0EsRUFBRSxLQUFLLGNBQWMsR0FDckIsTUFBTSxPQUFPLE1BQU0sS0FBSyxXQUFXLElBQUksWUFBWSxRQUFRLE1BQU0sVUFBVSxXQUFXLElBQUksS0FBSyxDQUNqRyxDQUNGO0dBQ0Y7R0FDQSxPQUFPQSxFQUFHQyxVQUFXLENBQUMsR0FBRyxNQUFNLFVBQVUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxjQUFjO0VBQ3pGO0NBQ0Y7QUFDRixDQUMwQztBQVkxQyxJQUFJLGNBQWMsQ0FDbEI7QUEyVEEsSUFBSSxlQTFUT0MsZ0JBQWlCO0NBQzFCLE1BQU07Q0FDTixPQUFPO0VBQ0wsSUFBSTtHQUNGLE1BQU0sQ0FBQyxRQUFRLE1BQU07R0FDckIsU0FBUztFQUNYO0VBQ0EsTUFBTTtHQUNKLE1BQU07R0FDTixnQkFBZ0IsQ0FBQztFQUNuQjtFQUNBLE1BQU07R0FDSixNQUFNLENBQUMsUUFBUSxNQUFNO0dBQ3JCLFNBQVM7RUFDWDtFQUNBLFFBQVE7R0FDTixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsU0FBUztHQUNQLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxnQkFBZ0I7R0FDZCxNQUFNO0lBQUM7SUFBUztJQUFRO0dBQVE7R0FDaEMsU0FBUztFQUNYO0VBQ0EsZUFBZTtHQUNiLE1BQU07SUFBQztJQUFTO0lBQVE7R0FBUTtHQUNoQyxTQUFTO0VBQ1g7RUFDQSxhQUFhO0dBQ1gsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLE1BQU07R0FDSixNQUFNO0dBQ04sZUFBZSxDQUFDO0VBQ2xCO0VBQ0EsUUFBUTtHQUNOLE1BQU07R0FDTixlQUFlLENBQUM7RUFDbEI7RUFDQSxTQUFTO0dBQ1AsTUFBTTtHQUNOLGdCQUFnQixDQUFDO0VBQ25CO0VBQ0Esd0JBQXdCO0dBQ3RCLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxPQUFPO0dBQ0wsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFVBQVU7R0FDUixNQUFNO0lBQUM7SUFBUztJQUFRO0dBQUs7R0FDN0IsU0FBUztFQUNYO0VBQ0EsVUFBVTtHQUNSLE1BQU07SUFBQztJQUFRO0lBQVE7R0FBSztHQUM1QixTQUFTO0VBQ1g7RUFDQSxTQUFTO0dBQ1AsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFlBQVk7R0FDVixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsVUFBVTtHQUNSLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxVQUFVO0dBQ1IsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFVBQVU7R0FDUixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsV0FBVztHQUNULE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxTQUFTO0dBQ1AsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLGVBQWU7R0FDYixNQUFNO0dBQ04sU0FBUztFQUNYO0VBQ0EsZUFBZTtHQUNiLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxjQUFjO0dBQ1osTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFdBQVc7R0FDVCxNQUFNLENBQUMsUUFBUSxLQUFLO0dBQ3BCLGVBQWUsQ0FBQztFQUNsQjtFQUNBLGdCQUFnQjtHQUNkLE1BQU0sQ0FBQyxTQUFTLE1BQU07R0FDdEIsU0FBUztFQUNYO0VBQ0EsV0FBVztHQUNULE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxTQUFTO0dBQ1AsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFdBQVc7R0FDVCxNQUFNLENBQUMsUUFBUSxRQUFRO0dBQ3ZCLFNBQVM7RUFDWDtDQUNGO0NBQ0EsTUFBTSxPQUFPLEVBQUUsT0FBTyxTQUFTO0VBQzdCLE1BQU0sZ0JBQWdCQyxJQUFLLENBQUM7RUFDNUIsTUFBTSxlQUFlQSxJQUFLO0VBQzFCLE1BQU0sZ0JBQWdCQyxlQUFnQjtHQUNwQyxJQUFJLE1BQU0sYUFBYSxNQUNyQixPQUFPLENBQUMsT0FBTztHQUVqQixJQUFJLE1BQU0sYUFBYSxPQUNyQixPQUFPLENBQUM7R0FFVixJQUFJLE1BQU0sUUFBUSxNQUFNLFFBQVEsR0FDOUIsT0FBTyxNQUFNO0dBRWYsT0FBTyxDQUFDLE1BQU0sUUFBUTtFQUN4QixDQUFDO0VBQ0QsTUFBTSxnQkFBZ0JBLGVBQWdCO0dBQ3BDLElBQUksTUFBTSxhQUFhLEdBQ3JCLE9BQU8sTUFBTTtHQUVmLElBQUksY0FBYyxNQUFNLFdBQVcsS0FBSyxjQUFjLE1BQU0sT0FBTyxTQUNqRSxPQUFPO0dBRVQsT0FBTyxPQUFPLElBQUksbUJBQW1CO0VBQ3ZDLENBQUM7RUFDRCxnQkFBaUI7R0FDZixJQUFJLGNBQWMsTUFBTSxTQUFTLE9BQU8sR0FDdEMsU0FBUztFQUViLENBQUM7RUFDRCxrQkFBbUI7R0FDakIsYUFBYSxhQUFhLEtBQUs7RUFDakMsQ0FBQztFQUNELE1BQU0sU0FBU0EsZUFDUEMsZ0JBQWlCLE1BQU0sSUFBSSxJQUFJLE1BQU0sS0FBSyxVQUFVLE1BQU0sVUFBVSxNQUFBLENBQU8sWUFBWSxDQUMvRjtFQUNBLE1BQU0sS0FBS0QsZUFBZ0I7R0FDekIsSUFBSSxPQUFPLE1BQU0sT0FBTyxZQUFZLE1BQU0sR0FBRyxZQUFZLE1BQU0sS0FDN0QsT0FBTyxNQUFNO0dBRWYsT0FBTyxPQUFPLFVBQVUsUUFBUSxXQUFXLE1BQU0sR0FBRyxZQUFZO0VBQ2xFLENBQUM7RUFDRCxNQUFNLGlCQUFpQkEsZUFDZkUseUJBQ0osT0FBTyxPQUNQRCxnQkFBaUIsTUFBTSxJQUFJLElBQUksTUFBTSxLQUFLLE1BQU0sTUFBTSxNQUN0RCxNQUFNLFFBQVEsQ0FBQyxHQUNmLE1BQU0sc0JBQ1IsQ0FDRjtFQUNBLE1BQU0sT0FBT0QsZUFBZ0IsZUFBZSxNQUFNLEVBQUU7RUFDcEQsTUFBTSxPQUFPQSxlQUFnQixlQUFlLE1BQU0sRUFBRTtFQUNwRCxNQUFNLG9CQUFvQkEsZUFBZ0I7R0FDeEMsSUFBSSxNQUFNLFdBQ1IsT0FBTyxNQUFNO0dBRWYsSUFBSSxNQUFNLFdBQVdDLGdCQUFpQixNQUFNLElBQUksR0FDOUMsT0FBT0UsOEJBQStCLE1BQU0sSUFBSTtHQUVsRCxPQUFPO0VBQ1QsQ0FBQztFQUNELE1BQU0sVUFBVUgsZUFBZ0I7R0FDOUIsSUFBSSxHQUFHLFVBQVUsVUFDZixPQUFPLEVBQUUsTUFBTSxTQUFTO0dBRTFCLElBQUksR0FBRyxVQUFVLE9BQU8sT0FBTyxHQUFHLFVBQVUsVUFDMUMsT0FBTyxFQUFFLE1BQU0sS0FBSyxNQUFNO0dBRTVCLE9BQU8sQ0FBQztFQUNWLENBQUM7RUFDRCxNQUFNLGFBQWFBLGdCQUFpQjtHQUNsQyxNQUFNLEtBQUs7R0FDWCxRQUFRLE9BQU87R0FDZixTQUFTLE1BQU07R0FDZixnQkFBZ0IsTUFBTTtHQUN0QixlQUFlLE1BQU0saUJBQWlCLE9BQU8sVUFBVTtHQUN2RCxhQUFhLE1BQU07R0FDbkIsTUFBTSxNQUFNO0dBQ1osUUFBUSxNQUFNO0dBQ2QsU0FBUyxNQUFNO0dBQ2YsT0FBTyxNQUFNO0dBQ2IsV0FBVyxrQkFBa0I7R0FDN0IsV0FBVyxNQUFNO0VBQ25CLEVBQUU7RUFDRixNQUFNLGNBQWNBLGdCQUFpQjtHQUNuQyxHQUFHLFdBQVc7R0FDZCxnQkFBZ0IsTUFBTTtHQUN0QixlQUFlLE1BQU07R0FDckIsVUFBVSxNQUFNO0dBQ2hCLFVBQVUsVUFBVTtJQUNsQixjQUFjO0lBQ2QsTUFBTSxVQUFVLEtBQUs7R0FDdkI7R0FDQSxZQUFZLE1BQU07R0FDbEIsV0FBVyxVQUFVO0lBQ25CLGNBQWM7SUFDZCxNQUFNLFdBQVcsS0FBSztHQUN4QjtHQUNBLFVBQVUsTUFBTTtHQUNoQixXQUFXLE1BQU07R0FDakIsU0FBUyxNQUFNO0VBQ2pCLEVBQUU7RUFDRixNQUFNLGlCQUFpQjtHQUNyQixPQUFRLFNBQ04sS0FBSyxPQUNMO0lBQ0UsR0FBRyxXQUFXO0lBQ2QsZUFBZSxNQUFNO0lBQ3JCLGNBQWMsTUFBTTtHQUN0QixHQUNBO0lBQ0UsVUFBVSxjQUFjO0lBQ3hCLFdBQVcsTUFBTTtHQUNuQixDQUNGO0VBQ0Y7RUFDQSxNQUFNLGdCQUFnQixFQUNwQixVQUFVLFVBQVU7R0FDbEIsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHO0lBQzFCLE1BQU0sZUFBZTtJQUNyQixPQUFRLE1BQU0sS0FBSyxPQUFPLFlBQVksS0FBSztHQUM3QztFQUNGLEVBQ0Y7RUFDQSxNQUFNLHNCQUFzQjtHQUMxQixvQkFBb0I7SUFDbEIsYUFBYSxRQUFRLGlCQUFpQjtLQUNwQyxTQUFTO0lBQ1gsR0FBRyxPQUFPLElBQUkscUJBQXFCLENBQUM7R0FDdEM7R0FDQSxvQkFBb0I7SUFDbEIsYUFBYSxhQUFhLEtBQUs7R0FDakM7R0FDQSxVQUFVLFVBQVU7SUFDbEIsYUFBYSxhQUFhLEtBQUs7SUFDL0IsY0FBYyxRQUFRLEtBQUs7R0FDN0I7RUFDRjtFQUNBLE1BQU0sc0JBQXNCO0dBQzFCLGNBQWMsVUFBVTtJQUN0QixJQUFJLGdCQUFnQixLQUFLLEdBQUc7S0FDMUIsTUFBTSxlQUFlO0tBQ3JCLFNBQVM7SUFDWDtHQUNGO0dBQ0EsWUFBWSxVQUFVO0lBQ3BCLElBQUksZUFBZSxLQUFLLEdBQUc7S0FDekIsTUFBTSxlQUFlO0tBQ3JCLFNBQVM7SUFDWDtHQUNGO0dBQ0EsWUFBWSxVQUFVO0lBQ3BCLElBQUksZ0JBQWdCLEtBQUssR0FBRztLQUMxQixNQUFNLGVBQWU7S0FDckIsT0FBUSxNQUFNLEtBQUssT0FBTyxZQUFZLEtBQUs7SUFDN0M7R0FDRjtHQUNBLFVBQVUsVUFBVTtJQUNsQixJQUFJLGVBQWUsS0FBSyxHQUFHO0tBQ3pCLE1BQU0sZUFBZTtLQUNyQixPQUFRLE1BQU0sS0FBSyxPQUFPLFlBQVksS0FBSztJQUM3QztHQUNGO0dBQ0EsVUFBVSxVQUFVO0lBQ2xCLElBQUksZ0JBQWdCLEtBQUssR0FDdkIsTUFBTSxlQUFlO0dBRXpCO0VBQ0Y7RUFDQSxhQUFhO0dBQ1gsT0FBT0ksRUFDTCxHQUFHLE9BQ0g7SUFDRSxHQUFHO0lBQ0gsR0FBRyxRQUFRO0lBQ1gsZ0JBQWdCLGNBQWMsUUFBUSxJQUFJLEtBQUssS0FBSztJQUNwRCxVQUFVO0tBQ1IsSUFBSSxjQUFjLE1BQU0sU0FBUyxPQUFPLEdBQ3RDLE9BQU87S0FFVCxJQUFJLGNBQWMsTUFBTSxTQUFTLE9BQU8sR0FDdEMsT0FBTztLQUVULE9BQU87SUFDVCxFQUFBLENBQUc7R0FDTCxHQUNBLEtBQ0Y7RUFDRjtDQUNGO0FBQ0YsQ0FDc0I7QUFjdEIsU0FBUyxRQUFRLEdBQUcsTUFBTTtDQUN4QixNQUFNLEVBQUUsYUFBYSxNQUFNLHlCQUF5QkMsYUFBYyxzQkFBc0IsR0FBRyxJQUFJO0NBQy9GLElBQUksa0JBQWtCO0NBQ3RCLElBQUksNEJBQTRCO0NBQ2hDLE1BQU0sRUFDSixNQUFNLFVBQ04sYUFDQSxjQUNBLHlCQUNBLGtCQUNBLDhCQUNBLGdDQUNBLHdCQUNBLG1CQUNBLGtCQUNBLGtCQUNFLGFBQWE7RUFDZjtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxPQUFPO0NBQ2IsS0FBSyxXQUFXO0NBQ2hCLE1BQU0sU0FBUyxPQUFPLFFBQVEsS0FBSyxZQUFZO0VBRTdDLElBRGlCLFFBQVEsV0FBVyxNQUNuQixPQUNmLE9BQU8sUUFBUSx1QkFBTyxJQUFJLE1BQU0sK0JBQStCLENBQUM7RUFFbEUsK0JBQStCO0VBQy9CLGtCQUFrQjtFQUNsQixrQkFBa0IsSUFBSSxnQkFBZ0I7RUFJdEMsUUFBUSxnQkFBZ0IsRUFGdEIsY0FBYyxpQkFBaUIsTUFBTSxFQUVMLENBQUM7RUFDbkMsUUFBUSxhQUFhLFFBQVEsY0FBYyw2QkFBNkIsS0FBSztFQUM3RSw0QkFBNEI7RUFDNUIsSUFBSTtFQUNKLElBQUksUUFBUSxZQUFZO0dBQ3RCLFdBQVdDLFlBQVcsS0FBSyxLQUFLLENBQUM7R0FDakMsTUFBTSxpQkFBaUIsUUFBUSxXQUFXQSxZQUFXLFFBQVEsQ0FBQztHQUM5RCxJQUFJLGdCQUNGLE9BQU8sS0FBSyxjQUFjLENBQUMsQ0FBQyxTQUFTLFNBQVM7SUFFNUMsS0FBSyxRQUFRLGVBQWU7R0FDOUIsQ0FBQztFQUVMO0VBQ0EsS0FBSyxhQUFhO0VBQ2xCLFFBQVEsVUFBVTtFQUVsQixNQUFNLGtCQURZLGFBQ2MsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDO0VBQzdDLE1BQU0sY0FBYyxTQUFTLGVBQWU7RUFDNUMsSUFBSSxhQUFhO0VBQ2pCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxXQUFXLE9BQU87R0FDcEIsTUFBTSxDQUFDLGlCQUFpQkMseUJBQ3RCLFFBQ0EsS0FDQSxlQUNGO0dBQ0EsYUFBYTtFQUNmLE9BQ0UsSUFBSSxhQUNGLGNBQWMsaUJBQWlCLGVBQWU7T0FDekM7R0FDTCxjQUFjLEtBQUssVUFBVSxlQUFlO0dBQzVDLGNBQWM7RUFDaEI7RUFFRixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRO0lBQzlDO0lBQ0EsS0FBSztJQUNMLE1BQU07SUFDTixTQUFTO0tBQ1AsUUFBUTtLQUNSLEdBQUcsY0FBYyxFQUFFLGdCQUFnQixZQUFZLElBQUksQ0FBQztLQUNwRCxHQUFHLFFBQVE7SUFDYjtJQUNBLFFBQVEsZ0JBQWdCO0lBQ3hCLG1CQUFtQixVQUFVO0tBQzNCLEtBQUssV0FBVztLQUNoQixRQUFRLGFBQWEsS0FBSztJQUM1QjtHQUNGLENBQUM7R0FDRCxNQUFNLGVBQWUsU0FBUyxPQUFPLEtBQUssTUFBTSxTQUFTLElBQUksSUFBSTtHQUNqRSxJQUFJLFNBQVMsVUFBVSxPQUFPLFNBQVMsU0FBUyxLQUFLO0lBQ25ELGlCQUFpQjtJQUNqQixLQUFLLFdBQVc7SUFDaEIsUUFBUSxZQUFZLGNBQWMsUUFBUTtJQUMxQyxJQUFJLENBQUMsNkJBQTZCLEdBQ2hDLFlBQVlELFlBQVcsS0FBSyxLQUFLLENBQUMsQ0FBQztJQUVyQyxLQUFLLFVBQVU7SUFDZixPQUFPO0dBQ1Q7R0FDQSxNQUFNLElBQUksa0JBQWtCLDhCQUE4QixTQUFTLFVBQVUsVUFBVSxHQUFHO0VBQzVGLFNBQVMsT0FBTztHQUNkLElBQUksVUFDRixPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsU0FBUyxTQUFTO0lBRXRDLEtBQUssUUFBUSxTQUFTO0dBQ3hCLENBQUM7R0FFSCxJQUFJLGlCQUFpQixtQkFBbUI7SUFDdEMsSUFBSSxNQUFNLFNBQVMsV0FBVyxLQUFLO0tBRWpDLE1BQU0sbUJBRGUsS0FBSyxNQUFNLE1BQU0sU0FBUyxJQUNYLENBQUMsQ0FBQyxVQUFVLENBQUM7S0FDakQsTUFBTSxrQkFBa0IsY0FBYyxRQUFRLElBQUksbUJBQW1CRSx5QkFBMEIsZ0JBQWdCO0tBQy9HLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxlQUFlO0tBQzNDLFFBQVEsVUFBVSxlQUFlO0tBQ2pDO0lBQ0Y7SUFDQSxRQUFRLGtCQUFrQixNQUFNLFFBQVE7SUFDeEMsTUFBTTtHQUNSO0dBQ0EsSUFBSSxpQkFBaUIsc0JBQXNCLGlCQUFpQixTQUFTLE1BQU0sU0FBUyxjQUFjO0lBQ2hHLFFBQVEsV0FBVztJQUNuQixNQUFNLElBQUksbUJBQW1CLHlCQUF5QixHQUFHO0dBQzNEO0dBQ0EsUUFBUSxpQkFBaUIsaUJBQWlCLFFBQVEsd0JBQVEsSUFBSSxNQUFNLGVBQWUsQ0FBQztHQUNwRixNQUFNO0VBQ1IsVUFBVTtHQUNSLGlCQUFpQjtHQUNqQixrQkFBa0I7R0FDbEIsUUFBUSxXQUFXO0VBQ3JCO0NBQ0Y7Q0FDQSxNQUFNLHNCQUFzQixXQUFXLE9BQU8sS0FBSyxVQUFVLENBQUMsTUFBTTtFQUNsRSxPQUFPLE9BQU8sUUFBUSxLQUFLLE9BQU87Q0FDcEM7Q0FDQSxPQUFPLE9BQU8sTUFBTTtFQUNsQixPQUFPLEdBQUcsT0FBTztHQUNmLE1BQU0sU0FBU0gsYUFBYyxxQkFBcUIsT0FBTyx3QkFBd0IsQ0FBQztHQUNsRixPQUFPLE9BQU8sT0FBTyxRQUFRLE9BQU8sS0FBSyxPQUFPLE9BQU87RUFDekQ7RUFDQSxLQUFLLG1CQUFtQixLQUFLO0VBQzdCLE1BQU0sbUJBQW1CLE1BQU07RUFDL0IsS0FBSyxtQkFBbUIsS0FBSztFQUM3QixPQUFPLG1CQUFtQixPQUFPO0VBQ2pDLFFBQVEsbUJBQW1CLFFBQVE7RUFDbkMsU0FBUztHQUNQLElBQUksaUJBQ0YsZ0JBQWdCLE1BQU07RUFFMUI7RUFDQSxhQUFhLEdBQUcsTUFBTTtHQUNwQix1QkFBdUIsSUFBSTtHQUMzQixPQUFPO0VBQ1Q7RUFDQSxXQUFXLFVBQVU7R0FDbkIsNEJBQTRCO0dBQzVCLE9BQU87RUFDVDtFQUNBLGdCQUFnQjtHQUNkLGNBQWMsT0FBTztHQUNyQixPQUFPO0VBQ1Q7Q0FDRixDQUFDO0NBQ0QsTUFBTSwyQkFBMkIsS0FBSztDQUN0QyxLQUFLLG9CQUFvQixHQUFHLFVBQVU7RUFDcEMseUJBQXlCLEtBQUssTUFBTSxHQUFHLEtBQUs7RUFDNUMsT0FBTztDQUNUO0NBQ0EsT0FBTyx3QkFBd0IsSUFBSSxPQUFPO0FBQzVDO0FBS0EsU0FBUyxRQUFRLFVBQVUsaUJBQWlCLENBQUMsR0FBRyxVQUFVO0NBQ3hELFdBQVc7Q0FDWCxXQUFXO0FBQ2IsR0FBRztDQUNELE1BQU0sWUFBWSxRQUFRLGFBQWE7Q0FDdkMsTUFBTSxFQUFFLE1BQU0sT0FBTyxZQUFZSSxPQUFRLEtBQUssVUFBVSxnQkFBZ0I7RUFDdEUsR0FBRztFQUNILFdBQVc7Q0FDYixDQUFDO0NBQ0QsTUFBTSxVQUFVQyxJQUFLLFNBQVM7Q0FDOUIsZ0JBQWlCO0VBQ2YsSUFBSSxXQUNGLE1BQU07Q0FFVixDQUFDO0NBQ0Qsa0JBQW1CO0VBQ2pCLFFBQVE7Q0FDVixDQUFDO0NBQ0QsT0FBTztFQUNMO0VBQ0EsWUFBWTtHQUNWLEtBQUs7R0FDTCxRQUFRLFFBQVE7RUFDbEI7RUFDQSxhQUFhO0dBQ1gsTUFBTTtHQUNOLFFBQVEsUUFBUTtFQUNsQjtDQUNGO0FBQ0Y7QUFLQSxTQUFTLFlBQVksVUFBVSxDQUFDLEdBQUc7Q0FDakMsTUFBTSxnQkFBZ0JDLElBQUssS0FBSztDQUNoQyxNQUFNLGdCQUFnQkEsSUFBSyxJQUFJO0NBQy9CLE1BQU0sZUFBZUEsSUFBSyxLQUFLO0NBQy9CLE1BQU0sU0FBUyxPQUFPLFdBQVcsY0FBYyxPQUFPQyxPQUFRLFVBQVUsT0FBTyxTQUFTLFVBQVUsT0FBTztDQUN6RyxNQUFNLFdBQVcsT0FBTyxXQUFXLGNBQWMsT0FBT0EsT0FBUSxlQUFlLE9BQU8sU0FBUyxVQUFVLE9BQU87Q0FDaEgsY0FBYyxRQUFRLFFBQVEsa0JBQWtCO0NBQ2hELGNBQWMsUUFBUSxhQUFhO0NBQ25DLGFBQWEsUUFBUSxXQUFXO0NBQ2hDLElBQUk7Q0FDSixJQUFJO0NBQ0osZ0JBQWlCO0VBQ2Ysd0JBQXdCQSxPQUFRLEdBQUcsZ0JBQWdCLE1BQU07R0FDdkQsSUFBSSxFQUFFLE9BQU8sTUFBTSxJQUFJLGFBQWEsT0FBTyxTQUFTLFVBQ2xELGNBQWMsUUFBUTtFQUUxQixDQUFDO0VBQ0QsdUJBQXVCQSxPQUFRLEdBQUcsZUFBZSxNQUFNO0dBQ3JELElBQUksRUFBRSxPQUFPLE1BQU0sSUFBSSxhQUFhLE9BQU8sU0FBUyxVQUFVO0lBQzVELGNBQWMsUUFBUTtJQUN0QixhQUFhLFFBQVE7R0FDdkI7RUFDRixDQUFDO0NBQ0gsQ0FBQztDQUNELGtCQUFtQjtFQUNqQixxQkFBcUI7RUFDckIsc0JBQXNCO0NBQ3hCLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0EsYUFBYUEsT0FBUSxNQUFNLE9BQU8sU0FBUyxVQUFVLE9BQU87Q0FDOUQ7QUFDRjtBQU1BLFNBQVMsWUFBWSxNQUFNLE1BQU07Q0FDL0IsSUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLFFBQVEsS0FBSyxtQkFBbUIsT0FDdkUsT0FBTztDQUVULE1BQU0sV0FBV0MsT0FBUyxRQUFRLElBQUk7Q0FDdEMsTUFBTSxPQUFPLFdBQVcsSUFBSSxJQUFJQyxXQUFZQztDQUM1QyxNQUFNLGVBQWUsT0FBTyxLQUFLLGVBQWUsY0FBYyxPQUFPLEtBQUssY0FBYztDQUN4RixNQUFNLGFBQWEsS0FDakIsYUFBYSxLQUFLLElBQUksT0FBTyxlQUFlLEtBQUssVUFBVUMsWUFBVyxRQUFRLENBQUMsSUFBSUEsWUFBVyxRQUFRLENBQ3hHO0NBQ0EsTUFDRSxhQUNDLGFBQWE7RUFDWixPQUFTLFNBQVNBLFlBQVcsZUFBZSxLQUFLLFdBQVcsSUFBSSxRQUFRLEdBQUcsSUFBSTtDQUNqRixHQUNBO0VBQUUsV0FBVztFQUFNLE1BQU07Q0FBSyxDQUNoQztDQUNBLE9BQU87QUFDVDtBQU1BLElBQUksc0JBQXNCQyxnQkFBaUI7Q0FDekMsTUFBTTtDQUNOLE9BQU87Q0FDUCxPQUFPO0VBQ0wsTUFBTSxFQUNKLE1BQU0sQ0FBQyxRQUFRLEtBQUssRUFDdEI7RUFDQSxRQUFRLEVBQ04sTUFBTSxPQUNSO0VBQ0EsUUFBUTtHQUNOLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFDQSxJQUFJO0dBQ0YsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFFBQVE7R0FDTixNQUFNO0dBQ04sU0FBUztFQUNYO0NBQ0Y7Q0FDQSxNQUFNLE9BQU8sRUFBRSxTQUFTO0VBQ3RCLE1BQU0sU0FBU0MsSUFBTSxLQUFLO0VBQzFCLE1BQU0sV0FBV0EsSUFBTSxLQUFLO0VBQzVCLE1BQU0sV0FBV0EsSUFBTSxJQUFJO0VBQzNCLE1BQU0sYUFBYUEsSUFBTSxJQUFJO0VBQzdCLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sT0FBT0MsZUFBZ0I7R0FDM0IsT0FBTyxNQUFNLE9BQU8sTUFBTSxRQUFRLE1BQU0sSUFBSSxJQUFJLE1BQU0sT0FBTyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUM7RUFDL0UsQ0FBQztFQUNELFNBQVMsa0JBQWtCO0dBQ3pCLE1BQU0sZUFBZTtJQUFFLGdCQUFnQjtJQUFNLEdBQUcsTUFBTTtHQUFPO0dBQzdELElBQUksTUFBTSxNQUNSLGFBQWEsT0FBTyxNQUFNLFFBQVEsTUFBTSxJQUFJLElBQUksTUFBTSxPQUFPLENBQUMsTUFBTSxJQUFJO0dBRTFFLE9BQU87RUFDVDtFQUNBLFNBQVMsbUJBQW1CO0dBQzFCLElBQUksT0FBTyxXQUFXLGFBQ3BCO0dBRUYsU0FBUyxPQUFPLFdBQVc7R0FDM0IsU0FBUyxRQUFRLElBQUksc0JBQ2xCLFlBQVk7SUFDWCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsZ0JBQ2Q7SUFFRixJQUFJLFNBQVMsT0FDWDtJQUVGLElBQUksQ0FBQyxNQUFNLFVBQVUsT0FBTyxPQUMxQjtJQUVGLFNBQVMsUUFBUTtJQUNqQixNQUFNLGVBQWUsZ0JBQWdCO0lBQ3JDLE9BQVMsT0FBTztLQUNkLEdBQUc7S0FDSCxVQUFVLE1BQU07TUFDZCxTQUFTLFFBQVE7TUFDakIsYUFBYSxVQUFVLENBQUM7S0FDMUI7S0FDQSxXQUFXLE1BQU07TUFDZixPQUFPLFFBQVE7TUFDZixTQUFTLFFBQVE7TUFDakIsYUFBYSxXQUFXLENBQUM7TUFDekIsSUFBSSxDQUFDLE1BQU0sUUFDVCxTQUFTLE9BQU8sV0FBVztLQUUvQjtJQUNGLENBQUM7R0FDSCxHQUNBLEVBQ0UsWUFBWSxHQUFHLE1BQU0sT0FBTyxJQUM5QixDQUNGO0dBQ0EsSUFBSSxXQUFXLE9BQ2IsU0FBUyxNQUFNLFFBQVEsV0FBVyxLQUFLO0VBRTNDO0VBQ0EsWUFDUSxLQUFLLE1BQU0sS0FBSyxTQUFTQyxJQUFLLE1BQU0sT0FBTyxJQUFJLENBQUMsU0FDaEQ7R0FDSixNQUFNLFNBQVMsS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLE1BQU0sT0FBTyxTQUFTQSxJQUFLLE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxDQUFDO0dBQ3JHLE9BQU8sUUFBUTtHQUNmLElBQUksVUFBVSxDQUFDLE1BQU0sUUFDbkI7R0FFRixJQUFJLENBQUMsU0FBUyxTQUFTLENBQUMsUUFDdEIsU0FBUyxnQkFBZ0I7RUFFN0IsR0FDQSxFQUFFLFdBQVcsS0FBSyxDQUNwQjtFQUNBLGtCQUFtQjtHQUNqQixTQUFTLE9BQU8sV0FBVztFQUM3QixDQUFDO0VBQ0QsYUFBYTtHQUNYLE1BQU0sTUFBTSxDQUFDO0dBQ2IsSUFBSSxNQUFNLFVBQVUsQ0FBQyxPQUFPLE9BQzFCLElBQUksS0FBS0MsRUFBRyxNQUFNLElBQUksRUFBRSxLQUFLLFdBQVcsQ0FBQyxDQUFDO0dBRTVDLElBQUksQ0FBQyxPQUFPLE9BQ1YsSUFBSSxLQUFLLE1BQU0sV0FBVyxNQUFNLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSTtRQUM5QyxJQUFJLE1BQU0sU0FDZixJQUFJLEtBQUssTUFBTSxRQUFRLEVBQUUsVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0dBRXRELE9BQU87RUFDVDtDQUNGO0FBQ0YsQ0FBQztBQUdELElBQUksU0FBU0MsU0FBVyxPQUFPLENBQUMsQ0FBQyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyXX0=