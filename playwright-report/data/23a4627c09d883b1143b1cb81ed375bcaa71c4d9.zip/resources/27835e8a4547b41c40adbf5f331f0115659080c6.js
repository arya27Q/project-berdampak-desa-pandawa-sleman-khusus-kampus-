import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Articles/Index.vue");import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import { Link, router } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Index',
  props: {
    articles: Object
},
  setup(__props, { expose: __expose }) {
  __expose();





const DEFAULT_ARTICLE_IMAGES = [
  'https://images.unsplash.com/photo-1592982537447-6f296d0ba967?w=150&h=150&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1586771107445-d3af9e173c52?w=150&h=150&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1530836369250-ef71a3f5e43d?w=150&h=150&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1585437812513-4338e932b1ba?w=150&h=150&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1620675506518-3df066bb2b30?w=150&h=150&fit=crop&auto=format'
];

const __returned__ = { DEFAULT_ARTICLE_IMAGES, AdminLayout, get Link() { return Link }, get router() { return router } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, renderList as _renderList, Fragment as _Fragment, toDisplayString as _toDisplayString, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8" }
const _hoisted_2 = { class: "space-y-4" }
const _hoisted_3 = { class: "flex items-center gap-6" }
const _hoisted_4 = { class: "w-14 h-14 rounded-2xl overflow-hidden bg-emerald-50" }
const _hoisted_5 = ["src"]
const _hoisted_6 = { class: "text-xl font-bold text-gray-900" }
const _hoisted_7 = { class: "text-gray-500 text-sm mt-1" }
const _hoisted_8 = { class: "flex items-center gap-3" }
const _hoisted_9 = ["onClick"]
const _hoisted_10 = {
  key: 0,
  class: "text-center py-10 text-gray-400"
}

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("div", _hoisted_1, [
      _cache[1] || (_cache[1] = _createElementVNode("div", null, [
        _createElementVNode("h2", { class: "text-3xl font-bold text-gray-900 tracking-tight" }, "Artikel Edukasi"),
        _createElementVNode("p", { class: "text-gray-500 mt-2" }, "Bagikan panduan tani & peternakan untuk pelanggan.")
      ], -1 /* CACHED */)),
      _createVNode($setup["Link"], {
        href: "/admin/articles/create",
        class: "inline-flex items-center justify-center px-6 py-3 border border-transparent text-sm font-medium rounded-xl text-white bg-emerald-600 hover:bg-emerald-700 shadow-md hover:shadow-lg transition-all gap-2"
      }, {
        default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
          _createElementVNode("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 4v16m8-8H4"
            })
          ], -1 /* CACHED */),
          _createTextVNode(" Tulis Artikel ", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      })
    ]),
    _createElementVNode("div", _hoisted_2, [
      (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.articles.data, (article, i) => {
        return (_openBlock(), _createElementBlock("div", {
          key: article.id,
          class: "bg-white rounded-3xl p-6 shadow-sm border border-emerald-50 flex items-center justify-between group hover:shadow-md transition-all"
        }, [
          _createElementVNode("div", _hoisted_3, [
            _createElementVNode("div", _hoisted_4, [
              _createElementVNode("img", {
                src: article.image_path ? (article.image_path.startsWith('http') ? article.image_path : '/storage/' + article.image_path) : $setup.DEFAULT_ARTICLE_IMAGES[i % $setup.DEFAULT_ARTICLE_IMAGES.length],
                class: "w-full h-full object-cover"
              }, null, 8 /* PROPS */, _hoisted_5)
            ]),
            _createElementVNode("div", null, [
              _createElementVNode("h3", _hoisted_6, _toDisplayString(article.title), 1 /* TEXT */),
              _createElementVNode("p", _hoisted_7, _toDisplayString(article.tag), 1 /* TEXT */)
            ])
          ]),
          _createElementVNode("div", _hoisted_8, [
            _createVNode($setup["Link"], {
              href: `/admin/articles/${article.id}/edit`,
              class: "w-12 h-12 rounded-full bg-white border border-gray-200 text-gray-500 hover:text-emerald-600 hover:border-emerald-200 flex items-center justify-center transition-colors shadow-sm"
            }, {
              default: _withCtx(() => [...(_cache[2] || (_cache[2] = [
                _createElementVNode("svg", {
                  class: "w-5 h-5",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24"
                }, [
                  _createElementVNode("path", {
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round",
                    "stroke-width": "2",
                    d: "M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                  })
                ], -1 /* CACHED */)
              ]))]),
              _: 1 /* STABLE */
            }, 8 /* PROPS */, ["href"]),
            _createElementVNode("button", {
              onClick: $event => ($setup.router.delete(`/admin/articles/${article.id}`)),
              class: "w-12 h-12 rounded-full bg-red-50 border border-red-100 text-red-500 hover:bg-red-100 flex items-center justify-center transition-colors shadow-sm"
            }, [...(_cache[3] || (_cache[3] = [
              _createElementVNode("svg", {
                class: "w-5 h-5",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24"
              }, [
                _createElementVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  "stroke-width": "2",
                  d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                })
              ], -1 /* CACHED */)
            ]))], 8 /* PROPS */, _hoisted_9)
          ])
        ]))
      }), 128 /* KEYED_FRAGMENT */)),
      (!$props.articles.data.length)
        ? (_openBlock(), _createElementBlock("div", _hoisted_10, "Belum ada artikel."))
        : _createCommentVNode("v-if", true)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "dddf1a6c"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
export const _rerender_only = __VUE_HMR_RUNTIME__.CHANGED_FILE === "C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Articles/Index.vue"
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Articles/Index.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW5kZXgudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgQWRtaW5MYXlvdXQgZnJvbSAnQC9MYXlvdXRzL0FkbWluTGF5b3V0LnZ1ZSc7XG5pbXBvcnQgeyBMaW5rLCByb3V0ZXIgfSBmcm9tICdAaW5lcnRpYWpzL3Z1ZTMnO1xuXG5kZWZpbmVPcHRpb25zKHsgbGF5b3V0OiBBZG1pbkxheW91dCB9KTtcblxuZGVmaW5lUHJvcHMoe1xuICAgIGFydGljbGVzOiBPYmplY3Rcbn0pO1xuXG5jb25zdCBERUZBVUxUX0FSVElDTEVfSU1BR0VTID0gW1xuICAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1OTI5ODI1Mzc0NDctNmYyOTZkMGJhOTY3P3c9MTUwJmg9MTUwJmZpdD1jcm9wJmF1dG89Zm9ybWF0JyxcbiAgJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTg2NzcxMTA3NDQ1LWQzYWY5ZTE3M2M1Mj93PTE1MCZoPTE1MCZmaXQ9Y3JvcCZhdXRvPWZvcm1hdCcsXG4gICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUzMDgzNjM2OTI1MC1lZjcxYTNmNWU0M2Q/dz0xNTAmaD0xNTAmZml0PWNyb3AmYXV0bz1mb3JtYXQnLFxuICAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1ODU0Mzc4MTI1MTMtNDMzOGU5MzJiMWJhP3c9MTUwJmg9MTUwJmZpdD1jcm9wJmF1dG89Zm9ybWF0JyxcbiAgJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNjIwNjc1NTA2NTE4LTNkZjA2NmJiMmIzMD93PTE1MCZoPTE1MCZmaXQ9Y3JvcCZhdXRvPWZvcm1hdCdcbl07XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IG1iLThcIj5cbiAgICA8ZGl2PlxuICAgICAgPGgyIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgdHJhY2tpbmctdGlnaHRcIj5BcnRpa2VsIEVkdWthc2k8L2gyPlxuICAgICAgPHAgY2xhc3M9XCJ0ZXh0LWdyYXktNTAwIG10LTJcIj5CYWdpa2FuIHBhbmR1YW4gdGFuaSAmIHBldGVybmFrYW4gdW50dWsgcGVsYW5nZ2FuLjwvcD5cbiAgICA8L2Rpdj5cbiAgICA8TGluayBocmVmPVwiL2FkbWluL2FydGljbGVzL2NyZWF0ZVwiIGNsYXNzPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTYgcHktMyBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC14bCB0ZXh0LXdoaXRlIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZ2FwLTJcIj5cbiAgICAgIDxzdmcgY2xhc3M9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIGQ9XCJNMTIgNHYxNm04LThINFwiPjwvcGF0aD48L3N2Zz5cbiAgICAgIFR1bGlzIEFydGlrZWxcbiAgICA8L0xpbms+XG4gIDwvZGl2PlxuXG4gIDxkaXYgY2xhc3M9XCJzcGFjZS15LTRcIj5cbiAgICA8ZGl2IHYtZm9yPVwiKGFydGljbGUsIGkpIGluIGFydGljbGVzLmRhdGFcIiA6a2V5PVwiYXJ0aWNsZS5pZFwiIGNsYXNzPVwiYmctd2hpdGUgcm91bmRlZC0zeGwgcC02IHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdyb3VwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ3LTE0IGgtMTQgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIGJnLWVtZXJhbGQtNTBcIj5cbiAgICAgICAgICAgPGltZyA6c3JjPVwiYXJ0aWNsZS5pbWFnZV9wYXRoID8gKGFydGljbGUuaW1hZ2VfcGF0aC5zdGFydHNXaXRoKCdodHRwJykgPyBhcnRpY2xlLmltYWdlX3BhdGggOiAnL3N0b3JhZ2UvJyArIGFydGljbGUuaW1hZ2VfcGF0aCkgOiBERUZBVUxUX0FSVElDTEVfSU1BR0VTW2kgJSBERUZBVUxUX0FSVElDTEVfSU1BR0VTLmxlbmd0aF1cIiBjbGFzcz1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPnt7IGFydGljbGUudGl0bGUgfX08L2gzPlxuICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIG10LTFcIj57eyBhcnRpY2xlLnRhZyB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICA8TGluayA6aHJlZj1cImAvYWRtaW4vYXJ0aWNsZXMvJHthcnRpY2xlLmlkfS9lZGl0YFwiIGNsYXNzPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTYwMCBob3Zlcjpib3JkZXItZW1lcmFsZC0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LXNtXCI+XG4gICAgICAgICAgPHN2ZyBjbGFzcz1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIyXCIgZD1cIk0xNS4yMzIgNS4yMzJsMy41MzYgMy41MzZtLTIuMDM2LTUuMDM2YTIuNSAyLjUgMCAxMTMuNTM2IDMuNTM2TDYuNSAyMS4wMzZIM3YtMy41NzJMMTYuNzMyIDMuNzMyelwiPjwvcGF0aD48L3N2Zz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8YnV0dG9uIEBjbGljaz1cInJvdXRlci5kZWxldGUoYC9hZG1pbi9hcnRpY2xlcy8ke2FydGljbGUuaWR9YClcIiBjbGFzcz1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTEwMCB0ZXh0LXJlZC01MDAgaG92ZXI6YmctcmVkLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIj5cbiAgICAgICAgICA8c3ZnIGNsYXNzPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJcIiBkPVwiTTE5IDdsLS44NjcgMTIuMTQyQTIgMiAwIDAxMTYuMTM4IDIxSDcuODYyYTIgMiAwIDAxLTEuOTk1LTEuODU4TDUgN201IDR2Nm00LTZ2Nm0xLTEwVjRhMSAxIDAgMDAtMS0xaC00YTEgMSAwIDAwLTEgMXYzTTQgN2gxNlwiPjwvcGF0aD48L3N2Zz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IHYtaWY9XCIhYXJ0aWNsZXMuZGF0YS5sZW5ndGhcIiBjbGFzcz1cInRleHQtY2VudGVyIHB5LTEwIHRleHQtZ3JheS00MDBcIj5CZWx1bSBhZGEgYXJ0aWtlbC48L2Rpdj5cblxuXG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FBUTlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRyxDQUFDOzs7Ozs7Ozs7O3FCQUlNLEtBQUssRUFBQyxzRUFBc0U7cUJBVzVFLEtBQUssRUFBQyxXQUFXO3FCQUViLEtBQUssRUFBQyx5QkFBeUI7cUJBQzdCLEtBQUssRUFBQyxxREFBcUQ7O3FCQUkxRCxLQUFLLEVBQUMsaUNBQWlDO3FCQUN4QyxLQUFLLEVBQUMsNEJBQTRCO3FCQUdwQyxLQUFLLEVBQUMseUJBQXlCOzs7O0VBU0osS0FBSyxFQUFDLGlDQUFpQzs7Ozs7SUEvQjNFLG9CQVNNLE9BVE4sVUFTTTtnQ0FSSixvQkFHTTtRQUZKLG9CQUFnRixRQUE1RSxLQUFLLEVBQUMsaURBQWlELElBQUMsaUJBQWU7UUFDM0Usb0JBQW9GLE9BQWpGLEtBQUssRUFBQyxvQkFBb0IsSUFBQyxvREFBa0Q7O01BRWxGLGFBR087UUFIRCxJQUFJLEVBQUMsd0JBQXdCO1FBQUMsS0FBSyxFQUFDLDBNQUEwTTs7MEJBQ2xQLENBQWlMO1VBQWpMLG9CQUFpTDtZQUE1SyxLQUFLLEVBQUMsU0FBUztZQUFDLElBQUksRUFBQyxNQUFNO1lBQUMsTUFBTSxFQUFDLGNBQWM7WUFBQyxPQUFPLEVBQUMsV0FBVzs7WUFBQyxvQkFBZ0c7Y0FBMUYsZ0JBQWMsRUFBQyxPQUFPO2NBQUMsaUJBQWUsRUFBQyxPQUFPO2NBQUMsY0FBWSxFQUFDLEdBQUc7Y0FBQyxDQUFDLEVBQUMsZ0JBQWdCOzs7MkJBQWMsaUJBRW5MOzs7OztJQUdGLG9CQXVCTSxPQXZCTixVQXVCTTt5QkF0Qkosb0JBa0JNLDZCQWxCc0IsZUFBUSxDQUFDLElBQUksR0FBNUIsT0FBTyxFQUFFLENBQUM7OEJBQXZCLG9CQWtCTTtVQWxCc0MsR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFO1VBQUUsS0FBSyxFQUFDLG9JQUFvSTs7VUFDck0sb0JBUU0sT0FSTixVQVFNO1lBUEosb0JBRU0sT0FGTixVQUVNO2NBREgsb0JBQWtPO2dCQUE1TixHQUFHLEVBQUUsT0FBTyxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLFVBQVUsV0FBVyxPQUFPLENBQUMsVUFBVSxpQkFBaUIsT0FBTyxDQUFDLFVBQVUsSUFBSSw2QkFBc0IsQ0FBQyxDQUFDLEdBQUcsNkJBQXNCLENBQUMsTUFBTTtnQkFBRyxLQUFLLEVBQUMsNEJBQTRCOzs7WUFFbE8sb0JBR007Y0FGSixvQkFBb0UsTUFBcEUsVUFBb0UsbUJBQXJCLE9BQU8sQ0FBQyxLQUFLO2NBQzVELG9CQUEyRCxLQUEzRCxVQUEyRCxtQkFBbEIsT0FBTyxDQUFDLEdBQUc7OztVQUd4RCxvQkFPTSxPQVBOLFVBT007WUFOSixhQUVPO2NBRkEsSUFBSSxxQkFBcUIsT0FBTyxDQUFDLEVBQUU7Y0FBUyxLQUFLLEVBQUMsbUxBQW1MOztnQ0FDMU8sQ0FBbVE7Z0JBQW5RLG9CQUFtUTtrQkFBOVAsS0FBSyxFQUFDLFNBQVM7a0JBQUMsSUFBSSxFQUFDLE1BQU07a0JBQUMsTUFBTSxFQUFDLGNBQWM7a0JBQUMsT0FBTyxFQUFDLFdBQVc7O2tCQUFDLG9CQUFrTDtvQkFBNUssZ0JBQWMsRUFBQyxPQUFPO29CQUFDLGlCQUFlLEVBQUMsT0FBTztvQkFBQyxjQUFZLEVBQUMsR0FBRztvQkFBQyxDQUFDLEVBQUMsa0dBQWtHOzs7Ozs7WUFFdlAsb0JBRVM7Y0FGQSxPQUFLLGFBQUUsYUFBTSxDQUFDLE1BQU0sb0JBQW9CLE9BQU8sQ0FBQyxFQUFFO2NBQUssS0FBSyxFQUFDLG1KQUFtSjs7Y0FDdk4sb0JBQStSO2dCQUExUixLQUFLLEVBQUMsU0FBUztnQkFBQyxJQUFJLEVBQUMsTUFBTTtnQkFBQyxNQUFNLEVBQUMsY0FBYztnQkFBQyxPQUFPLEVBQUMsV0FBVzs7Z0JBQUMsb0JBQThNO2tCQUF4TSxnQkFBYyxFQUFDLE9BQU87a0JBQUMsaUJBQWUsRUFBQyxPQUFPO2tCQUFDLGNBQVksRUFBQyxHQUFHO2tCQUFDLENBQUMsRUFBQyw4SEFBOEg7Ozs7Ozs7UUFJM1EsZUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNO3lCQUFoQyxvQkFBa0csT0FBbEcsV0FBa0csRUFBeEIsb0JBQWtCIiwiaWdub3JlTGlzdCI6W119