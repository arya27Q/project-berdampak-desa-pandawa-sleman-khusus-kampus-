import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Auth/Login.vue");import { useForm, Link } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";


const _sfc_main = {
  __name: 'Login',
  setup(__props, { expose: __expose }) {
  __expose();

const form = useForm({
    email: '',
    password: '',
});

const submit = () => {
    form.post('/admin/login', {
        onFinish: () => form.reset('password'),
    });
};

const __returned__ = { form, submit, get useForm() { return useForm }, get Link() { return Link } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, withModifiers as _withModifiers, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "min-h-screen flex items-center justify-center bg-gray-900 relative overflow-hidden" }
const _hoisted_2 = { class: "w-full max-w-md p-8 bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl shadow-2xl relative z-10" }
const _hoisted_3 = {
  key: 0,
  class: "text-red-400 text-sm mt-2"
}
const _hoisted_4 = {
  key: 0,
  class: "text-red-400 text-sm mt-2"
}
const _hoisted_5 = ["disabled"]
const _hoisted_6 = { key: 0 }
const _hoisted_7 = { key: 1 }
const _hoisted_8 = { class: "mt-6 text-center" }
const _hoisted_9 = { class: "text-sm text-gray-400" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createCommentVNode(" Background Elements "),
    _cache[7] || (_cache[7] = _createElementVNode("div", { class: "absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5" }, null, -1 /* CACHED */)),
    _cache[8] || (_cache[8] = _createElementVNode("div", { class: "absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-emerald-600 rounded-full blur-[120px] opacity-20" }, null, -1 /* CACHED */)),
    _cache[9] || (_cache[9] = _createElementVNode("div", { class: "absolute -bottom-[20%] -right-[10%] w-[50%] h-[50%] bg-teal-600 rounded-full blur-[120px] opacity-20" }, null, -1 /* CACHED */)),
    _createCommentVNode(" Login Card "),
    _createElementVNode("div", _hoisted_2, [
      _cache[6] || (_cache[6] = _createElementVNode("div", { class: "text-center mb-8" }, [
        _createElementVNode("h1", { class: "text-3xl font-bold text-white mb-2 tracking-tight" }, "Welcome Back"),
        _createElementVNode("p", { class: "text-gray-400" }, "Sign in to the Pandawa Kencana Admin Panel")
      ], -1 /* CACHED */)),
      _createElementVNode("form", {
        onSubmit: _withModifiers($setup.submit, ["prevent"]),
        class: "space-y-6"
      }, [
        _createElementVNode("div", null, [
          _cache[2] || (_cache[2] = _createElementVNode("label", {
            for: "email",
            class: "block text-sm font-medium text-gray-300 mb-2"
          }, "Email Address", -1 /* CACHED */)),
          _withDirectives(_createElementVNode("input", {
            id: "email",
            type: "email",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.email) = $event)),
            required: "",
            class: "w-full px-4 py-3 bg-gray-900/50 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all",
            placeholder: "admin@example.com"
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.form.email]
          ]),
          ($setup.form.errors.email)
            ? (_openBlock(), _createElementBlock("div", _hoisted_3, _toDisplayString($setup.form.errors.email), 1 /* TEXT */))
            : _createCommentVNode("v-if", true)
        ]),
        _createElementVNode("div", null, [
          _cache[3] || (_cache[3] = _createElementVNode("label", {
            for: "password",
            class: "block text-sm font-medium text-gray-300 mb-2"
          }, "Password", -1 /* CACHED */)),
          _withDirectives(_createElementVNode("input", {
            id: "password",
            type: "password",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.password) = $event)),
            required: "",
            class: "w-full px-4 py-3 bg-gray-900/50 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all",
            placeholder: "••••••••"
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.form.password]
          ]),
          ($setup.form.errors.password)
            ? (_openBlock(), _createElementBlock("div", _hoisted_4, _toDisplayString($setup.form.errors.password), 1 /* TEXT */))
            : _createCommentVNode("v-if", true)
        ]),
        _createElementVNode("button", {
          type: "submit",
          disabled: $setup.form.processing,
          class: "w-full py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-lg font-semibold shadow-lg transform transition-all active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed mt-4"
        }, [
          ($setup.form.processing)
            ? (_openBlock(), _createElementBlock("span", _hoisted_6, "Signing in..."))
            : (_openBlock(), _createElementBlock("span", _hoisted_7, "Sign In"))
        ], 8 /* PROPS */, _hoisted_5)
      ], 32 /* NEED_HYDRATION */),
      _createElementVNode("div", _hoisted_8, [
        _createElementVNode("p", _hoisted_9, [
          _cache[5] || (_cache[5] = _createTextVNode(" Don't have an account? ", -1 /* CACHED */)),
          _createVNode($setup["Link"], {
            href: "/admin/register",
            class: "font-medium text-emerald-500 hover:text-emerald-400 transition-colors"
          }, {
            default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
              _createTextVNode(" Register here ", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          })
        ])
      ])
    ])
  ]))
}



_sfc_main.__hmrId = "2237eb33"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Auth/Login.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW4udnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyB1c2VGb3JtLCBMaW5rIH0gZnJvbSAnQGluZXJ0aWFqcy92dWUzJztcblxuY29uc3QgZm9ybSA9IHVzZUZvcm0oe1xuICAgIGVtYWlsOiAnJyxcbiAgICBwYXNzd29yZDogJycsXG59KTtcblxuY29uc3Qgc3VibWl0ID0gKCkgPT4ge1xuICAgIGZvcm0ucG9zdCgnL2FkbWluL2xvZ2luJywge1xuICAgICAgICBvbkZpbmlzaDogKCkgPT4gZm9ybS5yZXNldCgncGFzc3dvcmQnKSxcbiAgICB9KTtcbn07XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICAgIDxkaXYgY2xhc3M9XCJtaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctZ3JheS05MDAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIDwhLS0gQmFja2dyb3VuZCBFbGVtZW50cyAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgYmctW3VybCgnaHR0cHM6Ly93d3cudHJhbnNwYXJlbnR0ZXh0dXJlcy5jb20vcGF0dGVybnMvY3ViZXMucG5nJyldIG9wYWNpdHktNVwiPjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgLXRvcC1bMjAlXSAtbGVmdC1bMTAlXSB3LVs1MCVdIGgtWzUwJV0gYmctZW1lcmFsZC02MDAgcm91bmRlZC1mdWxsIGJsdXItWzEyMHB4XSBvcGFjaXR5LTIwXCI+PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtYm90dG9tLVsyMCVdIC1yaWdodC1bMTAlXSB3LVs1MCVdIGgtWzUwJV0gYmctdGVhbC02MDAgcm91bmRlZC1mdWxsIGJsdXItWzEyMHB4XSBvcGFjaXR5LTIwXCI+PC9kaXY+XG5cbiAgICAgICAgPCEtLSBMb2dpbiBDYXJkIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIG1heC13LW1kIHAtOCBiZy1ncmF5LTgwMC82MCBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciBib3JkZXItZ3JheS03MDAvNTAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCByZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgbWItOFwiPlxuICAgICAgICAgICAgICAgIDxoMSBjbGFzcz1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTIgdHJhY2tpbmctdGlnaHRcIj5XZWxjb21lIEJhY2s8L2gxPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1ncmF5LTQwMFwiPlNpZ24gaW4gdG8gdGhlIFBhbmRhd2EgS2VuY2FuYSBBZG1pbiBQYW5lbDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBAc3VibWl0LnByZXZlbnQ9XCJzdWJtaXRcIiBjbGFzcz1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJlbWFpbFwiIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktMzAwIG1iLTJcIj5FbWFpbCBBZGRyZXNzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybS5lbWFpbFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS05MDAvNTAgYm9yZGVyIGJvcmRlci1ncmF5LTYwMCByb3VuZGVkLWxnIHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImFkbWluQGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiB2LWlmPVwiZm9ybS5lcnJvcnMuZW1haWxcIiBjbGFzcz1cInRleHQtcmVkLTQwMCB0ZXh0LXNtIG10LTJcIj57eyBmb3JtLmVycm9ycy5lbWFpbCB9fTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cInBhc3N3b3JkXCIgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS0zMDAgbWItMlwiPlBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybS5wYXNzd29yZFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS05MDAvNTAgYm9yZGVyIGJvcmRlci1ncmF5LTYwMCByb3VuZGVkLWxnIHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgdi1pZj1cImZvcm0uZXJyb3JzLnBhc3N3b3JkXCIgY2xhc3M9XCJ0ZXh0LXJlZC00MDAgdGV4dC1zbSBtdC0yXCI+e3sgZm9ybS5lcnJvcnMucGFzc3dvcmQgfX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIiBcbiAgICAgICAgICAgICAgICAgICAgOmRpc2FibGVkPVwiZm9ybS5wcm9jZXNzaW5nXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgcHktMyBweC00IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBmb250LXNlbWlib2xkIHNoYWRvdy1sZyB0cmFuc2Zvcm0gdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1IGRpc2FibGVkOm9wYWNpdHktNzAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIG10LTRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gdi1pZj1cImZvcm0ucHJvY2Vzc2luZ1wiPlNpZ25pbmcgaW4uLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHYtZWxzZT5TaWduIEluPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIERvbid0IGhhdmUgYW4gYWNjb3VudD8gXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWRtaW4vcmVnaXN0ZXJcIiBjbGFzcz1cImZvbnQtbWVkaXVtIHRleHQtZW1lcmFsZC01MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUmVnaXN0ZXIgaGVyZVxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC90ZW1wbGF0ZT5cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7OztBQUUvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUM7O0FBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7cUJBSVEsS0FBSyxFQUFDLG9GQUFvRjtxQkFPdEYsS0FBSyxFQUFDLG9IQUFvSDs7O0VBaUJyRixLQUFLLEVBQUMsMkJBQTJCOzs7O0VBYTlCLEtBQUssRUFBQywyQkFBMkI7Ozs7O3FCQWFyRSxLQUFLLEVBQUMsa0JBQWtCO3FCQUN0QixLQUFLLEVBQUMsdUJBQXVCOzs7d0JBbkQ1QyxvQkEyRE0sT0EzRE4sVUEyRE07SUExREYsNENBQTRCOzhCQUM1QixvQkFBaUgsU0FBNUcsS0FBSyxFQUFDLCtGQUErRjs4QkFDMUcsb0JBQXVILFNBQWxILEtBQUssRUFBQyxxR0FBcUc7OEJBQ2hILG9CQUF3SCxTQUFuSCxLQUFLLEVBQUMsc0dBQXNHO0lBRWpILG1DQUFtQjtJQUNuQixvQkFtRE0sT0FuRE4sVUFtRE07Z0NBbERGLG9CQUdNLFNBSEQsS0FBSyxFQUFDLGtCQUFrQjtRQUN6QixvQkFBK0UsUUFBM0UsS0FBSyxFQUFDLG1EQUFtRCxJQUFDLGNBQVk7UUFDMUUsb0JBQXVFLE9BQXBFLEtBQUssRUFBQyxlQUFlLElBQUMsNENBQTBDOztNQUd2RSxvQkFtQ087UUFuQ0EsUUFBTSxpQkFBVSxhQUFNO1FBQUUsS0FBSyxFQUFDLFdBQVc7O1FBQzVDLG9CQVdNO29DQVZGLG9CQUE2RjtZQUF0RixHQUFHLEVBQUMsT0FBTztZQUFDLEtBQUssRUFBQyw4Q0FBOEM7YUFBQyxlQUFhOzBCQUNyRixvQkFPRTtZQU5FLEVBQUUsRUFBQyxPQUFPO1lBQ1YsSUFBSSxFQUFDLE9BQU87eUVBQ0gsV0FBSSxDQUFDLEtBQUs7WUFDbkIsUUFBUSxFQUFSLEVBQVE7WUFDUixLQUFLLEVBQUMsNktBQTZLO1lBQ25MLFdBQVcsRUFBQyxtQkFBbUI7OzBCQUh0QixXQUFJLENBQUMsS0FBSzs7V0FLWixXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7NkJBQTVCLG9CQUE2RixPQUE3RixVQUE2RixtQkFBMUIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOzs7UUFHeEYsb0JBV007b0NBVkYsb0JBQTJGO1lBQXBGLEdBQUcsRUFBQyxVQUFVO1lBQUMsS0FBSyxFQUFDLDhDQUE4QzthQUFDLFVBQVE7MEJBQ25GLG9CQU9FO1lBTkUsRUFBRSxFQUFDLFVBQVU7WUFDYixJQUFJLEVBQUMsVUFBVTt5RUFDTixXQUFJLENBQUMsUUFBUTtZQUN0QixRQUFRLEVBQVIsRUFBUTtZQUNSLEtBQUssRUFBQyw2S0FBNks7WUFDbkwsV0FBVyxFQUFDLFVBQVU7OzBCQUhiLFdBQUksQ0FBQyxRQUFROztXQUtmLFdBQUksQ0FBQyxNQUFNLENBQUMsUUFBUTs2QkFBL0Isb0JBQW1HLE9BQW5HLFVBQW1HLG1CQUE3QixXQUFJLENBQUMsTUFBTSxDQUFDLFFBQVE7OztRQUc5RixvQkFPUztVQU5MLElBQUksRUFBQyxRQUFRO1VBQ1osUUFBUSxFQUFFLFdBQUksQ0FBQyxVQUFVO1VBQzFCLEtBQUssRUFBQyxxUEFBcVA7O1dBRS9PLFdBQUksQ0FBQyxVQUFVOzZCQUEzQixvQkFBaUQsb0JBQXBCLGVBQWE7NkJBQzFDLG9CQUEyQixvQkFBZCxTQUFPOzs7TUFJNUIsb0JBT00sT0FQTixVQU9NO1FBTkYsb0JBS0ksS0FMSixVQUtJO3FEQUw2QiwwQkFFN0I7VUFBQSxhQUVPO1lBRkQsSUFBSSxFQUFDLGlCQUFpQjtZQUFDLEtBQUssRUFBQyx1RUFBdUU7OzhCQUFDLENBRTNHOytCQUYyRyxpQkFFM0ciLCJpZ25vcmVMaXN0IjpbXX0=