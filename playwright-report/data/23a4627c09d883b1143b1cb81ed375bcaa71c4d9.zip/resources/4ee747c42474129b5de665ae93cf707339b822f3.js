import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Layouts/AdminLayout.vue");import { Head, Link } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import Icon from "/resources/js/Components/Icon.vue";


const _sfc_main = {
  __name: 'AdminLayout',
  props: {
  title: String,
  breadcrumbs: Array
},
  setup(__props, { expose: __expose }) {
  __expose();

const props = __props;

const __returned__ = { props, get Head() { return Head }, get Link() { return Link }, Icon }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createVNode as _createVNode, createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, normalizeClass as _normalizeClass, withCtx as _withCtx, toDisplayString as _toDisplayString, renderSlot as _renderSlot, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "min-h-screen bg-[#f8f9fa] flex text-gray-800 font-sans p-4 lg:p-6 gap-4 lg:gap-6" }
const _hoisted_2 = { class: "w-64 bg-white flex flex-col h-[calc(100vh-2rem)] lg:h-[calc(100vh-3rem)] sticky top-4 lg:top-6 rounded-3xl shadow-sm border border-gray-100 shrink-0 hidden md:flex overflow-hidden" }
const _hoisted_3 = { class: "p-6 flex items-center gap-2" }
const _hoisted_4 = { class: "flex-1 overflow-y-auto py-2 flex flex-col gap-8" }
const _hoisted_5 = { class: "space-y-1" }
const _hoisted_6 = { class: "space-y-1" }
const _hoisted_7 = { class: "p-6" }
const _hoisted_8 = { class: "bg-linear-to-br from-emerald-900 to-emerald-800 rounded-2xl p-5 text-white shadow-lg relative overflow-hidden" }
const _hoisted_9 = { class: "relative z-10" }
const _hoisted_10 = { class: "w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mb-3" }
const _hoisted_11 = { class: "flex-1 flex flex-col h-[calc(100vh-2rem)] lg:h-[calc(100vh-3rem)] overflow-hidden min-w-0 gap-4 lg:gap-6" }
const _hoisted_12 = { class: "bg-white/80 backdrop-blur-md rounded-3xl border border-gray-100 shadow-sm px-6 lg:px-8 py-4 flex items-center justify-between shrink-0 z-10" }
const _hoisted_13 = { class: "text-lg font-bold text-gray-800" }
const _hoisted_14 = { class: "text-xs text-gray-500" }
const _hoisted_15 = { class: "flex items-center gap-4" }
const _hoisted_16 = { class: "flex items-center gap-3 cursor-pointer group" }
const _hoisted_17 = { class: "w-10 h-10 rounded-full border border-gray-200 bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold" }
const _hoisted_18 = { class: "hidden md:block text-sm" }
const _hoisted_19 = { class: "font-bold text-gray-900 group-hover:text-emerald-700 transition-colors" }
const _hoisted_20 = { class: "text-xs text-gray-500" }
const _hoisted_21 = { class: "flex-1 overflow-y-auto pb-24 pr-2" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createVNode($setup["Head"], {
      title: $props.title ? `${$props.title} | Admin Pandawa` : 'Admin Pandawa Kencana'
    }, null, 8 /* PROPS */, ["title"]),
    _createElementVNode("div", _hoisted_1, [
      _createCommentVNode(" Sidebar "),
      _createElementVNode("aside", _hoisted_2, [
        _createCommentVNode(" Logo "),
        _createElementVNode("div", _hoisted_3, [
          _createVNode($setup["Icon"], {
            name: "leaf",
            class: "w-8 h-8 text-emerald-700"
          }),
          _cache[0] || (_cache[0] = _createElementVNode("span", { class: "font-display font-bold text-xl text-gray-900 tracking-tight" }, "Pandawa", -1 /* CACHED */))
        ]),
        _createCommentVNode(" Menu "),
        _createElementVNode("div", _hoisted_4, [
          _createElementVNode("div", null, [
            _cache[4] || (_cache[4] = _createElementVNode("div", { class: "px-6 mb-3 text-xs font-semibold text-gray-400 uppercase tracking-wider" }, "Menu", -1 /* CACHED */)),
            _createElementVNode("nav", _hoisted_5, [
              _createVNode($setup["Link"], {
                href: "/admin/dashboard",
                class: _normalizeClass(['flex items-center gap-3 px-6 py-3 border-l-4 transition-colors mr-4 rounded-r-2xl', _ctx.$page.url === '/admin/dashboard' ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 font-semibold' : 'border-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50'])
              }, {
                default: _withCtx(() => [
                  _createVNode($setup["Icon"], {
                    name: "grid",
                    class: "w-5 h-5"
                  }),
                  _cache[1] || (_cache[1] = _createTextVNode(" Dashboard ", -1 /* CACHED */))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["class"]),
              _createVNode($setup["Link"], {
                href: "/admin/products",
                class: _normalizeClass(['flex items-center gap-3 px-6 py-3 border-l-4 transition-colors mr-4 rounded-r-2xl', _ctx.$page.url.startsWith('/admin/products') ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 font-semibold' : 'border-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50'])
              }, {
                default: _withCtx(() => [
                  _createVNode($setup["Icon"], {
                    name: "box",
                    class: "w-5 h-5"
                  }),
                  _cache[2] || (_cache[2] = _createTextVNode(" Kelola Produk ", -1 /* CACHED */))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["class"]),
              _createVNode($setup["Link"], {
                href: "/admin/articles",
                class: _normalizeClass(['flex items-center gap-3 px-6 py-3 border-l-4 transition-colors mr-4 rounded-r-2xl', _ctx.$page.url.startsWith('/admin/articles') ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 font-semibold' : 'border-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50'])
              }, {
                default: _withCtx(() => [
                  _createVNode($setup["Icon"], {
                    name: "file",
                    class: "w-5 h-5"
                  }),
                  _cache[3] || (_cache[3] = _createTextVNode(" Artikel Edukasi ", -1 /* CACHED */))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["class"])
            ])
          ]),
          _createElementVNode("div", null, [
            _cache[7] || (_cache[7] = _createElementVNode("div", { class: "px-6 mb-3 text-xs font-semibold text-gray-400 uppercase tracking-wider" }, "General", -1 /* CACHED */)),
            _createElementVNode("nav", _hoisted_6, [
              _createVNode($setup["Link"], {
                href: "/admin/settings",
                class: _normalizeClass(['flex items-center gap-3 px-6 py-3 border-l-4 transition-colors mr-4 rounded-r-2xl', _ctx.$page.url.startsWith('/admin/settings') ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 font-semibold' : 'border-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50'])
              }, {
                default: _withCtx(() => [
                  _createVNode($setup["Icon"], {
                    name: "settings",
                    class: "w-5 h-5"
                  }),
                  _cache[5] || (_cache[5] = _createTextVNode(" Pengaturan Web ", -1 /* CACHED */))
                ]),
                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["class"]),
              _createVNode($setup["Link"], {
                method: "post",
                href: "/admin/logout",
                as: "button",
                class: "w-full text-left flex items-center gap-3 px-6 py-3 border-l-4 border-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50 transition-colors mr-4 rounded-r-2xl"
              }, {
                default: _withCtx(() => [
                  _createVNode($setup["Icon"], {
                    name: "logout",
                    class: "w-5 h-5"
                  }),
                  _cache[6] || (_cache[6] = _createTextVNode(" Logout ", -1 /* CACHED */))
                ]),
                _: 1 /* STABLE */
              })
            ])
          ])
        ]),
        _createCommentVNode(" Promo Bottom "),
        _createElementVNode("div", _hoisted_7, [
          _createElementVNode("div", _hoisted_8, [
            _createElementVNode("div", _hoisted_9, [
              _createElementVNode("div", _hoisted_10, [
                _createVNode($setup["Icon"], {
                  name: "leaf",
                  class: "w-4 h-4 text-white"
                })
              ]),
              _cache[8] || (_cache[8] = _createElementVNode("h4", { class: "font-bold text-sm mb-1" }, "Pandawa Kencana", -1 /* CACHED */)),
              _cache[9] || (_cache[9] = _createElementVNode("p", { class: "text-[0.65rem] text-emerald-200 mb-4 leading-relaxed" }, "Kelola produk & artikel lebih mudah di CMS modern.", -1 /* CACHED */)),
              _cache[10] || (_cache[10] = _createElementVNode("a", {
                href: "/",
                target: "_blank",
                class: "block w-full py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-center text-xs font-bold transition-colors"
              }, "Lihat Website", -1 /* CACHED */))
            ]),
            _createCommentVNode(" Deco "),
            _cache[11] || (_cache[11] = _createElementVNode("div", { class: "absolute -right-6 -bottom-6 w-24 h-24 bg-white/10 rounded-full blur-xl" }, null, -1 /* CACHED */)),
            _cache[12] || (_cache[12] = _createElementVNode("div", { class: "absolute -left-6 -top-6 w-24 h-24 bg-white/10 rounded-full blur-xl" }, null, -1 /* CACHED */))
          ])
        ])
      ]),
      _createCommentVNode(" Main Content "),
      _createElementVNode("div", _hoisted_11, [
        _createCommentVNode(" Topbar "),
        _createElementVNode("header", _hoisted_12, [
          _createCommentVNode(" left side "),
          _createElementVNode("div", null, [
            _createElementVNode("h1", _hoisted_13, _toDisplayString($props.title || 'Panel Admin'), 1 /* TEXT */),
            _createElementVNode("p", _hoisted_14, _toDisplayString(new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })), 1 /* TEXT */)
          ]),
          _createCommentVNode(" right side "),
          _createElementVNode("div", _hoisted_15, [
            _createElementVNode("div", _hoisted_16, [
              _createElementVNode("div", _hoisted_17, _toDisplayString(_ctx.$page.props.auth?.user?.name?.charAt(0) || 'A'), 1 /* TEXT */),
              _createElementVNode("div", _hoisted_18, [
                _createElementVNode("p", _hoisted_19, _toDisplayString(_ctx.$page.props.auth?.user?.name || 'Admin'), 1 /* TEXT */),
                _createElementVNode("p", _hoisted_20, _toDisplayString(_ctx.$page.props.auth?.user?.email || 'admin@pandawa.id'), 1 /* TEXT */)
              ])
            ])
          ])
        ]),
        _createCommentVNode(" Page Content "),
        _createElementVNode("main", _hoisted_21, [
          _renderSlot(_ctx.$slots, "default")
        ])
      ])
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "7ca33ed0"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
export const _rerender_only = __VUE_HMR_RUNTIME__.CHANGED_FILE === "C:/laragon/www/pandawa-kencana/resources/js/Layouts/AdminLayout.vue"
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Layouts/AdminLayout.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWRtaW5MYXlvdXQudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cbiAgPEhlYWQgOnRpdGxlPVwidGl0bGUgPyBgJHt0aXRsZX0gfCBBZG1pbiBQYW5kYXdhYCA6ICdBZG1pbiBQYW5kYXdhIEtlbmNhbmEnXCIgLz5cblxuICA8ZGl2IGNsYXNzPVwibWluLWgtc2NyZWVuIGJnLVsjZjhmOWZhXSBmbGV4IHRleHQtZ3JheS04MDAgZm9udC1zYW5zIHAtNCBsZzpwLTYgZ2FwLTQgbGc6Z2FwLTZcIj5cbiAgICBcbiAgICA8IS0tIFNpZGViYXIgLS0+XG4gICAgPGFzaWRlIGNsYXNzPVwidy02NCBiZy13aGl0ZSBmbGV4IGZsZXgtY29sIGgtW2NhbGMoMTAwdmgtMnJlbSldIGxnOmgtW2NhbGMoMTAwdmgtM3JlbSldIHN0aWNreSB0b3AtNCBsZzp0b3AtNiByb3VuZGVkLTN4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBzaHJpbmstMCBoaWRkZW4gbWQ6ZmxleCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIDwhLS0gTG9nbyAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJwLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgPEljb24gbmFtZT1cImxlYWZcIiBjbGFzcz1cInctOCBoLTggdGV4dC1lbWVyYWxkLTcwMFwiIC8+XG4gICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LXhsIHRleHQtZ3JheS05MDAgdHJhY2tpbmctdGlnaHRcIj5QYW5kYXdhPC9zcGFuPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0gTWVudSAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHB5LTIgZmxleCBmbGV4LWNvbCBnYXAtOFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJweC02IG1iLTMgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+TWVudTwvZGl2PlxuICAgICAgICAgIDxuYXYgY2xhc3M9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWRtaW4vZGFzaGJvYXJkXCIgOmNsYXNzPVwiWydmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC02IHB5LTMgYm9yZGVyLWwtNCB0cmFuc2l0aW9uLWNvbG9ycyBtci00IHJvdW5kZWQtci0yeGwnLCAkcGFnZS51cmwgPT09ICcvYWRtaW4vZGFzaGJvYXJkJyA/ICdib3JkZXItZW1lcmFsZC03MDAgdGV4dC1lbWVyYWxkLTgwMCBiZy1lbWVyYWxkLTUwLzUwIGZvbnQtc2VtaWJvbGQnIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS05MDAgaG92ZXI6YmctZ3JheS01MCddXCI+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJncmlkXCIgY2xhc3M9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgRGFzaGJvYXJkXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FkbWluL3Byb2R1Y3RzXCIgOmNsYXNzPVwiWydmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC02IHB5LTMgYm9yZGVyLWwtNCB0cmFuc2l0aW9uLWNvbG9ycyBtci00IHJvdW5kZWQtci0yeGwnLCAkcGFnZS51cmwuc3RhcnRzV2l0aCgnL2FkbWluL3Byb2R1Y3RzJykgPyAnYm9yZGVyLWVtZXJhbGQtNzAwIHRleHQtZW1lcmFsZC04MDAgYmctZW1lcmFsZC01MC81MCBmb250LXNlbWlib2xkJyA6ICdib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktOTAwIGhvdmVyOmJnLWdyYXktNTAnXVwiPlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYm94XCIgY2xhc3M9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgS2Vsb2xhIFByb2R1a1xuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9hZG1pbi9hcnRpY2xlc1wiIDpjbGFzcz1cIlsnZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNiBweS0zIGJvcmRlci1sLTQgdHJhbnNpdGlvbi1jb2xvcnMgbXItNCByb3VuZGVkLXItMnhsJywgJHBhZ2UudXJsLnN0YXJ0c1dpdGgoJy9hZG1pbi9hcnRpY2xlcycpID8gJ2JvcmRlci1lbWVyYWxkLTcwMCB0ZXh0LWVtZXJhbGQtODAwIGJnLWVtZXJhbGQtNTAvNTAgZm9udC1zZW1pYm9sZCcgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTkwMCBob3ZlcjpiZy1ncmF5LTUwJ11cIj5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImZpbGVcIiBjbGFzcz1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICBBcnRpa2VsIEVkdWthc2lcbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L25hdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJweC02IG1iLTMgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+R2VuZXJhbDwvZGl2PlxuICAgICAgICAgIDxuYXYgY2xhc3M9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWRtaW4vc2V0dGluZ3NcIiA6Y2xhc3M9XCJbJ2ZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTYgcHktMyBib3JkZXItbC00IHRyYW5zaXRpb24tY29sb3JzIG1yLTQgcm91bmRlZC1yLTJ4bCcsICRwYWdlLnVybC5zdGFydHNXaXRoKCcvYWRtaW4vc2V0dGluZ3MnKSA/ICdib3JkZXItZW1lcmFsZC03MDAgdGV4dC1lbWVyYWxkLTgwMCBiZy1lbWVyYWxkLTUwLzUwIGZvbnQtc2VtaWJvbGQnIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS05MDAgaG92ZXI6YmctZ3JheS01MCddXCI+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJzZXR0aW5nc1wiIGNsYXNzPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgIFBlbmdhdHVyYW4gV2ViXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8TGluayBtZXRob2Q9XCJwb3N0XCIgaHJlZj1cIi9hZG1pbi9sb2dvdXRcIiBhcz1cImJ1dHRvblwiIGNsYXNzPVwidy1mdWxsIHRleHQtbGVmdCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC02IHB5LTMgYm9yZGVyLWwtNCBib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktOTAwIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnMgbXItNCByb3VuZGVkLXItMnhsXCI+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJsb2dvdXRcIiBjbGFzcz1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICBMb2dvdXRcbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L25hdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgPCEtLSBQcm9tbyBCb3R0b20gLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwicC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJiZy1saW5lYXItdG8tYnIgZnJvbS1lbWVyYWxkLTkwMCB0by1lbWVyYWxkLTgwMCByb3VuZGVkLTJ4bCBwLTUgdGV4dC13aGl0ZSBzaGFkb3ctbGcgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTggaC04IGJnLXdoaXRlLzIwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi0zXCI+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJsZWFmXCIgY2xhc3M9XCJ3LTQgaC00IHRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aDQgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1zbSBtYi0xXCI+UGFuZGF3YSBLZW5jYW5hPC9oND5cbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1bMC42NXJlbV0gdGV4dC1lbWVyYWxkLTIwMCBtYi00IGxlYWRpbmctcmVsYXhlZFwiPktlbG9sYSBwcm9kdWsgJiBhcnRpa2VsIGxlYmloIG11ZGFoIGRpIENNUyBtb2Rlcm4uPC9wPlxuICAgICAgICAgICAgPGEgaHJlZj1cIi9cIiB0YXJnZXQ9XCJfYmxhbmtcIiBjbGFzcz1cImJsb2NrIHctZnVsbCBweS0yIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNTAwIHJvdW5kZWQteGwgdGV4dC1jZW50ZXIgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIj5MaWhhdCBXZWJzaXRlPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwhLS0gRGVjbyAtLT5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgLXJpZ2h0LTYgLWJvdHRvbS02IHctMjQgaC0yNCBiZy13aGl0ZS8xMCByb3VuZGVkLWZ1bGwgYmx1ci14bFwiPjwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtbGVmdC02IC10b3AtNiB3LTI0IGgtMjQgYmctd2hpdGUvMTAgcm91bmRlZC1mdWxsIGJsdXIteGxcIj48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FzaWRlPlxuXG4gICAgPCEtLSBNYWluIENvbnRlbnQgLS0+XG4gICAgPGRpdiBjbGFzcz1cImZsZXgtMSBmbGV4IGZsZXgtY29sIGgtW2NhbGMoMTAwdmgtMnJlbSldIGxnOmgtW2NhbGMoMTAwdmgtM3JlbSldIG92ZXJmbG93LWhpZGRlbiBtaW4tdy0wIGdhcC00IGxnOmdhcC02XCI+XG4gICAgICBcbiAgICAgIDwhLS0gVG9wYmFyIC0tPlxuICAgICAgPGhlYWRlciBjbGFzcz1cImJnLXdoaXRlLzgwIGJhY2tkcm9wLWJsdXItbWQgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBzaGFkb3ctc20gcHgtNiBsZzpweC04IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNocmluay0wIHotMTBcIj5cbiAgICAgICAgXG4gICAgICAgIDwhLS0gbGVmdCBzaWRlIC0tPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzcz1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57eyB0aXRsZSB8fCAnUGFuZWwgQWRtaW4nIH19PC9oMT5cbiAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPnt7IG5ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdpZC1JRCcsIHsgd2Vla2RheTogJ2xvbmcnLCB5ZWFyOiAnbnVtZXJpYycsIG1vbnRoOiAnbG9uZycsIGRheTogJ251bWVyaWMnIH0pIH19PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIDwhLS0gcmlnaHQgc2lkZSAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGN1cnNvci1wb2ludGVyIGdyb3VwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWVtZXJhbGQtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC03MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHt7ICRwYWdlLnByb3BzLmF1dGg/LnVzZXI/Lm5hbWU/LmNoYXJBdCgwKSB8fCAnQScgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpZGRlbiBtZDpibG9jayB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZ3JvdXAtaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPnt7ICRwYWdlLnByb3BzLmF1dGg/LnVzZXI/Lm5hbWUgfHwgJ0FkbWluJyB9fTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj57eyAkcGFnZS5wcm9wcy5hdXRoPy51c2VyPy5lbWFpbCB8fCAnYWRtaW5AcGFuZGF3YS5pZCcgfX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPCEtLSBQYWdlIENvbnRlbnQgLS0+XG4gICAgICA8bWFpbiBjbGFzcz1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcGItMjQgcHItMlwiPlxuICAgICAgICA8c2xvdCAvPlxuICAgICAgPC9tYWluPlxuICAgICAgXG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IEhlYWQsIExpbmsgfSBmcm9tICdAaW5lcnRpYWpzL3Z1ZTMnO1xuaW1wb3J0IEljb24gZnJvbSAnQC9Db21wb25lbnRzL0ljb24udnVlJztcblxuY29uc3QgcHJvcHMgPSBkZWZpbmVQcm9wcyh7XG4gIHRpdGxlOiBTdHJpbmcsXG4gIGJyZWFkY3J1bWJzOiBBcnJheVxufSk7XG48L3NjcmlwdD5cbiJdLCJtYXBwaW5ncyI6IkFBaUhBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7QUFFeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BR1o7Ozs7Ozs7Ozs7cUJBcEhLLEtBQUssRUFBQyxrRkFBa0Y7cUJBR3BGLEtBQUssRUFBQyxxTEFBcUw7cUJBRTNMLEtBQUssRUFBQyw2QkFBNkI7cUJBTW5DLEtBQUssRUFBQyxpREFBaUQ7cUJBR25ELEtBQUssRUFBQyxXQUFXO3FCQWtCakIsS0FBSyxFQUFDLFdBQVc7cUJBY3JCLEtBQUssRUFBQyxLQUFLO3FCQUNULEtBQUssRUFBQywrR0FBK0c7cUJBQ25ILEtBQUssRUFBQyxlQUFlO3NCQUNuQixLQUFLLEVBQUMsd0VBQXdFO3NCQWV0RixLQUFLLEVBQUMsMEdBQTBHO3NCQUczRyxLQUFLLEVBQUMsNklBQTZJO3NCQUluSixLQUFLLEVBQUMsaUNBQWlDO3NCQUN4QyxLQUFLLEVBQUMsdUJBQXVCO3NCQUk3QixLQUFLLEVBQUMseUJBQXlCO3NCQUU3QixLQUFLLEVBQUMsOENBQThDO3NCQUNsRCxLQUFLLEVBQUMsMEhBQTBIO3NCQUdoSSxLQUFLLEVBQUMseUJBQXlCO3NCQUMvQixLQUFLLEVBQUMsd0VBQXdFO3NCQUM5RSxLQUFLLEVBQUMsdUJBQXVCO3NCQU9sQyxLQUFLLEVBQUMsbUNBQW1DOzs7O0lBN0ZuRCxhQUE4RTtNQUF2RSxLQUFLLEVBQUUsWUFBSyxNQUFNLFlBQUs7O0lBRTlCLG9CQWdHTSxPQWhHTixVQWdHTTtNQTlGSixnQ0FBZ0I7TUFDaEIsb0JBMERRLFNBMURSLFVBMERRO1FBekROLDZCQUFhO1FBQ2Isb0JBR00sT0FITixVQUdNO1VBRkosYUFBcUQ7WUFBL0MsSUFBSSxFQUFDLE1BQU07WUFBQyxLQUFLLEVBQUMsMEJBQTBCOztvQ0FDbEQsb0JBQXdGLFVBQWxGLEtBQUssRUFBQyw2REFBNkQsSUFBQyxTQUFPOztRQUduRiw2QkFBYTtRQUNiLG9CQWdDTSxPQWhDTixVQWdDTTtVQS9CSixvQkFnQk07c0NBZkosb0JBQThGLFNBQXpGLEtBQUssRUFBQyx3RUFBd0UsSUFBQyxNQUFJO1lBQ3hGLG9CQWFNLE9BYk4sVUFhTTtjQVpKLGFBR087Z0JBSEQsSUFBSSxFQUFDLGtCQUFrQjtnQkFBRSxLQUFLLHdHQUF3RixVQUFLLENBQUMsR0FBRzs7a0NBQ25JLENBQW9DO2tCQUFwQyxhQUFvQztvQkFBOUIsSUFBSSxFQUFDLE1BQU07b0JBQUMsS0FBSyxFQUFDLFNBQVM7OzZEQUFHLGFBRXRDOzs7O2NBQ0EsYUFHTztnQkFIRCxJQUFJLEVBQUMsaUJBQWlCO2dCQUFFLEtBQUssd0dBQXdGLFVBQUssQ0FBQyxHQUFHLENBQUMsVUFBVTs7a0NBQzdJLENBQW1DO2tCQUFuQyxhQUFtQztvQkFBN0IsSUFBSSxFQUFDLEtBQUs7b0JBQUMsS0FBSyxFQUFDLFNBQVM7OzZEQUFHLGlCQUVyQzs7OztjQUNBLGFBR087Z0JBSEQsSUFBSSxFQUFDLGlCQUFpQjtnQkFBRSxLQUFLLHdHQUF3RixVQUFLLENBQUMsR0FBRyxDQUFDLFVBQVU7O2tDQUM3SSxDQUFvQztrQkFBcEMsYUFBb0M7b0JBQTlCLElBQUksRUFBQyxNQUFNO29CQUFDLEtBQUssRUFBQyxTQUFTOzs2REFBRyxtQkFFdEM7Ozs7OztVQUlKLG9CQVlNO3NDQVhKLG9CQUFpRyxTQUE1RixLQUFLLEVBQUMsd0VBQXdFLElBQUMsU0FBTztZQUMzRixvQkFTTSxPQVROLFVBU007Y0FSSixhQUdPO2dCQUhELElBQUksRUFBQyxpQkFBaUI7Z0JBQUUsS0FBSyx3R0FBd0YsVUFBSyxDQUFDLEdBQUcsQ0FBQyxVQUFVOztrQ0FDN0ksQ0FBd0M7a0JBQXhDLGFBQXdDO29CQUFsQyxJQUFJLEVBQUMsVUFBVTtvQkFBQyxLQUFLLEVBQUMsU0FBUzs7NkRBQUcsa0JBRTFDOzs7O2NBQ0EsYUFHTztnQkFIRCxNQUFNLEVBQUMsTUFBTTtnQkFBQyxJQUFJLEVBQUMsZUFBZTtnQkFBQyxFQUFFLEVBQUMsUUFBUTtnQkFBQyxLQUFLLEVBQUMsMEtBQTBLOztrQ0FDbk8sQ0FBc0M7a0JBQXRDLGFBQXNDO29CQUFoQyxJQUFJLEVBQUMsUUFBUTtvQkFBQyxLQUFLLEVBQUMsU0FBUzs7NkRBQUcsVUFFeEM7Ozs7Ozs7UUFLTixxQ0FBcUI7UUFDckIsb0JBY00sT0FkTixVQWNNO1VBYkosb0JBWU0sT0FaTixVQVlNO1lBWEosb0JBT00sT0FQTixVQU9NO2NBTkosb0JBRU0sT0FGTixXQUVNO2dCQURKLGFBQStDO2tCQUF6QyxJQUFJLEVBQUMsTUFBTTtrQkFBQyxLQUFLLEVBQUMsb0JBQW9COzs7d0NBRTlDLG9CQUF1RCxRQUFuRCxLQUFLLEVBQUMsd0JBQXdCLElBQUMsaUJBQWU7d0NBQ2xELG9CQUFzSCxPQUFuSCxLQUFLLEVBQUMsc0RBQXNELElBQUMsb0RBQWtEOzBDQUNsSCxvQkFBc0s7Z0JBQW5LLElBQUksRUFBQyxHQUFHO2dCQUFDLE1BQU0sRUFBQyxRQUFRO2dCQUFDLEtBQUssRUFBQyxrSEFBa0g7aUJBQUMsZUFBYTs7WUFFcEssNkJBQWE7d0NBQ2Isb0JBQTBGLFNBQXJGLEtBQUssRUFBQyx3RUFBd0U7d0NBQ25GLG9CQUFzRixTQUFqRixLQUFLLEVBQUMsb0VBQW9FOzs7O01BS3JGLHFDQUFxQjtNQUNyQixvQkErQk0sT0EvQk4sV0ErQk07UUE3QkosK0JBQWU7UUFDZixvQkFxQlMsVUFyQlQsV0FxQlM7VUFuQlAsa0NBQWtCO1VBQ2xCLG9CQUdNO1lBRkosb0JBQTZFLE1BQTdFLFdBQTZFLG1CQUE5QixZQUFLO1lBQ3BELG9CQUFzSixLQUF0SixXQUFzSix1QkFBOUcsSUFBSSxHQUFHLGtCQUFrQjs7VUFHbkUsbUNBQW1CO1VBQ25CLG9CQVdNLE9BWE4sV0FXTTtZQVRKLG9CQVFNLE9BUk4sV0FRTTtjQVBKLG9CQUVNLE9BRk4sV0FFTSxtQkFERCxVQUFLLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU07Y0FFekMsb0JBR00sT0FITixXQUdNO2dCQUZKLG9CQUFtSSxLQUFuSSxXQUFtSSxtQkFBOUMsVUFBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUk7Z0JBQ2pILG9CQUE4RixLQUE5RixXQUE4RixtQkFBMUQsVUFBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUs7Ozs7O1FBTXpFLHFDQUFxQjtRQUNyQixvQkFFTyxRQUZQLFdBRU87VUFETCxZQUFRIiwiaWdub3JlTGlzdCI6W119