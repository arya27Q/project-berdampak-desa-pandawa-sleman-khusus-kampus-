import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Components/Icon.vue");
const _sfc_main = {
  __name: 'Icon',
  props: {
  name: {
    type: String,
    required: true,
  },
},
  setup(__props, { expose: __expose }) {
  __expose();



const __returned__ = {  }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, mergeProps as _mergeProps, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return ($props.name === 'leaf')
    ? (_openBlock(), _createElementBlock("svg", _mergeProps({
        key: 0,
        viewBox: "0 0 24 24",
        "aria-hidden": "true",
        fill: "none"
      }, _ctx.$attrs), [...(_cache[0] || (_cache[0] = [
        _createElementVNode("path", {
          d: "M4 20C4 11 11 4 20 4C20 13 13 20 4 20Z",
          fill: "currentColor",
          opacity: "0.9"
        }, null, -1 /* CACHED */),
        _createElementVNode("path", {
          d: "M4 20C9 15 14 10 18 6",
          stroke: "var(--color-cream)",
          "stroke-width": "1.2",
          "stroke-linecap": "round"
        }, null, -1 /* CACHED */)
      ]))], 16 /* FULL_PROPS */))
    : ($props.name === 'whatsapp')
      ? (_openBlock(), _createElementBlock("svg", _mergeProps({
          key: 1,
          viewBox: "0 0 24 24",
          "aria-hidden": "true",
          fill: "currentColor"
        }, _ctx.$attrs), [...(_cache[1] || (_cache[1] = [
          _createElementVNode("path", { d: "M17.5 14.4c-.3-.2-1.7-.9-2-1-.3-.1-.5-.2-.6.2-.2.3-.7.9-.9 1.1-.2.2-.3.2-.6.1-1.6-.8-2.7-1.5-3.7-3.4-.3-.5.3-.5.8-1.5.1-.2 0-.3 0-.5s-.6-1.6-.9-2.1c-.2-.5-.4-.5-.6-.5h-.5c-.2 0-.5.1-.7.3-.3.3-1 1-1 2.4s1 2.8 1.2 3c.1.2 2 3.1 5 4.3 1.8.8 2.5.8 3.4.7.5-.1 1.7-.7 1.9-1.4.2-.6.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3z" }, null, -1 /* CACHED */),
          _createElementVNode("path", { d: "M12 2a10 10 0 0 0-8.5 15.2L2 22l4.9-1.4A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.3-1.1l-.3-.2-2.9.8.8-2.8-.2-.3A8.2 8.2 0 1 1 12 20.2z" }, null, -1 /* CACHED */)
        ]))], 16 /* FULL_PROPS */))
      : ($props.name === 'clock')
        ? (_openBlock(), _createElementBlock("svg", _mergeProps({
            key: 2,
            viewBox: "0 0 24 24",
            "aria-hidden": "true",
            fill: "none",
            stroke: "currentColor",
            "stroke-width": "1.8",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
          }, _ctx.$attrs), [...(_cache[2] || (_cache[2] = [
            _createElementVNode("circle", {
              cx: "12",
              cy: "12",
              r: "9"
            }, null, -1 /* CACHED */),
            _createElementVNode("path", { d: "M12 7v5l3 2" }, null, -1 /* CACHED */)
          ]))], 16 /* FULL_PROPS */))
        : ($props.name === 'pin')
          ? (_openBlock(), _createElementBlock("svg", _mergeProps({
              key: 3,
              viewBox: "0 0 24 24",
              "aria-hidden": "true",
              fill: "none",
              stroke: "currentColor",
              "stroke-width": "1.8",
              "stroke-linecap": "round",
              "stroke-linejoin": "round"
            }, _ctx.$attrs), [...(_cache[3] || (_cache[3] = [
              _createElementVNode("path", { d: "M12 21s7-6 7-11a7 7 0 1 0-14 0c0 5 7 11 7 11z" }, null, -1 /* CACHED */),
              _createElementVNode("circle", {
                cx: "12",
                cy: "10",
                r: "2.5"
              }, null, -1 /* CACHED */)
            ]))], 16 /* FULL_PROPS */))
          : ($props.name === 'chat')
            ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                key: 4,
                viewBox: "0 0 24 24",
                "aria-hidden": "true",
                fill: "none",
                stroke: "currentColor",
                "stroke-width": "1.8",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }, _ctx.$attrs), [...(_cache[4] || (_cache[4] = [
                _createElementVNode("path", { d: "M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.5A8 8 0 1 1 21 12z" }, null, -1 /* CACHED */)
              ]))], 16 /* FULL_PROPS */))
            : ($props.name === 'check')
              ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                  key: 5,
                  viewBox: "0 0 24 24",
                  "aria-hidden": "true",
                  fill: "none",
                  stroke: "currentColor",
                  "stroke-width": "2.2",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }, _ctx.$attrs), [...(_cache[5] || (_cache[5] = [
                  _createElementVNode("path", { d: "M5 13l4 4L19 7" }, null, -1 /* CACHED */)
                ]))], 16 /* FULL_PROPS */))
              : ($props.name === 'mail')
                ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                    key: 6,
                    viewBox: "0 0 24 24",
                    "aria-hidden": "true",
                    fill: "none",
                    stroke: "currentColor",
                    "stroke-width": "1.8",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                  }, _ctx.$attrs), [...(_cache[6] || (_cache[6] = [
                    _createElementVNode("rect", {
                      x: "3",
                      y: "5",
                      width: "18",
                      height: "14",
                      rx: "2"
                    }, null, -1 /* CACHED */),
                    _createElementVNode("path", { d: "M3 7l9 6 9-6" }, null, -1 /* CACHED */)
                  ]))], 16 /* FULL_PROPS */))
                : ($props.name === 'basket')
                  ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                      key: 7,
                      viewBox: "0 0 24 24",
                      "aria-hidden": "true",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.8",
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round"
                    }, _ctx.$attrs), [...(_cache[7] || (_cache[7] = [
                      _createElementVNode("path", { d: "M5 9h14l-1.2 9.5a2 2 0 0 1-2 1.5H8.2a2 2 0 0 1-2-1.5L5 9z" }, null, -1 /* CACHED */),
                      _createElementVNode("path", { d: "M9 9l3-5 3 5" }, null, -1 /* CACHED */)
                    ]))], 16 /* FULL_PROPS */))
                  : ($props.name === 'truck')
                    ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                        key: 8,
                        viewBox: "0 0 24 24",
                        "aria-hidden": "true",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "1.8",
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round"
                      }, _ctx.$attrs), [...(_cache[8] || (_cache[8] = [
                        _createElementVNode("path", { d: "M3 6h11v9H3zM14 9h4l3 3v3h-7z" }, null, -1 /* CACHED */),
                        _createElementVNode("circle", {
                          cx: "7",
                          cy: "18",
                          r: "1.6"
                        }, null, -1 /* CACHED */),
                        _createElementVNode("circle", {
                          cx: "17.5",
                          cy: "18",
                          r: "1.6"
                        }, null, -1 /* CACHED */)
                      ]))], 16 /* FULL_PROPS */))
                    : ($props.name === 'arrow')
                      ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                          key: 9,
                          viewBox: "0 0 24 24",
                          "aria-hidden": "true",
                          fill: "none",
                          stroke: "currentColor",
                          "stroke-width": "2",
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round"
                        }, _ctx.$attrs), [...(_cache[9] || (_cache[9] = [
                          _createElementVNode("path", { d: "M5 12h14M13 6l6 6-6 6" }, null, -1 /* CACHED */)
                        ]))], 16 /* FULL_PROPS */))
                      : ($props.name === 'grid')
                        ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                            key: 10,
                            viewBox: "0 0 24 24",
                            "aria-hidden": "true",
                            fill: "none",
                            stroke: "currentColor",
                            "stroke-width": "1.8",
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round"
                          }, _ctx.$attrs), [...(_cache[10] || (_cache[10] = [
                            _createElementVNode("rect", {
                              x: "3",
                              y: "3",
                              width: "7",
                              height: "7",
                              rx: "1.5"
                            }, null, -1 /* CACHED */),
                            _createElementVNode("rect", {
                              x: "14",
                              y: "3",
                              width: "7",
                              height: "7",
                              rx: "1.5"
                            }, null, -1 /* CACHED */),
                            _createElementVNode("rect", {
                              x: "3",
                              y: "14",
                              width: "7",
                              height: "7",
                              rx: "1.5"
                            }, null, -1 /* CACHED */),
                            _createElementVNode("rect", {
                              x: "14",
                              y: "14",
                              width: "7",
                              height: "7",
                              rx: "1.5"
                            }, null, -1 /* CACHED */)
                          ]))], 16 /* FULL_PROPS */))
                        : ($props.name === 'box')
                          ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                              key: 11,
                              viewBox: "0 0 24 24",
                              "aria-hidden": "true",
                              fill: "none",
                              stroke: "currentColor",
                              "stroke-width": "1.8",
                              "stroke-linecap": "round",
                              "stroke-linejoin": "round"
                            }, _ctx.$attrs), [...(_cache[11] || (_cache[11] = [
                              _createElementVNode("path", { d: "M21 8l-9-5-9 5v8l9 5 9-5V8z" }, null, -1 /* CACHED */),
                              _createElementVNode("path", { d: "M3 8l9 5 9-5M12 13v8" }, null, -1 /* CACHED */)
                            ]))], 16 /* FULL_PROPS */))
                          : ($props.name === 'file')
                            ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                                key: 12,
                                viewBox: "0 0 24 24",
                                "aria-hidden": "true",
                                fill: "none",
                                stroke: "currentColor",
                                "stroke-width": "1.8",
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round"
                              }, _ctx.$attrs), [...(_cache[12] || (_cache[12] = [
                                _createElementVNode("path", { d: "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" }, null, -1 /* CACHED */),
                                _createElementVNode("path", { d: "M14 3v5h5M9 13h6M9 17h6" }, null, -1 /* CACHED */)
                              ]))], 16 /* FULL_PROPS */))
                            : ($props.name === 'settings')
                              ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                                  key: 13,
                                  viewBox: "0 0 24 24",
                                  "aria-hidden": "true",
                                  fill: "none",
                                  stroke: "currentColor",
                                  "stroke-width": "1.8",
                                  "stroke-linecap": "round",
                                  "stroke-linejoin": "round"
                                }, _ctx.$attrs), [...(_cache[13] || (_cache[13] = [
                                  _createElementVNode("circle", {
                                    cx: "12",
                                    cy: "12",
                                    r: "3"
                                  }, null, -1 /* CACHED */),
                                  _createElementVNode("path", { d: "M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 7 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H1a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 2.6 7a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 7 2.6h.1A1.6 1.6 0 0 0 8 1.1V1a2 2 0 1 1 4 0v.1A1.6 1.6 0 0 0 15 2.6a1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8v.1a1.6 1.6 0 0 0 1.5 1H23a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z" }, null, -1 /* CACHED */)
                                ]))], 16 /* FULL_PROPS */))
                              : ($props.name === 'logout')
                                ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                                    key: 14,
                                    viewBox: "0 0 24 24",
                                    "aria-hidden": "true",
                                    fill: "none",
                                    stroke: "currentColor",
                                    "stroke-width": "1.8",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round"
                                  }, _ctx.$attrs), [...(_cache[14] || (_cache[14] = [
                                    _createElementVNode("path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" }, null, -1 /* CACHED */)
                                  ]))], 16 /* FULL_PROPS */))
                                : ($props.name === 'search')
                                  ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                                      key: 15,
                                      viewBox: "0 0 24 24",
                                      "aria-hidden": "true",
                                      fill: "none",
                                      stroke: "currentColor",
                                      "stroke-width": "1.8",
                                      "stroke-linecap": "round",
                                      "stroke-linejoin": "round"
                                    }, _ctx.$attrs), [...(_cache[15] || (_cache[15] = [
                                      _createElementVNode("circle", {
                                        cx: "11",
                                        cy: "11",
                                        r: "8"
                                      }, null, -1 /* CACHED */),
                                      _createElementVNode("path", { d: "M21 21l-4.35-4.35" }, null, -1 /* CACHED */)
                                    ]))], 16 /* FULL_PROPS */))
                                  : ($props.name === 'bell')
                                    ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                                        key: 16,
                                        viewBox: "0 0 24 24",
                                        "aria-hidden": "true",
                                        fill: "none",
                                        stroke: "currentColor",
                                        "stroke-width": "1.8",
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round"
                                      }, _ctx.$attrs), [...(_cache[16] || (_cache[16] = [
                                        _createElementVNode("path", { d: "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" }, null, -1 /* CACHED */),
                                        _createElementVNode("path", { d: "M13.73 21a2 2 0 0 1-3.46 0" }, null, -1 /* CACHED */)
                                      ]))], 16 /* FULL_PROPS */))
                                    : ($props.name === 'plus')
                                      ? (_openBlock(), _createElementBlock("svg", _mergeProps({
                                          key: 17,
                                          viewBox: "0 0 24 24",
                                          "aria-hidden": "true",
                                          fill: "none",
                                          stroke: "currentColor",
                                          "stroke-width": "1.8",
                                          "stroke-linecap": "round",
                                          "stroke-linejoin": "round"
                                        }, _ctx.$attrs), [...(_cache[17] || (_cache[17] = [
                                          _createElementVNode("path", { d: "M12 5v14M5 12h14" }, null, -1 /* CACHED */)
                                        ]))], 16 /* FULL_PROPS */))
                                      : _createCommentVNode("v-if", true)
}



_sfc_main.__hmrId = "62999225"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Components/Icon.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSWNvbi52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbmRlZmluZVByb3BzKHtcbiAgbmFtZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICByZXF1aXJlZDogdHJ1ZSxcbiAgfSxcbn0pO1xuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPHN2ZyB2LWlmPVwibmFtZSA9PT0gJ2xlYWYnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHBhdGggZD1cIk00IDIwQzQgMTEgMTEgNCAyMCA0QzIwIDEzIDEzIDIwIDQgMjBaXCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIG9wYWNpdHk9XCIwLjlcIiAvPlxuICAgIDxwYXRoIGQ9XCJNNCAyMEM5IDE1IDE0IDEwIDE4IDZcIiBzdHJva2U9XCJ2YXIoLS1jb2xvci1jcmVhbSlcIiBzdHJva2Utd2lkdGg9XCIxLjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgLz5cbiAgPC9zdmc+XG4gIDxzdmcgdi1lbHNlLWlmPVwibmFtZSA9PT0gJ3doYXRzYXBwJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwiY3VycmVudENvbG9yXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHBhdGggZD1cIk0xNy41IDE0LjRjLS4zLS4yLTEuNy0uOS0yLTEtLjMtLjEtLjUtLjItLjYuMi0uMi4zLS43LjktLjkgMS4xLS4yLjItLjMuMi0uNi4xLTEuNi0uOC0yLjctMS41LTMuNy0zLjQtLjMtLjUuMy0uNS44LTEuNS4xLS4yIDAtLjMgMC0uNXMtLjYtMS42LS45LTIuMWMtLjItLjUtLjQtLjUtLjYtLjVoLS41Yy0uMiAwLS41LjEtLjcuMy0uMy4zLTEgMS0xIDIuNHMxIDIuOCAxLjIgM2MuMS4yIDIgMy4xIDUgNC4zIDEuOC44IDIuNS44IDMuNC43LjUtLjEgMS43LS43IDEuOS0xLjQuMi0uNi4yLTEuMi4yLTEuNC0uMS0uMS0uMy0uMi0uNi0uM3pcIiAvPlxuICAgIDxwYXRoIGQ9XCJNMTIgMmExMCAxMCAwIDAgMC04LjUgMTUuMkwyIDIybDQuOS0xLjRBMTAgMTAgMCAxIDAgMTIgMnptMCAxOC4yYy0xLjUgMC0zLS40LTQuMy0xLjFsLS4zLS4yLTIuOS44LjgtMi44LS4yLS4zQTguMiA4LjIgMCAxIDEgMTIgMjAuMnpcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAnY2xvY2snXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCI5XCIgLz5cbiAgICA8cGF0aCBkPVwiTTEyIDd2NWwzIDJcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAncGluJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxwYXRoIGQ9XCJNMTIgMjFzNy02IDctMTFhNyA3IDAgMSAwLTE0IDBjMCA1IDcgMTEgNyAxMXpcIiAvPlxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTBcIiByPVwiMi41XCIgLz5cbiAgPC9zdmc+XG4gIDxzdmcgdi1lbHNlLWlmPVwibmFtZSA9PT0gJ2NoYXQnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHBhdGggZD1cIk0yMSAxMmE4IDggMCAwIDEtMTEuNSA3LjJMNCAyMGwxLTQuNUE4IDggMCAxIDEgMjEgMTJ6XCIgLz5cbiAgPC9zdmc+XG4gIDxzdmcgdi1lbHNlLWlmPVwibmFtZSA9PT0gJ2NoZWNrJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjIuMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxwYXRoIGQ9XCJNNSAxM2w0IDRMMTkgN1wiIC8+XG4gIDwvc3ZnPlxuICA8c3ZnIHYtZWxzZS1pZj1cIm5hbWUgPT09ICdtYWlsJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxyZWN0IHg9XCIzXCIgeT1cIjVcIiB3aWR0aD1cIjE4XCIgaGVpZ2h0PVwiMTRcIiByeD1cIjJcIiAvPlxuICAgIDxwYXRoIGQ9XCJNMyA3bDkgNiA5LTZcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAnYmFza2V0J1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxwYXRoIGQ9XCJNNSA5aDE0bC0xLjIgOS41YTIgMiAwIDAgMS0yIDEuNUg4LjJhMiAyIDAgMCAxLTItMS41TDUgOXpcIiAvPlxuICAgIDxwYXRoIGQ9XCJNOSA5bDMtNSAzIDVcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAndHJ1Y2snXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHBhdGggZD1cIk0zIDZoMTF2OUgzek0xNCA5aDRsMyAzdjNoLTd6XCIgLz5cbiAgICA8Y2lyY2xlIGN4PVwiN1wiIGN5PVwiMThcIiByPVwiMS42XCIgLz5cbiAgICA8Y2lyY2xlIGN4PVwiMTcuNVwiIGN5PVwiMThcIiByPVwiMS42XCIgLz5cbiAgPC9zdmc+XG4gIDxzdmcgdi1lbHNlLWlmPVwibmFtZSA9PT0gJ2Fycm93J1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiB2LWJpbmQ9XCIkYXR0cnNcIj5cbiAgICA8cGF0aCBkPVwiTTUgMTJoMTRNMTMgNmw2IDYtNiA2XCIgLz5cbiAgPC9zdmc+XG4gIDxzdmcgdi1lbHNlLWlmPVwibmFtZSA9PT0gJ2dyaWQnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHJlY3QgeD1cIjNcIiB5PVwiM1wiIHdpZHRoPVwiN1wiIGhlaWdodD1cIjdcIiByeD1cIjEuNVwiIC8+XG4gICAgPHJlY3QgeD1cIjE0XCIgeT1cIjNcIiB3aWR0aD1cIjdcIiBoZWlnaHQ9XCI3XCIgcng9XCIxLjVcIiAvPlxuICAgIDxyZWN0IHg9XCIzXCIgeT1cIjE0XCIgd2lkdGg9XCI3XCIgaGVpZ2h0PVwiN1wiIHJ4PVwiMS41XCIgLz5cbiAgICA8cmVjdCB4PVwiMTRcIiB5PVwiMTRcIiB3aWR0aD1cIjdcIiBoZWlnaHQ9XCI3XCIgcng9XCIxLjVcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAnYm94J1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxwYXRoIGQ9XCJNMjEgOGwtOS01LTkgNXY4bDkgNSA5LTVWOHpcIiAvPlxuICAgIDxwYXRoIGQ9XCJNMyA4bDkgNSA5LTVNMTIgMTN2OFwiIC8+XG4gIDwvc3ZnPlxuICA8c3ZnIHYtZWxzZS1pZj1cIm5hbWUgPT09ICdmaWxlJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxwYXRoIGQ9XCJNMTQgM0g3YTIgMiAwIDAgMC0yIDJ2MTRhMiAyIDAgMCAwIDIgMmgxMGEyIDIgMCAwIDAgMi0yVjh6XCIgLz5cbiAgICA8cGF0aCBkPVwiTTE0IDN2NWg1TTkgMTNoNk05IDE3aDZcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAnc2V0dGluZ3MnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIzXCIgLz5cbiAgICA8cGF0aCBkPVwiTTE5LjQgMTVhMS42IDEuNiAwIDAgMCAuMyAxLjhsLjEuMWEyIDIgMCAxIDEtMi44IDIuOGwtLjEtLjFhMS42IDEuNiAwIDAgMC0yLjcgMS4xVjIxYTIgMiAwIDEgMS00IDB2LS4xQTEuNiAxLjYgMCAwIDAgNyAxOS40YTEuNiAxLjYgMCAwIDAtMS44LjNsLS4xLjFhMiAyIDAgMSAxLTIuOC0yLjhsLjEtLjFhMS42IDEuNiAwIDAgMC0xLjEtMi43SDFhMiAyIDAgMSAxIDAtNGguMUExLjYgMS42IDAgMCAwIDIuNiA3YTEuNiAxLjYgMCAwIDAtLjMtMS44bC0uMS0uMWEyIDIgMCAxIDEgMi44LTIuOGwuMS4xQTEuNiAxLjYgMCAwIDAgNyAyLjZoLjFBMS42IDEuNiAwIDAgMCA4IDEuMVYxYTIgMiAwIDEgMSA0IDB2LjFBMS42IDEuNiAwIDAgMCAxNSAyLjZhMS42IDEuNiAwIDAgMCAxLjgtLjNsLjEtLjFhMiAyIDAgMSAxIDIuOCAyLjhsLS4xLjFhMS42IDEuNiAwIDAgMC0uMyAxLjh2LjFhMS42IDEuNiAwIDAgMCAxLjUgMUgyM2EyIDIgMCAxIDEgMCA0aC0uMWExLjYgMS42IDAgMCAwLTEuNSAxelwiIC8+XG4gIDwvc3ZnPlxuICA8c3ZnIHYtZWxzZS1pZj1cIm5hbWUgPT09ICdsb2dvdXQnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHBhdGggZD1cIk05IDIxSDVhMiAyIDAgMCAxLTItMlY1YTIgMiAwIDAgMSAyLTJoNE0xNiAxN2w1LTUtNS01TTIxIDEySDlcIiAvPlxuICA8L3N2Zz5cbiAgPHN2ZyB2LWVsc2UtaWY9XCJuYW1lID09PSAnc2VhcmNoJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxjaXJjbGUgY3g9XCIxMVwiIGN5PVwiMTFcIiByPVwiOFwiIC8+XG4gICAgPHBhdGggZD1cIk0yMSAyMWwtNC4zNS00LjM1XCIgLz5cbiAgPC9zdmc+XG4gIDxzdmcgdi1lbHNlLWlmPVwibmFtZSA9PT0gJ2JlbGwnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMS44XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgdi1iaW5kPVwiJGF0dHJzXCI+XG4gICAgPHBhdGggZD1cIk0xOCA4QTYgNiAwIDAgMCA2IDhjMCA3LTMgOS0zIDloMThzLTMtMi0zLTlcIiAvPlxuICAgIDxwYXRoIGQ9XCJNMTMuNzMgMjFhMiAyIDAgMCAxLTMuNDYgMFwiIC8+XG4gIDwvc3ZnPlxuICA8c3ZnIHYtZWxzZS1pZj1cIm5hbWUgPT09ICdwbHVzJ1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjEuOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHYtYmluZD1cIiRhdHRyc1wiPlxuICAgIDxwYXRoIGQ9XCJNMTIgNXYxNE01IDEyaDE0XCIgLz5cbiAgPC9zdmc+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztVQVVhLFdBQUk7cUJBQWYsb0JBR00sT0FITixZQUdNOztRQUhzQixPQUFPLEVBQUMsV0FBVztRQUFDLGFBQVcsRUFBQyxNQUFNO1FBQUMsSUFBSSxFQUFDLE1BQU07U0FBUyxXQUFNO1FBQzNGLG9CQUFxRjtVQUEvRSxDQUFDLEVBQUMsd0NBQXdDO1VBQUMsSUFBSSxFQUFDLGNBQWM7VUFBQyxPQUFPLEVBQUMsS0FBSzs7UUFDbEYsb0JBQXdHO1VBQWxHLENBQUMsRUFBQyx1QkFBdUI7VUFBQyxNQUFNLEVBQUMsb0JBQW9CO1VBQUMsY0FBWSxFQUFDLEtBQUs7VUFBQyxnQkFBYyxFQUFDLE9BQU87OztPQUV2RixXQUFJO3VCQUFwQixvQkFHTSxPQUhOLFlBR007O1VBSCtCLE9BQU8sRUFBQyxXQUFXO1VBQUMsYUFBVyxFQUFDLE1BQU07VUFBQyxJQUFJLEVBQUMsY0FBYztXQUFTLFdBQU07VUFDNUcsb0JBQTZULFVBQXZULENBQUMsRUFBQyxrVEFBa1Q7VUFDMVQsb0JBQWlKLFVBQTNJLENBQUMsRUFBQyxzSUFBc0k7O1NBRWhJLFdBQUk7eUJBQXBCLG9CQUdNLE9BSE4sWUFHTTs7WUFINEIsT0FBTyxFQUFDLFdBQVc7WUFBQyxhQUFXLEVBQUMsTUFBTTtZQUFDLElBQUksRUFBQyxNQUFNO1lBQUMsTUFBTSxFQUFDLGNBQWM7WUFBQyxjQUFZLEVBQUMsS0FBSztZQUFDLGdCQUFjLEVBQUMsT0FBTztZQUFDLGlCQUFlLEVBQUMsT0FBTzthQUFTLFdBQU07WUFDekwsb0JBQWdDO2NBQXhCLEVBQUUsRUFBQyxJQUFJO2NBQUMsRUFBRSxFQUFDLElBQUk7Y0FBQyxDQUFDLEVBQUMsR0FBRzs7WUFDN0Isb0JBQXdCLFVBQWxCLENBQUMsRUFBQyxhQUFhOztXQUVQLFdBQUk7MkJBQXBCLG9CQUdNLE9BSE4sWUFHTTs7Y0FIMEIsT0FBTyxFQUFDLFdBQVc7Y0FBQyxhQUFXLEVBQUMsTUFBTTtjQUFDLElBQUksRUFBQyxNQUFNO2NBQUMsTUFBTSxFQUFDLGNBQWM7Y0FBQyxjQUFZLEVBQUMsS0FBSztjQUFDLGdCQUFjLEVBQUMsT0FBTztjQUFDLGlCQUFlLEVBQUMsT0FBTztlQUFTLFdBQU07Y0FDdkwsb0JBQTBELFVBQXBELENBQUMsRUFBQywrQ0FBK0M7Y0FDdkQsb0JBQWtDO2dCQUExQixFQUFFLEVBQUMsSUFBSTtnQkFBQyxFQUFFLEVBQUMsSUFBSTtnQkFBQyxDQUFDLEVBQUMsS0FBSzs7O2FBRWpCLFdBQUk7NkJBQXBCLG9CQUVNLE9BRk4sWUFFTTs7Z0JBRjJCLE9BQU8sRUFBQyxXQUFXO2dCQUFDLGFBQVcsRUFBQyxNQUFNO2dCQUFDLElBQUksRUFBQyxNQUFNO2dCQUFDLE1BQU0sRUFBQyxjQUFjO2dCQUFDLGNBQVksRUFBQyxLQUFLO2dCQUFDLGdCQUFjLEVBQUMsT0FBTztnQkFBQyxpQkFBZSxFQUFDLE9BQU87aUJBQVMsV0FBTTtnQkFDeEwsb0JBQWtFLFVBQTVELENBQUMsRUFBQyx1REFBdUQ7O2VBRWpELFdBQUk7K0JBQXBCLG9CQUVNLE9BRk4sWUFFTTs7a0JBRjRCLE9BQU8sRUFBQyxXQUFXO2tCQUFDLGFBQVcsRUFBQyxNQUFNO2tCQUFDLElBQUksRUFBQyxNQUFNO2tCQUFDLE1BQU0sRUFBQyxjQUFjO2tCQUFDLGNBQVksRUFBQyxLQUFLO2tCQUFDLGdCQUFjLEVBQUMsT0FBTztrQkFBQyxpQkFBZSxFQUFDLE9BQU87bUJBQVMsV0FBTTtrQkFDekwsb0JBQTJCLFVBQXJCLENBQUMsRUFBQyxnQkFBZ0I7O2lCQUVWLFdBQUk7aUNBQXBCLG9CQUdNLE9BSE4sWUFHTTs7b0JBSDJCLE9BQU8sRUFBQyxXQUFXO29CQUFDLGFBQVcsRUFBQyxNQUFNO29CQUFDLElBQUksRUFBQyxNQUFNO29CQUFDLE1BQU0sRUFBQyxjQUFjO29CQUFDLGNBQVksRUFBQyxLQUFLO29CQUFDLGdCQUFjLEVBQUMsT0FBTztvQkFBQyxpQkFBZSxFQUFDLE9BQU87cUJBQVMsV0FBTTtvQkFDeEwsb0JBQWtEO3NCQUE1QyxDQUFDLEVBQUMsR0FBRztzQkFBQyxDQUFDLEVBQUMsR0FBRztzQkFBQyxLQUFLLEVBQUMsSUFBSTtzQkFBQyxNQUFNLEVBQUMsSUFBSTtzQkFBQyxFQUFFLEVBQUMsR0FBRzs7b0JBQy9DLG9CQUF5QixVQUFuQixDQUFDLEVBQUMsY0FBYzs7bUJBRVIsV0FBSTttQ0FBcEIsb0JBR00sT0FITixZQUdNOztzQkFINkIsT0FBTyxFQUFDLFdBQVc7c0JBQUMsYUFBVyxFQUFDLE1BQU07c0JBQUMsSUFBSSxFQUFDLE1BQU07c0JBQUMsTUFBTSxFQUFDLGNBQWM7c0JBQUMsY0FBWSxFQUFDLEtBQUs7c0JBQUMsZ0JBQWMsRUFBQyxPQUFPO3NCQUFDLGlCQUFlLEVBQUMsT0FBTzt1QkFBUyxXQUFNO3NCQUMxTCxvQkFBc0UsVUFBaEUsQ0FBQyxFQUFDLDJEQUEyRDtzQkFDbkUsb0JBQXlCLFVBQW5CLENBQUMsRUFBQyxjQUFjOztxQkFFUixXQUFJO3FDQUFwQixvQkFJTSxPQUpOLFlBSU07O3dCQUo0QixPQUFPLEVBQUMsV0FBVzt3QkFBQyxhQUFXLEVBQUMsTUFBTTt3QkFBQyxJQUFJLEVBQUMsTUFBTTt3QkFBQyxNQUFNLEVBQUMsY0FBYzt3QkFBQyxjQUFZLEVBQUMsS0FBSzt3QkFBQyxnQkFBYyxFQUFDLE9BQU87d0JBQUMsaUJBQWUsRUFBQyxPQUFPO3lCQUFTLFdBQU07d0JBQ3pMLG9CQUEwQyxVQUFwQyxDQUFDLEVBQUMsK0JBQStCO3dCQUN2QyxvQkFBaUM7MEJBQXpCLEVBQUUsRUFBQyxHQUFHOzBCQUFDLEVBQUUsRUFBQyxJQUFJOzBCQUFDLENBQUMsRUFBQyxLQUFLOzt3QkFDOUIsb0JBQW9DOzBCQUE1QixFQUFFLEVBQUMsTUFBTTswQkFBQyxFQUFFLEVBQUMsSUFBSTswQkFBQyxDQUFDLEVBQUMsS0FBSzs7O3VCQUVuQixXQUFJO3VDQUFwQixvQkFFTSxPQUZOLFlBRU07OzBCQUY0QixPQUFPLEVBQUMsV0FBVzswQkFBQyxhQUFXLEVBQUMsTUFBTTswQkFBQyxJQUFJLEVBQUMsTUFBTTswQkFBQyxNQUFNLEVBQUMsY0FBYzswQkFBQyxjQUFZLEVBQUMsR0FBRzswQkFBQyxnQkFBYyxFQUFDLE9BQU87MEJBQUMsaUJBQWUsRUFBQyxPQUFPOzJCQUFTLFdBQU07MEJBQ3ZMLG9CQUFrQyxVQUE1QixDQUFDLEVBQUMsdUJBQXVCOzt5QkFFakIsV0FBSTt5Q0FBcEIsb0JBS00sT0FMTixZQUtNOzs0QkFMMkIsT0FBTyxFQUFDLFdBQVc7NEJBQUMsYUFBVyxFQUFDLE1BQU07NEJBQUMsSUFBSSxFQUFDLE1BQU07NEJBQUMsTUFBTSxFQUFDLGNBQWM7NEJBQUMsY0FBWSxFQUFDLEtBQUs7NEJBQUMsZ0JBQWMsRUFBQyxPQUFPOzRCQUFDLGlCQUFlLEVBQUMsT0FBTzs2QkFBUyxXQUFNOzRCQUN4TCxvQkFBa0Q7OEJBQTVDLENBQUMsRUFBQyxHQUFHOzhCQUFDLENBQUMsRUFBQyxHQUFHOzhCQUFDLEtBQUssRUFBQyxHQUFHOzhCQUFDLE1BQU0sRUFBQyxHQUFHOzhCQUFDLEVBQUUsRUFBQyxLQUFLOzs0QkFDL0Msb0JBQW1EOzhCQUE3QyxDQUFDLEVBQUMsSUFBSTs4QkFBQyxDQUFDLEVBQUMsR0FBRzs4QkFBQyxLQUFLLEVBQUMsR0FBRzs4QkFBQyxNQUFNLEVBQUMsR0FBRzs4QkFBQyxFQUFFLEVBQUMsS0FBSzs7NEJBQ2hELG9CQUFtRDs4QkFBN0MsQ0FBQyxFQUFDLEdBQUc7OEJBQUMsQ0FBQyxFQUFDLElBQUk7OEJBQUMsS0FBSyxFQUFDLEdBQUc7OEJBQUMsTUFBTSxFQUFDLEdBQUc7OEJBQUMsRUFBRSxFQUFDLEtBQUs7OzRCQUNoRCxvQkFBb0Q7OEJBQTlDLENBQUMsRUFBQyxJQUFJOzhCQUFDLENBQUMsRUFBQyxJQUFJOzhCQUFDLEtBQUssRUFBQyxHQUFHOzhCQUFDLE1BQU0sRUFBQyxHQUFHOzhCQUFDLEVBQUUsRUFBQyxLQUFLOzs7MkJBRW5DLFdBQUk7MkNBQXBCLG9CQUdNLE9BSE4sWUFHTTs7OEJBSDBCLE9BQU8sRUFBQyxXQUFXOzhCQUFDLGFBQVcsRUFBQyxNQUFNOzhCQUFDLElBQUksRUFBQyxNQUFNOzhCQUFDLE1BQU0sRUFBQyxjQUFjOzhCQUFDLGNBQVksRUFBQyxLQUFLOzhCQUFDLGdCQUFjLEVBQUMsT0FBTzs4QkFBQyxpQkFBZSxFQUFDLE9BQU87K0JBQVMsV0FBTTs4QkFDdkwsb0JBQXdDLFVBQWxDLENBQUMsRUFBQyw2QkFBNkI7OEJBQ3JDLG9CQUFpQyxVQUEzQixDQUFDLEVBQUMsc0JBQXNCOzs2QkFFaEIsV0FBSTs2Q0FBcEIsb0JBR00sT0FITixZQUdNOztnQ0FIMkIsT0FBTyxFQUFDLFdBQVc7Z0NBQUMsYUFBVyxFQUFDLE1BQU07Z0NBQUMsSUFBSSxFQUFDLE1BQU07Z0NBQUMsTUFBTSxFQUFDLGNBQWM7Z0NBQUMsY0FBWSxFQUFDLEtBQUs7Z0NBQUMsZ0JBQWMsRUFBQyxPQUFPO2dDQUFDLGlCQUFlLEVBQUMsT0FBTztpQ0FBUyxXQUFNO2dDQUN4TCxvQkFBdUUsVUFBakUsQ0FBQyxFQUFDLDREQUE0RDtnQ0FDcEUsb0JBQW9DLFVBQTlCLENBQUMsRUFBQyx5QkFBeUI7OytCQUVuQixXQUFJOytDQUFwQixvQkFHTSxPQUhOLFlBR007O2tDQUgrQixPQUFPLEVBQUMsV0FBVztrQ0FBQyxhQUFXLEVBQUMsTUFBTTtrQ0FBQyxJQUFJLEVBQUMsTUFBTTtrQ0FBQyxNQUFNLEVBQUMsY0FBYztrQ0FBQyxjQUFZLEVBQUMsS0FBSztrQ0FBQyxnQkFBYyxFQUFDLE9BQU87a0NBQUMsaUJBQWUsRUFBQyxPQUFPO21DQUFTLFdBQU07a0NBQzVMLG9CQUFnQztvQ0FBeEIsRUFBRSxFQUFDLElBQUk7b0NBQUMsRUFBRSxFQUFDLElBQUk7b0NBQUMsQ0FBQyxFQUFDLEdBQUc7O2tDQUM3QixvQkFBc2dCLFVBQWhnQixDQUFDLEVBQUMsMmZBQTJmOztpQ0FFcmYsV0FBSTtpREFBcEIsb0JBRU0sT0FGTixZQUVNOztvQ0FGNkIsT0FBTyxFQUFDLFdBQVc7b0NBQUMsYUFBVyxFQUFDLE1BQU07b0NBQUMsSUFBSSxFQUFDLE1BQU07b0NBQUMsTUFBTSxFQUFDLGNBQWM7b0NBQUMsY0FBWSxFQUFDLEtBQUs7b0NBQUMsZ0JBQWMsRUFBQyxPQUFPO29DQUFDLGlCQUFlLEVBQUMsT0FBTztxQ0FBUyxXQUFNO29DQUMxTCxvQkFBMEUsVUFBcEUsQ0FBQyxFQUFDLCtEQUErRDs7bUNBRXpELFdBQUk7bURBQXBCLG9CQUdNLE9BSE4sWUFHTTs7c0NBSDZCLE9BQU8sRUFBQyxXQUFXO3NDQUFDLGFBQVcsRUFBQyxNQUFNO3NDQUFDLElBQUksRUFBQyxNQUFNO3NDQUFDLE1BQU0sRUFBQyxjQUFjO3NDQUFDLGNBQVksRUFBQyxLQUFLO3NDQUFDLGdCQUFjLEVBQUMsT0FBTztzQ0FBQyxpQkFBZSxFQUFDLE9BQU87dUNBQVMsV0FBTTtzQ0FDMUwsb0JBQWdDO3dDQUF4QixFQUFFLEVBQUMsSUFBSTt3Q0FBQyxFQUFFLEVBQUMsSUFBSTt3Q0FBQyxDQUFDLEVBQUMsR0FBRzs7c0NBQzdCLG9CQUE4QixVQUF4QixDQUFDLEVBQUMsbUJBQW1COztxQ0FFYixXQUFJO3FEQUFwQixvQkFHTSxPQUhOLFlBR007O3dDQUgyQixPQUFPLEVBQUMsV0FBVzt3Q0FBQyxhQUFXLEVBQUMsTUFBTTt3Q0FBQyxJQUFJLEVBQUMsTUFBTTt3Q0FBQyxNQUFNLEVBQUMsY0FBYzt3Q0FBQyxjQUFZLEVBQUMsS0FBSzt3Q0FBQyxnQkFBYyxFQUFDLE9BQU87d0NBQUMsaUJBQWUsRUFBQyxPQUFPO3lDQUFTLFdBQU07d0NBQ3hMLG9CQUF3RCxVQUFsRCxDQUFDLEVBQUMsNkNBQTZDO3dDQUNyRCxvQkFBdUMsVUFBakMsQ0FBQyxFQUFDLDRCQUE0Qjs7dUNBRXRCLFdBQUk7dURBQXBCLG9CQUVNLE9BRk4sWUFFTTs7MENBRjJCLE9BQU8sRUFBQyxXQUFXOzBDQUFDLGFBQVcsRUFBQyxNQUFNOzBDQUFDLElBQUksRUFBQyxNQUFNOzBDQUFDLE1BQU0sRUFBQyxjQUFjOzBDQUFDLGNBQVksRUFBQyxLQUFLOzBDQUFDLGdCQUFjLEVBQUMsT0FBTzswQ0FBQyxpQkFBZSxFQUFDLE9BQU87MkNBQVMsV0FBTTswQ0FDeEwsb0JBQTZCLFVBQXZCLENBQUMsRUFBQyxrQkFBa0IiLCJpZ25vcmVMaXN0IjpbXX0=