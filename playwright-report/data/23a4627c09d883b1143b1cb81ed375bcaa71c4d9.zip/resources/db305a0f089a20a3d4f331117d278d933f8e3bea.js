import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Articles.vue");import { Head, Link } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import Icon from "/resources/js/Components/Icon.vue";


const _sfc_main = {
  __name: 'Articles',
  props: {
  articles: {
    type: Object,
    default: () => ({ data: [] })
  }
},
  setup(__props, { expose: __expose }) {
  __expose();

const props = __props;

const __returned__ = { props, get Head() { return Head }, get Link() { return Link }, Icon }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createVNode as _createVNode, createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, withCtx as _withCtx, createTextVNode as _createTextVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "min-h-screen bg-sand text-bark font-sans" }
const _hoisted_2 = { class: "sticky top-0 z-50 border-b border-leaf/15 bg-cream/85 backdrop-blur-md" }
const _hoisted_3 = { class: "mx-auto flex max-w-6xl items-center justify-between px-6 py-4" }
const _hoisted_4 = { class: "flex h-10 w-10 items-center justify-center rounded-full bg-moss text-cream" }
const _hoisted_5 = { class: "py-20 px-6" }
const _hoisted_6 = { class: "mx-auto max-w-6xl grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3" }
const _hoisted_7 = { class: "aspect-16/10 overflow-hidden bg-parchment relative" }
const _hoisted_8 = ["src", "alt"]
const _hoisted_9 = { class: "flex flex-1 flex-col p-6" }
const _hoisted_10 = { class: "flex items-center justify-between mb-3" }
const _hoisted_11 = { class: "rounded-full bg-sand px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-wide text-leaf" }
const _hoisted_12 = { class: "text-xs text-bark/50 font-medium" }
const _hoisted_13 = { class: "font-display text-xl font-semibold leading-snug text-moss" }
const _hoisted_14 = { class: "mt-3 flex-1 text-sm leading-relaxed text-bark/70" }
const _hoisted_15 = {
  href: "#",
  class: "mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-clay transition-colors hover:text-moss"
}
const _hoisted_16 = { class: "mx-auto max-w-6xl mt-16 flex justify-center gap-2" }
const _hoisted_17 = { class: "w-10 h-10 rounded-full flex items-center justify-center border border-leaf/20 text-bark/40 cursor-not-allowed" }
const _hoisted_18 = { class: "w-10 h-10 rounded-full flex items-center justify-center border border-leaf/20 text-bark hover:bg-cream transition-colors" }
const _hoisted_19 = { class: "bg-bark text-cream/80 border-t border-cream/10" }
const _hoisted_20 = { class: "mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 text-center text-sm sm:flex-row" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createVNode($setup["Head"], { title: "Semua Artikel | Pandawa Kencana" }),
    _createElementVNode("div", _hoisted_1, [
      _createCommentVNode(" Navbar "),
      _createElementVNode("header", _hoisted_2, [
        _createElementVNode("div", _hoisted_3, [
          _createVNode($setup["Link"], {
            href: "/",
            class: "flex items-center gap-2.5"
          }, {
            default: _withCtx(() => [
              _createElementVNode("span", _hoisted_4, [
                _createVNode($setup["Icon"], {
                  name: "leaf",
                  class: "h-5 w-5"
                })
              ]),
              _cache[0] || (_cache[0] = _createElementVNode("span", { class: "leading-tight" }, [
                _createElementVNode("span", { class: "block font-display text-lg font-semibold text-moss" }, "Pandawa Kencana"),
                _createElementVNode("span", { class: "block text-[0.7rem] font-medium uppercase tracking-[0.2em] text-leaf" }, "Multi Farm")
              ], -1 /* CACHED */))
            ]),
            _: 1 /* STABLE */
          }),
          _createVNode($setup["Link"], {
            href: "/",
            class: "text-sm font-semibold text-moss hover:text-sprout transition-colors flex items-center gap-2"
          }, {
            default: _withCtx(() => [
              _createVNode($setup["Icon"], {
                name: "arrow",
                class: "h-4 w-4 rotate-180"
              }),
              _cache[1] || (_cache[1] = _createTextVNode(" Kembali ke Beranda ", -1 /* CACHED */))
            ]),
            _: 1 /* STABLE */
          })
        ])
      ]),
      _createCommentVNode(" Header "),
      _cache[8] || (_cache[8] = _createElementVNode("section", { class: "bg-moss py-16 px-6" }, [
        _createElementVNode("div", { class: "mx-auto max-w-6xl text-center" }, [
          _createElementVNode("h1", { class: "font-display text-4xl font-semibold text-cream md:text-5xl" }, "Artikel & Edukasi Tani"),
          _createElementVNode("p", { class: "mt-4 text-cream/80 max-w-2xl mx-auto text-lg" }, " Kumpulan panduan, tips, dan informasi terbaru seputar pertanian dan peternakan organik. ")
        ])
      ], -1 /* CACHED */)),
      _createCommentVNode(" Articles Grid "),
      _createElementVNode("section", _hoisted_5, [
        _createElementVNode("div", _hoisted_6, [
          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.articles.data, (a) => {
            return (_openBlock(), _createElementBlock("article", {
              key: a.title,
              class: "group flex flex-col overflow-hidden rounded-2xl border border-leaf/10 bg-cream shadow-sm transition-shadow hover:shadow-lg"
            }, [
              _createElementVNode("div", _hoisted_7, [
                _createElementVNode("img", {
                  src: a.image_path ? '/storage/' + a.image_path : 'https://images.unsplash.com/photo-1620675506518-3df066bb2b30?w=700&h=480&fit=crop&auto=format',
                  alt: a.title,
                  class: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                }, null, 8 /* PROPS */, _hoisted_8),
                _cache[2] || (_cache[2] = _createElementVNode("div", { class: "absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-500" }, null, -1 /* CACHED */))
              ]),
              _createElementVNode("div", _hoisted_9, [
                _createElementVNode("div", _hoisted_10, [
                  _createElementVNode("span", _hoisted_11, _toDisplayString(a.tag), 1 /* TEXT */),
                  _createElementVNode("span", _hoisted_12, _toDisplayString(a.date), 1 /* TEXT */)
                ]),
                _createElementVNode("h3", _hoisted_13, _toDisplayString(a.title), 1 /* TEXT */),
                _createElementVNode("p", _hoisted_14, _toDisplayString(a.excerpt), 1 /* TEXT */),
                _createElementVNode("a", _hoisted_15, [
                  _cache[3] || (_cache[3] = _createTextVNode(" Baca selengkapnya ", -1 /* CACHED */)),
                  _createVNode($setup["Icon"], {
                    name: "arrow",
                    class: "h-4 w-4"
                  })
                ])
              ])
            ]))
          }), 128 /* KEYED_FRAGMENT */))
        ]),
        _createCommentVNode(" Pagination "),
        _createElementVNode("div", _hoisted_16, [
          _createElementVNode("button", _hoisted_17, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "h-4 w-4 rotate-180"
            })
          ]),
          _cache[4] || (_cache[4] = _createElementVNode("button", { class: "w-10 h-10 rounded-full flex items-center justify-center bg-moss text-cream font-bold" }, "1", -1 /* CACHED */)),
          _cache[5] || (_cache[5] = _createElementVNode("button", { class: "w-10 h-10 rounded-full flex items-center justify-center border border-leaf/20 text-bark hover:bg-cream transition-colors" }, "2", -1 /* CACHED */)),
          _createElementVNode("button", _hoisted_18, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "h-4 w-4"
            })
          ])
        ])
      ]),
      _createCommentVNode(" Footer "),
      _createElementVNode("footer", _hoisted_19, [
        _createElementVNode("div", _hoisted_20, [
          _cache[7] || (_cache[7] = _createElementVNode("span", null, "© 2026 CV Pandawa Kencana Multi Farm.", -1 /* CACHED */)),
          _createVNode($setup["Link"], {
            href: "/admin/dashboard",
            class: "transition-colors hover:text-sprout"
          }, {
            default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
              _createTextVNode("Login Admin", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          })
        ])
      ])
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "16926513"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Articles.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXJ0aWNsZXMudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyBIZWFkLCBMaW5rIH0gZnJvbSAnQGluZXJ0aWFqcy92dWUzJztcbmltcG9ydCBJY29uIGZyb20gJ0AvQ29tcG9uZW50cy9JY29uLnZ1ZSc7XG5cbmNvbnN0IHByb3BzID0gZGVmaW5lUHJvcHMoe1xuICBhcnRpY2xlczoge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgICBkZWZhdWx0OiAoKSA9PiAoeyBkYXRhOiBbXSB9KVxuICB9XG59KTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxIZWFkIHRpdGxlPVwiU2VtdWEgQXJ0aWtlbCB8IFBhbmRhd2EgS2VuY2FuYVwiIC8+XG5cbiAgPGRpdiBjbGFzcz1cIm1pbi1oLXNjcmVlbiBiZy1zYW5kIHRleHQtYmFyayBmb250LXNhbnNcIj5cbiAgICA8IS0tIE5hdmJhciAtLT5cbiAgICA8aGVhZGVyIGNsYXNzPVwic3RpY2t5IHRvcC0wIHotNTAgYm9yZGVyLWIgYm9yZGVyLWxlYWYvMTUgYmctY3JlYW0vODUgYmFja2Ryb3AtYmx1ci1tZFwiPlxuICAgICAgPGRpdiBjbGFzcz1cIm14LWF1dG8gZmxleCBtYXgtdy02eGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTRcIj5cbiAgICAgICAgPExpbmsgaHJlZj1cIi9cIiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctbW9zcyB0ZXh0LWNyZWFtXCI+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwibGVhZlwiIGNsYXNzPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGVhZGluZy10aWdodFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJibG9jayBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtbW9zc1wiPlBhbmRhd2EgS2VuY2FuYTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmxvY2sgdGV4dC1bMC43cmVtXSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMmVtXSB0ZXh0LWxlYWZcIj5NdWx0aSBGYXJtPC9zcGFuPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8TGluayBocmVmPVwiL1wiIGNsYXNzPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtbW9zcyBob3Zlcjp0ZXh0LXNwcm91dCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwiaC00IHctNCByb3RhdGUtMTgwXCIgLz5cbiAgICAgICAgICBLZW1iYWxpIGtlIEJlcmFuZGFcbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG5cbiAgICA8IS0tIEhlYWRlciAtLT5cbiAgICA8c2VjdGlvbiBjbGFzcz1cImJnLW1vc3MgcHktMTYgcHgtNlwiPlxuICAgICAgPGRpdiBjbGFzcz1cIm14LWF1dG8gbWF4LXctNnhsIHRleHQtY2VudGVyXCI+XG4gICAgICAgIDxoMSBjbGFzcz1cImZvbnQtZGlzcGxheSB0ZXh0LTR4bCBmb250LXNlbWlib2xkIHRleHQtY3JlYW0gbWQ6dGV4dC01eGxcIj5BcnRpa2VsICYgRWR1a2FzaSBUYW5pPC9oMT5cbiAgICAgICAgPHAgY2xhc3M9XCJtdC00IHRleHQtY3JlYW0vODAgbWF4LXctMnhsIG14LWF1dG8gdGV4dC1sZ1wiPlxuICAgICAgICAgIEt1bXB1bGFuIHBhbmR1YW4sIHRpcHMsIGRhbiBpbmZvcm1hc2kgdGVyYmFydSBzZXB1dGFyIHBlcnRhbmlhbiBkYW4gcGV0ZXJuYWthbiBvcmdhbmlrLlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8IS0tIEFydGljbGVzIEdyaWQgLS0+XG4gICAgPHNlY3Rpb24gY2xhc3M9XCJweS0yMCBweC02XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibXgtYXV0byBtYXgtdy02eGwgZ3JpZCBncmlkLWNvbHMtMSBnYXAtOCBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtM1wiPlxuICAgICAgICA8YXJ0aWNsZSB2LWZvcj1cImEgaW4gYXJ0aWNsZXMuZGF0YVwiIDprZXk9XCJhLnRpdGxlXCIgY2xhc3M9XCJncm91cCBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWxlYWYvMTAgYmctY3JlYW0gc2hhZG93LXNtIHRyYW5zaXRpb24tc2hhZG93IGhvdmVyOnNoYWRvdy1sZ1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJhc3BlY3QtMTYvMTAgb3ZlcmZsb3ctaGlkZGVuIGJnLXBhcmNobWVudCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGltZyA6c3JjPVwiYS5pbWFnZV9wYXRoID8gJy9zdG9yYWdlLycgKyBhLmltYWdlX3BhdGggOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE2MjA2NzU1MDY1MTgtM2RmMDY2YmIyYjMwP3c9NzAwJmg9NDgwJmZpdD1jcm9wJmF1dG89Zm9ybWF0J1wiIDphbHQ9XCJhLnRpdGxlXCIgY2xhc3M9XCJoLWZ1bGwgdy1mdWxsIG9iamVjdC1jb3ZlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1XCIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzEwIGdyb3VwLWhvdmVyOmJnLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTUwMFwiPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtMSBmbGV4LWNvbCBwLTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInJvdW5kZWQtZnVsbCBiZy1zYW5kIHB4LTMgcHktMSB0ZXh0LVswLjdyZW1dIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1sZWFmXCI+XG4gICAgICAgICAgICAgICAge3sgYS50YWcgfX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgdGV4dC1iYXJrLzUwIGZvbnQtbWVkaXVtXCI+e3sgYS5kYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWRpc3BsYXkgdGV4dC14bCBmb250LXNlbWlib2xkIGxlYWRpbmctc251ZyB0ZXh0LW1vc3NcIj57eyBhLnRpdGxlIH19PC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzPVwibXQtMyBmbGV4LTEgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1iYXJrLzcwXCI+e3sgYS5leGNlcnB0IH19PC9wPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzcz1cIm10LTUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtY2xheSB0cmFuc2l0aW9uLWNvbG9ycyBob3Zlcjp0ZXh0LW1vc3NcIj5cbiAgICAgICAgICAgICAgQmFjYSBzZWxlbmdrYXBueWFcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImFycm93XCIgY2xhc3M9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9hcnRpY2xlPlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIDwhLS0gUGFnaW5hdGlvbiAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJteC1hdXRvIG1heC13LTZ4bCBtdC0xNiBmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItbGVhZi8yMCB0ZXh0LWJhcmsvNDAgY3Vyc29yLW5vdC1hbGxvd2VkXCI+XG4gICAgICAgICAgPEljb24gbmFtZT1cImFycm93XCIgY2xhc3M9XCJoLTQgdy00IHJvdGF0ZS0xODBcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctbW9zcyB0ZXh0LWNyZWFtIGZvbnQtYm9sZFwiPjE8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1sZWFmLzIwIHRleHQtYmFyayBob3ZlcjpiZy1jcmVhbSB0cmFuc2l0aW9uLWNvbG9yc1wiPjI8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1sZWFmLzIwIHRleHQtYmFyayBob3ZlcjpiZy1jcmVhbSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwiaC00IHctNFwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuXG4gICAgPCEtLSBGb290ZXIgLS0+XG4gICAgPGZvb3RlciBjbGFzcz1cImJnLWJhcmsgdGV4dC1jcmVhbS84MCBib3JkZXItdCBib3JkZXItY3JlYW0vMTBcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJteC1hdXRvIGZsZXggbWF4LXctNnhsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcHgtNiBweS04IHRleHQtY2VudGVyIHRleHQtc20gc206ZmxleC1yb3dcIj5cbiAgICAgICAgPHNwYW4+wqkgMjAyNiBDViBQYW5kYXdhIEtlbmNhbmEgTXVsdGkgRmFybS48L3NwYW4+XG4gICAgICAgIDxMaW5rIGhyZWY9XCIvYWRtaW4vZGFzaGJvYXJkXCIgY2xhc3M9XCJ0cmFuc2l0aW9uLWNvbG9ycyBob3Zlcjp0ZXh0LXNwcm91dFwiPkxvZ2luIEFkbWluPC9MaW5rPlxuICAgICAgPC9kaXY+XG4gICAgPC9mb290ZXI+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7O0FBRXhDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUtaOzs7Ozs7Ozs7O3FCQU1LLEtBQUssRUFBQywwQ0FBMEM7cUJBRTNDLEtBQUssRUFBQyx3RUFBd0U7cUJBQy9FLEtBQUssRUFBQywrREFBK0Q7cUJBRWhFLEtBQUssRUFBQyw0RUFBNEU7cUJBMEJyRixLQUFLLEVBQUMsWUFBWTtxQkFDcEIsS0FBSyxFQUFDLHdFQUF3RTtxQkFFMUUsS0FBSyxFQUFDLG9EQUFvRDs7cUJBSTFELEtBQUssRUFBQywwQkFBMEI7c0JBQzlCLEtBQUssRUFBQyx3Q0FBd0M7c0JBQzNDLEtBQUssRUFBQyw4RkFBOEY7c0JBR3BHLEtBQUssRUFBQyxrQ0FBa0M7c0JBRTVDLEtBQUssRUFBQywyREFBMkQ7c0JBQ2xFLEtBQUssRUFBQyxrREFBa0Q7O0VBQ3hELElBQUksRUFBQyxHQUFHO0VBQUMsS0FBSyxFQUFDLHlHQUF5Rzs7c0JBUzVILEtBQUssRUFBQyxtREFBbUQ7c0JBQ3BELEtBQUssRUFBQywrR0FBK0c7c0JBS3JILEtBQUssRUFBQywwSEFBMEg7c0JBT3BJLEtBQUssRUFBQyxnREFBZ0Q7c0JBQ3ZELEtBQUssRUFBQyw4R0FBOEc7Ozs7SUF4RTdILGFBQWdELGtCQUExQyxLQUFLLEVBQUMsaUNBQWlDO0lBRTdDLG9CQTJFTSxPQTNFTixVQTJFTTtNQTFFSiwrQkFBZTtNQUNmLG9CQWdCUyxVQWhCVCxVQWdCUztRQWZQLG9CQWNNLE9BZE4sVUFjTTtVQWJKLGFBUU87WUFSRCxJQUFJLEVBQUMsR0FBRztZQUFDLEtBQUssRUFBQywyQkFBMkI7OzhCQUM5QyxDQUVPO2NBRlAsb0JBRU8sUUFGUCxVQUVPO2dCQURMLGFBQW9DO2tCQUE5QixJQUFJLEVBQUMsTUFBTTtrQkFBQyxLQUFLLEVBQUMsU0FBUzs7O3dDQUVuQyxvQkFHTyxVQUhELEtBQUssRUFBQyxlQUFlO2dCQUN6QixvQkFBdUYsVUFBakYsS0FBSyxFQUFDLG9EQUFvRCxJQUFDLGlCQUFlO2dCQUNoRixvQkFBb0csVUFBOUYsS0FBSyxFQUFDLHNFQUFzRSxJQUFDLFlBQVU7Ozs7O1VBR2pHLGFBR087WUFIRCxJQUFJLEVBQUMsR0FBRztZQUFDLEtBQUssRUFBQyw2RkFBNkY7OzhCQUNoSCxDQUFnRDtjQUFoRCxhQUFnRDtnQkFBMUMsSUFBSSxFQUFDLE9BQU87Z0JBQUMsS0FBSyxFQUFDLG9CQUFvQjs7eURBQUcsc0JBRWxEOzs7Ozs7TUFJSiwrQkFBZTtnQ0FDZixvQkFPVSxhQVBELEtBQUssRUFBQyxvQkFBb0I7UUFDakMsb0JBS00sU0FMRCxLQUFLLEVBQUMsK0JBQStCO1VBQ3hDLG9CQUFrRyxRQUE5RixLQUFLLEVBQUMsNERBQTRELElBQUMsd0JBQXNCO1VBQzdGLG9CQUVJLE9BRkQsS0FBSyxFQUFDLDhDQUE4QyxJQUFDLDJGQUV4RDs7O01BSUosc0NBQXNCO01BQ3RCLG9CQW1DVSxXQW5DVixVQW1DVTtRQWxDUixvQkFxQk0sT0FyQk4sVUFxQk07NkJBcEJKLG9CQW1CVSw2QkFuQlcsZUFBUSxDQUFDLElBQUksR0FBbEIsQ0FBQztrQ0FBakIsb0JBbUJVO2NBbkIyQixHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUs7Y0FBRSxLQUFLLEVBQUMsNEhBQTRIOztjQUNuTCxvQkFHTSxPQUhOLFVBR007Z0JBRkosb0JBQW9RO2tCQUE5UCxHQUFHLEVBQUUsQ0FBQyxDQUFDLFVBQVUsaUJBQWlCLENBQUMsQ0FBQyxVQUFVO2tCQUFxRyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUs7a0JBQUUsS0FBSyxFQUFDLG9GQUFvRjs7MENBQ2pRLG9CQUEwRyxTQUFyRyxLQUFLLEVBQUMsd0ZBQXdGOztjQUVyRyxvQkFhTSxPQWJOLFVBYU07Z0JBWkosb0JBS00sT0FMTixXQUtNO2tCQUpKLG9CQUVPLFFBRlAsV0FFTyxtQkFERixDQUFDLENBQUMsR0FBRztrQkFFVixvQkFBa0UsUUFBbEUsV0FBa0UsbUJBQWhCLENBQUMsQ0FBQyxJQUFJOztnQkFFMUQsb0JBQXdGLE1BQXhGLFdBQXdGLG1CQUFmLENBQUMsQ0FBQyxLQUFLO2dCQUNoRixvQkFBK0UsS0FBL0UsV0FBK0UsbUJBQWhCLENBQUMsQ0FBQyxPQUFPO2dCQUN4RSxvQkFHSSxLQUhKLFdBR0k7NkRBSHdILHFCQUUxSDtrQkFBQSxhQUFxQztvQkFBL0IsSUFBSSxFQUFDLE9BQU87b0JBQUMsS0FBSyxFQUFDLFNBQVM7Ozs7Ozs7UUFNMUMsbUNBQW1CO1FBQ25CLG9CQVNNLE9BVE4sV0FTTTtVQVJKLG9CQUVTLFVBRlQsV0FFUztZQURQLGFBQWdEO2NBQTFDLElBQUksRUFBQyxPQUFPO2NBQUMsS0FBSyxFQUFDLG9CQUFvQjs7O29DQUUvQyxvQkFBK0csWUFBdkcsS0FBSyxFQUFDLHNGQUFzRixJQUFDLEdBQUM7b0NBQ3RHLG9CQUFtSixZQUEzSSxLQUFLLEVBQUMsMEhBQTBILElBQUMsR0FBQztVQUMxSSxvQkFFUyxVQUZULFdBRVM7WUFEUCxhQUFxQztjQUEvQixJQUFJLEVBQUMsT0FBTztjQUFDLEtBQUssRUFBQyxTQUFTOzs7OztNQUt4QywrQkFBZTtNQUNmLG9CQUtTLFVBTFQsV0FLUztRQUpQLG9CQUdNLE9BSE4sV0FHTTtvQ0FGSixvQkFBa0QsY0FBNUMsdUNBQXFDO1VBQzNDLGFBQTRGO1lBQXRGLElBQUksRUFBQyxrQkFBa0I7WUFBQyxLQUFLLEVBQUMscUNBQXFDOzs4QkFBQyxDQUFXOytCQUFYLGFBQVciLCJpZ25vcmVMaXN0IjpbXX0=