import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Articles/Create.vue");import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import { Link, useForm } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import { ref } from "/node_modules/.vite/deps/vue.js?v=cebe2491";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Create',
  setup(__props, { expose: __expose }) {
  __expose();



const form = useForm({
    title: '',
    excerpt: '',
    content: '',
    tag: 'Edukasi',
    image: null,
});

const imagePreview = ref(null);

const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
        form.image = file;
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.value = e.target.result;
        };
        reader.readAsDataURL(file);
    }
};

const submit = () => {
    form.post('/admin/articles', {
        preserveScroll: true,
    });
};

const __returned__ = { form, imagePreview, handleImageUpload, submit, AdminLayout, get Link() { return Link }, get useForm() { return useForm }, ref }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, createCommentVNode as _createCommentVNode, vModelText as _vModelText, withDirectives as _withDirectives, toDisplayString as _toDisplayString, withModifiers as _withModifiers, createStaticVNode as _createStaticVNode, Fragment as _Fragment } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "mb-8" }
const _hoisted_2 = { class: "bg-white rounded-3xl shadow-sm border border-emerald-50 overflow-hidden max-w-4xl" }
const _hoisted_3 = { class: "grid grid-cols-1 gap-6" }
const _hoisted_4 = { class: "space-y-2" }
const _hoisted_5 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_6 = { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }
const _hoisted_7 = { class: "space-y-2" }
const _hoisted_8 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_9 = { class: "space-y-2" }
const _hoisted_10 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_11 = { class: "space-y-2" }
const _hoisted_12 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_13 = { class: "space-y-2" }
const _hoisted_14 = { class: "mt-2 flex justify-center rounded-xl border border-dashed border-gray-300 px-6 py-10 bg-gray-50 hover:bg-emerald-50 hover:border-emerald-300 transition-all cursor-pointer relative overflow-hidden group" }
const _hoisted_15 = {
  key: 0,
  class: "text-center"
}
const _hoisted_16 = {
  key: 1,
  class: "relative w-full max-w-sm h-48 rounded-lg overflow-hidden border border-gray-200"
}
const _hoisted_17 = ["src"]
const _hoisted_18 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_19 = { class: "pt-6 border-t border-gray-100 flex justify-end gap-3" }
const _hoisted_20 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("div", _hoisted_1, [
      _createVNode($setup["Link"], {
        href: "/admin/articles",
        class: "text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-2 mb-4"
      }, {
        default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
          _createElementVNode("svg", {
            class: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M10 19l-7-7m0 0l7-7m-7 7h18"
            })
          ], -1 /* CACHED */),
          _createTextVNode(" Kembali ke Kelola Artikel ", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      }),
      _cache[5] || (_cache[5] = _createElementVNode("h2", { class: "text-3xl font-bold text-gray-900 tracking-tight" }, "Tambah Artikel Baru", -1 /* CACHED */)),
      _cache[6] || (_cache[6] = _createElementVNode("p", { class: "text-gray-500 mt-2" }, "Masukkan informasi detail untuk artikel edukasi.", -1 /* CACHED */))
    ]),
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("form", {
        onSubmit: _withModifiers($setup.submit, ["prevent"]),
        class: "p-8 space-y-6"
      }, [
        _createElementVNode("div", _hoisted_3, [
          _createCommentVNode(" Judul Artikel "),
          _createElementVNode("div", _hoisted_4, [
            _cache[7] || (_cache[7] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Judul Artikel", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.title) = $event)),
              type: "text",
              placeholder: "Masukkan judul artikel...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.title]
            ]),
            ($setup.form.errors.title)
              ? (_openBlock(), _createElementBlock("p", _hoisted_5, _toDisplayString($setup.form.errors.title), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createElementVNode("div", _hoisted_6, [
            _createCommentVNode(" Tag / Kategori "),
            _createElementVNode("div", _hoisted_7, [
              _cache[8] || (_cache[8] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Tag / Kategori", -1 /* CACHED */)),
              _withDirectives(_createElementVNode("input", {
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.tag) = $event)),
                type: "text",
                placeholder: "Misal: Edukasi, Tips, Panduan",
                class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
                required: ""
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.form.tag]
              ]),
              ($setup.form.errors.tag)
                ? (_openBlock(), _createElementBlock("p", _hoisted_8, _toDisplayString($setup.form.errors.tag), 1 /* TEXT */))
                : _createCommentVNode("v-if", true)
            ])
          ]),
          _createCommentVNode(" Excerpt "),
          _createElementVNode("div", _hoisted_9, [
            _cache[9] || (_cache[9] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Ringkasan (Excerpt)", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.excerpt) = $event)),
              rows: "2",
              placeholder: "Tuliskan ringkasan singkat artikel...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.excerpt]
            ]),
            ($setup.form.errors.excerpt)
              ? (_openBlock(), _createElementBlock("p", _hoisted_10, _toDisplayString($setup.form.errors.excerpt), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Content "),
          _createElementVNode("div", _hoisted_11, [
            _cache[10] || (_cache[10] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Isi Artikel", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.content) = $event)),
              rows: "10",
              placeholder: "Tuliskan isi artikel edukasi di sini...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.content]
            ]),
            ($setup.form.errors.content)
              ? (_openBlock(), _createElementBlock("p", _hoisted_12, _toDisplayString($setup.form.errors.content), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Foto "),
          _createElementVNode("div", _hoisted_13, [
            _cache[13] || (_cache[13] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Gambar Cover (Opsional)", -1 /* CACHED */)),
            _createElementVNode("div", _hoisted_14, [
              _createElementVNode("input", {
                type: "file",
                onChange: $setup.handleImageUpload,
                class: "absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10",
                accept: "image/*"
              }, null, 32 /* NEED_HYDRATION */),
              (!$setup.imagePreview)
                ? (_openBlock(), _createElementBlock("div", _hoisted_15, [...(_cache[11] || (_cache[11] = [
                    _createStaticVNode("<svg class=\"mx-auto h-12 w-12 text-gray-300 group-hover:text-emerald-500 transition-colors\" viewBox=\"0 0 24 24\" fill=\"currentColor\" aria-hidden=\"true\"><path fill-rule=\"evenodd\" d=\"M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z\" clip-rule=\"evenodd\"></path></svg><div class=\"mt-4 flex text-sm leading-6 text-gray-600 justify-center\"><span class=\"relative rounded-md font-semibold text-emerald-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-emerald-600 focus-within:ring-offset-2 hover:text-emerald-500\"><span>Upload a file</span></span><p class=\"pl-1\">or drag and drop</p></div><p class=\"text-xs leading-5 text-gray-500\">PNG, JPG, GIF up to 2MB</p>", 3)
                  ]))]))
                : (_openBlock(), _createElementBlock("div", _hoisted_16, [
                    _createElementVNode("img", {
                      src: $setup.imagePreview,
                      class: "w-full h-full object-cover"
                    }, null, 8 /* PROPS */, _hoisted_17),
                    _cache[12] || (_cache[12] = _createElementVNode("div", { class: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center" }, [
                      _createElementVNode("p", { class: "text-white text-sm font-bold" }, "Ganti Foto")
                    ], -1 /* CACHED */))
                  ]))
            ]),
            ($setup.form.errors.image)
              ? (_openBlock(), _createElementBlock("p", _hoisted_18, _toDisplayString($setup.form.errors.image), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ])
        ]),
        _createCommentVNode(" Submit Button "),
        _createElementVNode("div", _hoisted_19, [
          _createVNode($setup["Link"], {
            href: "/admin/articles",
            class: "px-6 py-3 border border-gray-200 text-gray-600 font-medium rounded-xl hover:bg-gray-50 transition-colors"
          }, {
            default: _withCtx(() => [...(_cache[14] || (_cache[14] = [
              _createTextVNode("Batal", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }),
          _createElementVNode("button", {
            type: "submit",
            disabled: $setup.form.processing,
            class: "px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all disabled:opacity-50"
          }, " Simpan Artikel ", 8 /* PROPS */, _hoisted_20)
        ])
      ], 32 /* NEED_HYDRATION */)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "47951a60"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Articles/Create.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ3JlYXRlLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuaW1wb3J0IEFkbWluTGF5b3V0IGZyb20gJ0AvTGF5b3V0cy9BZG1pbkxheW91dC52dWUnO1xuaW1wb3J0IHsgTGluaywgdXNlRm9ybSB9IGZyb20gJ0BpbmVydGlhanMvdnVlMyc7XG5pbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnO1xuXG5kZWZpbmVPcHRpb25zKHsgbGF5b3V0OiBBZG1pbkxheW91dCB9KTtcblxuY29uc3QgZm9ybSA9IHVzZUZvcm0oe1xuICAgIHRpdGxlOiAnJyxcbiAgICBleGNlcnB0OiAnJyxcbiAgICBjb250ZW50OiAnJyxcbiAgICB0YWc6ICdFZHVrYXNpJyxcbiAgICBpbWFnZTogbnVsbCxcbn0pO1xuXG5jb25zdCBpbWFnZVByZXZpZXcgPSByZWYobnVsbCk7XG5cbmNvbnN0IGhhbmRsZUltYWdlVXBsb2FkID0gKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXNbMF07XG4gICAgaWYgKGZpbGUpIHtcbiAgICAgICAgZm9ybS5pbWFnZSA9IGZpbGU7XG4gICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICAgIHJlYWRlci5vbmxvYWQgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaW1hZ2VQcmV2aWV3LnZhbHVlID0gZS50YXJnZXQucmVzdWx0O1xuICAgICAgICB9O1xuICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICB9XG59O1xuXG5jb25zdCBzdWJtaXQgPSAoKSA9PiB7XG4gICAgZm9ybS5wb3N0KCcvYWRtaW4vYXJ0aWNsZXMnLCB7XG4gICAgICAgIHByZXNlcnZlU2Nyb2xsOiB0cnVlLFxuICAgIH0pO1xufTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJtYi04XCI+XG4gICAgPExpbmsgaHJlZj1cIi9hZG1pbi9hcnRpY2xlc1wiIGNsYXNzPVwidGV4dC1zbSB0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxuICAgICAgPHN2ZyBjbGFzcz1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIyXCIgZD1cIk0xMCAxOWwtNy03bTAgMGw3LTdtLTcgN2gxOFwiPjwvcGF0aD48L3N2Zz5cbiAgICAgIEtlbWJhbGkga2UgS2Vsb2xhIEFydGlrZWxcbiAgICA8L0xpbms+XG4gICAgPGgyIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgdHJhY2tpbmctdGlnaHRcIj5UYW1iYWggQXJ0aWtlbCBCYXJ1PC9oMj5cbiAgICA8cCBjbGFzcz1cInRleHQtZ3JheS01MDAgbXQtMlwiPk1hc3Vra2FuIGluZm9ybWFzaSBkZXRhaWwgdW50dWsgYXJ0aWtlbCBlZHVrYXNpLjwvcD5cbiAgPC9kaXY+XG5cbiAgPGRpdiBjbGFzcz1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAgb3ZlcmZsb3ctaGlkZGVuIG1heC13LTR4bFwiPlxuICAgIDxmb3JtIEBzdWJtaXQucHJldmVudD1cInN1Ym1pdFwiIGNsYXNzPVwicC04IHNwYWNlLXktNlwiPlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNlwiPlxuICAgICAgICA8IS0tIEp1ZHVsIEFydGlrZWwgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+SnVkdWwgQXJ0aWtlbDwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJmb3JtLnRpdGxlXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk1hc3Vra2FuIGp1ZHVsIGFydGlrZWwuLi5cIiBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMudGl0bGVcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMudGl0bGUgfX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAgPCEtLSBUYWcgLyBLYXRlZ29yaSAtLT5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+VGFnIC8gS2F0ZWdvcmk8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJmb3JtLnRhZ1wiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJNaXNhbDogRWR1a2FzaSwgVGlwcywgUGFuZHVhblwiIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIiByZXF1aXJlZCAvPlxuICAgICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLnRhZ1wiIGNsYXNzPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57eyBmb3JtLmVycm9ycy50YWcgfX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0gRXhjZXJwdCAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5SaW5na2FzYW4gKEV4Y2VycHQpPC9sYWJlbD5cbiAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImZvcm0uZXhjZXJwdFwiIHJvd3M9XCIyXCIgcGxhY2Vob2xkZXI9XCJUdWxpc2thbiByaW5na2FzYW4gc2luZ2thdCBhcnRpa2VsLi4uXCIgY2xhc3M9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgdGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWFsbFwiPjwvdGV4dGFyZWE+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmV4Y2VycHRcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuZXhjZXJwdCB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBDb250ZW50IC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPklzaSBBcnRpa2VsPC9sYWJlbD5cbiAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImZvcm0uY29udGVudFwiIHJvd3M9XCIxMFwiIHBsYWNlaG9sZGVyPVwiVHVsaXNrYW4gaXNpIGFydGlrZWwgZWR1a2FzaSBkaSBzaW5pLi4uXCIgY2xhc3M9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgdGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWFsbFwiIHJlcXVpcmVkPjwvdGV4dGFyZWE+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmNvbnRlbnRcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuY29udGVudCB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBGb3RvIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPkdhbWJhciBDb3ZlciAoT3BzaW9uYWwpPC9sYWJlbD5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMiBmbGV4IGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIHB4LTYgcHktMTAgYmctZ3JheS01MCBob3ZlcjpiZy1lbWVyYWxkLTUwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTMwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIj5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIEBjaGFuZ2U9XCJoYW5kbGVJbWFnZVVwbG9hZFwiIGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCB3LWZ1bGwgaC1mdWxsIG9wYWNpdHktMCBjdXJzb3ItcG9pbnRlciB6LTEwXCIgYWNjZXB0PVwiaW1hZ2UvKlwiIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXJcIiB2LWlmPVwiIWltYWdlUHJldmlld1wiPlxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzPVwibXgtYXV0byBoLTEyIHctMTIgdGV4dC1ncmF5LTMwMCBncm91cC1ob3Zlcjp0ZXh0LWVtZXJhbGQtNTAwIHRyYW5zaXRpb24tY29sb3JzXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgICAgICAgICAgICA8cGF0aCBmaWxsLXJ1bGU9XCJldmVub2RkXCIgZD1cIk0xLjUgNmEyLjI1IDIuMjUgMCAwMTIuMjUtMi4yNWgxNi41QTIuMjUgMi4yNSAwIDAxMjIuNSA2djEyYTIuMjUgMi4yNSAwIDAxLTIuMjUgMi4yNUgzLjc1QTIuMjUgMi4yNSAwIDAxMS41IDE4VjZ6TTMgMTYuMDZWMThjMCAuNDE0LjMzNi43NS43NS43NWgxNi41QS43NS43NSAwIDAwMjEgMTh2LTEuOTRsLTIuNjktMi42ODlhMS41IDEuNSAwIDAwLTIuMTIgMGwtLjg4Ljg3OS45Ny45N2EuNzUuNzUgMCAxMS0xLjA2IDEuMDZsLTUuMTYtNS4xNTlhMS41IDEuNSAwIDAwLTIuMTIgMEwzIDE2LjA2MXptMTAuMTI1LTcuODFhMS4xMjUgMS4xMjUgMCAxMTIuMjUgMCAxLjEyNSAxLjEyNSAwIDAxLTIuMjUgMHpcIiBjbGlwLXJ1bGU9XCJldmVub2RkXCIgLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC00IGZsZXggdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1ncmF5LTYwMCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicmVsYXRpdmUgcm91bmRlZC1tZCBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgZm9jdXMtd2l0aGluOm91dGxpbmUtbm9uZSBmb2N1cy13aXRoaW46cmluZy0yIGZvY3VzLXdpdGhpbjpyaW5nLWVtZXJhbGQtNjAwIGZvY3VzLXdpdGhpbjpyaW5nLW9mZnNldC0yIGhvdmVyOnRleHQtZW1lcmFsZC01MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlVwbG9hZCBhIGZpbGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwicGwtMVwiPm9yIGRyYWcgYW5kIGRyb3A8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgbGVhZGluZy01IHRleHQtZ3JheS01MDBcIj5QTkcsIEpQRywgR0lGIHVwIHRvIDJNQjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiB2LWVsc2UgY2xhc3M9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctc20gaC00OCByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgIDxpbWcgOnNyYz1cImltYWdlUHJldmlld1wiIGNsYXNzPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81MCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1ib2xkXCI+R2FudGkgRm90bzwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMuaW1hZ2VcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuaW1hZ2UgfX08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0gU3VibWl0IEJ1dHRvbiAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJwdC02IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XG4gICAgICAgIDxMaW5rIGhyZWY9XCIvYWRtaW4vYXJ0aWNsZXNcIiBjbGFzcz1cInB4LTYgcHktMyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHRleHQtZ3JheS02MDAgZm9udC1tZWRpdW0gcm91bmRlZC14bCBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tY29sb3JzXCI+QmF0YWw8L0xpbms+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIDpkaXNhYmxlZD1cImZvcm0ucHJvY2Vzc2luZ1wiIGNsYXNzPVwicHgtOCBweS0zIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNTBcIj5cbiAgICAgICAgICBTaW1wYW4gQXJ0aWtlbFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9mb3JtPlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG4iXSwibWFwcGluZ3MiOiJBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7O0FBSXpCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUM7O0FBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRTlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQzs7Ozs7Ozs7OztxQkFJTSxLQUFLLEVBQUMsTUFBTTtxQkFTWixLQUFLLEVBQUMsbUZBQW1GO3FCQUdyRixLQUFLLEVBQUMsd0JBQXdCO3FCQUU1QixLQUFLLEVBQUMsV0FBVzs7O0VBR1EsS0FBSyxFQUFDLHNCQUFzQjs7cUJBR3JELEtBQUssRUFBQyx1Q0FBdUM7cUJBRTNDLEtBQUssRUFBQyxXQUFXOzs7RUFHTSxLQUFLLEVBQUMsc0JBQXNCOztxQkFLckQsS0FBSyxFQUFDLFdBQVc7OztFQUdVLEtBQUssRUFBQyxzQkFBc0I7O3NCQUl2RCxLQUFLLEVBQUMsV0FBVzs7O0VBR1UsS0FBSyxFQUFDLHNCQUFzQjs7c0JBSXZELEtBQUssRUFBQyxXQUFXO3NCQUVmLEtBQUssRUFBQywwTUFBME07OztFQUU5TSxLQUFLLEVBQUMsYUFBYTs7OztFQVlaLEtBQUssRUFBQyxpRkFBaUY7Ozs7O0VBT3pFLEtBQUssRUFBQyxzQkFBc0I7O3NCQUt2RCxLQUFLLEVBQUMsc0RBQXNEOzs7OztJQXhFckUsb0JBT00sT0FQTixVQU9NO01BTkosYUFHTztRQUhELElBQUksRUFBQyxpQkFBaUI7UUFBQyxLQUFLLEVBQUMsMEZBQTBGOzswQkFDM0gsQ0FBOEw7VUFBOUwsb0JBQThMO1lBQXpMLEtBQUssRUFBQyxTQUFTO1lBQUMsSUFBSSxFQUFDLE1BQU07WUFBQyxNQUFNLEVBQUMsY0FBYztZQUFDLE9BQU8sRUFBQyxXQUFXOztZQUFDLG9CQUE2RztjQUF2RyxnQkFBYyxFQUFDLE9BQU87Y0FBQyxpQkFBZSxFQUFDLE9BQU87Y0FBQyxjQUFZLEVBQUMsR0FBRztjQUFDLENBQUMsRUFBQyw2QkFBNkI7OzsyQkFBYyw2QkFFaE07Ozs7Z0NBQ0Esb0JBQW9GLFFBQWhGLEtBQUssRUFBQyxpREFBaUQsSUFBQyxxQkFBbUI7Z0NBQy9FLG9CQUFrRixPQUEvRSxLQUFLLEVBQUMsb0JBQW9CLElBQUMsa0RBQWdEOztJQUdoRixvQkF1RU0sT0F2RU4sVUF1RU07TUF0RUosb0JBcUVPO1FBckVBLFFBQU0saUJBQVUsYUFBTTtRQUFFLEtBQUssRUFBQyxlQUFlOztRQUVsRCxvQkF5RE0sT0F6RE4sVUF5RE07VUF4REosc0NBQXNCO1VBQ3RCLG9CQUlNLE9BSk4sVUFJTTtzQ0FISixvQkFBMEUsV0FBbkUsS0FBSyxFQUFDLHVDQUF1QyxJQUFDLGVBQWE7NEJBQ2xFLG9CQUF3UTsyRUFBeFAsV0FBSSxDQUFDLEtBQUs7Y0FBRSxJQUFJLEVBQUMsTUFBTTtjQUFDLFdBQVcsRUFBQywyQkFBMkI7Y0FBQyxLQUFLLEVBQUMsc0tBQXNLO2NBQUMsUUFBUSxFQUFSLEVBQVE7OzRCQUFyUCxXQUFJLENBQUMsS0FBSzs7YUFDakIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOytCQUExQixvQkFBb0YsS0FBcEYsVUFBb0YsbUJBQXhCLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzs7O1VBRy9FLG9CQU9NLE9BUE4sVUFPTTtZQU5KLHVDQUF1QjtZQUN2QixvQkFJTSxPQUpOLFVBSU07d0NBSEosb0JBQTJFLFdBQXBFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxnQkFBYzs4QkFDbkUsb0JBQTBROzZFQUExUCxXQUFJLENBQUMsR0FBRztnQkFBRSxJQUFJLEVBQUMsTUFBTTtnQkFBQyxXQUFXLEVBQUMsK0JBQStCO2dCQUFDLEtBQUssRUFBQyxzS0FBc0s7Z0JBQUMsUUFBUSxFQUFSLEVBQVE7OzhCQUF2UCxXQUFJLENBQUMsR0FBRzs7ZUFDZixXQUFJLENBQUMsTUFBTSxDQUFDLEdBQUc7aUNBQXhCLG9CQUFnRixLQUFoRixVQUFnRixtQkFBdEIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHOzs7O1VBSTdFLGdDQUFnQjtVQUNoQixvQkFJTSxPQUpOLFVBSU07c0NBSEosb0JBQWdGLFdBQXpFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxxQkFBbUI7NEJBQ3hFLG9CQUFzUjsyRUFBblEsV0FBSSxDQUFDLE9BQU87Y0FBRSxJQUFJLEVBQUMsR0FBRztjQUFDLFdBQVcsRUFBQyx1Q0FBdUM7Y0FBQyxLQUFLLEVBQUMsc0tBQXNLOzs0QkFBdlAsV0FBSSxDQUFDLE9BQU87O2FBQ3RCLFdBQUksQ0FBQyxNQUFNLENBQUMsT0FBTzsrQkFBNUIsb0JBQXdGLEtBQXhGLFdBQXdGLG1CQUExQixXQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87OztVQUduRixnQ0FBZ0I7VUFDaEIsb0JBSU0sT0FKTixXQUlNO3dDQUhKLG9CQUF3RSxXQUFqRSxLQUFLLEVBQUMsdUNBQXVDLElBQUMsYUFBVzs0QkFDaEUsb0JBQWtTOzJFQUEvUSxXQUFJLENBQUMsT0FBTztjQUFFLElBQUksRUFBQyxJQUFJO2NBQUMsV0FBVyxFQUFDLHlDQUF5QztjQUFDLEtBQUssRUFBQyxzS0FBc0s7Y0FBQyxRQUFRLEVBQVIsRUFBUTs7NEJBQW5RLFdBQUksQ0FBQyxPQUFPOzthQUN0QixXQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87K0JBQTVCLG9CQUF3RixLQUF4RixXQUF3RixtQkFBMUIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPOzs7VUFHbkYsNkJBQWE7VUFDYixvQkF3Qk0sT0F4Qk4sV0F3Qk07d0NBdkJKLG9CQUFvRixXQUE3RSxLQUFLLEVBQUMsdUNBQXVDLElBQUMseUJBQXVCO1lBQzVFLG9CQW9CTSxPQXBCTixXQW9CTTtjQW5CSixvQkFBdUk7Z0JBQWhJLElBQUksRUFBQyxNQUFNO2dCQUFFLFFBQU0sRUFBRSx3QkFBaUI7Z0JBQUUsS0FBSyxFQUFDLDhEQUE4RDtnQkFBQyxNQUFNLEVBQUMsU0FBUzs7Z0JBQ3BHLG1CQUFZO2lDQUE1QyxvQkFXTSxPQVhOLFdBV007OztpQ0FDTixvQkFLTSxPQUxOLFdBS007b0JBSkosb0JBQThEO3NCQUF4RCxHQUFHLEVBQUUsbUJBQVk7c0JBQUUsS0FBSyxFQUFDLDRCQUE0Qjs7Z0RBQzNELG9CQUVNLFNBRkQsS0FBSyxFQUFDLG9IQUFvSDtzQkFDN0gsb0JBQXNELE9BQW5ELEtBQUssRUFBQyw4QkFBOEIsSUFBQyxZQUFVOzs7O2FBSS9DLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzsrQkFBMUIsb0JBQW9GLEtBQXBGLFdBQW9GLG1CQUF4QixXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7Ozs7UUFJakYsc0NBQXNCO1FBQ3RCLG9CQUtNLE9BTE4sV0FLTTtVQUpKLGFBQTBKO1lBQXBKLElBQUksRUFBQyxpQkFBaUI7WUFBQyxLQUFLLEVBQUMsMEdBQTBHOzs4QkFBQyxDQUFLOytCQUFMLE9BQUs7Ozs7VUFDbkosb0JBRVM7WUFGRCxJQUFJLEVBQUMsUUFBUTtZQUFFLFFBQVEsRUFBRSxXQUFJLENBQUMsVUFBVTtZQUFFLEtBQUssRUFBQyw0SEFBNEg7YUFBQyxrQkFFckwiLCJpZ25vcmVMaXN0IjpbXX0=