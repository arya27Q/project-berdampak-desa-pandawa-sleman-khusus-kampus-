import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Dashboard.vue");import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import Icon from "/resources/js/Components/Icon.vue";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Dashboard',
  props: {
    totalProducts: Number,
    totalArticles: Number,
    totalVisits: Number,
    newOrders: Number,
    recentProducts: Array,
    recentArticles: Array
},
  setup(__props, { expose: __expose }) {
  __expose();





const __returned__ = { AdminLayout, Icon }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, createVNode as _createVNode, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "max-w-350 mx-auto" }
const _hoisted_2 = { class: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-6" }
const _hoisted_3 = { class: "bg-emerald-800 rounded-3xl p-6 text-white relative overflow-hidden group hover:shadow-lg transition-all" }
const _hoisted_4 = { class: "flex justify-between items-start mb-4 relative z-10" }
const _hoisted_5 = { class: "w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm group-hover:bg-white/30 transition-colors cursor-pointer" }
const _hoisted_6 = { class: "text-4xl font-display font-bold mb-4 relative z-10" }
const _hoisted_7 = { class: "flex items-center gap-2 text-[0.65rem] text-emerald-200 relative z-10 font-medium" }
const _hoisted_8 = { class: "bg-white/20 px-1.5 py-0.5 rounded flex items-center gap-1" }
const _hoisted_9 = { class: "bg-white rounded-3xl p-6 border border-gray-100 group hover:shadow-md transition-all" }
const _hoisted_10 = { class: "flex justify-between items-start mb-4" }
const _hoisted_11 = { class: "w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 group-hover:text-emerald-700 group-hover:border-emerald-200 transition-colors cursor-pointer" }
const _hoisted_12 = { class: "text-4xl font-display font-bold text-gray-900 mb-4" }
const _hoisted_13 = { class: "flex items-center gap-2 text-[0.65rem] text-gray-400 font-medium" }
const _hoisted_14 = { class: "bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded flex items-center gap-1" }
const _hoisted_15 = { class: "bg-white rounded-3xl p-6 border border-gray-100 group hover:shadow-md transition-all" }
const _hoisted_16 = { class: "flex justify-between items-start mb-4" }
const _hoisted_17 = { class: "w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 group-hover:text-emerald-700 group-hover:border-emerald-200 transition-colors cursor-pointer" }
const _hoisted_18 = { class: "text-4xl font-display font-bold text-gray-900 mb-4" }
const _hoisted_19 = { class: "flex items-center gap-2 text-[0.65rem] text-gray-400 font-medium" }
const _hoisted_20 = { class: "bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded flex items-center gap-1" }
const _hoisted_21 = { class: "bg-white rounded-3xl p-6 border border-gray-100 group hover:shadow-md transition-all" }
const _hoisted_22 = { class: "flex justify-between items-start mb-4" }
const _hoisted_23 = { class: "w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 group-hover:text-emerald-700 group-hover:border-emerald-200 transition-colors cursor-pointer" }
const _hoisted_24 = { class: "text-4xl font-display font-bold text-gray-900 mb-4" }
const _hoisted_25 = { class: "grid grid-cols-1 lg:grid-cols-2 gap-5" }
const _hoisted_26 = { class: "bg-white rounded-3xl p-6 border border-gray-100 flex flex-col" }
const _hoisted_27 = { class: "space-y-4" }
const _hoisted_28 = { class: "flex items-center gap-3" }
const _hoisted_29 = ["src"]
const _hoisted_30 = { class: "text-sm font-bold text-gray-900 leading-tight mb-0.5" }
const _hoisted_31 = { class: "text-[0.65rem] text-gray-500 font-medium" }
const _hoisted_32 = { class: "px-2 py-1 rounded text-[0.7rem] font-bold bg-emerald-50 text-emerald-700 tracking-wide" }
const _hoisted_33 = {
  key: 0,
  class: "text-sm text-gray-400 py-4"
}
const _hoisted_34 = { class: "bg-white rounded-3xl p-6 border border-gray-100 flex flex-col" }
const _hoisted_35 = { class: "space-y-4" }
const _hoisted_36 = { class: "flex items-center gap-3" }
const _hoisted_37 = ["src"]
const _hoisted_38 = { class: "text-sm font-bold text-gray-900 leading-tight mb-0.5" }
const _hoisted_39 = { class: "text-[0.65rem] text-gray-500 font-medium" }
const _hoisted_40 = {
  key: 0,
  class: "text-sm text-gray-400 py-4"
}

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createCommentVNode(" Header "),
    _cache[14] || (_cache[14] = _createElementVNode("div", { class: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8" }, [
      _createElementVNode("div", null, [
        _createElementVNode("h2", { class: "text-3xl font-bold text-gray-900 tracking-tight" }, "Dashboard"),
        _createElementVNode("p", { class: "text-sm text-gray-500 mt-1" }, "Plan, prioritize, and accomplish your tasks with ease.")
      ])
    ], -1 /* CACHED */)),
    _createCommentVNode(" Stat Cards "),
    _createElementVNode("div", _hoisted_2, [
      _createCommentVNode(" Card 1 "),
      _createElementVNode("div", _hoisted_3, [
        _createElementVNode("div", _hoisted_4, [
          _cache[0] || (_cache[0] = _createElementVNode("span", { class: "font-medium text-emerald-100 text-sm" }, "Total Produk", -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_5, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-4 h-4 -rotate-45"
            })
          ])
        ]),
        _createElementVNode("div", _hoisted_6, _toDisplayString($props.totalProducts), 1 /* TEXT */),
        _createElementVNode("div", _hoisted_7, [
          _createElementVNode("span", _hoisted_8, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-3 h-3 -rotate-90"
            }),
            _cache[1] || (_cache[1] = _createTextVNode(" 5", -1 /* CACHED */))
          ]),
          _cache[2] || (_cache[2] = _createTextVNode(" Increased from last month ", -1 /* CACHED */))
        ]),
        _cache[3] || (_cache[3] = _createElementVNode("div", { class: "absolute -right-8 -bottom-8 w-32 h-32 bg-white/10 rounded-full blur-xl" }, null, -1 /* CACHED */))
      ]),
      _createCommentVNode(" Card 2 "),
      _createElementVNode("div", _hoisted_9, [
        _createElementVNode("div", _hoisted_10, [
          _cache[4] || (_cache[4] = _createElementVNode("span", { class: "font-medium text-gray-900 text-sm" }, "Pesanan Baru", -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_11, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-4 h-4 -rotate-45"
            })
          ])
        ]),
        _createElementVNode("div", _hoisted_12, _toDisplayString($props.newOrders), 1 /* TEXT */),
        _createElementVNode("div", _hoisted_13, [
          _createElementVNode("span", _hoisted_14, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-3 h-3 -rotate-90"
            }),
            _cache[5] || (_cache[5] = _createTextVNode(" 6", -1 /* CACHED */))
          ]),
          _cache[6] || (_cache[6] = _createTextVNode(" Increased from last month ", -1 /* CACHED */))
        ])
      ]),
      _createCommentVNode(" Card 3 "),
      _createElementVNode("div", _hoisted_15, [
        _createElementVNode("div", _hoisted_16, [
          _cache[7] || (_cache[7] = _createElementVNode("span", { class: "font-medium text-gray-900 text-sm" }, "Total Kunjungan", -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_17, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-4 h-4 -rotate-45"
            })
          ])
        ]),
        _createElementVNode("div", _hoisted_18, _toDisplayString($props.totalVisits), 1 /* TEXT */),
        _createElementVNode("div", _hoisted_19, [
          _createElementVNode("span", _hoisted_20, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-3 h-3 -rotate-90"
            }),
            _cache[8] || (_cache[8] = _createTextVNode(" 2", -1 /* CACHED */))
          ]),
          _cache[9] || (_cache[9] = _createTextVNode(" Increased from last month ", -1 /* CACHED */))
        ])
      ]),
      _createCommentVNode(" Card 4 "),
      _createElementVNode("div", _hoisted_21, [
        _createElementVNode("div", _hoisted_22, [
          _cache[10] || (_cache[10] = _createElementVNode("span", { class: "font-medium text-gray-900 text-sm" }, "Artikel Edukasi", -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_23, [
            _createVNode($setup["Icon"], {
              name: "arrow",
              class: "w-4 h-4 -rotate-45"
            })
          ])
        ]),
        _createElementVNode("div", _hoisted_24, _toDisplayString($props.totalArticles), 1 /* TEXT */),
        _cache[11] || (_cache[11] = _createElementVNode("div", { class: "flex items-center gap-2 text-[0.65rem] text-gray-400 font-medium" }, " On Discuss ", -1 /* CACHED */))
      ])
    ]),
    _createElementVNode("div", _hoisted_25, [
      _createCommentVNode(" Recent Products "),
      _createElementVNode("div", _hoisted_26, [
        _cache[12] || (_cache[12] = _createElementVNode("div", { class: "flex items-center justify-between mb-6" }, [
          _createElementVNode("h3", { class: "font-bold text-gray-900" }, "Produk Terbaru")
        ], -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_27, [
          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.recentProducts, (product) => {
            return (_openBlock(), _createElementBlock("div", {
              key: product.id,
              class: "flex items-center justify-between border-b border-gray-50 pb-4 last:border-0 last:pb-0"
            }, [
              _createElementVNode("div", _hoisted_28, [
                _createElementVNode("img", {
                  src: product.image_path ? (product.image_path.startsWith('http') ? product.image_path : '/storage/' + product.image_path) : 'https://picsum.photos/seed/'+product.id+'/150/150',
                  class: "w-12 h-12 rounded-xl border border-gray-100 object-cover"
                }, null, 8 /* PROPS */, _hoisted_29),
                _createElementVNode("div", null, [
                  _createElementVNode("p", _hoisted_30, _toDisplayString(product.name), 1 /* TEXT */),
                  _createElementVNode("p", _hoisted_31, _toDisplayString(product.category), 1 /* TEXT */)
                ])
              ]),
              _createElementVNode("span", _hoisted_32, "Rp " + _toDisplayString(product.price), 1 /* TEXT */)
            ]))
          }), 128 /* KEYED_FRAGMENT */)),
          (!$props.recentProducts.length)
            ? (_openBlock(), _createElementBlock("div", _hoisted_33, "Belum ada produk."))
            : _createCommentVNode("v-if", true)
        ])
      ]),
      _createCommentVNode(" Recent Articles "),
      _createElementVNode("div", _hoisted_34, [
        _cache[13] || (_cache[13] = _createElementVNode("div", { class: "flex items-center justify-between mb-6" }, [
          _createElementVNode("h3", { class: "font-bold text-gray-900" }, "Artikel Edukasi Terbaru")
        ], -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_35, [
          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.recentArticles, (article) => {
            return (_openBlock(), _createElementBlock("div", {
              key: article.id,
              class: "flex items-center justify-between border-b border-gray-50 pb-4 last:border-0 last:pb-0"
            }, [
              _createElementVNode("div", _hoisted_36, [
                _createElementVNode("img", {
                  src: article.image_path ? (article.image_path.startsWith('http') ? article.image_path : '/storage/' + article.image_path) : 'https://picsum.photos/seed/'+article.id+'/150/150',
                  class: "w-12 h-12 rounded-xl border border-gray-100 object-cover"
                }, null, 8 /* PROPS */, _hoisted_37),
                _createElementVNode("div", null, [
                  _createElementVNode("p", _hoisted_38, _toDisplayString(article.title), 1 /* TEXT */),
                  _createElementVNode("p", _hoisted_39, _toDisplayString(article.tag), 1 /* TEXT */)
                ])
              ])
            ]))
          }), 128 /* KEYED_FRAGMENT */)),
          (!$props.recentArticles.length)
            ? (_openBlock(), _createElementBlock("div", _hoisted_40, "Belum ada artikel."))
            : _createCommentVNode("v-if", true)
        ])
      ])
    ])
  ]))
}



_sfc_main.__hmrId = "ce5ab480"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
export const _rerender_only = __VUE_HMR_RUNTIME__.CHANGED_FILE === "C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Dashboard.vue"
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Dashboard.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuaW1wb3J0IEFkbWluTGF5b3V0IGZyb20gJ0AvTGF5b3V0cy9BZG1pbkxheW91dC52dWUnO1xuaW1wb3J0IEljb24gZnJvbSAnQC9Db21wb25lbnRzL0ljb24udnVlJztcblxuZGVmaW5lT3B0aW9ucyh7IGxheW91dDogQWRtaW5MYXlvdXQgfSk7XG5cbmRlZmluZVByb3BzKHtcbiAgICB0b3RhbFByb2R1Y3RzOiBOdW1iZXIsXG4gICAgdG90YWxBcnRpY2xlczogTnVtYmVyLFxuICAgIHRvdGFsVmlzaXRzOiBOdW1iZXIsXG4gICAgbmV3T3JkZXJzOiBOdW1iZXIsXG4gICAgcmVjZW50UHJvZHVjdHM6IEFycmF5LFxuICAgIHJlY2VudEFydGljbGVzOiBBcnJheVxufSk7XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8ZGl2IGNsYXNzPVwibWF4LXctMzUwIG14LWF1dG9cIj5cbiAgICA8IS0tIEhlYWRlciAtLT5cbiAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IG1iLThcIj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMiBjbGFzcz1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIHRyYWNraW5nLXRpZ2h0XCI+RGFzaGJvYXJkPC9oMj5cbiAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlBsYW4sIHByaW9yaXRpemUsIGFuZCBhY2NvbXBsaXNoIHlvdXIgdGFza3Mgd2l0aCBlYXNlLjwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9kaXY+XG5cbiAgICA8IS0tIFN0YXQgQ2FyZHMgLS0+XG4gICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTUgbWItNlwiPlxuICAgICAgPCEtLSBDYXJkIDEgLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwiYmctZW1lcmFsZC04MDAgcm91bmRlZC0zeGwgcC02IHRleHQtd2hpdGUgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGdyb3VwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItNCByZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LW1lZGl1bSB0ZXh0LWVtZXJhbGQtMTAwIHRleHQtc21cIj5Ub3RhbCBQcm9kdWs8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLXdoaXRlLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJhY2tkcm9wLWJsdXItc20gZ3JvdXAtaG92ZXI6Ymctd2hpdGUvMzAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwidy00IGgtNCAtcm90YXRlLTQ1XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LTR4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIG1iLTQgcmVsYXRpdmUgei0xMFwiPnt7IHRvdGFsUHJvZHVjdHMgfX08L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzAuNjVyZW1dIHRleHQtZW1lcmFsZC0yMDAgcmVsYXRpdmUgei0xMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmctd2hpdGUvMjAgcHgtMS41IHB5LTAuNSByb3VuZGVkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+PEljb24gbmFtZT1cImFycm93XCIgY2xhc3M9XCJ3LTMgaC0zIC1yb3RhdGUtOTBcIiAvPiA1PC9zcGFuPlxuICAgICAgICAgIEluY3JlYXNlZCBmcm9tIGxhc3QgbW9udGhcbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtcmlnaHQtOCAtYm90dG9tLTggdy0zMiBoLTMyIGJnLXdoaXRlLzEwIHJvdW5kZWQtZnVsbCBibHVyLXhsXCI+PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgPCEtLSBDYXJkIDIgLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwiYmctd2hpdGUgcm91bmRlZC0zeGwgcC02IGJvcmRlciBib3JkZXItZ3JheS0xMDAgZ3JvdXAgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtYi00XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIHRleHQtc21cIj5QZXNhbmFuIEJhcnU8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInctOCBoLTggcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ncmF5LTQwMCBncm91cC1ob3Zlcjp0ZXh0LWVtZXJhbGQtNzAwIGdyb3VwLWhvdmVyOmJvcmRlci1lbWVyYWxkLTIwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImFycm93XCIgY2xhc3M9XCJ3LTQgaC00IC1yb3RhdGUtNDVcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtNHhsIGZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi00XCI+e3sgbmV3T3JkZXJzIH19PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVswLjY1cmVtXSB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwidy0zIGgtMyAtcm90YXRlLTkwXCIgLz4gNjwvc3Bhbj5cbiAgICAgICAgICBJbmNyZWFzZWQgZnJvbSBsYXN0IG1vbnRoXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0gQ2FyZCAzIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGdyb3VwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItNFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtXCI+VG90YWwgS3VuanVuZ2FuPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZ3JheS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBncm91cC1ob3Zlcjpib3JkZXItZW1lcmFsZC0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwidy00IGgtNCAtcm90YXRlLTQ1XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LTR4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItNFwiPnt7IHRvdGFsVmlzaXRzIH19PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVswLjY1cmVtXSB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwidy0zIGgtMyAtcm90YXRlLTkwXCIgLz4gMjwvc3Bhbj5cbiAgICAgICAgICBJbmNyZWFzZWQgZnJvbSBsYXN0IG1vbnRoXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0gQ2FyZCA0IC0tPlxuICAgICAgPGRpdiBjbGFzcz1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGdyb3VwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItNFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtXCI+QXJ0aWtlbCBFZHVrYXNpPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZ3JheS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBncm91cC1ob3Zlcjpib3JkZXItZW1lcmFsZC0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwidy00IGgtNCAtcm90YXRlLTQ1XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LTR4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItNFwiPnt7IHRvdGFsQXJ0aWNsZXMgfX08L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzAuNjVyZW1dIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICBPbiBEaXNjdXNzXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNVwiPlxuICAgICAgPCEtLSBSZWNlbnQgUHJvZHVjdHMgLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwiYmctd2hpdGUgcm91bmRlZC0zeGwgcC02IGJvcmRlciBib3JkZXItZ3JheS0xMDAgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cbiAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlByb2R1ayBUZXJiYXJ1PC9oMz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICA8ZGl2IHYtZm9yPVwicHJvZHVjdCBpbiByZWNlbnRQcm9kdWN0c1wiIDprZXk9XCJwcm9kdWN0LmlkXCIgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWdyYXktNTAgcGItNCBsYXN0OmJvcmRlci0wIGxhc3Q6cGItMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxpbWcgOnNyYz1cInByb2R1Y3QuaW1hZ2VfcGF0aCA/IChwcm9kdWN0LmltYWdlX3BhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcHJvZHVjdC5pbWFnZV9wYXRoIDogJy9zdG9yYWdlLycgKyBwcm9kdWN0LmltYWdlX3BhdGgpIDogJ2h0dHBzOi8vcGljc3VtLnBob3Rvcy9zZWVkLycrcHJvZHVjdC5pZCsnLzE1MC8xNTAnXCIgY2xhc3M9XCJ3LTEyIGgtMTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctdGlnaHQgbWItMC41XCI+e3sgcHJvZHVjdC5uYW1lIH19PC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1bMC42NXJlbV0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPnt7IHByb2R1Y3QuY2F0ZWdvcnkgfX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInB4LTIgcHktMSByb3VuZGVkIHRleHQtWzAuN3JlbV0gZm9udC1ib2xkIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCB0cmFja2luZy13aWRlXCI+UnAge3sgcHJvZHVjdC5wcmljZSB9fTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHYtaWY9XCIhcmVjZW50UHJvZHVjdHMubGVuZ3RoXCIgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDAgcHktNFwiPkJlbHVtIGFkYSBwcm9kdWsuPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0gUmVjZW50IEFydGljbGVzIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02XCI+XG4gICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5BcnRpa2VsIEVkdWthc2kgVGVyYmFydTwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiB2LWZvcj1cImFydGljbGUgaW4gcmVjZW50QXJ0aWNsZXNcIiA6a2V5PVwiYXJ0aWNsZS5pZFwiIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTUwIHBiLTQgbGFzdDpib3JkZXItMCBsYXN0OnBiLTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8aW1nIDpzcmM9XCJhcnRpY2xlLmltYWdlX3BhdGggPyAoYXJ0aWNsZS5pbWFnZV9wYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IGFydGljbGUuaW1hZ2VfcGF0aCA6ICcvc3RvcmFnZS8nICsgYXJ0aWNsZS5pbWFnZV9wYXRoKSA6ICdodHRwczovL3BpY3N1bS5waG90b3Mvc2VlZC8nK2FydGljbGUuaWQrJy8xNTAvMTUwJ1wiIGNsYXNzPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBsZWFkaW5nLXRpZ2h0IG1iLTAuNVwiPnt7IGFydGljbGUudGl0bGUgfX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LVswLjY1cmVtXSB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+e3sgYXJ0aWNsZS50YWcgfX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiB2LWlmPVwiIXJlY2VudEFydGljbGVzLmxlbmd0aFwiIGNsYXNzPVwidGV4dC1zbSB0ZXh0LWdyYXktNDAwIHB5LTRcIj5CZWx1bSBhZGEgYXJ0aWtlbC48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQWVqQyxLQUFLLEVBQUMsbUJBQW1CO3FCQVd2QixLQUFLLEVBQUMsMkRBQTJEO3FCQUUvRCxLQUFLLEVBQUMseUdBQXlHO3FCQUM3RyxLQUFLLEVBQUMscURBQXFEO3FCQUV6RCxLQUFLLEVBQUMsNklBQTZJO3FCQUlySixLQUFLLEVBQUMsb0RBQW9EO3FCQUMxRCxLQUFLLEVBQUMsbUZBQW1GO3FCQUN0RixLQUFLLEVBQUMsMkRBQTJEO3FCQU90RSxLQUFLLEVBQUMsc0ZBQXNGO3NCQUMxRixLQUFLLEVBQUMsdUNBQXVDO3NCQUUzQyxLQUFLLEVBQUMseUxBQXlMO3NCQUlqTSxLQUFLLEVBQUMsb0RBQW9EO3NCQUMxRCxLQUFLLEVBQUMsa0VBQWtFO3NCQUNyRSxLQUFLLEVBQUMseUVBQXlFO3NCQU1wRixLQUFLLEVBQUMsc0ZBQXNGO3NCQUMxRixLQUFLLEVBQUMsdUNBQXVDO3NCQUUzQyxLQUFLLEVBQUMseUxBQXlMO3NCQUlqTSxLQUFLLEVBQUMsb0RBQW9EO3NCQUMxRCxLQUFLLEVBQUMsa0VBQWtFO3NCQUNyRSxLQUFLLEVBQUMseUVBQXlFO3NCQU1wRixLQUFLLEVBQUMsc0ZBQXNGO3NCQUMxRixLQUFLLEVBQUMsdUNBQXVDO3NCQUUzQyxLQUFLLEVBQUMseUxBQXlMO3NCQUlqTSxLQUFLLEVBQUMsb0RBQW9EO3NCQU85RCxLQUFLLEVBQUMsdUNBQXVDO3NCQUUzQyxLQUFLLEVBQUMsK0RBQStEO3NCQUluRSxLQUFLLEVBQUMsV0FBVztzQkFFYixLQUFLLEVBQUMseUJBQXlCOztzQkFHN0IsS0FBSyxFQUFDLHNEQUFzRDtzQkFDNUQsS0FBSyxFQUFDLDBDQUEwQztzQkFHakQsS0FBSyxFQUFDLHdGQUF3Rjs7O0VBRW5FLEtBQUssRUFBQyw0QkFBNEI7O3NCQUtwRSxLQUFLLEVBQUMsK0RBQStEO3NCQUluRSxLQUFLLEVBQUMsV0FBVztzQkFFYixLQUFLLEVBQUMseUJBQXlCOztzQkFHN0IsS0FBSyxFQUFDLHNEQUFzRDtzQkFDNUQsS0FBSyxFQUFDLDBDQUEwQzs7O0VBSXRCLEtBQUssRUFBQyw0QkFBNEI7Ozs7d0JBN0c3RSxvQkFpSE0sT0FqSE4sVUFpSE07SUFoSEosK0JBQWU7Z0NBQ2Ysb0JBTU0sU0FORCxLQUFLLEVBQUMsc0VBQXNFO01BQy9FLG9CQUdNO1FBRkosb0JBQTBFLFFBQXRFLEtBQUssRUFBQyxpREFBaUQsSUFBQyxXQUFTO1FBQ3JFLG9CQUFnRyxPQUE3RixLQUFLLEVBQUMsNEJBQTRCLElBQUMsd0RBQXNEOzs7SUFLaEcsbUNBQW1CO0lBQ25CLG9CQTRETSxPQTVETixVQTRETTtNQTNESiwrQkFBZTtNQUNmLG9CQWFNLE9BYk4sVUFhTTtRQVpKLG9CQUtNLE9BTE4sVUFLTTtvQ0FKSixvQkFBc0UsVUFBaEUsS0FBSyxFQUFDLHNDQUFzQyxJQUFDLGNBQVk7VUFDL0Qsb0JBRU0sT0FGTixVQUVNO1lBREosYUFBZ0Q7Y0FBMUMsSUFBSSxFQUFDLE9BQU87Y0FBQyxLQUFLLEVBQUMsb0JBQW9COzs7O1FBR2pELG9CQUF5RixPQUF6RixVQUF5RixtQkFBdEIsb0JBQWE7UUFDaEYsb0JBR00sT0FITixVQUdNO1VBRkosb0JBQWlJLFFBQWpJLFVBQWlJO1lBQXpELGFBQWdEO2NBQTFDLElBQUksRUFBQyxPQUFPO2NBQUMsS0FBSyxFQUFDLG9CQUFvQjs7dURBQUcsSUFBRTs7cURBQU8sNkJBRW5JOztrQ0FDQSxvQkFBMEYsU0FBckYsS0FBSyxFQUFDLHdFQUF3RTs7TUFHckYsK0JBQWU7TUFDZixvQkFZTSxPQVpOLFVBWU07UUFYSixvQkFLTSxPQUxOLFdBS007b0NBSkosb0JBQW1FLFVBQTdELEtBQUssRUFBQyxtQ0FBbUMsSUFBQyxjQUFZO1VBQzVELG9CQUVNLE9BRk4sV0FFTTtZQURKLGFBQWdEO2NBQTFDLElBQUksRUFBQyxPQUFPO2NBQUMsS0FBSyxFQUFDLG9CQUFvQjs7OztRQUdqRCxvQkFBcUYsT0FBckYsV0FBcUYsbUJBQWxCLGdCQUFTO1FBQzVFLG9CQUdNLE9BSE4sV0FHTTtVQUZKLG9CQUErSSxRQUEvSSxXQUErSTtZQUF6RCxhQUFnRDtjQUExQyxJQUFJLEVBQUMsT0FBTztjQUFDLEtBQUssRUFBQyxvQkFBb0I7O3VEQUFHLElBQUU7O3FEQUFPLDZCQUVqSjs7O01BR0YsK0JBQWU7TUFDZixvQkFZTSxPQVpOLFdBWU07UUFYSixvQkFLTSxPQUxOLFdBS007b0NBSkosb0JBQXNFLFVBQWhFLEtBQUssRUFBQyxtQ0FBbUMsSUFBQyxpQkFBZTtVQUMvRCxvQkFFTSxPQUZOLFdBRU07WUFESixhQUFnRDtjQUExQyxJQUFJLEVBQUMsT0FBTztjQUFDLEtBQUssRUFBQyxvQkFBb0I7Ozs7UUFHakQsb0JBQXVGLE9BQXZGLFdBQXVGLG1CQUFwQixrQkFBVztRQUM5RSxvQkFHTSxPQUhOLFdBR007VUFGSixvQkFBK0ksUUFBL0ksV0FBK0k7WUFBekQsYUFBZ0Q7Y0FBMUMsSUFBSSxFQUFDLE9BQU87Y0FBQyxLQUFLLEVBQUMsb0JBQW9COzt1REFBRyxJQUFFOztxREFBTyw2QkFFako7OztNQUdGLCtCQUFlO01BQ2Ysb0JBV00sT0FYTixXQVdNO1FBVkosb0JBS00sT0FMTixXQUtNO3NDQUpKLG9CQUFzRSxVQUFoRSxLQUFLLEVBQUMsbUNBQW1DLElBQUMsaUJBQWU7VUFDL0Qsb0JBRU0sT0FGTixXQUVNO1lBREosYUFBZ0Q7Y0FBMUMsSUFBSSxFQUFDLE9BQU87Y0FBQyxLQUFLLEVBQUMsb0JBQW9COzs7O1FBR2pELG9CQUF5RixPQUF6RixXQUF5RixtQkFBdEIsb0JBQWE7b0NBQ2hGLG9CQUVNLFNBRkQsS0FBSyxFQUFDLGtFQUFrRSxJQUFDLGNBRTlFOzs7SUFJSixvQkF1Q00sT0F2Q04sV0F1Q007TUF0Q0osd0NBQXdCO01BQ3hCLG9CQWlCTSxPQWpCTixXQWlCTTtvQ0FoQkosb0JBRU0sU0FGRCxLQUFLLEVBQUMsd0NBQXdDO1VBQ2pELG9CQUF1RCxRQUFuRCxLQUFLLEVBQUMseUJBQXlCLElBQUMsZ0JBQWM7O1FBRXBELG9CQVlNLE9BWk4sV0FZTTs2QkFYSixvQkFTTSw2QkFUaUIscUJBQWMsR0FBekIsT0FBTztrQ0FBbkIsb0JBU007Y0FUa0MsR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFO2NBQUUsS0FBSyxFQUFDLHdGQUF3Rjs7Y0FDckosb0JBTU0sT0FOTixXQU1NO2dCQUxKLG9CQUEwUDtrQkFBcFAsR0FBRyxFQUFFLE9BQU8sQ0FBQyxVQUFVLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxVQUFVLFdBQVcsT0FBTyxDQUFDLFVBQVUsaUJBQWlCLE9BQU8sQ0FBQyxVQUFVLGtDQUFrQyxPQUFPLENBQUMsRUFBRTtrQkFBYSxLQUFLLEVBQUMsMERBQTBEOztnQkFDdlAsb0JBR007a0JBRkosb0JBQXNGLEtBQXRGLFdBQXNGLG1CQUFuQixPQUFPLENBQUMsSUFBSTtrQkFDL0Usb0JBQThFLEtBQTlFLFdBQThFLG1CQUF2QixPQUFPLENBQUMsUUFBUTs7O2NBRzNFLG9CQUFrSSxRQUFsSSxXQUFrSSxFQUE3QixLQUFHLG9CQUFHLE9BQU8sQ0FBQyxLQUFLOzs7WUFFOUcscUJBQWMsQ0FBQyxNQUFNOzZCQUFqQyxvQkFBNkYsT0FBN0YsV0FBNkYsRUFBdkIsbUJBQWlCOzs7O01BSTNGLHdDQUF3QjtNQUN4QixvQkFnQk0sT0FoQk4sV0FnQk07b0NBZkosb0JBRU0sU0FGRCxLQUFLLEVBQUMsd0NBQXdDO1VBQ2pELG9CQUFnRSxRQUE1RCxLQUFLLEVBQUMseUJBQXlCLElBQUMseUJBQXVCOztRQUU3RCxvQkFXTSxPQVhOLFdBV007NkJBVkosb0JBUU0sNkJBUmlCLHFCQUFjLEdBQXpCLE9BQU87a0NBQW5CLG9CQVFNO2NBUmtDLEdBQUcsRUFBRSxPQUFPLENBQUMsRUFBRTtjQUFFLEtBQUssRUFBQyx3RkFBd0Y7O2NBQ3JKLG9CQU1NLE9BTk4sV0FNTTtnQkFMSixvQkFBMFA7a0JBQXBQLEdBQUcsRUFBRSxPQUFPLENBQUMsVUFBVSxJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsVUFBVSxXQUFXLE9BQU8sQ0FBQyxVQUFVLGlCQUFpQixPQUFPLENBQUMsVUFBVSxrQ0FBa0MsT0FBTyxDQUFDLEVBQUU7a0JBQWEsS0FBSyxFQUFDLDBEQUEwRDs7Z0JBQ3ZQLG9CQUdNO2tCQUZKLG9CQUF1RixLQUF2RixXQUF1RixtQkFBcEIsT0FBTyxDQUFDLEtBQUs7a0JBQ2hGLG9CQUF5RSxLQUF6RSxXQUF5RSxtQkFBbEIsT0FBTyxDQUFDLEdBQUc7Ozs7O1lBSTVELHFCQUFjLENBQUMsTUFBTTs2QkFBakMsb0JBQThGLE9BQTlGLFdBQThGLEVBQXhCLG9CQUFrQiIsImlnbm9yZUxpc3QiOltdfQ==