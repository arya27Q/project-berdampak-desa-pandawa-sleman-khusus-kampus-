import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Products/Edit.vue");import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import { Link, useForm } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import { ref } from "/node_modules/.vite/deps/vue.js?v=cebe2491";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Edit',
  props: {
    product: Object
},
  setup(__props, { expose: __expose }) {
  __expose();



const props = __props;

const form = useForm({
    name: props.product.name || '',
    category: props.product.category || 'Pupuk Organik',
    desc: props.product.desc || '',
    price: props.product.price || '',
    badge: props.product.badge || '',
    badgeTone: props.product.badgeTone || 'leaf',
    image: null,
    _method: 'put'
});

const imagePreview = ref(props.product.image_path ? '/storage/' + props.product.image_path : null);

const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
        form.image = file;
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.value = e.target.result;
        };
        reader.readAsDataURL(file);
    }
};

const submit = () => {
    form.post(`/admin/products/${props.product.id}`, {
        preserveScroll: true,
    });
};

const __returned__ = { props, form, imagePreview, handleImageUpload, submit, AdminLayout, get Link() { return Link }, get useForm() { return useForm }, ref }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, toDisplayString as _toDisplayString, createCommentVNode as _createCommentVNode, vModelText as _vModelText, withDirectives as _withDirectives, vModelSelect as _vModelSelect, withModifiers as _withModifiers, createStaticVNode as _createStaticVNode, Fragment as _Fragment } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "mb-8" }
const _hoisted_2 = { class: "text-3xl font-bold text-gray-900 tracking-tight" }
const _hoisted_3 = { class: "bg-white rounded-3xl shadow-sm border border-emerald-50 overflow-hidden max-w-4xl" }
const _hoisted_4 = { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }
const _hoisted_5 = { class: "space-y-2" }
const _hoisted_6 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_7 = { class: "space-y-2" }
const _hoisted_8 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_9 = { class: "space-y-2" }
const _hoisted_10 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_11 = { class: "space-y-2" }
const _hoisted_12 = { class: "flex gap-2" }
const _hoisted_13 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_14 = { class: "space-y-2" }
const _hoisted_15 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_16 = { class: "space-y-2" }
const _hoisted_17 = { class: "mt-2 flex justify-center rounded-xl border border-dashed border-gray-300 px-6 py-10 bg-gray-50 hover:bg-emerald-50 hover:border-emerald-300 transition-all cursor-pointer relative overflow-hidden group" }
const _hoisted_18 = {
  key: 0,
  class: "text-center"
}
const _hoisted_19 = {
  key: 1,
  class: "relative w-full max-w-sm h-48 rounded-lg overflow-hidden border border-gray-200"
}
const _hoisted_20 = ["src"]
const _hoisted_21 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_22 = { class: "pt-6 border-t border-gray-100 flex justify-end gap-3" }
const _hoisted_23 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("div", _hoisted_1, [
      _createVNode($setup["Link"], {
        href: "/admin/products",
        class: "text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-2 mb-4"
      }, {
        default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
          _createElementVNode("svg", {
            class: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M10 19l-7-7m0 0l7-7m-7 7h18"
            })
          ], -1 /* CACHED */),
          _createTextVNode(" Kembali ke Kelola Produk ", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      }),
      _createElementVNode("h2", _hoisted_2, "Edit Produk: " + _toDisplayString($setup.props.product.name), 1 /* TEXT */),
      _cache[7] || (_cache[7] = _createElementVNode("p", { class: "text-gray-500 mt-2" }, "Perbarui informasi detail untuk produk ini.", -1 /* CACHED */))
    ]),
    _createElementVNode("div", _hoisted_3, [
      _createElementVNode("form", {
        onSubmit: _withModifiers($setup.submit, ["prevent"]),
        class: "p-8 space-y-6"
      }, [
        _createElementVNode("div", _hoisted_4, [
          _createCommentVNode(" Nama Produk "),
          _createElementVNode("div", _hoisted_5, [
            _cache[8] || (_cache[8] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Nama Produk", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.name) = $event)),
              type: "text",
              placeholder: "Masukkan nama produk...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.name]
            ]),
            ($setup.form.errors.name)
              ? (_openBlock(), _createElementBlock("p", _hoisted_6, _toDisplayString($setup.form.errors.name), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Harga "),
          _createElementVNode("div", _hoisted_7, [
            _cache[9] || (_cache[9] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Harga (Teks/Format Bebas)", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.price) = $event)),
              type: "text",
              placeholder: "Misal: Rp 45.000",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.price]
            ]),
            ($setup.form.errors.price)
              ? (_openBlock(), _createElementBlock("p", _hoisted_8, _toDisplayString($setup.form.errors.price), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Kategori "),
          _createElementVNode("div", _hoisted_9, [
            _cache[11] || (_cache[11] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Kategori", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("select", {
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.category) = $event)),
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
            }, [...(_cache[10] || (_cache[10] = [
              _createElementVNode("option", { value: "Pupuk Organik" }, "Pupuk Organik", -1 /* CACHED */),
              _createElementVNode("option", { value: "Probiotik Peternakan" }, "Probiotik Peternakan", -1 /* CACHED */)
            ]))], 512 /* NEED_PATCH */), [
              [_vModelSelect, $setup.form.category]
            ]),
            ($setup.form.errors.category)
              ? (_openBlock(), _createElementBlock("p", _hoisted_10, _toDisplayString($setup.form.errors.category), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Badge "),
          _createElementVNode("div", _hoisted_11, [
            _cache[13] || (_cache[13] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Badge/Label (Opsional)", -1 /* CACHED */)),
            _createElementVNode("div", _hoisted_12, [
              _withDirectives(_createElementVNode("input", {
                "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.badge) = $event)),
                type: "text",
                placeholder: "Misal: Terlaris",
                class: "flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.form.badge]
              ]),
              _withDirectives(_createElementVNode("select", {
                "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.form.badgeTone) = $event)),
                class: "w-32 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
              }, [...(_cache[12] || (_cache[12] = [
                _createElementVNode("option", { value: "leaf" }, "Hijau", -1 /* CACHED */),
                _createElementVNode("option", { value: "clay" }, "Coklat", -1 /* CACHED */)
              ]))], 512 /* NEED_PATCH */), [
                [_vModelSelect, $setup.form.badgeTone]
              ])
            ]),
            ($setup.form.errors.badge)
              ? (_openBlock(), _createElementBlock("p", _hoisted_13, _toDisplayString($setup.form.errors.badge), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ])
        ]),
        _createCommentVNode(" Deskripsi "),
        _createElementVNode("div", _hoisted_14, [
          _cache[14] || (_cache[14] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Deskripsi Singkat", -1 /* CACHED */)),
          _withDirectives(_createElementVNode("textarea", {
            "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => (($setup.form.desc) = $event)),
            rows: "3",
            placeholder: "Tuliskan deskripsi singkat atau manfaat produk...",
            class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.form.desc]
          ]),
          ($setup.form.errors.desc)
            ? (_openBlock(), _createElementBlock("p", _hoisted_15, _toDisplayString($setup.form.errors.desc), 1 /* TEXT */))
            : _createCommentVNode("v-if", true)
        ]),
        _createCommentVNode(" Foto "),
        _createElementVNode("div", _hoisted_16, [
          _cache[17] || (_cache[17] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Foto Produk (Biarkan kosong jika tidak ingin mengubah)", -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_17, [
            _createElementVNode("input", {
              type: "file",
              onChange: $setup.handleImageUpload,
              class: "absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10",
              accept: "image/*"
            }, null, 32 /* NEED_HYDRATION */),
            (!$setup.imagePreview)
              ? (_openBlock(), _createElementBlock("div", _hoisted_18, [...(_cache[15] || (_cache[15] = [
                  _createStaticVNode("<svg class=\"mx-auto h-12 w-12 text-gray-300 group-hover:text-emerald-500 transition-colors\" viewBox=\"0 0 24 24\" fill=\"currentColor\" aria-hidden=\"true\"><path fill-rule=\"evenodd\" d=\"M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z\" clip-rule=\"evenodd\"></path></svg><div class=\"mt-4 flex text-sm leading-6 text-gray-600 justify-center\"><span class=\"relative rounded-md font-semibold text-emerald-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-emerald-600 focus-within:ring-offset-2 hover:text-emerald-500\"><span>Upload a file</span></span><p class=\"pl-1\">or drag and drop</p></div><p class=\"text-xs leading-5 text-gray-500\">PNG, JPG, GIF up to 2MB</p>", 3)
                ]))]))
              : (_openBlock(), _createElementBlock("div", _hoisted_19, [
                  _createElementVNode("img", {
                    src: $setup.imagePreview,
                    class: "w-full h-full object-cover"
                  }, null, 8 /* PROPS */, _hoisted_20),
                  _cache[16] || (_cache[16] = _createElementVNode("div", { class: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center" }, [
                    _createElementVNode("p", { class: "text-white text-sm font-bold" }, "Ganti Foto")
                  ], -1 /* CACHED */))
                ]))
          ]),
          ($setup.form.errors.image)
            ? (_openBlock(), _createElementBlock("p", _hoisted_21, _toDisplayString($setup.form.errors.image), 1 /* TEXT */))
            : _createCommentVNode("v-if", true)
        ]),
        _createCommentVNode(" Submit Button "),
        _createElementVNode("div", _hoisted_22, [
          _createVNode($setup["Link"], {
            href: "/admin/products",
            class: "px-6 py-3 border border-gray-200 text-gray-600 font-medium rounded-xl hover:bg-gray-50 transition-colors"
          }, {
            default: _withCtx(() => [...(_cache[18] || (_cache[18] = [
              _createTextVNode("Batal", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }),
          _createElementVNode("button", {
            type: "submit",
            disabled: $setup.form.processing,
            class: "px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all disabled:opacity-50"
          }, " Simpan Perubahan ", 8 /* PROPS */, _hoisted_23)
        ])
      ], 32 /* NEED_HYDRATION */)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "f265c91a"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Products/Edit.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRWRpdC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbmltcG9ydCBBZG1pbkxheW91dCBmcm9tICdAL0xheW91dHMvQWRtaW5MYXlvdXQudnVlJztcbmltcG9ydCB7IExpbmssIHVzZUZvcm0gfSBmcm9tICdAaW5lcnRpYWpzL3Z1ZTMnO1xuaW1wb3J0IHsgcmVmIH0gZnJvbSAndnVlJztcblxuZGVmaW5lT3B0aW9ucyh7IGxheW91dDogQWRtaW5MYXlvdXQgfSk7XG5cbmNvbnN0IHByb3BzID0gZGVmaW5lUHJvcHMoe1xuICAgIHByb2R1Y3Q6IE9iamVjdFxufSk7XG5cbmNvbnN0IGZvcm0gPSB1c2VGb3JtKHtcbiAgICBuYW1lOiBwcm9wcy5wcm9kdWN0Lm5hbWUgfHwgJycsXG4gICAgY2F0ZWdvcnk6IHByb3BzLnByb2R1Y3QuY2F0ZWdvcnkgfHwgJ1B1cHVrIE9yZ2FuaWsnLFxuICAgIGRlc2M6IHByb3BzLnByb2R1Y3QuZGVzYyB8fCAnJyxcbiAgICBwcmljZTogcHJvcHMucHJvZHVjdC5wcmljZSB8fCAnJyxcbiAgICBiYWRnZTogcHJvcHMucHJvZHVjdC5iYWRnZSB8fCAnJyxcbiAgICBiYWRnZVRvbmU6IHByb3BzLnByb2R1Y3QuYmFkZ2VUb25lIHx8ICdsZWFmJyxcbiAgICBpbWFnZTogbnVsbCxcbiAgICBfbWV0aG9kOiAncHV0J1xufSk7XG5cbmNvbnN0IGltYWdlUHJldmlldyA9IHJlZihwcm9wcy5wcm9kdWN0LmltYWdlX3BhdGggPyAnL3N0b3JhZ2UvJyArIHByb3BzLnByb2R1Y3QuaW1hZ2VfcGF0aCA6IG51bGwpO1xuXG5jb25zdCBoYW5kbGVJbWFnZVVwbG9hZCA9IChlKSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xuICAgIGlmIChmaWxlKSB7XG4gICAgICAgIGZvcm0uaW1hZ2UgPSBmaWxlO1xuICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICByZWFkZXIub25sb2FkID0gKGUpID0+IHtcbiAgICAgICAgICAgIGltYWdlUHJldmlldy52YWx1ZSA9IGUudGFyZ2V0LnJlc3VsdDtcbiAgICAgICAgfTtcbiAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgfVxufTtcblxuY29uc3Qgc3VibWl0ID0gKCkgPT4ge1xuICAgIGZvcm0ucG9zdChgL2FkbWluL3Byb2R1Y3RzLyR7cHJvcHMucHJvZHVjdC5pZH1gLCB7XG4gICAgICAgIHByZXNlcnZlU2Nyb2xsOiB0cnVlLFxuICAgIH0pO1xufTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJtYi04XCI+XG4gICAgPExpbmsgaHJlZj1cIi9hZG1pbi9wcm9kdWN0c1wiIGNsYXNzPVwidGV4dC1zbSB0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxuICAgICAgPHN2ZyBjbGFzcz1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIyXCIgZD1cIk0xMCAxOWwtNy03bTAgMGw3LTdtLTcgN2gxOFwiPjwvcGF0aD48L3N2Zz5cbiAgICAgIEtlbWJhbGkga2UgS2Vsb2xhIFByb2R1a1xuICAgIDwvTGluaz5cbiAgICA8aDIgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cmFja2luZy10aWdodFwiPkVkaXQgUHJvZHVrOiB7eyBwcm9wcy5wcm9kdWN0Lm5hbWUgfX08L2gyPlxuICAgIDxwIGNsYXNzPVwidGV4dC1ncmF5LTUwMCBtdC0yXCI+UGVyYmFydWkgaW5mb3JtYXNpIGRldGFpbCB1bnR1ayBwcm9kdWsgaW5pLjwvcD5cbiAgPC9kaXY+XG5cbiAgPGRpdiBjbGFzcz1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAgb3ZlcmZsb3ctaGlkZGVuIG1heC13LTR4bFwiPlxuICAgIDxmb3JtIEBzdWJtaXQucHJldmVudD1cInN1Ym1pdFwiIGNsYXNzPVwicC04IHNwYWNlLXktNlwiPlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICA8IS0tIE5hbWEgUHJvZHVrIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPk5hbWEgUHJvZHVrPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImZvcm0ubmFtZVwiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJNYXN1a2thbiBuYW1hIHByb2R1ay4uLlwiIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIiByZXF1aXJlZCAvPlxuICAgICAgICAgIDxwIHYtaWY9XCJmb3JtLmVycm9ycy5uYW1lXCIgY2xhc3M9XCJ0ZXh0LXJlZC01MDAgdGV4dC14c1wiPnt7IGZvcm0uZXJyb3JzLm5hbWUgfX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0gSGFyZ2EgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+SGFyZ2EgKFRla3MvRm9ybWF0IEJlYmFzKTwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJmb3JtLnByaWNlXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk1pc2FsOiBScCA0NS4wMDBcIiBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMucHJpY2VcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMucHJpY2UgfX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0gS2F0ZWdvcmkgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+S2F0ZWdvcmk8L2xhYmVsPlxuICAgICAgICAgIDxzZWxlY3Qgdi1tb2RlbD1cImZvcm0uY2F0ZWdvcnlcIiBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCI+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUHVwdWsgT3JnYW5pa1wiPlB1cHVrIE9yZ2FuaWs8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQcm9iaW90aWsgUGV0ZXJuYWthblwiPlByb2Jpb3RpayBQZXRlcm5ha2FuPC9vcHRpb24+XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmNhdGVnb3J5XCIgY2xhc3M9XCJ0ZXh0LXJlZC01MDAgdGV4dC14c1wiPnt7IGZvcm0uZXJyb3JzLmNhdGVnb3J5IH19PC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8IS0tIEJhZGdlIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPkJhZGdlL0xhYmVsIChPcHNpb25hbCk8L2xhYmVsPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImZvcm0uYmFkZ2VcIiB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiTWlzYWw6IFRlcmxhcmlzXCIgY2xhc3M9XCJmbGV4LTEgcHgtNCBweS0zIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgdGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWFsbFwiIC8+XG4gICAgICAgICAgICA8c2VsZWN0IHYtbW9kZWw9XCJmb3JtLmJhZGdlVG9uZVwiIGNsYXNzPVwidy0zMiBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCI+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJsZWFmXCI+SGlqYXU8L29wdGlvbj5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNsYXlcIj5Db2tsYXQ8L29wdGlvbj5cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIHYtaWY9XCJmb3JtLmVycm9ycy5iYWRnZVwiIGNsYXNzPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57eyBmb3JtLmVycm9ycy5iYWRnZSB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPCEtLSBEZXNrcmlwc2kgLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5EZXNrcmlwc2kgU2luZ2thdDwvbGFiZWw+XG4gICAgICAgIDx0ZXh0YXJlYSB2LW1vZGVsPVwiZm9ybS5kZXNjXCIgcm93cz1cIjNcIiBwbGFjZWhvbGRlcj1cIlR1bGlza2FuIGRlc2tyaXBzaSBzaW5na2F0IGF0YXUgbWFuZmFhdCBwcm9kdWsuLi5cIiBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmRlc2NcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuZGVzYyB9fTwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8IS0tIEZvdG8gLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5Gb3RvIFByb2R1ayAoQmlhcmthbiBrb3NvbmcgamlrYSB0aWRhayBpbmdpbiBtZW5ndWJhaCk8L2xhYmVsPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMiBmbGV4IGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIHB4LTYgcHktMTAgYmctZ3JheS01MCBob3ZlcjpiZy1lbWVyYWxkLTUwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTMwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBAY2hhbmdlPVwiaGFuZGxlSW1hZ2VVcGxvYWRcIiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgdy1mdWxsIGgtZnVsbCBvcGFjaXR5LTAgY3Vyc29yLXBvaW50ZXIgei0xMFwiIGFjY2VwdD1cImltYWdlLypcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiIHYtaWY9XCIhaW1hZ2VQcmV2aWV3XCI+XG4gICAgICAgICAgICA8c3ZnIGNsYXNzPVwibXgtYXV0byBoLTEyIHctMTIgdGV4dC1ncmF5LTMwMCBncm91cC1ob3Zlcjp0ZXh0LWVtZXJhbGQtNTAwIHRyYW5zaXRpb24tY29sb3JzXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgICAgICAgICAgPHBhdGggZmlsbC1ydWxlPVwiZXZlbm9kZFwiIGQ9XCJNMS41IDZhMi4yNSAyLjI1IDAgMDEyLjI1LTIuMjVoMTYuNUEyLjI1IDIuMjUgMCAwMTIyLjUgNnYxMmEyLjI1IDIuMjUgMCAwMS0yLjI1IDIuMjVIMy43NUEyLjI1IDIuMjUgMCAwMTEuNSAxOFY2ek0zIDE2LjA2VjE4YzAgLjQxNC4zMzYuNzUuNzUuNzVoMTYuNUEuNzUuNzUgMCAwMDIxIDE4di0xLjk0bC0yLjY5LTIuNjg5YTEuNSAxLjUgMCAwMC0yLjEyIDBsLS44OC44NzkuOTcuOTdhLjc1Ljc1IDAgMTEtMS4wNiAxLjA2bC01LjE2LTUuMTU5YTEuNSAxLjUgMCAwMC0yLjEyIDBMMyAxNi4wNjF6bTEwLjEyNS03LjgxYTEuMTI1IDEuMTI1IDAgMTEyLjI1IDAgMS4xMjUgMS4xMjUgMCAwMS0yLjI1IDB6XCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC00IGZsZXggdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1ncmF5LTYwMCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInJlbGF0aXZlIHJvdW5kZWQtbWQgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGZvY3VzLXdpdGhpbjpvdXRsaW5lLW5vbmUgZm9jdXMtd2l0aGluOnJpbmctMiBmb2N1cy13aXRoaW46cmluZy1lbWVyYWxkLTYwMCBmb2N1cy13aXRoaW46cmluZy1vZmZzZXQtMiBob3Zlcjp0ZXh0LWVtZXJhbGQtNTAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+VXBsb2FkIGEgZmlsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cInBsLTFcIj5vciBkcmFnIGFuZCBkcm9wPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgbGVhZGluZy01IHRleHQtZ3JheS01MDBcIj5QTkcsIEpQRywgR0lGIHVwIHRvIDJNQjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1zbSBoLTQ4IHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgIDxpbWcgOnNyYz1cImltYWdlUHJldmlld1wiIGNsYXNzPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNTAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtd2hpdGUgdGV4dC1zbSBmb250LWJvbGRcIj5HYW50aSBGb3RvPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMuaW1hZ2VcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuaW1hZ2UgfX08L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPCEtLSBTdWJtaXQgQnV0dG9uIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cInB0LTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cbiAgICAgICAgPExpbmsgaHJlZj1cIi9hZG1pbi9wcm9kdWN0c1wiIGNsYXNzPVwicHgtNiBweS0zIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTYwMCBmb250LW1lZGl1bSByb3VuZGVkLXhsIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5CYXRhbDwvTGluaz5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgOmRpc2FibGVkPVwiZm9ybS5wcm9jZXNzaW5nXCIgY2xhc3M9XCJweC04IHB5LTMgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxuICAgICAgICAgIFNpbXBhbiBQZXJ1YmFoYW5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZm9ybT5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQUl6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FFWjs7QUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUM7O0FBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVsRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7O0FBRUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDOzs7Ozs7Ozs7O3FCQUlNLEtBQUssRUFBQyxNQUFNO3FCQUtYLEtBQUssRUFBQyxpREFBaUQ7cUJBSXhELEtBQUssRUFBQyxtRkFBbUY7cUJBR3JGLEtBQUssRUFBQyx1Q0FBdUM7cUJBRTNDLEtBQUssRUFBQyxXQUFXOzs7RUFHTyxLQUFLLEVBQUMsc0JBQXNCOztxQkFJcEQsS0FBSyxFQUFDLFdBQVc7OztFQUdRLEtBQUssRUFBQyxzQkFBc0I7O3FCQUlyRCxLQUFLLEVBQUMsV0FBVzs7O0VBTVcsS0FBSyxFQUFDLHNCQUFzQjs7c0JBSXhELEtBQUssRUFBQyxXQUFXO3NCQUVmLEtBQUssRUFBQyxZQUFZOzs7RUFPSyxLQUFLLEVBQUMsc0JBQXNCOztzQkFLdkQsS0FBSyxFQUFDLFdBQVc7OztFQUdPLEtBQUssRUFBQyxzQkFBc0I7O3NCQUlwRCxLQUFLLEVBQUMsV0FBVztzQkFFZixLQUFLLEVBQUMsME1BQTBNOzs7RUFFOU0sS0FBSyxFQUFDLGFBQWE7Ozs7RUFZWixLQUFLLEVBQUMsaUZBQWlGOzs7OztFQU96RSxLQUFLLEVBQUMsc0JBQXNCOztzQkFJckQsS0FBSyxFQUFDLHNEQUFzRDs7Ozs7SUF0RnJFLG9CQU9NLE9BUE4sVUFPTTtNQU5KLGFBR087UUFIRCxJQUFJLEVBQUMsaUJBQWlCO1FBQUMsS0FBSyxFQUFDLDBGQUEwRjs7MEJBQzNILENBQThMO1VBQTlMLG9CQUE4TDtZQUF6TCxLQUFLLEVBQUMsU0FBUztZQUFDLElBQUksRUFBQyxNQUFNO1lBQUMsTUFBTSxFQUFDLGNBQWM7WUFBQyxPQUFPLEVBQUMsV0FBVzs7WUFBQyxvQkFBNkc7Y0FBdkcsZ0JBQWMsRUFBQyxPQUFPO2NBQUMsaUJBQWUsRUFBQyxPQUFPO2NBQUMsY0FBWSxFQUFDLEdBQUc7Y0FBQyxDQUFDLEVBQUMsNkJBQTZCOzs7MkJBQWMsNEJBRWhNOzs7O01BQ0Esb0JBQXNHLE1BQXRHLFVBQXNHLEVBQTFDLGVBQWEsb0JBQUcsWUFBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJO2dDQUM5RixvQkFBNkUsT0FBMUUsS0FBSyxFQUFDLG9CQUFvQixJQUFDLDZDQUEyQzs7SUFHM0Usb0JBcUZNLE9BckZOLFVBcUZNO01BcEZKLG9CQW1GTztRQW5GQSxRQUFNLGlCQUFVLGFBQU07UUFBRSxLQUFLLEVBQUMsZUFBZTs7UUFFbEQsb0JBcUNNLE9BckNOLFVBcUNNO1VBcENKLG9DQUFvQjtVQUNwQixvQkFJTSxPQUpOLFVBSU07c0NBSEosb0JBQXdFLFdBQWpFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxhQUFXOzRCQUNoRSxvQkFBcVE7MkVBQXJQLFdBQUksQ0FBQyxJQUFJO2NBQUUsSUFBSSxFQUFDLE1BQU07Y0FBQyxXQUFXLEVBQUMseUJBQXlCO2NBQUMsS0FBSyxFQUFDLHNLQUFzSztjQUFDLFFBQVEsRUFBUixFQUFROzs0QkFBbFAsV0FBSSxDQUFDLElBQUk7O2FBQ2hCLFdBQUksQ0FBQyxNQUFNLENBQUMsSUFBSTsrQkFBekIsb0JBQWtGLEtBQWxGLFVBQWtGLG1CQUF2QixXQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7OztVQUc3RSw4QkFBYztVQUNkLG9CQUlNLE9BSk4sVUFJTTtzQ0FISixvQkFBc0YsV0FBL0UsS0FBSyxFQUFDLHVDQUF1QyxJQUFDLDJCQUF5Qjs0QkFDOUUsb0JBQStQOzJFQUEvTyxXQUFJLENBQUMsS0FBSztjQUFFLElBQUksRUFBQyxNQUFNO2NBQUMsV0FBVyxFQUFDLGtCQUFrQjtjQUFDLEtBQUssRUFBQyxzS0FBc0s7Y0FBQyxRQUFRLEVBQVIsRUFBUTs7NEJBQTVPLFdBQUksQ0FBQyxLQUFLOzthQUNqQixXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7K0JBQTFCLG9CQUFvRixLQUFwRixVQUFvRixtQkFBeEIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOzs7VUFHL0UsaUNBQWlCO1VBQ2pCLG9CQU9NLE9BUE4sVUFPTTt3Q0FOSixvQkFBcUUsV0FBOUQsS0FBSyxFQUFDLHVDQUF1QyxJQUFDLFVBQVE7NEJBQzdELG9CQUdTOzJFQUhRLFdBQUksQ0FBQyxRQUFRO2NBQUUsS0FBSyxFQUFDLHNLQUFzSzs7Y0FDMU0sb0JBQW9ELFlBQTVDLEtBQUssRUFBQyxlQUFlLElBQUMsZUFBYTtjQUMzQyxvQkFBa0UsWUFBMUQsS0FBSyxFQUFDLHNCQUFzQixJQUFDLHNCQUFvQjs7OEJBRjFDLFdBQUksQ0FBQyxRQUFROzthQUlyQixXQUFJLENBQUMsTUFBTSxDQUFDLFFBQVE7K0JBQTdCLG9CQUEwRixLQUExRixXQUEwRixtQkFBM0IsV0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFROzs7VUFHckYsOEJBQWM7VUFDZCxvQkFVTSxPQVZOLFdBVU07d0NBVEosb0JBQW1GLFdBQTVFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyx3QkFBc0I7WUFDM0Usb0JBTU0sT0FOTixXQU1NOzhCQUxKLG9CQUFxUDs2RUFBck8sV0FBSSxDQUFDLEtBQUs7Z0JBQUUsSUFBSSxFQUFDLE1BQU07Z0JBQUMsV0FBVyxFQUFDLGlCQUFpQjtnQkFBQyxLQUFLLEVBQUMsc0tBQXNLOzs4QkFBbE8sV0FBSSxDQUFDLEtBQUs7OzhCQUMxQixvQkFHUzs2RUFIUSxXQUFJLENBQUMsU0FBUztnQkFBRSxLQUFLLEVBQUMsb0tBQW9LOztnQkFDek0sb0JBQW1DLFlBQTNCLEtBQUssRUFBQyxNQUFNLElBQUMsT0FBSztnQkFDMUIsb0JBQW9DLFlBQTVCLEtBQUssRUFBQyxNQUFNLElBQUMsUUFBTTs7Z0NBRlosV0FBSSxDQUFDLFNBQVM7OzthQUt4QixXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7K0JBQTFCLG9CQUFvRixLQUFwRixXQUFvRixtQkFBeEIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOzs7O1FBSWpGLGtDQUFrQjtRQUNsQixvQkFJTSxPQUpOLFdBSU07c0NBSEosb0JBQThFLFdBQXZFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxtQkFBaUI7MEJBQ3RFLG9CQUErUjt5RUFBNVEsV0FBSSxDQUFDLElBQUk7WUFBRSxJQUFJLEVBQUMsR0FBRztZQUFDLFdBQVcsRUFBQyxtREFBbUQ7WUFBQyxLQUFLLEVBQUMsc0tBQXNLOzswQkFBaFEsV0FBSSxDQUFDLElBQUk7O1dBQ25CLFdBQUksQ0FBQyxNQUFNLENBQUMsSUFBSTs2QkFBekIsb0JBQWtGLEtBQWxGLFdBQWtGLG1CQUF2QixXQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7OztRQUc3RSw2QkFBYTtRQUNiLG9CQXdCTSxPQXhCTixXQXdCTTtzQ0F2Qkosb0JBQW1ILFdBQTVHLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyx3REFBc0Q7VUFDM0csb0JBb0JNLE9BcEJOLFdBb0JNO1lBbkJKLG9CQUF1STtjQUFoSSxJQUFJLEVBQUMsTUFBTTtjQUFFLFFBQU0sRUFBRSx3QkFBaUI7Y0FBRSxLQUFLLEVBQUMsOERBQThEO2NBQUMsTUFBTSxFQUFDLFNBQVM7O2NBQ3BHLG1CQUFZOytCQUE1QyxvQkFXTSxPQVhOLFdBV007OzsrQkFDTixvQkFLTSxPQUxOLFdBS007a0JBSkosb0JBQThEO29CQUF4RCxHQUFHLEVBQUUsbUJBQVk7b0JBQUUsS0FBSyxFQUFDLDRCQUE0Qjs7OENBQzNELG9CQUVNLFNBRkQsS0FBSyxFQUFDLG9IQUFvSDtvQkFDN0gsb0JBQXNELE9BQW5ELEtBQUssRUFBQyw4QkFBOEIsSUFBQyxZQUFVOzs7O1dBSS9DLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzs2QkFBMUIsb0JBQW9GLEtBQXBGLFdBQW9GLG1CQUF4QixXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7OztRQUcvRSxzQ0FBc0I7UUFDdEIsb0JBS00sT0FMTixXQUtNO1VBSkosYUFBMEo7WUFBcEosSUFBSSxFQUFDLGlCQUFpQjtZQUFDLEtBQUssRUFBQywwR0FBMEc7OzhCQUFDLENBQUs7K0JBQUwsT0FBSzs7OztVQUNuSixvQkFFUztZQUZELElBQUksRUFBQyxRQUFRO1lBQUUsUUFBUSxFQUFFLFdBQUksQ0FBQyxVQUFVO1lBQUUsS0FBSyxFQUFDLDRIQUE0SDthQUFDLG9CQUVyTCIsImlnbm9yZUxpc3QiOltdfQ==