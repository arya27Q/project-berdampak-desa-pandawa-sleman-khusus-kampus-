import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Products/Index.vue");const debounce = __vite__cjsImport3_lodash_debounce;import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import { Link, router } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import { ref, watch } from "/node_modules/.vite/deps/vue.js?v=cebe2491";
import __vite__cjsImport3_lodash_debounce from "/node_modules/.vite/deps/lodash_debounce.js?v=cebe2491";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Index',
  props: {
    products: Object,
    filters: Object,
},
  setup(__props, { expose: __expose }) {
  __expose();



const props = __props;

const search = ref(props.filters.search || '');
const category = ref(props.filters.category || 'Semua');

watch([search, category], debounce(([newSearch, newCategory]) => {
    router.get('/admin/products', { search: newSearch, category: newCategory }, {
        preserveState: true,
        replace: true
    });
}, 300));

const setCategory = (c) => {
    category.value = c;
};

const __returned__ = { props, search, category, setCategory, AdminLayout, get Link() { return Link }, get router() { return router }, ref, watch, get debounce() { return debounce } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, vModelText as _vModelText, withDirectives as _withDirectives, normalizeClass as _normalizeClass, renderList as _renderList, Fragment as _Fragment, toDisplayString as _toDisplayString, createCommentVNode as _createCommentVNode, createBlock as _createBlock } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8" }
const _hoisted_2 = { class: "flex flex-col lg:flex-row gap-4 mb-6" }
const _hoisted_3 = { class: "grow relative" }
const _hoisted_4 = { class: "flex gap-2" }
const _hoisted_5 = { class: "bg-white rounded-3xl shadow-sm border border-emerald-50 overflow-hidden" }
const _hoisted_6 = { class: "min-w-full divide-y divide-emerald-50" }
const _hoisted_7 = { class: "bg-white divide-y divide-emerald-50" }
const _hoisted_8 = { class: "px-8 py-5 whitespace-nowrap" }
const _hoisted_9 = { class: "w-16 h-16 rounded-xl overflow-hidden bg-gray-100" }
const _hoisted_10 = ["src"]
const _hoisted_11 = { class: "px-8 py-5" }
const _hoisted_12 = { class: "text-sm font-bold text-gray-900" }
const _hoisted_13 = { class: "px-8 py-5 whitespace-nowrap" }
const _hoisted_14 = { class: "px-8 py-5 whitespace-nowrap text-sm font-medium text-gray-900" }
const _hoisted_15 = { class: "px-8 py-5 whitespace-nowrap text-right text-sm font-medium" }
const _hoisted_16 = { class: "flex justify-end gap-2" }
const _hoisted_17 = ["onClick"]
const _hoisted_18 = { key: 0 }
const _hoisted_19 = {
  key: 0,
  class: "px-8 py-5 bg-white border-t border-emerald-50 flex items-center justify-between"
}
const _hoisted_20 = { class: "text-sm text-gray-500" }
const _hoisted_21 = { class: "font-bold text-gray-900" }
const _hoisted_22 = { class: "font-bold text-gray-900" }
const _hoisted_23 = { class: "font-bold text-gray-900" }
const _hoisted_24 = { class: "flex gap-1" }
const _hoisted_25 = ["innerHTML"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("div", _hoisted_1, [
      _cache[5] || (_cache[5] = _createElementVNode("div", null, [
        _createElementVNode("h2", { class: "text-3xl font-bold text-gray-900 tracking-tight" }, "Kelola Produk"),
        _createElementVNode("p", { class: "text-gray-500 mt-2" }, "Pupuk organik & probiotik unggulan Pandawa Kencana.")
      ], -1 /* CACHED */)),
      _createVNode($setup["Link"], {
        href: "/admin/products/create",
        class: "inline-flex items-center justify-center px-6 py-3 border border-transparent text-sm font-medium rounded-xl text-white bg-emerald-600 hover:bg-emerald-700 shadow-md hover:shadow-lg transition-all gap-2"
      }, {
        default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
          _createElementVNode("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 4v16m8-8H4"
            })
          ], -1 /* CACHED */),
          _createTextVNode(" Tambah Produk Baru ", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      })
    ]),
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("div", _hoisted_3, [
        _withDirectives(_createElementVNode("input", {
          "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.search) = $event)),
          type: "text",
          placeholder: "Cari nama produk...",
          class: "w-full pl-5 pr-12 py-3.5 bg-white border border-emerald-50 rounded-2xl shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700"
        }, null, 512 /* NEED_PATCH */), [
          [_vModelText, $setup.search]
        ]),
        _cache[6] || (_cache[6] = _createElementVNode("div", { class: "absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-gray-400" }, [
          _createElementVNode("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            })
          ])
        ], -1 /* CACHED */))
      ]),
      _createElementVNode("div", _hoisted_4, [
        _cache[7] || (_cache[7] = _createElementVNode("div", { class: "bg-emerald-100/50 p-2 rounded-2xl flex items-center justify-center text-emerald-700 px-3 border border-emerald-100" }, [
          _createElementVNode("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
            })
          ])
        ], -1 /* CACHED */)),
        _createElementVNode("button", {
          onClick: _cache[1] || (_cache[1] = $event => ($setup.setCategory('Semua'))),
          class: _normalizeClass(['px-6 py-3.5 rounded-2xl text-sm font-medium shadow-sm transition-colors', $setup.category === 'Semua' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:text-emerald-700 border border-emerald-50'])
        }, "Semua", 2 /* CLASS */),
        _createElementVNode("button", {
          onClick: _cache[2] || (_cache[2] = $event => ($setup.setCategory('Pupuk Organik'))),
          class: _normalizeClass(['px-6 py-3.5 rounded-2xl text-sm font-medium shadow-sm transition-colors', $setup.category === 'Pupuk Organik' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:text-emerald-700 border border-emerald-50'])
        }, "Pupuk Organik", 2 /* CLASS */),
        _createElementVNode("button", {
          onClick: _cache[3] || (_cache[3] = $event => ($setup.setCategory('Probiotik Peternakan'))),
          class: _normalizeClass(['px-6 py-3.5 rounded-2xl text-sm font-medium shadow-sm transition-colors', $setup.category === 'Probiotik Peternakan' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:text-emerald-700 border border-emerald-50'])
        }, "Probiotik Peternakan", 2 /* CLASS */)
      ])
    ]),
    _createElementVNode("div", _hoisted_5, [
      _createElementVNode("table", _hoisted_6, [
        _cache[12] || (_cache[12] = _createElementVNode("thead", { class: "bg-gray-50/50" }, [
          _createElementVNode("tr", null, [
            _createElementVNode("th", {
              scope: "col",
              class: "px-8 py-5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"
            }, "Foto"),
            _createElementVNode("th", {
              scope: "col",
              class: "px-8 py-5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"
            }, "Nama Produk"),
            _createElementVNode("th", {
              scope: "col",
              class: "px-8 py-5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"
            }, "Kategori"),
            _createElementVNode("th", {
              scope: "col",
              class: "px-8 py-5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"
            }, "Harga"),
            _createElementVNode("th", {
              scope: "col",
              class: "px-8 py-5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"
            }, "Status"),
            _createElementVNode("th", {
              scope: "col",
              class: "px-8 py-5 text-right text-xs font-bold text-gray-500 uppercase tracking-wider"
            }, "Aksi")
          ])
        ], -1 /* CACHED */)),
        _createElementVNode("tbody", _hoisted_7, [
          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.products.data, (product) => {
            return (_openBlock(), _createElementBlock("tr", {
              key: product.id,
              class: "hover:bg-gray-50/50 transition-colors"
            }, [
              _createElementVNode("td", _hoisted_8, [
                _createElementVNode("div", _hoisted_9, [
                  _createElementVNode("img", {
                    src: product.image_path ? '/storage/' + product.image_path : 'https://images.unsplash.com/photo-1599839619722-39751411ea63?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
                    class: "w-full h-full object-cover"
                  }, null, 8 /* PROPS */, _hoisted_10)
                ])
              ]),
              _createElementVNode("td", _hoisted_11, [
                _createElementVNode("div", _hoisted_12, _toDisplayString(product.name), 1 /* TEXT */)
              ]),
              _createElementVNode("td", _hoisted_13, [
                _createElementVNode("span", {
                  class: _normalizeClass([
              'px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full',
              product.category.toLowerCase().includes('pupuk') ? 'bg-amber-50 text-amber-700 border border-amber-100' : 'bg-emerald-50 text-emerald-700'
            ])
                }, _toDisplayString(product.category), 3 /* TEXT, CLASS */)
              ]),
              _createElementVNode("td", _hoisted_14, " Rp " + _toDisplayString(product.price), 1 /* TEXT */),
              _cache[10] || (_cache[10] = _createElementVNode("td", { class: "px-8 py-5 whitespace-nowrap" }, [
                _createElementVNode("div", { class: "flex items-center gap-3" }, [
                  _createElementVNode("div", { class: "w-12 h-6 bg-emerald-500 rounded-full relative cursor-pointer shadow-inner" }, [
                    _createElementVNode("div", { class: "absolute right-1 top-1 bg-white w-4 h-4 rounded-full shadow-sm" })
                  ]),
                  _createElementVNode("span", { class: "text-sm font-medium text-emerald-700" }, "Tampil")
                ])
              ], -1 /* CACHED */)),
              _createElementVNode("td", _hoisted_15, [
                _createElementVNode("div", _hoisted_16, [
                  _createVNode($setup["Link"], {
                    href: `/admin/products/${product.id}/edit`,
                    class: "w-10 h-10 rounded-full bg-white border border-gray-200 text-gray-500 hover:text-emerald-600 hover:border-emerald-200 flex items-center justify-center transition-colors shadow-sm"
                  }, {
                    default: _withCtx(() => [...(_cache[8] || (_cache[8] = [
                      _createElementVNode("svg", {
                        class: "w-4 h-4",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        _createElementVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                        })
                      ], -1 /* CACHED */)
                    ]))]),
                    _: 1 /* STABLE */
                  }, 8 /* PROPS */, ["href"]),
                  _createElementVNode("button", {
                    onClick: $event => ($setup.router.delete(`/admin/products/${product.id}`)),
                    class: "w-10 h-10 rounded-full bg-red-50 border border-red-100 text-red-500 hover:bg-red-100 flex items-center justify-center transition-colors shadow-sm"
                  }, [...(_cache[9] || (_cache[9] = [
                    _createElementVNode("svg", {
                      class: "w-4 h-4",
                      fill: "none",
                      stroke: "currentColor",
                      viewBox: "0 0 24 24"
                    }, [
                      _createElementVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        "stroke-width": "2",
                        d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                      })
                    ], -1 /* CACHED */)
                  ]))], 8 /* PROPS */, _hoisted_17)
                ])
              ])
            ]))
          }), 128 /* KEYED_FRAGMENT */)),
          (!$props.products.data.length)
            ? (_openBlock(), _createElementBlock("tr", _hoisted_18, [...(_cache[11] || (_cache[11] = [
                _createElementVNode("td", {
                  colspan: "6",
                  class: "px-8 py-10 text-center text-gray-400"
                }, "Belum ada data produk.", -1 /* CACHED */)
              ]))]))
            : _createCommentVNode("v-if", true)
        ])
      ]),
      _createCommentVNode(" Pagination "),
      ($props.products.data.length > 0)
        ? (_openBlock(), _createElementBlock("div", _hoisted_19, [
            _createElementVNode("p", _hoisted_20, [
              _cache[13] || (_cache[13] = _createTextVNode("Menampilkan ", -1 /* CACHED */)),
              _createElementVNode("span", _hoisted_21, _toDisplayString($props.products.from), 1 /* TEXT */),
              _cache[14] || (_cache[14] = _createTextVNode(" - ", -1 /* CACHED */)),
              _createElementVNode("span", _hoisted_22, _toDisplayString($props.products.to), 1 /* TEXT */),
              _cache[15] || (_cache[15] = _createTextVNode(" dari ", -1 /* CACHED */)),
              _createElementVNode("span", _hoisted_23, _toDisplayString($props.products.total), 1 /* TEXT */),
              _cache[16] || (_cache[16] = _createTextVNode(" produk", -1 /* CACHED */))
            ]),
            _createElementVNode("div", _hoisted_24, [
              (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.products.links, (link, k) => {
                return (_openBlock(), _createElementBlock(_Fragment, { key: k }, [
                  (!link.url)
                    ? (_openBlock(), _createElementBlock("div", {
                        key: 0,
                        innerHTML: link.label.replace('« Previous', '«').replace('Next »', '»'),
                        class: "min-w-[2.5rem] px-3 h-10 rounded-full flex items-center justify-center font-bold shadow-sm transition-colors bg-white border border-emerald-50 text-gray-400 opacity-50 cursor-not-allowed"
                      }, null, 8 /* PROPS */, _hoisted_25))
                    : (_openBlock(), _createBlock($setup["Link"], {
                        key: 1,
                        href: link.url,
                        innerHTML: link.label.replace('« Previous', '«').replace('Next »', '»'),
                        class: _normalizeClass(['min-w-[2.5rem] px-3 h-10 rounded-full flex items-center justify-center font-bold shadow-sm transition-colors', link.active ? 'bg-emerald-600 text-white shadow-md' : 'bg-white border border-emerald-50 text-gray-600 hover:text-emerald-700 hover:bg-gray-50'])
                      }, null, 8 /* PROPS */, ["href", "innerHTML", "class"]))
                ], 64 /* STABLE_FRAGMENT */))
              }), 128 /* KEYED_FRAGMENT */))
            ])
          ]))
        : _createCommentVNode("v-if", true)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "5aeaab55"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
export const _rerender_only = __VUE_HMR_RUNTIME__.CHANGED_FILE === "C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Products/Index.vue"
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Products/Index.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW5kZXgudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIlxuPHNjcmlwdCBzZXR1cD5cbmltcG9ydCBBZG1pbkxheW91dCBmcm9tICdAL0xheW91dHMvQWRtaW5MYXlvdXQudnVlJztcbmltcG9ydCB7IExpbmssIHJvdXRlciB9IGZyb20gJ0BpbmVydGlhanMvdnVlMyc7XG5pbXBvcnQgeyByZWYsIHdhdGNoIH0gZnJvbSAndnVlJztcbmltcG9ydCBkZWJvdW5jZSBmcm9tICdsb2Rhc2gvZGVib3VuY2UnO1xuXG5kZWZpbmVPcHRpb25zKHsgbGF5b3V0OiBBZG1pbkxheW91dCB9KTtcblxuY29uc3QgcHJvcHMgPSBkZWZpbmVQcm9wcyh7XG4gICAgcHJvZHVjdHM6IE9iamVjdCxcbiAgICBmaWx0ZXJzOiBPYmplY3QsXG59KTtcblxuY29uc3Qgc2VhcmNoID0gcmVmKHByb3BzLmZpbHRlcnMuc2VhcmNoIHx8ICcnKTtcbmNvbnN0IGNhdGVnb3J5ID0gcmVmKHByb3BzLmZpbHRlcnMuY2F0ZWdvcnkgfHwgJ1NlbXVhJyk7XG5cbndhdGNoKFtzZWFyY2gsIGNhdGVnb3J5XSwgZGVib3VuY2UoKFtuZXdTZWFyY2gsIG5ld0NhdGVnb3J5XSkgPT4ge1xuICAgIHJvdXRlci5nZXQoJy9hZG1pbi9wcm9kdWN0cycsIHsgc2VhcmNoOiBuZXdTZWFyY2gsIGNhdGVnb3J5OiBuZXdDYXRlZ29yeSB9LCB7XG4gICAgICAgIHByZXNlcnZlU3RhdGU6IHRydWUsXG4gICAgICAgIHJlcGxhY2U6IHRydWVcbiAgICB9KTtcbn0sIDMwMCkpO1xuXG5jb25zdCBzZXRDYXRlZ29yeSA9IChjKSA9PiB7XG4gICAgY2F0ZWdvcnkudmFsdWUgPSBjO1xufTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgbWItOFwiPlxuICAgIDxkaXY+XG4gICAgICA8aDIgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cmFja2luZy10aWdodFwiPktlbG9sYSBQcm9kdWs8L2gyPlxuICAgICAgPHAgY2xhc3M9XCJ0ZXh0LWdyYXktNTAwIG10LTJcIj5QdXB1ayBvcmdhbmlrICYgcHJvYmlvdGlrIHVuZ2d1bGFuIFBhbmRhd2EgS2VuY2FuYS48L3A+XG4gICAgPC9kaXY+XG4gICAgPExpbmsgaHJlZj1cIi9hZG1pbi9wcm9kdWN0cy9jcmVhdGVcIiBjbGFzcz1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweC02IHB5LTMgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHJvdW5kZWQteGwgdGV4dC13aGl0ZSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGdhcC0yXCI+XG4gICAgICA8c3ZnIGNsYXNzPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJcIiBkPVwiTTEyIDR2MTZtOC04SDRcIj48L3BhdGg+PC9zdmc+XG4gICAgICBUYW1iYWggUHJvZHVrIEJhcnVcbiAgICA8L0xpbms+XG4gIDwvZGl2PlxuXG4gIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGdhcC00IG1iLTZcIj5cbiAgICA8ZGl2IGNsYXNzPVwiZ3JvdyByZWxhdGl2ZVwiPlxuICAgICAgPGlucHV0IHYtbW9kZWw9XCJzZWFyY2hcIiB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiQ2FyaSBuYW1hIHByb2R1ay4uLlwiIGNsYXNzPVwidy1mdWxsIHBsLTUgcHItMTIgcHktMy41IGJnLXdoaXRlIGJvcmRlciBib3JkZXItZW1lcmFsZC01MCByb3VuZGVkLTJ4bCBzaGFkb3ctc20gZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwXCIgLz5cbiAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBwci00IHBvaW50ZXItZXZlbnRzLW5vbmUgdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICA8c3ZnIGNsYXNzPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJcIiBkPVwiTTIxIDIxbC02LTZtMi01YTcgNyAwIDExLTE0IDAgNyA3IDAgMDExNCAwelwiPjwvcGF0aD48L3N2Zz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0yXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiYmctZW1lcmFsZC0xMDAvNTAgcC0yIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC03MDAgcHgtMyBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMTAwXCI+XG4gICAgICAgIDxzdmcgY2xhc3M9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIGQ9XCJNMyA0YTEgMSAwIDAxMS0xaDE2YTEgMSAwIDAxMSAxdjIuNTg2YTEgMSAwIDAxLS4yOTMuNzA3bC02LjQxNCA2LjQxNGExIDEgMCAwMC0uMjkzLjcwN1YxN2wtNCA0di02LjU4NmExIDEgMCAwMC0uMjkzLS43MDdMMy4yOTMgNy4yOTNBMSAxIDAgMDEzIDYuNTg2VjR6XCI+PC9wYXRoPjwvc3ZnPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIEBjbGljaz1cInNldENhdGVnb3J5KCdTZW11YScpXCIgOmNsYXNzPVwiWydweC02IHB5LTMuNSByb3VuZGVkLTJ4bCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycycsIGNhdGVnb3J5ID09PSAnU2VtdWEnID8gJ2JnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUnIDogJ2JnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAnXVwiPlNlbXVhPC9idXR0b24+XG4gICAgICA8YnV0dG9uIEBjbGljaz1cInNldENhdGVnb3J5KCdQdXB1ayBPcmdhbmlrJylcIiA6Y2xhc3M9XCJbJ3B4LTYgcHktMy41IHJvdW5kZWQtMnhsIHRleHQtc20gZm9udC1tZWRpdW0gc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzJywgY2F0ZWdvcnkgPT09ICdQdXB1ayBPcmdhbmlrJyA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlJyA6ICdiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwJ11cIj5QdXB1ayBPcmdhbmlrPC9idXR0b24+XG4gICAgICA8YnV0dG9uIEBjbGljaz1cInNldENhdGVnb3J5KCdQcm9iaW90aWsgUGV0ZXJuYWthbicpXCIgOmNsYXNzPVwiWydweC02IHB5LTMuNSByb3VuZGVkLTJ4bCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycycsIGNhdGVnb3J5ID09PSAnUHJvYmlvdGlrIFBldGVybmFrYW4nID8gJ2JnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUnIDogJ2JnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAnXVwiPlByb2Jpb3RpayBQZXRlcm5ha2FuPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuXG4gIDxkaXYgY2xhc3M9XCJiZy13aGl0ZSByb3VuZGVkLTN4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgIDx0YWJsZSBjbGFzcz1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWVtZXJhbGQtNTBcIj5cbiAgICAgIDx0aGVhZCBjbGFzcz1cImJnLWdyYXktNTAvNTBcIj5cbiAgICAgICAgPHRyPlxuICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzPVwicHgtOCBweS01IHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkZvdG88L3RoPlxuICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzPVwicHgtOCBweS01IHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPk5hbWEgUHJvZHVrPC90aD5cbiAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzcz1cInB4LTggcHktNSB0ZXh0LWxlZnQgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5LYXRlZ29yaTwvdGg+XG4gICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3M9XCJweC04IHB5LTUgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+SGFyZ2E8L3RoPlxuICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzPVwicHgtOCBweS01IHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlN0YXR1czwvdGg+XG4gICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3M9XCJweC04IHB5LTUgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkFrc2k8L3RoPlxuICAgICAgICA8L3RyPlxuICAgICAgPC90aGVhZD5cbiAgICAgIDx0Ym9keSBjbGFzcz1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1lbWVyYWxkLTUwXCI+XG4gICAgICAgIDx0ciB2LWZvcj1cInByb2R1Y3QgaW4gcHJvZHVjdHMuZGF0YVwiIDprZXk9XCJwcm9kdWN0LmlkXCIgY2xhc3M9XCJob3ZlcjpiZy1ncmF5LTUwLzUwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgPHRkIGNsYXNzPVwicHgtOCBweS01IHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNiBoLTE2IHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGJnLWdyYXktMTAwXCI+XG4gICAgICAgICAgICAgIDxpbWcgOnNyYz1cInByb2R1Y3QuaW1hZ2VfcGF0aCA/ICcvc3RvcmFnZS8nICsgcHJvZHVjdC5pbWFnZV9wYXRoIDogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTk5ODM5NjE5NzIyLTM5NzUxNDExZWE2Mz9peGxpYj1yYi00LjAuMyZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZ3PTE1MCZxPTgwJ1wiIGNsYXNzPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3M9XCJweC04IHB5LTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+e3sgcHJvZHVjdC5uYW1lIH19PC9kaXY+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3M9XCJweC04IHB5LTUgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgIDxzcGFuIDpjbGFzcz1cIltcbiAgICAgICAgICAgICAgJ3B4LTMgcHktMSBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCcsXG4gICAgICAgICAgICAgIHByb2R1Y3QuY2F0ZWdvcnkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygncHVwdWsnKSA/ICdiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTEwMCcgOiAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwJ1xuICAgICAgICAgICAgXVwiPnt7IHByb2R1Y3QuY2F0ZWdvcnkgfX08L3NwYW4+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3M9XCJweC04IHB5LTUgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICBScCB7eyBwcm9kdWN0LnByaWNlIH19XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3M9XCJweC04IHB5LTUgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xMiBoLTYgYmctZW1lcmFsZC01MDAgcm91bmRlZC1mdWxsIHJlbGF0aXZlIGN1cnNvci1wb2ludGVyIHNoYWRvdy1pbm5lclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSByaWdodC0xIHRvcC0xIGJnLXdoaXRlIHctNCBoLTQgcm91bmRlZC1mdWxsIHNoYWRvdy1zbVwiPjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZW1lcmFsZC03MDBcIj5UYW1waWw8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZCBjbGFzcz1cInB4LTggcHktNSB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxMaW5rIDpocmVmPVwiYC9hZG1pbi9wcm9kdWN0cy8ke3Byb2R1Y3QuaWR9L2VkaXRgXCIgY2xhc3M9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzPVwidy00IGgtNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJcIiBkPVwiTTE1LjIzMiA1LjIzMmwzLjUzNiAzLjUzNm0tMi4wMzYtNS4wMzZhMi41IDIuNSAwIDExMy41MzYgMy41MzZMNi41IDIxLjAzNkgzdi0zLjU3MkwxNi43MzIgMy43MzJ6XCI+PC9wYXRoPjwvc3ZnPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgIDxidXR0b24gQGNsaWNrPVwicm91dGVyLmRlbGV0ZShgL2FkbWluL3Byb2R1Y3RzLyR7cHJvZHVjdC5pZH1gKVwiIGNsYXNzPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMTAwIHRleHQtcmVkLTUwMCBob3ZlcjpiZy1yZWQtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3M9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIGQ9XCJNMTkgN2wtLjg2NyAxMi4xNDJBMiAyIDAgMDExNi4xMzggMjFINy44NjJhMiAyIDAgMDEtMS45OTUtMS44NThMNSA3bTUgNHY2bTQtNnY2bTEtMTBWNGExIDEgMCAwMC0xLTFoLTRhMSAxIDAgMDAtMSAxdjNNNCA3aDE2XCI+PC9wYXRoPjwvc3ZnPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICAgIDx0ciB2LWlmPVwiIXByb2R1Y3RzLmRhdGEubGVuZ3RoXCI+XG4gICAgICAgICAgPHRkIGNvbHNwYW49XCI2XCIgY2xhc3M9XCJweC04IHB5LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDBcIj5CZWx1bSBhZGEgZGF0YSBwcm9kdWsuPC90ZD5cbiAgICAgICAgPC90cj5cbiAgICAgIDwvdGJvZHk+XG4gICAgPC90YWJsZT5cbiAgICBcbiAgICA8IS0tIFBhZ2luYXRpb24gLS0+XG4gICAgPGRpdiBjbGFzcz1cInB4LTggcHktNSBiZy13aGl0ZSBib3JkZXItdCBib3JkZXItZW1lcmFsZC01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIiB2LWlmPVwicHJvZHVjdHMuZGF0YS5sZW5ndGggPiAwXCI+XG4gICAgICA8cCBjbGFzcz1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk1lbmFtcGlsa2FuIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj57eyBwcm9kdWN0cy5mcm9tIH19PC9zcGFuPiAtIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj57eyBwcm9kdWN0cy50byB9fTwvc3Bhbj4gZGFyaSA8c3BhbiBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+e3sgcHJvZHVjdHMudG90YWwgfX08L3NwYW4+IHByb2R1azwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0xXCI+XG4gICAgICAgIDx0ZW1wbGF0ZSB2LWZvcj1cIihsaW5rLCBrKSBpbiBwcm9kdWN0cy5saW5rc1wiIDprZXk9XCJrXCI+XG4gICAgICAgICAgPGRpdiB2LWlmPVwiIWxpbmsudXJsXCIgdi1odG1sPVwibGluay5sYWJlbC5yZXBsYWNlKCcmbGFxdW87IFByZXZpb3VzJywgJyZsYXF1bzsnKS5yZXBsYWNlKCdOZXh0ICZyYXF1bzsnLCAnJnJhcXVvOycpXCIgY2xhc3M9XCJtaW4tdy1bMi41cmVtXSBweC0zIGgtMTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnMgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwIHRleHQtZ3JheS00MDAgb3BhY2l0eS01MCBjdXJzb3Itbm90LWFsbG93ZWRcIj48L2Rpdj5cbiAgICAgICAgICA8TGluayB2LWVsc2UgOmhyZWY9XCJsaW5rLnVybFwiIHYtaHRtbD1cImxpbmsubGFiZWwucmVwbGFjZSgnJmxhcXVvOyBQcmV2aW91cycsICcmbGFxdW87JykucmVwbGFjZSgnTmV4dCAmcmFxdW87JywgJyZyYXF1bzsnKVwiIDpjbGFzcz1cIlsnbWluLXctWzIuNXJlbV0gcHgtMyBoLTEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzJywgbGluay5hY3RpdmUgPyAnYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQnIDogJ2JnLXdoaXRlIGJvcmRlciBib3JkZXItZW1lcmFsZC01MCB0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgaG92ZXI6YmctZ3JheS01MCddXCIgLz5cbiAgICAgICAgPC90ZW1wbGF0ZT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG4iXSwibWFwcGluZ3MiOiJBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7QUFJdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BR1o7O0FBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUM7Ozs7Ozs7Ozs7cUJBSU0sS0FBSyxFQUFDLHNFQUFzRTtxQkFXNUUsS0FBSyxFQUFDLHNDQUFzQztxQkFDMUMsS0FBSyxFQUFDLGVBQWU7cUJBTXJCLEtBQUssRUFBQyxZQUFZO3FCQVVwQixLQUFLLEVBQUMseUVBQXlFO3FCQUMzRSxLQUFLLEVBQUMsdUNBQXVDO3FCQVczQyxLQUFLLEVBQUMscUNBQXFDO3FCQUUxQyxLQUFLLEVBQUMsNkJBQTZCO3FCQUNoQyxLQUFLLEVBQUMsa0RBQWtEOztzQkFJM0QsS0FBSyxFQUFDLFdBQVc7c0JBQ2QsS0FBSyxFQUFDLGlDQUFpQztzQkFFMUMsS0FBSyxFQUFDLDZCQUE2QjtzQkFNbkMsS0FBSyxFQUFDLCtEQUErRDtzQkFXckUsS0FBSyxFQUFDLDREQUE0RDtzQkFDL0QsS0FBSyxFQUFDLHdCQUF3Qjs7Ozs7RUFpQnRDLEtBQUssRUFBQyxpRkFBaUY7O3NCQUN2RixLQUFLLEVBQUMsdUJBQXVCO3NCQUFtQixLQUFLLEVBQUMseUJBQXlCO3NCQUFvQyxLQUFLLEVBQUMseUJBQXlCO3NCQUFxQyxLQUFLLEVBQUMseUJBQXlCO3NCQUNwTixLQUFLLEVBQUMsWUFBWTs7Ozs7SUF2RjNCLG9CQVNNLE9BVE4sVUFTTTtnQ0FSSixvQkFHTTtRQUZKLG9CQUE4RSxRQUExRSxLQUFLLEVBQUMsaURBQWlELElBQUMsZUFBYTtRQUN6RSxvQkFBcUYsT0FBbEYsS0FBSyxFQUFDLG9CQUFvQixJQUFDLHFEQUFtRDs7TUFFbkYsYUFHTztRQUhELElBQUksRUFBQyx3QkFBd0I7UUFBQyxLQUFLLEVBQUMsME1BQTBNOzswQkFDbFAsQ0FBaUw7VUFBakwsb0JBQWlMO1lBQTVLLEtBQUssRUFBQyxTQUFTO1lBQUMsSUFBSSxFQUFDLE1BQU07WUFBQyxNQUFNLEVBQUMsY0FBYztZQUFDLE9BQU8sRUFBQyxXQUFXOztZQUFDLG9CQUFnRztjQUExRixnQkFBYyxFQUFDLE9BQU87Y0FBQyxpQkFBZSxFQUFDLE9BQU87Y0FBQyxjQUFZLEVBQUMsR0FBRztjQUFDLENBQUMsRUFBQyxnQkFBZ0I7OzsyQkFBYyxzQkFFbkw7Ozs7O0lBR0Ysb0JBZU0sT0FmTixVQWVNO01BZEosb0JBS00sT0FMTixVQUtNO3dCQUpKLG9CQUF5UDt1RUFBek8sYUFBTTtVQUFFLElBQUksRUFBQyxNQUFNO1VBQUMsV0FBVyxFQUFDLHFCQUFxQjtVQUFDLEtBQUssRUFBQywwS0FBMEs7O3dCQUF0TyxhQUFNOztrQ0FDdEIsb0JBRU0sU0FGRCxLQUFLLEVBQUMscUZBQXFGO1VBQzlGLG9CQUE4TTtZQUF6TSxLQUFLLEVBQUMsU0FBUztZQUFDLElBQUksRUFBQyxNQUFNO1lBQUMsTUFBTSxFQUFDLGNBQWM7WUFBQyxPQUFPLEVBQUMsV0FBVzs7WUFBQyxvQkFBNkg7Y0FBdkgsZ0JBQWMsRUFBQyxPQUFPO2NBQUMsaUJBQWUsRUFBQyxPQUFPO2NBQUMsY0FBWSxFQUFDLEdBQUc7Y0FBQyxDQUFDLEVBQUMsNkNBQTZDOzs7OztNQUdwTSxvQkFPTSxPQVBOLFVBT007a0NBTkosb0JBRU0sU0FGRCxLQUFLLEVBQUMsb0hBQW9IO1VBQzdILG9CQUEwVDtZQUFyVCxLQUFLLEVBQUMsU0FBUztZQUFDLElBQUksRUFBQyxNQUFNO1lBQUMsTUFBTSxFQUFDLGNBQWM7WUFBQyxPQUFPLEVBQUMsV0FBVzs7WUFBQyxvQkFBeU87Y0FBbk8sZ0JBQWMsRUFBQyxPQUFPO2NBQUMsaUJBQWUsRUFBQyxPQUFPO2NBQUMsY0FBWSxFQUFDLEdBQUc7Y0FBQyxDQUFDLEVBQUMseUpBQXlKOzs7O1FBRTlTLG9CQUF3UTtVQUEvUCxPQUFLLHVDQUFFLGtCQUFXO1VBQVksS0FBSyw4RkFBOEUsZUFBUTtXQUF3SCxPQUFLO1FBQy9QLG9CQUFnUztVQUF2UixPQUFLLHVDQUFFLGtCQUFXO1VBQW9CLEtBQUssOEZBQThFLGVBQVE7V0FBZ0ksZUFBYTtRQUN2UixvQkFBcVQ7VUFBNVMsT0FBSyx1Q0FBRSxrQkFBVztVQUEyQixLQUFLLDhGQUE4RSxlQUFRO1dBQXVJLHNCQUFvQjs7O0lBSWhULG9CQWtFTSxPQWxFTixVQWtFTTtNQWpFSixvQkFxRFEsU0FyRFIsVUFxRFE7b0NBcEROLG9CQVNRLFdBVEQsS0FBSyxFQUFDLGVBQWU7VUFDMUIsb0JBT0s7WUFOSCxvQkFBOEc7Y0FBMUcsS0FBSyxFQUFDLEtBQUs7Y0FBQyxLQUFLLEVBQUMsOEVBQThFO2VBQUMsTUFBSTtZQUN6RyxvQkFBcUg7Y0FBakgsS0FBSyxFQUFDLEtBQUs7Y0FBQyxLQUFLLEVBQUMsOEVBQThFO2VBQUMsYUFBVztZQUNoSCxvQkFBa0g7Y0FBOUcsS0FBSyxFQUFDLEtBQUs7Y0FBQyxLQUFLLEVBQUMsOEVBQThFO2VBQUMsVUFBUTtZQUM3RyxvQkFBK0c7Y0FBM0csS0FBSyxFQUFDLEtBQUs7Y0FBQyxLQUFLLEVBQUMsOEVBQThFO2VBQUMsT0FBSztZQUMxRyxvQkFBZ0g7Y0FBNUcsS0FBSyxFQUFDLEtBQUs7Y0FBQyxLQUFLLEVBQUMsOEVBQThFO2VBQUMsUUFBTTtZQUMzRyxvQkFBK0c7Y0FBM0csS0FBSyxFQUFDLEtBQUs7Y0FBQyxLQUFLLEVBQUMsK0VBQStFO2VBQUMsTUFBSTs7O1FBRzlHLG9CQXlDUSxTQXpDUixVQXlDUTs2QkF4Q04sb0JBb0NLLDZCQXBDaUIsZUFBUSxDQUFDLElBQUksR0FBeEIsT0FBTztrQ0FBbEIsb0JBb0NLO2NBcENpQyxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUU7Y0FBRSxLQUFLLEVBQUMsdUNBQXVDOztjQUNsRyxvQkFJSyxNQUpMLFVBSUs7Z0JBSEgsb0JBRU0sT0FGTixVQUVNO2tCQURKLG9CQUF1TjtvQkFBak4sR0FBRyxFQUFFLE9BQU8sQ0FBQyxVQUFVLGlCQUFpQixPQUFPLENBQUMsVUFBVTtvQkFBa0gsS0FBSyxFQUFDLDRCQUE0Qjs7OztjQUd4TixvQkFFSyxNQUZMLFdBRUs7Z0JBREgsb0JBQXFFLE9BQXJFLFdBQXFFLG1CQUFyQixPQUFPLENBQUMsSUFBSTs7Y0FFOUQsb0JBS0ssTUFMTCxXQUtLO2dCQUpILG9CQUdnQztrQkFIekIsS0FBSzs7Y0FBc0csT0FBTyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsUUFBUTs7b0NBR25KLE9BQU8sQ0FBQyxRQUFROztjQUV4QixvQkFFSyxNQUZMLFdBRUssRUFGcUUsTUFDckUsb0JBQUcsT0FBTyxDQUFDLEtBQUs7MENBRXJCLG9CQU9LLFFBUEQsS0FBSyxFQUFDLDZCQUE2QjtnQkFDckMsb0JBS00sU0FMRCxLQUFLLEVBQUMseUJBQXlCO2tCQUNsQyxvQkFFTSxTQUZELEtBQUssRUFBQywyRUFBMkU7b0JBQ3BGLG9CQUFrRixTQUE3RSxLQUFLLEVBQUMsZ0VBQWdFOztrQkFFN0Usb0JBQWdFLFVBQTFELEtBQUssRUFBQyxzQ0FBc0MsSUFBQyxRQUFNOzs7Y0FHN0Qsb0JBU0ssTUFUTCxXQVNLO2dCQVJILG9CQU9NLE9BUE4sV0FPTTtrQkFOSixhQUVPO29CQUZBLElBQUkscUJBQXFCLE9BQU8sQ0FBQyxFQUFFO29CQUFTLEtBQUssRUFBQyxtTEFBbUw7O3NDQUMxTyxDQUFtUTtzQkFBblEsb0JBQW1RO3dCQUE5UCxLQUFLLEVBQUMsU0FBUzt3QkFBQyxJQUFJLEVBQUMsTUFBTTt3QkFBQyxNQUFNLEVBQUMsY0FBYzt3QkFBQyxPQUFPLEVBQUMsV0FBVzs7d0JBQUMsb0JBQWtMOzBCQUE1SyxnQkFBYyxFQUFDLE9BQU87MEJBQUMsaUJBQWUsRUFBQyxPQUFPOzBCQUFDLGNBQVksRUFBQyxHQUFHOzBCQUFDLENBQUMsRUFBQyxrR0FBa0c7Ozs7OztrQkFFdlAsb0JBRVM7b0JBRkEsT0FBSyxhQUFFLGFBQU0sQ0FBQyxNQUFNLG9CQUFvQixPQUFPLENBQUMsRUFBRTtvQkFBSyxLQUFLLEVBQUMsbUpBQW1KOztvQkFDdk4sb0JBQStSO3NCQUExUixLQUFLLEVBQUMsU0FBUztzQkFBQyxJQUFJLEVBQUMsTUFBTTtzQkFBQyxNQUFNLEVBQUMsY0FBYztzQkFBQyxPQUFPLEVBQUMsV0FBVzs7c0JBQUMsb0JBQThNO3dCQUF4TSxnQkFBYyxFQUFDLE9BQU87d0JBQUMsaUJBQWUsRUFBQyxPQUFPO3dCQUFDLGNBQVksRUFBQyxHQUFHO3dCQUFDLENBQUMsRUFBQyw4SEFBOEg7Ozs7Ozs7O1lBSzlRLGVBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTTs2QkFBL0Isb0JBRUs7Z0JBREgsb0JBQXdGO2tCQUFwRixPQUFPLEVBQUMsR0FBRztrQkFBQyxLQUFLLEVBQUMsc0NBQXNDO21CQUFDLHdCQUFzQjs7Ozs7TUFLekYsbUNBQW1CO09BQ2dGLGVBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTTt5QkFBdkgsb0JBUU0sT0FSTixXQVFNO1lBUEosb0JBQWdRLEtBQWhRLFdBQWdROzJEQUEvTixjQUFZO2NBQUEsb0JBQWdFLFFBQWhFLFdBQWdFLG1CQUF2QixlQUFRLENBQUMsSUFBSTsyREFBVSxLQUFHO2NBQUEsb0JBQThELFFBQTlELFdBQThELG1CQUFyQixlQUFRLENBQUMsRUFBRTsyREFBVSxRQUFNO2NBQUEsb0JBQWlFLFFBQWpFLFdBQWlFLG1CQUF4QixlQUFRLENBQUMsS0FBSzsyREFBVSxTQUFPOztZQUM1UCxvQkFLTSxPQUxOLFdBS007aUNBSkosb0JBR1csNkJBSG1CLGVBQVEsQ0FBQyxLQUFLLEdBQTFCLElBQUksRUFBRSxDQUFDOzRFQUEyQixDQUFDO29CQUN2QyxJQUFJLENBQUMsR0FBRztxQ0FBcEIsb0JBQTZUOzt3QkFBdlMsU0FBNkYsRUFBckYsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLG9CQUFvQixPQUFPO3dCQUF5QyxLQUFLLEVBQUMsNExBQTRMOztxQ0FDdFQsYUFBeVk7O3dCQUEzWCxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUc7d0JBQUUsU0FBNkYsRUFBckYsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLG9CQUFvQixPQUFPO3dCQUEwQyxLQUFLLG1JQUFtSCxJQUFJLENBQUMsTUFBTSIsImlnbm9yZUxpc3QiOltdfQ==