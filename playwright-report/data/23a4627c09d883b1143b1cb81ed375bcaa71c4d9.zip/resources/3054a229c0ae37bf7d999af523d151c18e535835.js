import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Articles/Edit.vue");import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import { Link, useForm, router } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import { ref } from "/node_modules/.vite/deps/vue.js?v=cebe2491";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Edit',
  props: {
    article: Object,
},
  setup(__props, { expose: __expose }) {
  __expose();



const props = __props;

const form = useForm({
    title: props.article.title || '',
    excerpt: props.article.excerpt || '',
    content: props.article.content || '',
    tag: props.article.tag || 'Edukasi',
    image: null,
    _method: 'PUT',
});

const imagePreview = ref(props.article.image_path ? '/storage/' + props.article.image_path : null);

const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
        form.image = file;
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.value = e.target.result;
        };
        reader.readAsDataURL(file);
    }
};

const submit = () => {
    form.post(`/admin/articles/${props.article.id}`, {
        preserveScroll: true,
    });
};

const __returned__ = { props, form, imagePreview, handleImageUpload, submit, AdminLayout, get Link() { return Link }, get useForm() { return useForm }, get router() { return router }, ref }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, createCommentVNode as _createCommentVNode, vModelText as _vModelText, withDirectives as _withDirectives, toDisplayString as _toDisplayString, withModifiers as _withModifiers, createStaticVNode as _createStaticVNode, Fragment as _Fragment } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4" }
const _hoisted_2 = { class: "bg-white rounded-3xl shadow-sm border border-emerald-50 overflow-hidden max-w-4xl" }
const _hoisted_3 = { class: "grid grid-cols-1 gap-6" }
const _hoisted_4 = { class: "space-y-2" }
const _hoisted_5 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_6 = { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }
const _hoisted_7 = { class: "space-y-2" }
const _hoisted_8 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_9 = { class: "space-y-2" }
const _hoisted_10 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_11 = { class: "space-y-2" }
const _hoisted_12 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_13 = { class: "space-y-2" }
const _hoisted_14 = { class: "mt-2 flex justify-center rounded-xl border border-dashed border-gray-300 px-6 py-10 bg-gray-50 hover:bg-emerald-50 hover:border-emerald-300 transition-all cursor-pointer relative overflow-hidden group" }
const _hoisted_15 = {
  key: 0,
  class: "text-center"
}
const _hoisted_16 = {
  key: 1,
  class: "relative w-full max-w-sm h-48 rounded-lg overflow-hidden border border-gray-200"
}
const _hoisted_17 = ["src"]
const _hoisted_18 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_19 = { class: "pt-6 border-t border-gray-100 flex justify-end gap-3" }
const _hoisted_20 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("div", _hoisted_1, [
      _createElementVNode("div", null, [
        _createVNode($setup["Link"], {
          href: "/admin/articles",
          class: "text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-2 mb-4"
        }, {
          default: _withCtx(() => [...(_cache[5] || (_cache[5] = [
            _createElementVNode("svg", {
              class: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24"
            }, [
              _createElementVNode("path", {
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M10 19l-7-7m0 0l7-7m-7 7h18"
              })
            ], -1 /* CACHED */),
            _createTextVNode(" Kembali ke Kelola Artikel ", -1 /* CACHED */)
          ]))]),
          _: 1 /* STABLE */
        }),
        _cache[6] || (_cache[6] = _createElementVNode("h2", { class: "text-3xl font-bold text-gray-900 tracking-tight" }, "Edit Artikel", -1 /* CACHED */)),
        _cache[7] || (_cache[7] = _createElementVNode("p", { class: "text-gray-500 mt-2" }, "Ubah informasi untuk artikel edukasi.", -1 /* CACHED */))
      ]),
      _createElementVNode("button", {
        onClick: _cache[0] || (_cache[0] = $event => ($setup.router.delete(`/admin/articles/${$props.article.id}`))),
        class: "inline-flex items-center justify-center px-6 py-3 border border-red-100 text-sm font-medium rounded-xl text-red-600 bg-red-50 hover:bg-red-100 shadow-sm transition-all gap-2"
      }, [...(_cache[8] || (_cache[8] = [
        _createElementVNode("svg", {
          class: "w-5 h-5",
          fill: "none",
          stroke: "currentColor",
          viewBox: "0 0 24 24"
        }, [
          _createElementVNode("path", {
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
            "stroke-width": "2",
            d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
          })
        ], -1 /* CACHED */),
        _createTextVNode(" Hapus Artikel ", -1 /* CACHED */)
      ]))])
    ]),
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("form", {
        onSubmit: _withModifiers($setup.submit, ["prevent"]),
        class: "p-8 space-y-6"
      }, [
        _createElementVNode("div", _hoisted_3, [
          _createCommentVNode(" Judul Artikel "),
          _createElementVNode("div", _hoisted_4, [
            _cache[9] || (_cache[9] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Judul Artikel", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.title) = $event)),
              type: "text",
              placeholder: "Masukkan judul artikel...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.title]
            ]),
            ($setup.form.errors.title)
              ? (_openBlock(), _createElementBlock("p", _hoisted_5, _toDisplayString($setup.form.errors.title), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createElementVNode("div", _hoisted_6, [
            _createCommentVNode(" Tag / Kategori "),
            _createElementVNode("div", _hoisted_7, [
              _cache[10] || (_cache[10] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Tag / Kategori", -1 /* CACHED */)),
              _withDirectives(_createElementVNode("input", {
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.tag) = $event)),
                type: "text",
                placeholder: "Misal: Edukasi, Tips, Panduan",
                class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
                required: ""
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.form.tag]
              ]),
              ($setup.form.errors.tag)
                ? (_openBlock(), _createElementBlock("p", _hoisted_8, _toDisplayString($setup.form.errors.tag), 1 /* TEXT */))
                : _createCommentVNode("v-if", true)
            ])
          ]),
          _createCommentVNode(" Excerpt "),
          _createElementVNode("div", _hoisted_9, [
            _cache[11] || (_cache[11] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Ringkasan (Excerpt)", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.excerpt) = $event)),
              rows: "2",
              placeholder: "Tuliskan ringkasan singkat artikel...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.excerpt]
            ]),
            ($setup.form.errors.excerpt)
              ? (_openBlock(), _createElementBlock("p", _hoisted_10, _toDisplayString($setup.form.errors.excerpt), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Content "),
          _createElementVNode("div", _hoisted_11, [
            _cache[12] || (_cache[12] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Isi Artikel", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.form.content) = $event)),
              rows: "10",
              placeholder: "Tuliskan isi artikel edukasi di sini...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.content]
            ]),
            ($setup.form.errors.content)
              ? (_openBlock(), _createElementBlock("p", _hoisted_12, _toDisplayString($setup.form.errors.content), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Foto "),
          _createElementVNode("div", _hoisted_13, [
            _cache[15] || (_cache[15] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Gambar Cover (Biarkan kosong jika tidak ingin mengubah)", -1 /* CACHED */)),
            _createElementVNode("div", _hoisted_14, [
              _createElementVNode("input", {
                type: "file",
                onChange: $setup.handleImageUpload,
                class: "absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10",
                accept: "image/*"
              }, null, 32 /* NEED_HYDRATION */),
              (!$setup.imagePreview)
                ? (_openBlock(), _createElementBlock("div", _hoisted_15, [...(_cache[13] || (_cache[13] = [
                    _createStaticVNode("<svg class=\"mx-auto h-12 w-12 text-gray-300 group-hover:text-emerald-500 transition-colors\" viewBox=\"0 0 24 24\" fill=\"currentColor\" aria-hidden=\"true\"><path fill-rule=\"evenodd\" d=\"M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z\" clip-rule=\"evenodd\"></path></svg><div class=\"mt-4 flex text-sm leading-6 text-gray-600 justify-center\"><span class=\"relative rounded-md font-semibold text-emerald-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-emerald-600 focus-within:ring-offset-2 hover:text-emerald-500\"><span>Upload a file</span></span><p class=\"pl-1\">or drag and drop</p></div><p class=\"text-xs leading-5 text-gray-500\">PNG, JPG, GIF up to 2MB</p>", 3)
                  ]))]))
                : (_openBlock(), _createElementBlock("div", _hoisted_16, [
                    _createElementVNode("img", {
                      src: $setup.imagePreview,
                      class: "w-full h-full object-cover"
                    }, null, 8 /* PROPS */, _hoisted_17),
                    _cache[14] || (_cache[14] = _createElementVNode("div", { class: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center" }, [
                      _createElementVNode("p", { class: "text-white text-sm font-bold" }, "Ganti Foto")
                    ], -1 /* CACHED */))
                  ]))
            ]),
            ($setup.form.errors.image)
              ? (_openBlock(), _createElementBlock("p", _hoisted_18, _toDisplayString($setup.form.errors.image), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ])
        ]),
        _createCommentVNode(" Submit Button "),
        _createElementVNode("div", _hoisted_19, [
          _createVNode($setup["Link"], {
            href: "/admin/articles",
            class: "px-6 py-3 border border-gray-200 text-gray-600 font-medium rounded-xl hover:bg-gray-50 transition-colors"
          }, {
            default: _withCtx(() => [...(_cache[16] || (_cache[16] = [
              _createTextVNode("Batal", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }),
          _createElementVNode("button", {
            type: "submit",
            disabled: $setup.form.processing,
            class: "px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all disabled:opacity-50"
          }, " Simpan Perubahan ", 8 /* PROPS */, _hoisted_20)
        ])
      ], 32 /* NEED_HYDRATION */)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "3823e5e3"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Articles/Edit.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRWRpdC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbmltcG9ydCBBZG1pbkxheW91dCBmcm9tICdAL0xheW91dHMvQWRtaW5MYXlvdXQudnVlJztcbmltcG9ydCB7IExpbmssIHVzZUZvcm0sIHJvdXRlciB9IGZyb20gJ0BpbmVydGlhanMvdnVlMyc7XG5pbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnO1xuXG5kZWZpbmVPcHRpb25zKHsgbGF5b3V0OiBBZG1pbkxheW91dCB9KTtcblxuY29uc3QgcHJvcHMgPSBkZWZpbmVQcm9wcyh7XG4gICAgYXJ0aWNsZTogT2JqZWN0LFxufSk7XG5cbmNvbnN0IGZvcm0gPSB1c2VGb3JtKHtcbiAgICB0aXRsZTogcHJvcHMuYXJ0aWNsZS50aXRsZSB8fCAnJyxcbiAgICBleGNlcnB0OiBwcm9wcy5hcnRpY2xlLmV4Y2VycHQgfHwgJycsXG4gICAgY29udGVudDogcHJvcHMuYXJ0aWNsZS5jb250ZW50IHx8ICcnLFxuICAgIHRhZzogcHJvcHMuYXJ0aWNsZS50YWcgfHwgJ0VkdWthc2knLFxuICAgIGltYWdlOiBudWxsLFxuICAgIF9tZXRob2Q6ICdQVVQnLFxufSk7XG5cbmNvbnN0IGltYWdlUHJldmlldyA9IHJlZihwcm9wcy5hcnRpY2xlLmltYWdlX3BhdGggPyAnL3N0b3JhZ2UvJyArIHByb3BzLmFydGljbGUuaW1hZ2VfcGF0aCA6IG51bGwpO1xuXG5jb25zdCBoYW5kbGVJbWFnZVVwbG9hZCA9IChlKSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xuICAgIGlmIChmaWxlKSB7XG4gICAgICAgIGZvcm0uaW1hZ2UgPSBmaWxlO1xuICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICByZWFkZXIub25sb2FkID0gKGUpID0+IHtcbiAgICAgICAgICAgIGltYWdlUHJldmlldy52YWx1ZSA9IGUudGFyZ2V0LnJlc3VsdDtcbiAgICAgICAgfTtcbiAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgfVxufTtcblxuY29uc3Qgc3VibWl0ID0gKCkgPT4ge1xuICAgIGZvcm0ucG9zdChgL2FkbWluL2FydGljbGVzLyR7cHJvcHMuYXJ0aWNsZS5pZH1gLCB7XG4gICAgICAgIHByZXNlcnZlU2Nyb2xsOiB0cnVlLFxuICAgIH0pO1xufTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJtYi04IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgIDxkaXY+XG4gICAgICA8TGluayBocmVmPVwiL2FkbWluL2FydGljbGVzXCIgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtZW1lcmFsZC02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XG4gICAgICAgIDxzdmcgY2xhc3M9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIGQ9XCJNMTAgMTlsLTctN20wIDBsNy03bS03IDdoMThcIj48L3BhdGg+PC9zdmc+XG4gICAgICAgIEtlbWJhbGkga2UgS2Vsb2xhIEFydGlrZWxcbiAgICAgIDwvTGluaz5cbiAgICAgIDxoMiBjbGFzcz1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIHRyYWNraW5nLXRpZ2h0XCI+RWRpdCBBcnRpa2VsPC9oMj5cbiAgICAgIDxwIGNsYXNzPVwidGV4dC1ncmF5LTUwMCBtdC0yXCI+VWJhaCBpbmZvcm1hc2kgdW50dWsgYXJ0aWtlbCBlZHVrYXNpLjwvcD5cbiAgICA8L2Rpdj5cbiAgICA8YnV0dG9uIEBjbGljaz1cInJvdXRlci5kZWxldGUoYC9hZG1pbi9hcnRpY2xlcy8ke2FydGljbGUuaWR9YClcIiBjbGFzcz1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweC02IHB5LTMgYm9yZGVyIGJvcmRlci1yZWQtMTAwIHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC14bCB0ZXh0LXJlZC02MDAgYmctcmVkLTUwIGhvdmVyOmJnLXJlZC0xMDAgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGdhcC0yXCI+XG4gICAgICA8c3ZnIGNsYXNzPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJcIiBkPVwiTTE5IDdsLS44NjcgMTIuMTQyQTIgMiAwIDAxMTYuMTM4IDIxSDcuODYyYTIgMiAwIDAxLTEuOTk1LTEuODU4TDUgN201IDR2Nm00LTZ2Nm0xLTEwVjRhMSAxIDAgMDAtMS0xaC00YTEgMSAwIDAwLTEgMXYzTTQgN2gxNlwiPjwvcGF0aD48L3N2Zz5cbiAgICAgIEhhcHVzIEFydGlrZWxcbiAgICA8L2J1dHRvbj5cbiAgPC9kaXY+XG5cbiAgPGRpdiBjbGFzcz1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAgb3ZlcmZsb3ctaGlkZGVuIG1heC13LTR4bFwiPlxuICAgIDxmb3JtIEBzdWJtaXQucHJldmVudD1cInN1Ym1pdFwiIGNsYXNzPVwicC04IHNwYWNlLXktNlwiPlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNlwiPlxuICAgICAgICA8IS0tIEp1ZHVsIEFydGlrZWwgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+SnVkdWwgQXJ0aWtlbDwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJmb3JtLnRpdGxlXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk1hc3Vra2FuIGp1ZHVsIGFydGlrZWwuLi5cIiBjbGFzcz1cInctZnVsbCBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMudGl0bGVcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMudGl0bGUgfX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAgPCEtLSBUYWcgLyBLYXRlZ29yaSAtLT5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+VGFnIC8gS2F0ZWdvcmk8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJmb3JtLnRhZ1wiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJNaXNhbDogRWR1a2FzaSwgVGlwcywgUGFuZHVhblwiIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIiByZXF1aXJlZCAvPlxuICAgICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLnRhZ1wiIGNsYXNzPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57eyBmb3JtLmVycm9ycy50YWcgfX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0gRXhjZXJwdCAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5SaW5na2FzYW4gKEV4Y2VycHQpPC9sYWJlbD5cbiAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImZvcm0uZXhjZXJwdFwiIHJvd3M9XCIyXCIgcGxhY2Vob2xkZXI9XCJUdWxpc2thbiByaW5na2FzYW4gc2luZ2thdCBhcnRpa2VsLi4uXCIgY2xhc3M9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgdGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWFsbFwiPjwvdGV4dGFyZWE+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmV4Y2VycHRcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuZXhjZXJwdCB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBDb250ZW50IC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPklzaSBBcnRpa2VsPC9sYWJlbD5cbiAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImZvcm0uY29udGVudFwiIHJvd3M9XCIxMFwiIHBsYWNlaG9sZGVyPVwiVHVsaXNrYW4gaXNpIGFydGlrZWwgZWR1a2FzaSBkaSBzaW5pLi4uXCIgY2xhc3M9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgdGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWFsbFwiIHJlcXVpcmVkPjwvdGV4dGFyZWE+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmNvbnRlbnRcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuY29udGVudCB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBGb3RvIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPkdhbWJhciBDb3ZlciAoQmlhcmthbiBrb3NvbmcgamlrYSB0aWRhayBpbmdpbiBtZW5ndWJhaCk8L2xhYmVsPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0yIGZsZXgganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDAgcHgtNiBweS0xMCBiZy1ncmF5LTUwIGhvdmVyOmJnLWVtZXJhbGQtNTAgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtMzAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBncm91cFwiPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgQGNoYW5nZT1cImhhbmRsZUltYWdlVXBsb2FkXCIgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIHctZnVsbCBoLWZ1bGwgb3BhY2l0eS0wIGN1cnNvci1wb2ludGVyIHotMTBcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiIHYtaWY9XCIhaW1hZ2VQcmV2aWV3XCI+XG4gICAgICAgICAgICAgIDxzdmcgY2xhc3M9XCJteC1hdXRvIGgtMTIgdy0xMiB0ZXh0LWdyYXktMzAwIGdyb3VwLWhvdmVyOnRleHQtZW1lcmFsZC01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICAgICAgICAgIDxwYXRoIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBkPVwiTTEuNSA2YTIuMjUgMi4yNSAwIDAxMi4yNS0yLjI1aDE2LjVBMi4yNSAyLjI1IDAgMDEyMi41IDZ2MTJhMi4yNSAyLjI1IDAgMDEtMi4yNSAyLjI1SDMuNzVBMi4yNSAyLjI1IDAgMDExLjUgMThWNnpNMyAxNi4wNlYxOGMwIC40MTQuMzM2Ljc1Ljc1Ljc1aDE2LjVBLjc1Ljc1IDAgMDAyMSAxOHYtMS45NGwtMi42OS0yLjY4OWExLjUgMS41IDAgMDAtMi4xMiAwbC0uODguODc5Ljk3Ljk3YS43NS43NSAwIDExLTEuMDYgMS4wNmwtNS4xNi01LjE1OWExLjUgMS41IDAgMDAtMi4xMiAwTDMgMTYuMDYxem0xMC4xMjUtNy44MWExLjEyNSAxLjEyNSAwIDExMi4yNSAwIDEuMTI1IDEuMTI1IDAgMDEtMi4yNSAwelwiIGNsaXAtcnVsZT1cImV2ZW5vZGRcIiAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTQgZmxleCB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LWdyYXktNjAwIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJyZWxhdGl2ZSByb3VuZGVkLW1kIGZvbnQtc2VtaWJvbGQgdGV4dC1lbWVyYWxkLTYwMCBmb2N1cy13aXRoaW46b3V0bGluZS1ub25lIGZvY3VzLXdpdGhpbjpyaW5nLTIgZm9jdXMtd2l0aGluOnJpbmctZW1lcmFsZC02MDAgZm9jdXMtd2l0aGluOnJpbmctb2Zmc2V0LTIgaG92ZXI6dGV4dC1lbWVyYWxkLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+VXBsb2FkIGEgZmlsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJwbC0xXCI+b3IgZHJhZyBhbmQgZHJvcDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyBsZWFkaW5nLTUgdGV4dC1ncmF5LTUwMFwiPlBORywgSlBHLCBHSUYgdXAgdG8gMk1CPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1zbSBoLTQ4IHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgPGltZyA6c3JjPVwiaW1hZ2VQcmV2aWV3XCIgY2xhc3M9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzUwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtd2hpdGUgdGV4dC1zbSBmb250LWJvbGRcIj5HYW50aSBGb3RvPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIHYtaWY9XCJmb3JtLmVycm9ycy5pbWFnZVwiIGNsYXNzPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57eyBmb3JtLmVycm9ycy5pbWFnZSB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPCEtLSBTdWJtaXQgQnV0dG9uIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cInB0LTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cbiAgICAgICAgPExpbmsgaHJlZj1cIi9hZG1pbi9hcnRpY2xlc1wiIGNsYXNzPVwicHgtNiBweS0zIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTYwMCBmb250LW1lZGl1bSByb3VuZGVkLXhsIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5CYXRhbDwvTGluaz5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgOmRpc2FibGVkPVwiZm9ybS5wcm9jZXNzaW5nXCIgY2xhc3M9XCJweC04IHB5LTMgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxuICAgICAgICAgIFNpbXBhbiBQZXJ1YmFoYW5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZm9ybT5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUFJekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BRVo7O0FBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDOztBQUVGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFbEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDOztBQUVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQzs7Ozs7Ozs7OztxQkFJTSxLQUFLLEVBQUMsc0VBQXNFO3FCQWU1RSxLQUFLLEVBQUMsbUZBQW1GO3FCQUdyRixLQUFLLEVBQUMsd0JBQXdCO3FCQUU1QixLQUFLLEVBQUMsV0FBVzs7O0VBR1EsS0FBSyxFQUFDLHNCQUFzQjs7cUJBR3JELEtBQUssRUFBQyx1Q0FBdUM7cUJBRTNDLEtBQUssRUFBQyxXQUFXOzs7RUFHTSxLQUFLLEVBQUMsc0JBQXNCOztxQkFLckQsS0FBSyxFQUFDLFdBQVc7OztFQUdVLEtBQUssRUFBQyxzQkFBc0I7O3NCQUl2RCxLQUFLLEVBQUMsV0FBVzs7O0VBR1UsS0FBSyxFQUFDLHNCQUFzQjs7c0JBSXZELEtBQUssRUFBQyxXQUFXO3NCQUVmLEtBQUssRUFBQywwTUFBME07OztFQUU5TSxLQUFLLEVBQUMsYUFBYTs7OztFQVlaLEtBQUssRUFBQyxpRkFBaUY7Ozs7O0VBT3pFLEtBQUssRUFBQyxzQkFBc0I7O3NCQUt2RCxLQUFLLEVBQUMsc0RBQXNEOzs7OztJQTlFckUsb0JBYU0sT0FiTixVQWFNO01BWkosb0JBT007UUFOSixhQUdPO1VBSEQsSUFBSSxFQUFDLGlCQUFpQjtVQUFDLEtBQUssRUFBQywwRkFBMEY7OzRCQUMzSCxDQUE4TDtZQUE5TCxvQkFBOEw7Y0FBekwsS0FBSyxFQUFDLFNBQVM7Y0FBQyxJQUFJLEVBQUMsTUFBTTtjQUFDLE1BQU0sRUFBQyxjQUFjO2NBQUMsT0FBTyxFQUFDLFdBQVc7O2NBQUMsb0JBQTZHO2dCQUF2RyxnQkFBYyxFQUFDLE9BQU87Z0JBQUMsaUJBQWUsRUFBQyxPQUFPO2dCQUFDLGNBQVksRUFBQyxHQUFHO2dCQUFDLENBQUMsRUFBQyw2QkFBNkI7Ozs2QkFBYyw2QkFFaE07Ozs7a0NBQ0Esb0JBQTZFLFFBQXpFLEtBQUssRUFBQyxpREFBaUQsSUFBQyxjQUFZO2tDQUN4RSxvQkFBdUUsT0FBcEUsS0FBSyxFQUFDLG9CQUFvQixJQUFDLHVDQUFxQzs7TUFFckUsb0JBR1M7UUFIQSxPQUFLLHVDQUFFLGFBQU0sQ0FBQyxNQUFNLG9CQUFvQixjQUFPLENBQUMsRUFBRTtRQUFLLEtBQUssRUFBQywrS0FBK0s7O1FBQ25QLG9CQUErUjtVQUExUixLQUFLLEVBQUMsU0FBUztVQUFDLElBQUksRUFBQyxNQUFNO1VBQUMsTUFBTSxFQUFDLGNBQWM7VUFBQyxPQUFPLEVBQUMsV0FBVzs7VUFBQyxvQkFBOE07WUFBeE0sZ0JBQWMsRUFBQyxPQUFPO1lBQUMsaUJBQWUsRUFBQyxPQUFPO1lBQUMsY0FBWSxFQUFDLEdBQUc7WUFBQyxDQUFDLEVBQUMsOEhBQThIOzs7eUJBQWMsaUJBRWpTOzs7SUFHRixvQkF1RU0sT0F2RU4sVUF1RU07TUF0RUosb0JBcUVPO1FBckVBLFFBQU0saUJBQVUsYUFBTTtRQUFFLEtBQUssRUFBQyxlQUFlOztRQUVsRCxvQkF5RE0sT0F6RE4sVUF5RE07VUF4REosc0NBQXNCO1VBQ3RCLG9CQUlNLE9BSk4sVUFJTTtzQ0FISixvQkFBMEUsV0FBbkUsS0FBSyxFQUFDLHVDQUF1QyxJQUFDLGVBQWE7NEJBQ2xFLG9CQUF3UTsyRUFBeFAsV0FBSSxDQUFDLEtBQUs7Y0FBRSxJQUFJLEVBQUMsTUFBTTtjQUFDLFdBQVcsRUFBQywyQkFBMkI7Y0FBQyxLQUFLLEVBQUMsc0tBQXNLO2NBQUMsUUFBUSxFQUFSLEVBQVE7OzRCQUFyUCxXQUFJLENBQUMsS0FBSzs7YUFDakIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOytCQUExQixvQkFBb0YsS0FBcEYsVUFBb0YsbUJBQXhCLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzs7O1VBRy9FLG9CQU9NLE9BUE4sVUFPTTtZQU5KLHVDQUF1QjtZQUN2QixvQkFJTSxPQUpOLFVBSU07MENBSEosb0JBQTJFLFdBQXBFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxnQkFBYzs4QkFDbkUsb0JBQTBROzZFQUExUCxXQUFJLENBQUMsR0FBRztnQkFBRSxJQUFJLEVBQUMsTUFBTTtnQkFBQyxXQUFXLEVBQUMsK0JBQStCO2dCQUFDLEtBQUssRUFBQyxzS0FBc0s7Z0JBQUMsUUFBUSxFQUFSLEVBQVE7OzhCQUF2UCxXQUFJLENBQUMsR0FBRzs7ZUFDZixXQUFJLENBQUMsTUFBTSxDQUFDLEdBQUc7aUNBQXhCLG9CQUFnRixLQUFoRixVQUFnRixtQkFBdEIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHOzs7O1VBSTdFLGdDQUFnQjtVQUNoQixvQkFJTSxPQUpOLFVBSU07d0NBSEosb0JBQWdGLFdBQXpFLEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxxQkFBbUI7NEJBQ3hFLG9CQUFzUjsyRUFBblEsV0FBSSxDQUFDLE9BQU87Y0FBRSxJQUFJLEVBQUMsR0FBRztjQUFDLFdBQVcsRUFBQyx1Q0FBdUM7Y0FBQyxLQUFLLEVBQUMsc0tBQXNLOzs0QkFBdlAsV0FBSSxDQUFDLE9BQU87O2FBQ3RCLFdBQUksQ0FBQyxNQUFNLENBQUMsT0FBTzsrQkFBNUIsb0JBQXdGLEtBQXhGLFdBQXdGLG1CQUExQixXQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87OztVQUduRixnQ0FBZ0I7VUFDaEIsb0JBSU0sT0FKTixXQUlNO3dDQUhKLG9CQUF3RSxXQUFqRSxLQUFLLEVBQUMsdUNBQXVDLElBQUMsYUFBVzs0QkFDaEUsb0JBQWtTOzJFQUEvUSxXQUFJLENBQUMsT0FBTztjQUFFLElBQUksRUFBQyxJQUFJO2NBQUMsV0FBVyxFQUFDLHlDQUF5QztjQUFDLEtBQUssRUFBQyxzS0FBc0s7Y0FBQyxRQUFRLEVBQVIsRUFBUTs7NEJBQW5RLFdBQUksQ0FBQyxPQUFPOzthQUN0QixXQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87K0JBQTVCLG9CQUF3RixLQUF4RixXQUF3RixtQkFBMUIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPOzs7VUFHbkYsNkJBQWE7VUFDYixvQkF3Qk0sT0F4Qk4sV0F3Qk07d0NBdkJKLG9CQUFvSCxXQUE3RyxLQUFLLEVBQUMsdUNBQXVDLElBQUMseURBQXVEO1lBQzVHLG9CQW9CTSxPQXBCTixXQW9CTTtjQW5CSixvQkFBdUk7Z0JBQWhJLElBQUksRUFBQyxNQUFNO2dCQUFFLFFBQU0sRUFBRSx3QkFBaUI7Z0JBQUUsS0FBSyxFQUFDLDhEQUE4RDtnQkFBQyxNQUFNLEVBQUMsU0FBUzs7Z0JBQ3BHLG1CQUFZO2lDQUE1QyxvQkFXTSxPQVhOLFdBV007OztpQ0FDTixvQkFLTSxPQUxOLFdBS007b0JBSkosb0JBQThEO3NCQUF4RCxHQUFHLEVBQUUsbUJBQVk7c0JBQUUsS0FBSyxFQUFDLDRCQUE0Qjs7Z0RBQzNELG9CQUVNLFNBRkQsS0FBSyxFQUFDLG9IQUFvSDtzQkFDN0gsb0JBQXNELE9BQW5ELEtBQUssRUFBQyw4QkFBOEIsSUFBQyxZQUFVOzs7O2FBSS9DLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzsrQkFBMUIsb0JBQW9GLEtBQXBGLFdBQW9GLG1CQUF4QixXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7Ozs7UUFJakYsc0NBQXNCO1FBQ3RCLG9CQUtNLE9BTE4sV0FLTTtVQUpKLGFBQTBKO1lBQXBKLElBQUksRUFBQyxpQkFBaUI7WUFBQyxLQUFLLEVBQUMsMEdBQTBHOzs4QkFBQyxDQUFLOytCQUFMLE9BQUs7Ozs7VUFDbkosb0JBRVM7WUFGRCxJQUFJLEVBQUMsUUFBUTtZQUFFLFFBQVEsRUFBRSxXQUFJLENBQUMsVUFBVTtZQUFFLEtBQUssRUFBQyw0SEFBNEg7YUFBQyxvQkFFckwiLCJpZ25vcmVMaXN0IjpbXX0=