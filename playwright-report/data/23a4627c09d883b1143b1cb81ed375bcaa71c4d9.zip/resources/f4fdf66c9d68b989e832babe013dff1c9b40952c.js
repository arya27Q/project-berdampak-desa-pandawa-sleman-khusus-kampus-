import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Landing.vue");import { ref, computed } from "/node_modules/.vite/deps/vue.js?v=cebe2491";
import Icon from "/resources/js/Components/Icon.vue";
import { Head, Link, useForm } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";

import { usePage } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";

const _sfc_main = {
  __name: 'Landing',
  props: {
  products: {
    type: Array,
    default: () => []
  },
  articles: {
    type: Array,
    default: () => []
  }
},
  setup(__props, { expose: __expose }) {
  __expose();

const props = __props;

const page = usePage();
const WHATSAPP_NUMBER = computed(() => {
  let num = page.props.settings?.whatsapp || '0812-3456-7890';
  // convert 08... to 628... and strip non-digits
  num = num.replace(/\D/g,'');
  if (num.startsWith('0')) num = '62' + num.substring(1);
  return num;
});

const NAV_LINKS = [
  { label: 'Beranda', href: '#beranda' },
  { label: 'Profil', href: '#profil' },
  { label: 'Katalog', href: '#katalog' },
  { label: 'Artikel Edukasi', href: '#artikel' },
  { label: 'Kontak', href: '#kontak' },
];

const DEFAULT_ARTICLE_IMAGES = [
  'https://images.unsplash.com/photo-1592982537447-6f296d0ba967?w=700&h=480&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1586771107445-d3af9e173c52?w=700&h=480&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1530836369250-ef71a3f5e43d?w=700&h=480&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1585437812513-4338e932b1ba?w=700&h=480&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1620675506518-3df066bb2b30?w=700&h=480&fit=crop&auto=format'
];



const FILTERS = ['Semua', 'Pupuk Organik', 'Probiotik Peternakan', 'Terlaris', 'Populer'];

const STATS = [
  { value: '50+', label: 'Mitra Tani' },
  { value: '100%', label: 'Bahan Organik' },
  { value: '10+', label: 'Tahun Pengalaman' },
  { value: 'DIY & Jateng', label: 'Jangkauan Pengiriman' },
];

const STEPS = [
  {
    n: '01',
    title: 'Pilih Produk',
    desc: 'Telusuri katalog dan tentukan pupuk atau probiotik yang sesuai kebutuhan lahan Anda.',
    icon: 'basket',
  },
  {
    n: '02',
    title: 'Hubungi WhatsApp',
    desc: 'Klik tombol pesan, chat otomatis terisi. Tim kami siap membantu jumlah dan pengiriman.',
    icon: 'chat',
  },
  {
    n: '03',
    title: 'Konfirmasi & Kirim',
    desc: 'Konfirmasi pesanan dan alamat, produk dikirim ke seluruh DIY dan Jawa Tengah.',
    icon: 'truck',
  },
];



const TESTIMONIALS = [
  {
    quote: 'Sejak pakai pupuk organik Pandawa, struktur tanah sawah makin gembur. Hasil panen padi musim ini meningkat drastis dan biaya pupuk kimia jadi jauh lebih hemat.',
    name: 'Pak Marno',
    role: 'Ketua Kelompok Tani, Cangkringan',
    image: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=150&h=150&fit=crop&auto=format'
  },
  {
    quote: 'Probiotik ternak dari Pandawa benar-benar ampuh menghilangkan bau kandang kambing. Selain itu, ternak jadi lebih sehat dan makannya lahap banget.',
    name: 'Budi Santoso',
    role: 'Peternak Kambing Etawa, Sleman',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&auto=format'
  },
  {
    quote: 'Awalnya ragu beralih ke organik, tapi setelah didampingi langsung oleh tim Pandawa, sekarang kebun sayur saya 100% bebas kimia. Panen melimpah.',
    name: 'Ibu Ningsih',
    role: 'Petani Sayur, Kaliurang',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&h=150&fit=crop&auto=format'
  }
];

const FAQS = [
  {
    q: 'Apakah melayani pembelian eceran (B2C)?',
    a: 'Ya, kami melayani pembelian dalam jumlah kecil untuk konsumen umum maupun kebutuhan rumah tangga.'
  },
  {
    q: 'Bagaimana cara menjadi agen atau mitra Pandawa?',
    a: 'Anda dapat menghubungi kami via WhatsApp. Kami memiliki program kemitraan khusus dengan harga grosir untuk kelompok tani dan toko pertanian.'
  },
  {
    q: 'Apakah pupuk organik cair (POC) bisa dicampur pestisida kimia?',
    a: 'Sebaiknya hindari mencampur POC dengan bahan kimia sintetis agar mikroba baik di dalam pupuk tetap hidup dan bekerja maksimal di tanah.'
  },
  {
    q: 'Apakah ada biaya pengiriman?',
    a: 'Gratis ongkos kirim untuk wilayah Sleman dengan minimal pembelian tertentu. Untuk luar daerah, ongkir disesuaikan dengan jasa ekspedisi/kargo.'
  }
];

function waLink(productName = '') {
  const text = productName
    ? `Halo Pandawa Kencana Multi Farm, saya ingin memesan *${productName}*.\n\nJumlah: \nAlamat pengiriman: \n\nMohon info ketersediaan dan totalnya. Terima kasih.`
    : 'Halo Pandawa Kencana Multi Farm, saya ingin bertanya tentang produk pupuk organik dan probiotiknya.';
  return `https://wa.me/${WHATSAPP_NUMBER.value}?text=${encodeURIComponent(text)}`;
}

const menuOpen = ref(false);
const filter = ref('Semua');
const activeFaq = ref(null);

const toggleFaq = (idx) => {
  activeFaq.value = activeFaq.value === idx ? null : idx;
};

const visibleProducts = computed(() => {
  if (filter.value === 'Semua') return props.products;
  if (filter.value === 'Terlaris' || filter.value === 'Populer') {
    return props.products.filter(p => p.badge && p.badge.toLowerCase() === filter.value.toLowerCase());
  }
  return props.products.filter(p => p.category === filter.value);
});

const showLeadModal = ref(false);
const leadProductName = ref('');

const leadForm = useForm({
  name: '',
  phone: '',
  message: ''
});

const openModal = (productName = '') => {
  leadProductName.value = productName;
  leadForm.message = productName ? `Saya ingin pesan ${productName}` : '';
  showLeadModal.value = true;
};

const closeModal = () => {
  showLeadModal.value = false;
  leadForm.reset();
};

const submitLead = () => {
  leadForm.post('/lead', {
    onSuccess: () => {
      window.open(waLink(leadProductName.value), '_blank');
      closeModal();
    }
  });
};

const __returned__ = { props, page, WHATSAPP_NUMBER, NAV_LINKS, DEFAULT_ARTICLE_IMAGES, FILTERS, STATS, STEPS, TESTIMONIALS, FAQS, waLink, menuOpen, filter, activeFaq, toggleFaq, visibleProducts, showLeadModal, leadProductName, leadForm, openModal, closeModal, submitLead, ref, computed, Icon, get Head() { return Head }, get Link() { return Link }, get useForm() { return useForm }, get usePage() { return usePage } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createVNode as _createVNode, createCommentVNode as _createCommentVNode, createTextVNode as _createTextVNode, createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, normalizeClass as _normalizeClass, vShow as _vShow, withDirectives as _withDirectives, withCtx as _withCtx, vModelText as _vModelText, withModifiers as _withModifiers, createStaticVNode as _createStaticVNode } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "min-h-screen bg-cream text-bark font-sans" }
const _hoisted_2 = { class: "hidden bg-moss text-cream/90 md:block" }
const _hoisted_3 = { class: "mx-auto flex max-w-6xl items-center justify-between px-6 py-2 text-xs" }
const _hoisted_4 = { class: "flex items-center gap-6" }
const _hoisted_5 = { class: "inline-flex items-center gap-1.5" }
const _hoisted_6 = { class: "inline-flex items-center gap-1.5" }
const _hoisted_7 = { class: "sticky top-0 z-50 border-b border-leaf/15 bg-cream/85 backdrop-blur-md" }
const _hoisted_8 = { class: "mx-auto flex max-w-6xl items-center justify-between px-6 py-4" }
const _hoisted_9 = {
  href: "#beranda",
  class: "flex items-center gap-2.5"
}
const _hoisted_10 = { class: "flex h-10 w-10 items-center justify-center rounded-full bg-moss text-cream" }
const _hoisted_11 = { class: "hidden items-center gap-8 lg:flex" }
const _hoisted_12 = ["href"]
const _hoisted_13 = { class: "flex items-center gap-3" }
const _hoisted_14 = {
  key: 0,
  class: "border-t border-leaf/15 bg-cream px-6 py-4 lg:hidden"
}
const _hoisted_15 = { class: "flex flex-col gap-3" }
const _hoisted_16 = ["href"]
const _hoisted_17 = {
  id: "beranda",
  class: "relative overflow-hidden"
}
const _hoisted_18 = { class: "relative mx-auto grid max-w-6xl grid-cols-1 gap-10 px-6 py-20 md:py-32 lg:grid-cols-12" }
const _hoisted_19 = { class: "lg:col-span-8" }
const _hoisted_20 = { class: "mt-6 font-display text-4xl font-semibold leading-[1.05] text-cream sm:text-5xl md:text-6xl" }
const _hoisted_21 = { class: "border-y border-leaf/15 bg-sand" }
const _hoisted_22 = { class: "mx-auto grid max-w-6xl grid-cols-2 gap-6 px-6 py-8 lg:grid-cols-4" }
const _hoisted_23 = { class: "font-display text-2xl font-semibold text-moss md:text-3xl" }
const _hoisted_24 = { class: "mt-1 text-xs font-medium uppercase tracking-wide text-bark/60 md:text-sm" }
const _hoisted_25 = {
  id: "profil",
  class: "mx-auto max-w-6xl px-6 py-20 md:py-28"
}
const _hoisted_26 = { class: "max-w-4xl" }
const _hoisted_27 = { class: "mt-7 grid gap-4 sm:grid-cols-2" }
const _hoisted_28 = {
  id: "katalog",
  class: "bg-sand py-20 md:py-28"
}
const _hoisted_29 = { class: "mx-auto max-w-6xl px-6" }
const _hoisted_30 = { class: "mt-10 flex flex-wrap justify-center gap-2" }
const _hoisted_31 = ["onClick"]
const _hoisted_32 = { class: "mt-10 grid grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3" }
const _hoisted_33 = { class: "relative aspect-4/3 overflow-hidden bg-parchment" }
const _hoisted_34 = ["src", "alt"]
const _hoisted_35 = { class: "absolute right-3 top-3 rounded-full bg-cream/90 px-3 py-1 text-[0.7rem] font-medium text-moss" }
const _hoisted_36 = { class: "flex flex-1 flex-col p-5" }
const _hoisted_37 = { class: "font-display text-lg font-semibold text-moss" }
const _hoisted_38 = { class: "mt-2 flex-1 text-sm leading-relaxed text-bark/70" }
const _hoisted_39 = { class: "mt-4 font-display text-lg font-semibold text-clay" }
const _hoisted_40 = ["onClick"]
const _hoisted_41 = { class: "bg-sand py-20 md:py-28" }
const _hoisted_42 = { class: "mx-auto max-w-6xl px-6" }
const _hoisted_43 = { class: "grid grid-cols-1 gap-6 md:grid-cols-3" }
const _hoisted_44 = { class: "mb-6 flex gap-1 text-amber-400" }
const _hoisted_45 = { class: "text-sm leading-relaxed text-bark/80 mb-8 italic" }
const _hoisted_46 = { class: "flex items-center gap-4 mt-auto" }
const _hoisted_47 = ["src"]
const _hoisted_48 = { class: "font-bold text-moss text-sm" }
const _hoisted_49 = { class: "text-[0.65rem] text-bark/60 uppercase tracking-widest" }
const _hoisted_50 = { class: "mx-auto max-w-6xl px-6 py-20 md:py-28" }
const _hoisted_51 = { class: "mt-14 grid grid-cols-1 gap-6 md:grid-cols-3" }
const _hoisted_52 = { class: "h-full rounded-2xl border border-leaf/12 bg-cream p-7" }
const _hoisted_53 = { class: "flex items-center justify-between" }
const _hoisted_54 = { class: "flex h-12 w-12 items-center justify-center rounded-xl bg-sand text-moss" }
const _hoisted_55 = { class: "font-display text-3xl font-semibold text-leaf/25" }
const _hoisted_56 = { class: "mt-5 font-display text-lg font-semibold text-moss" }
const _hoisted_57 = { class: "mt-2 text-sm leading-relaxed text-bark/70" }
const _hoisted_58 = {
  key: 0,
  class: "absolute -right-3 top-1/2 hidden -translate-y-1/2 text-leaf/40 md:block"
}
const _hoisted_59 = { class: "mx-auto max-w-3xl px-6 py-20 md:py-28" }
const _hoisted_60 = { class: "space-y-4" }
const _hoisted_61 = ["onClick"]
const _hoisted_62 = {
  id: "artikel",
  class: "bg-sand py-20 md:py-28"
}
const _hoisted_63 = { class: "mx-auto max-w-6xl px-6" }
const _hoisted_64 = { class: "flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end" }
const _hoisted_65 = { class: "mt-12 grid grid-cols-1 gap-7 md:grid-cols-3" }
const _hoisted_66 = { class: "aspect-16/10 overflow-hidden bg-parchment" }
const _hoisted_67 = ["src", "alt"]
const _hoisted_68 = { class: "flex flex-1 flex-col p-6" }
const _hoisted_69 = { class: "w-fit rounded-full bg-sand px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-wide text-leaf" }
const _hoisted_70 = { class: "mt-3 font-display text-lg font-semibold leading-snug text-moss" }
const _hoisted_71 = { class: "mt-2 flex-1 text-sm leading-relaxed text-bark/70" }
const _hoisted_72 = {
  href: "#",
  class: "mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-clay transition-colors hover:text-moss"
}
const _hoisted_73 = { class: "bg-moss" }
const _hoisted_74 = { class: "mx-auto flex max-w-6xl flex-col items-center gap-6 px-6 py-14 text-center md:flex-row md:justify-between md:text-left" }
const _hoisted_75 = {
  id: "kontak",
  class: "bg-bark text-cream/80"
}
const _hoisted_76 = { class: "mx-auto grid max-w-6xl grid-cols-1 gap-10 px-6 py-16 lg:grid-cols-12" }
const _hoisted_77 = { class: "lg:col-span-4" }
const _hoisted_78 = { class: "flex items-center gap-2.5" }
const _hoisted_79 = { class: "flex h-10 w-10 items-center justify-center rounded-full bg-moss text-cream" }
const _hoisted_80 = { class: "lg:col-span-2" }
const _hoisted_81 = { class: "mt-4 space-y-3 text-sm text-cream/70" }
const _hoisted_82 = ["href"]
const _hoisted_83 = { class: "lg:col-span-3" }
const _hoisted_84 = { class: "mt-4 space-y-3 text-sm text-cream/70" }
const _hoisted_85 = { class: "flex gap-2" }
const _hoisted_86 = {
  href: "mailto:halo@pandawakencana.id",
  class: "inline-flex items-center gap-2 transition-colors hover:text-sprout"
}
const _hoisted_87 = { class: "lg:col-span-3" }
const _hoisted_88 = { class: "mt-4 flex aspect-4/3 flex-col items-center justify-center gap-2 rounded-xl border border-cream/15 bg-cream/5 text-center text-cream/60" }
const _hoisted_89 = {
  key: 0,
  class: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-bark/60 backdrop-blur-sm"
}
const _hoisted_90 = { class: "bg-cream w-full max-w-md rounded-3xl p-8 shadow-xl relative animate-in fade-in zoom-in duration-200" }
const _hoisted_91 = {
  key: 0,
  class: "hidden"
}
const _hoisted_92 = ["disabled"]
const _hoisted_93 = { key: 0 }
const _hoisted_94 = {
  key: 1,
  class: "flex items-center gap-2"
}

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createVNode($setup["Head"], { title: "Pandawa Kencana | Pertanian Berkelanjutan" }),
    _createElementVNode("div", _hoisted_1, [
      _createCommentVNode(" Top Bar "),
      _createElementVNode("div", _hoisted_2, [
        _createElementVNode("div", _hoisted_3, [
          _createElementVNode("div", _hoisted_4, [
            _createElementVNode("span", _hoisted_5, [
              _createVNode($setup["Icon"], {
                name: "clock",
                class: "h-3.5 w-3.5"
              }),
              _cache[11] || (_cache[11] = _createTextVNode(" Buka Sen–Jum: 08.00–16.00 WIB ", -1 /* CACHED */))
            ]),
            _createElementVNode("span", _hoisted_6, [
              _createVNode($setup["Icon"], {
                name: "pin",
                class: "h-3.5 w-3.5"
              }),
              _cache[12] || (_cache[12] = _createTextVNode(" Desa Cangkringan, Sleman ", -1 /* CACHED */))
            ])
          ]),
          _createElementVNode("button", {
            onClick: _cache[0] || (_cache[0] = $event => ($setup.openModal())),
            class: "inline-flex items-center gap-1.5 font-medium transition-colors hover:text-sprout"
          }, [
            _createVNode($setup["Icon"], {
              name: "chat",
              class: "h-3.5 w-3.5"
            }),
            _createTextVNode(" Customer Service: " + _toDisplayString(_ctx.$page.props.settings?.whatsapp || '0812-3456-7890'), 1 /* TEXT */)
          ])
        ])
      ]),
      _createCommentVNode(" Navbar "),
      _createElementVNode("header", _hoisted_7, [
        _createElementVNode("div", _hoisted_8, [
          _createElementVNode("a", _hoisted_9, [
            _createElementVNode("span", _hoisted_10, [
              _createVNode($setup["Icon"], {
                name: "leaf",
                class: "h-5 w-5"
              })
            ]),
            _cache[13] || (_cache[13] = _createElementVNode("span", { class: "leading-tight" }, [
              _createElementVNode("span", { class: "block font-display text-lg font-semibold text-moss" }, "Pandawa Kencana"),
              _createElementVNode("span", { class: "block text-[0.7rem] font-medium uppercase tracking-[0.2em] text-leaf" }, "Multi Farm")
            ], -1 /* CACHED */))
          ]),
          _createElementVNode("nav", _hoisted_11, [
            (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.NAV_LINKS, (l) => {
              return _createElementVNode("a", {
                key: l.href,
                href: l.href,
                class: "text-sm font-medium text-bark/70 transition-colors hover:text-moss"
              }, _toDisplayString(l.label), 9 /* TEXT, PROPS */, _hoisted_12)
            }), 64 /* STABLE_FRAGMENT */))
          ]),
          _createElementVNode("div", _hoisted_13, [
            _createElementVNode("button", {
              onClick: _cache[1] || (_cache[1] = $event => ($setup.openModal())),
              class: "hidden rounded-full bg-moss px-5 py-2 text-sm font-semibold text-cream transition-colors hover:bg-leaf sm:inline-flex"
            }, " Pesan Sekarang "),
            _createElementVNode("button", {
              class: "flex h-10 w-10 items-center justify-center rounded-lg border border-leaf/20 text-moss lg:hidden",
              onClick: _cache[2] || (_cache[2] = $event => ($setup.menuOpen = !$setup.menuOpen)),
              "aria-label": "Buka menu"
            }, [...(_cache[14] || (_cache[14] = [
              _createElementVNode("div", { class: "space-y-1.5" }, [
                _createElementVNode("span", { class: "block h-0.5 w-5 bg-current" }),
                _createElementVNode("span", { class: "block h-0.5 w-5 bg-current" }),
                _createElementVNode("span", { class: "block h-0.5 w-5 bg-current" })
              ], -1 /* CACHED */)
            ]))])
          ])
        ]),
        ($setup.menuOpen)
          ? (_openBlock(), _createElementBlock("nav", _hoisted_14, [
              _createElementVNode("div", _hoisted_15, [
                (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.NAV_LINKS, (l) => {
                  return _createElementVNode("a", {
                    key: l.href,
                    href: l.href,
                    onClick: _cache[3] || (_cache[3] = $event => ($setup.menuOpen = false)),
                    class: "text-sm font-medium text-bark/80"
                  }, _toDisplayString(l.label), 9 /* TEXT, PROPS */, _hoisted_16)
                }), 64 /* STABLE_FRAGMENT */)),
                _createElementVNode("button", {
                  onClick: _cache[4] || (_cache[4] = $event => ($setup.openModal())),
                  class: "mt-1 rounded-full bg-moss px-5 py-2.5 text-center text-sm font-semibold text-cream"
                }, " Pesan Sekarang ")
              ])
            ]))
          : _createCommentVNode("v-if", true)
      ]),
      _createCommentVNode(" Hero "),
      _createElementVNode("section", _hoisted_17, [
        _cache[18] || (_cache[18] = _createElementVNode("div", { class: "absolute inset-0" }, [
          _createElementVNode("img", {
            src: "https://images.unsplash.com/photo-1558388556-2261d4cc1938?w=1600&h=1000&fit=crop&auto=format",
            alt: "Lahan pertanian organik di Desa Cangkringan",
            class: "h-full w-full bg-moss object-cover"
          }),
          _createElementVNode("div", { class: "absolute inset-0 bg-linear-to-r from-bark/85 via-moss/70 to-moss/25" })
        ], -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_18, [
          _createElementVNode("div", _hoisted_19, [
            _cache[15] || (_cache[15] = _createElementVNode("span", { class: "inline-flex items-center gap-2 rounded-full border border-cream/30 bg-cream/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-cream/90" }, [
              _createElementVNode("span", { class: "h-1.5 w-1.5 rounded-full bg-sprout" }),
              _createTextVNode(" CV Pandawa Kencana Multi Farm · Sleman, Yogyakarta ")
            ], -1 /* CACHED */)),
            _createElementVNode("h1", _hoisted_20, _toDisplayString(_ctx.$page.props.settings?.headline || 'Pupuk Organik & Probiotik Berkualitas untuk Panen Melimpah'), 1 /* TEXT */),
            _cache[16] || (_cache[16] = _createElementVNode("p", { class: "mt-5 max-w-xl text-lg leading-relaxed text-cream/85" }, " Produsen pupuk organik dan probiotik terpercaya dari Desa Cangkringan untuk hasil panen optimal dan ramah lingkungan. ", -1 /* CACHED */)),
            _cache[17] || (_cache[17] = _createElementVNode("div", { class: "mt-8 flex flex-wrap gap-3" }, [
              _createElementVNode("a", {
                href: "#katalog",
                class: "rounded-full bg-sprout px-7 py-3.5 text-sm font-semibold text-bark shadow-lg shadow-bark/20 transition-transform hover:-translate-y-0.5 hover:bg-cream"
              }, " Lihat Katalog "),
              _createElementVNode("a", {
                href: "#profil",
                class: "rounded-full border border-cream/40 px-7 py-3.5 text-sm font-semibold text-cream transition-colors hover:bg-cream/10"
              }, " Pelajari Lebih Lanjut ")
            ], -1 /* CACHED */))
          ])
        ])
      ]),
      _createCommentVNode(" Statistik "),
      _createElementVNode("section", _hoisted_21, [
        _createElementVNode("div", _hoisted_22, [
          (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.STATS, (s) => {
            return _createElementVNode("div", {
              key: s.label,
              class: "text-center"
            }, [
              _createElementVNode("p", _hoisted_23, _toDisplayString(s.value), 1 /* TEXT */),
              _createElementVNode("p", _hoisted_24, _toDisplayString(s.label), 1 /* TEXT */)
            ])
          }), 64 /* STABLE_FRAGMENT */))
        ])
      ]),
      _createCommentVNode(" Tentang Kami & Profil Perusahaan "),
      _createElementVNode("section", _hoisted_25, [
        _createCommentVNode(" TENTANG KAMI "),
        _cache[23] || (_cache[23] = _createStaticVNode("<div class=\"grid grid-cols-1 items-center gap-12 lg:grid-cols-12 mb-20 md:mb-24\"><div class=\"relative lg:col-span-5\"><div class=\"overflow-hidden rounded-3xl\"><img src=\"https://images.unsplash.com/photo-1597868165956-03a6827955b1?w=900&amp;h=1000&amp;fit=crop&amp;auto=format\" alt=\"Proses produksi pupuk organik\" class=\"h-full w-full bg-parchment object-cover\"></div><div class=\"absolute -bottom-6 -right-4 hidden rounded-2xl bg-moss px-6 py-5 text-cream shadow-xl sm:block\"><p class=\"font-display text-3xl font-semibold\">10+</p><p class=\"text-[0.65rem] uppercase tracking-widest text-cream/80 mt-1\">Tahun Melayani Petani</p></div></div><div class=\"lg:col-span-7\"><span class=\"text-xs font-semibold uppercase tracking-[0.2em] text-leaf\">Tentang Kami</span><h2 class=\"mt-3 font-display text-3xl font-semibold leading-tight text-moss md:text-4xl\"> Lahir dari tanah Cangkringan, tumbuh bersama petani. </h2><p class=\"mt-5 leading-relaxed text-bark/75\"> Pandawa Kencana Multi Farm adalah usaha pertanian yang berlokasi di Desa Cangkringan, Sleman. Kami memproduksi pupuk organik dan probiotik untuk mengembalikan kesuburan tanah secara alami tanpa merusak lingkungan. </p><p class=\"mt-4 leading-relaxed text-bark/75\"> Komitmen kami sederhana: mendukung pertanian berkelanjutan yang sehat bagi tanah, tanaman, dan generasi mendatang. Setiap produk kami dibuat dengan ketelitian agar mitra tani memperoleh hasil panen terbaik. </p><div class=\"my-8 h-px w-full bg-leaf/15\"></div><div class=\"flex gap-12\"><div><p class=\"font-display text-3xl font-semibold text-moss\">500+</p><p class=\"text-xs text-bark/60 mt-1\">Mitra Tani Terbantu</p></div><div><p class=\"font-display text-3xl font-semibold text-moss\">100%</p><p class=\"text-xs text-bark/60 mt-1\">Bahan Organik Alami</p></div></div></div></div>", 1)),
        _createCommentVNode(" PROFIL PERUSAHAAN "),
        _createElementVNode("div", _hoisted_26, [
          _cache[19] || (_cache[19] = _createElementVNode("span", { class: "text-xs font-semibold uppercase tracking-[0.2em] text-leaf" }, "Profil Perusahaan", -1 /* CACHED */)),
          _cache[20] || (_cache[20] = _createElementVNode("h2", { class: "mt-3 font-display text-3xl font-semibold leading-tight text-moss md:text-4xl" }, " Mendukung ekosistem pertanian lokal Sleman ", -1 /* CACHED */)),
          _cache[21] || (_cache[21] = _createElementVNode("p", { class: "mt-5 leading-relaxed text-bark/75" }, " CV Pandawa Kencana Multi Farm berdiri di Desa Cangkringan dengan visi memajukan pertanian berkelanjutan. Kami memproduksi pupuk organik dan probiotik berkualitas untuk mengembalikan kesuburan tanah secara alami. ", -1 /* CACHED */)),
          _cache[22] || (_cache[22] = _createElementVNode("p", { class: "mt-4 leading-relaxed text-bark/75" }, " Lebih dari sekadar produsen, kami hadir sebagai mitra edukasi bagi kelompok tani — mendampingi dari pemilihan produk, aplikasi, hingga panen, agar hasil melimpah dan ramah lingkungan. ", -1 /* CACHED */)),
          _createElementVNode("ul", _hoisted_27, [
            (_openBlock(), _createElementBlock(_Fragment, null, _renderList(['Produksi lokal Desa Cangkringan', 'Pendampingan mitra tani B2B', 'Melayani konsumen umum B2C', 'Pengiriman se-DIY & Jateng'], (item) => {
              return _createElementVNode("li", {
                key: item,
                class: "flex items-center gap-2.5 text-sm text-bark/80"
              }, [
                _createVNode($setup["Icon"], {
                  name: "check",
                  class: "h-4 w-4 shrink-0 text-leaf"
                }),
                _createTextVNode(" " + _toDisplayString(item), 1 /* TEXT */)
              ])
            }), 64 /* STABLE_FRAGMENT */))
          ])
        ])
      ]),
      _createCommentVNode(" Katalog Produk "),
      _createElementVNode("section", _hoisted_28, [
        _createElementVNode("div", _hoisted_29, [
          _cache[25] || (_cache[25] = _createElementVNode("div", { class: "mx-auto max-w-2xl text-center" }, [
            _createElementVNode("span", { class: "text-xs font-semibold uppercase tracking-[0.2em] text-leaf" }, "Katalog Produk"),
            _createElementVNode("h2", { class: "mt-3 font-display text-3xl font-semibold text-moss md:text-4xl" }, " Nutrisi terbaik untuk lahan & ternak "),
            _createElementVNode("p", { class: "mt-4 text-bark/70" }, " Saring berdasarkan kategori, lalu pesan langsung via WhatsApp dengan form otomatis. ")
          ], -1 /* CACHED */)),
          _createCommentVNode(" Filter "),
          _createElementVNode("div", _hoisted_30, [
            (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.FILTERS, (f) => {
              return _createElementVNode("button", {
                key: f,
                onClick: $event => ($setup.filter = f),
                class: _normalizeClass(['rounded-full px-5 py-2 text-sm font-semibold transition-colors', $setup.filter === f ? 'bg-moss text-cream' : 'border border-leaf/25 bg-cream text-bark/70 hover:border-leaf/50'])
              }, _toDisplayString(f), 11 /* TEXT, CLASS, PROPS */, _hoisted_31)
            }), 64 /* STABLE_FRAGMENT */))
          ]),
          _createElementVNode("div", _hoisted_32, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.visibleProducts, (p) => {
              return (_openBlock(), _createElementBlock("article", {
                key: p.name,
                class: "group flex flex-col overflow-hidden rounded-2xl border border-leaf/10 bg-cream shadow-sm transition-shadow hover:shadow-lg"
              }, [
                _createElementVNode("div", _hoisted_33, [
                  _createElementVNode("img", {
                    src: p.image_path ? '/storage/' + p.image_path : 'https://images.unsplash.com/photo-1599839619722-39751411ea63?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
                    alt: p.name,
                    class: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  }, null, 8 /* PROPS */, _hoisted_34),
                  (p.badge)
                    ? (_openBlock(), _createElementBlock("span", {
                        key: 0,
                        class: _normalizeClass(['absolute left-3 top-3 rounded-full px-3 py-1 text-[0.7rem] font-semibold text-cream', p.badgeTone === 'clay' ? 'bg-clay' : 'bg-leaf'])
                      }, _toDisplayString(p.badge), 3 /* TEXT, CLASS */))
                    : _createCommentVNode("v-if", true),
                  _createElementVNode("span", _hoisted_35, _toDisplayString(p.category), 1 /* TEXT */)
                ]),
                _createElementVNode("div", _hoisted_36, [
                  _createElementVNode("h3", _hoisted_37, _toDisplayString(p.name), 1 /* TEXT */),
                  _createElementVNode("p", _hoisted_38, _toDisplayString(p.desc), 1 /* TEXT */),
                  _createElementVNode("p", _hoisted_39, _toDisplayString(p.price), 1 /* TEXT */),
                  _createElementVNode("button", {
                    onClick: $event => ($setup.openModal(p.name)),
                    class: "mt-4 inline-flex items-center justify-center gap-2 rounded-full bg-moss px-4 py-2.5 text-sm font-semibold text-cream transition-colors hover:bg-leaf"
                  }, [
                    _createVNode($setup["Icon"], {
                      name: "whatsapp",
                      class: "h-4 w-4"
                    }),
                    _cache[24] || (_cache[24] = _createTextVNode(" Pesan via WhatsApp ", -1 /* CACHED */))
                  ], 8 /* PROPS */, _hoisted_40)
                ])
              ]))
            }), 128 /* KEYED_FRAGMENT */))
          ])
        ])
      ]),
      _createCommentVNode(" Testimoni "),
      _createElementVNode("section", _hoisted_41, [
        _createElementVNode("div", _hoisted_42, [
          _cache[26] || (_cache[26] = _createElementVNode("div", { class: "text-center mb-14" }, [
            _createElementVNode("span", { class: "text-xs font-semibold uppercase tracking-[0.2em] text-leaf" }, "Kata Mereka"),
            _createElementVNode("h2", { class: "mt-3 font-display text-3xl font-semibold text-moss md:text-4xl" }, " Bukti nyata di lahan petani ")
          ], -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_43, [
            (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.TESTIMONIALS, (t, i) => {
              return _createElementVNode("div", {
                key: i,
                class: "rounded-3xl bg-cream p-8 shadow-sm border border-leaf/10 relative flex flex-col"
              }, [
                _createVNode($setup["Icon"], {
                  name: "chat",
                  class: "absolute right-8 top-8 h-8 w-8 text-leaf/10"
                }),
                _createElementVNode("div", _hoisted_44, [
                  (_openBlock(), _createElementBlock(_Fragment, null, _renderList(5, (n) => {
                    return _createVNode($setup["Icon"], {
                      name: "check",
                      class: "h-4 w-4",
                      key: n
                    })
                  }), 64 /* STABLE_FRAGMENT */))
                ]),
                _createElementVNode("p", _hoisted_45, "\"" + _toDisplayString(t.quote) + "\"", 1 /* TEXT */),
                _createElementVNode("div", _hoisted_46, [
                  _createElementVNode("img", {
                    src: t.image,
                    class: "h-12 w-12 rounded-full object-cover border border-leaf/20"
                  }, null, 8 /* PROPS */, _hoisted_47),
                  _createElementVNode("div", null, [
                    _createElementVNode("p", _hoisted_48, _toDisplayString(t.name), 1 /* TEXT */),
                    _createElementVNode("p", _hoisted_49, _toDisplayString(t.role), 1 /* TEXT */)
                  ])
                ])
              ])
            }), 64 /* STABLE_FRAGMENT */))
          ])
        ])
      ]),
      _createCommentVNode(" Alur Pemesanan "),
      _createElementVNode("section", _hoisted_50, [
        _cache[27] || (_cache[27] = _createElementVNode("div", { class: "mx-auto max-w-2xl text-center" }, [
          _createElementVNode("span", { class: "text-xs font-semibold uppercase tracking-[0.2em] text-leaf" }, "Alur Pemesanan"),
          _createElementVNode("h2", { class: "mt-3 font-display text-3xl font-semibold text-moss md:text-4xl" }, " Tiga langkah mudah untuk memesan "),
          _createElementVNode("p", { class: "mt-4 text-bark/70" }, " Sederhana dan cepat — dirancang agar semua kalangan petani bisa memesan tanpa ribet. ")
        ], -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_51, [
          (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.STEPS, (s, i) => {
            return _createElementVNode("div", {
              key: s.n,
              class: "relative"
            }, [
              _createElementVNode("div", _hoisted_52, [
                _createElementVNode("div", _hoisted_53, [
                  _createElementVNode("span", _hoisted_54, [
                    _createVNode($setup["Icon"], {
                      name: s.icon,
                      class: "h-6 w-6"
                    }, null, 8 /* PROPS */, ["name"])
                  ]),
                  _createElementVNode("span", _hoisted_55, _toDisplayString(s.n), 1 /* TEXT */)
                ]),
                _createElementVNode("h3", _hoisted_56, _toDisplayString(s.title), 1 /* TEXT */),
                _createElementVNode("p", _hoisted_57, _toDisplayString(s.desc), 1 /* TEXT */)
              ]),
              (i < $setup.STEPS.length - 1)
                ? (_openBlock(), _createElementBlock("div", _hoisted_58, [
                    _createVNode($setup["Icon"], {
                      name: "arrow",
                      class: "h-6 w-6"
                    })
                  ]))
                : _createCommentVNode("v-if", true)
            ])
          }), 64 /* STABLE_FRAGMENT */))
        ])
      ]),
      _createCommentVNode(" FAQ "),
      _createElementVNode("section", _hoisted_59, [
        _cache[28] || (_cache[28] = _createElementVNode("div", { class: "text-center mb-12" }, [
          _createElementVNode("span", { class: "text-xs font-semibold uppercase tracking-[0.2em] text-leaf" }, "Tanya Jawab"),
          _createElementVNode("h2", { class: "mt-3 font-display text-3xl font-semibold text-moss md:text-4xl" }, " Pertanyaan yang sering diajukan ")
        ], -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_60, [
          (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.FAQS, (faq, i) => {
            return _createElementVNode("div", {
              key: i,
              class: "rounded-2xl border border-leaf/15 bg-cream overflow-hidden"
            }, [
              _createElementVNode("button", {
                onClick: $event => ($setup.toggleFaq(i)),
                class: "flex w-full items-center justify-between px-6 py-5 text-left font-semibold text-moss transition-colors hover:bg-leaf/5"
              }, [
                _createElementVNode("span", null, _toDisplayString(faq.q), 1 /* TEXT */),
                _createVNode($setup["Icon"], {
                  name: $setup.activeFaq === i ? 'check' : 'plus',
                  class: _normalizeClass(["h-5 w-5 shrink-0 text-leaf transition-transform duration-300", { 'rotate-180': $setup.activeFaq === i }])
                }, null, 8 /* PROPS */, ["name", "class"])
              ], 8 /* PROPS */, _hoisted_61),
              _withDirectives(_createElementVNode("div", { class: "px-6 pb-6 pt-2 text-sm leading-relaxed text-bark/75" }, _toDisplayString(faq.a), 513 /* TEXT, NEED_PATCH */), [
                [_vShow, $setup.activeFaq === i]
              ])
            ])
          }), 64 /* STABLE_FRAGMENT */))
        ])
      ]),
      _createCommentVNode(" Artikel / Edukasi Tani "),
      _createElementVNode("section", _hoisted_62, [
        _createElementVNode("div", _hoisted_63, [
          _createElementVNode("div", _hoisted_64, [
            _cache[30] || (_cache[30] = _createElementVNode("div", { class: "max-w-xl" }, [
              _createElementVNode("span", { class: "text-xs font-semibold uppercase tracking-[0.2em] text-leaf" }, "Artikel & Edukasi Tani"),
              _createElementVNode("h2", { class: "mt-3 font-display text-3xl font-semibold text-moss md:text-4xl" }, " Belajar bertani lebih cerdas "),
              _createElementVNode("p", { class: "mt-4 text-bark/70" }, " Bagian dari program literasi tani untuk masyarakat Desa Cangkringan. ")
            ], -1 /* CACHED */)),
            _createVNode($setup["Link"], {
              href: "/articles",
              class: "shrink-0 rounded-full border border-leaf/30 px-5 py-2.5 text-sm font-semibold text-moss transition-colors hover:bg-cream"
            }, {
              default: _withCtx(() => [...(_cache[29] || (_cache[29] = [
                _createTextVNode(" Lihat Semua Artikel ", -1 /* CACHED */)
              ]))]),
              _: 1 /* STABLE */
            })
          ]),
          _createElementVNode("div", _hoisted_65, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($props.articles, (a, i) => {
              return (_openBlock(), _createElementBlock("article", {
                key: a.title,
                class: "group flex flex-col overflow-hidden rounded-2xl border border-leaf/10 bg-cream shadow-sm transition-shadow hover:shadow-lg"
              }, [
                _createElementVNode("div", _hoisted_66, [
                  _createElementVNode("img", {
                    src: a.image_path ? (a.image_path.startsWith('http') ? a.image_path : '/storage/' + a.image_path) : $setup.DEFAULT_ARTICLE_IMAGES[i % $setup.DEFAULT_ARTICLE_IMAGES.length],
                    alt: a.title,
                    class: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  }, null, 8 /* PROPS */, _hoisted_67)
                ]),
                _createElementVNode("div", _hoisted_68, [
                  _createElementVNode("span", _hoisted_69, _toDisplayString(a.tag), 1 /* TEXT */),
                  _createElementVNode("h3", _hoisted_70, _toDisplayString(a.title), 1 /* TEXT */),
                  _createElementVNode("p", _hoisted_71, _toDisplayString(a.excerpt), 1 /* TEXT */),
                  _createElementVNode("a", _hoisted_72, [
                    _cache[31] || (_cache[31] = _createTextVNode(" Baca selengkapnya ", -1 /* CACHED */)),
                    _createVNode($setup["Icon"], {
                      name: "arrow",
                      class: "h-4 w-4"
                    })
                  ])
                ])
              ]))
            }), 128 /* KEYED_FRAGMENT */))
          ])
        ])
      ]),
      _createCommentVNode(" CTA band "),
      _createElementVNode("section", _hoisted_73, [
        _createElementVNode("div", _hoisted_74, [
          _cache[33] || (_cache[33] = _createElementVNode("div", null, [
            _createElementVNode("h2", { class: "font-display text-2xl font-semibold text-cream md:text-3xl" }, " Siap memulai pertanian yang lebih sehat? "),
            _createElementVNode("p", { class: "mt-2 text-cream/80" }, " Konsultasikan kebutuhan lahan atau ternak Anda bersama tim kami. ")
          ], -1 /* CACHED */)),
          _createElementVNode("button", {
            onClick: _cache[5] || (_cache[5] = $event => ($setup.openModal())),
            class: "inline-flex items-center gap-2 rounded-full bg-sprout px-7 py-3.5 text-sm font-semibold text-bark transition-transform hover:-translate-y-0.5 hover:bg-cream"
          }, [
            _createVNode($setup["Icon"], {
              name: "whatsapp",
              class: "h-4 w-4"
            }),
            _cache[32] || (_cache[32] = _createTextVNode(" Hubungi via WhatsApp ", -1 /* CACHED */))
          ])
        ])
      ]),
      _createCommentVNode(" Footer "),
      _createElementVNode("footer", _hoisted_75, [
        _createElementVNode("div", _hoisted_76, [
          _createElementVNode("div", _hoisted_77, [
            _createElementVNode("div", _hoisted_78, [
              _createElementVNode("span", _hoisted_79, [
                _createVNode($setup["Icon"], {
                  name: "leaf",
                  class: "h-5 w-5"
                })
              ]),
              _cache[34] || (_cache[34] = _createElementVNode("span", { class: "font-display text-lg font-semibold text-cream" }, "Pandawa Kencana", -1 /* CACHED */))
            ]),
            _cache[35] || (_cache[35] = _createElementVNode("p", { class: "mt-4 max-w-sm text-sm leading-relaxed text-cream/70" }, " CV Pandawa Kencana Multi Farm — produsen pupuk organik dan probiotik untuk pertanian berkelanjutan. Menyuburkan tanah, menumbuhkan harapan. ", -1 /* CACHED */))
          ]),
          _createElementVNode("div", _hoisted_80, [
            _cache[36] || (_cache[36] = _createElementVNode("h4", { class: "text-sm font-semibold uppercase tracking-widest text-cream" }, "Tautan Cepat", -1 /* CACHED */)),
            _createElementVNode("ul", _hoisted_81, [
              (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.NAV_LINKS, (l) => {
                return _createElementVNode("li", {
                  key: l.href
                }, [
                  _createElementVNode("a", {
                    href: l.href,
                    class: "transition-colors hover:text-sprout"
                  }, _toDisplayString(l.label), 9 /* TEXT, PROPS */, _hoisted_82)
                ])
              }), 64 /* STABLE_FRAGMENT */))
            ])
          ]),
          _createElementVNode("div", _hoisted_83, [
            _cache[38] || (_cache[38] = _createElementVNode("h4", { class: "text-sm font-semibold uppercase tracking-widest text-cream" }, "Kontak", -1 /* CACHED */)),
            _createElementVNode("ul", _hoisted_84, [
              _createElementVNode("li", _hoisted_85, [
                _createVNode($setup["Icon"], {
                  name: "pin",
                  class: "mt-0.5 h-4 w-4 shrink-0 text-sprout"
                }),
                _createTextVNode(" " + _toDisplayString(_ctx.$page.props.settings?.address || 'Jl. Kaliurang KM 20, Desa Cangkringan, Sleman, Yogyakarta'), 1 /* TEXT */)
              ]),
              _createElementVNode("li", null, [
                _createElementVNode("button", {
                  onClick: _cache[6] || (_cache[6] = $event => ($setup.openModal())),
                  class: "inline-flex items-center gap-2 transition-colors hover:text-sprout"
                }, [
                  _createVNode($setup["Icon"], {
                    name: "whatsapp",
                    class: "h-4 w-4 text-sprout"
                  }),
                  _createTextVNode(" " + _toDisplayString(_ctx.$page.props.settings?.whatsapp || '0812-3456-7890'), 1 /* TEXT */)
                ])
              ]),
              _createElementVNode("li", null, [
                _createElementVNode("a", _hoisted_86, [
                  _createVNode($setup["Icon"], {
                    name: "mail",
                    class: "h-4 w-4 text-sprout"
                  }),
                  _cache[37] || (_cache[37] = _createTextVNode(" halo@pandawakencana.id ", -1 /* CACHED */))
                ])
              ])
            ])
          ]),
          _createElementVNode("div", _hoisted_87, [
            _cache[41] || (_cache[41] = _createElementVNode("h4", { class: "text-sm font-semibold uppercase tracking-widest text-cream" }, "Lokasi Kami", -1 /* CACHED */)),
            _createElementVNode("div", _hoisted_88, [
              _createVNode($setup["Icon"], {
                name: "pin",
                class: "h-8 w-8 text-sprout"
              }),
              _cache[39] || (_cache[39] = _createElementVNode("span", { class: "text-xs" }, "Placeholder Peta Google Maps", -1 /* CACHED */)),
              _cache[40] || (_cache[40] = _createElementVNode("a", {
                href: "https://maps.google.com/?q=Cangkringan+Sleman+Yogyakarta",
                target: "_blank",
                rel: "noreferrer",
                class: "text-xs font-semibold text-sprout underline underline-offset-2"
              }, " Buka di Google Maps ", -1 /* CACHED */))
            ])
          ])
        ]),
        _cache[42] || (_cache[42] = _createElementVNode("div", { class: "border-t border-cream/10" }, [
          _createElementVNode("div", { class: "mx-auto flex max-w-6xl flex-col items-center justify-center gap-2 px-6 py-5 text-center text-xs text-cream/50" }, [
            _createElementVNode("span", null, "© 2026 CV Pandawa Kencana Multi Farm. Seluruh hak cipta dilindungi.")
          ])
        ], -1 /* CACHED */))
      ]),
      _createCommentVNode(" Modal Form Pemesanan "),
      ($setup.showLeadModal)
        ? (_openBlock(), _createElementBlock("div", _hoisted_89, [
            _createElementVNode("div", _hoisted_90, [
              _createElementVNode("button", {
                onClick: _cache[7] || (_cache[7] = $event => ($setup.closeModal())),
                class: "absolute right-6 top-6 text-bark/50 hover:text-moss transition-colors"
              }, [
                _createVNode($setup["Icon"], {
                  name: "plus",
                  class: "w-6 h-6 rotate-45"
                })
              ]),
              _cache[46] || (_cache[46] = _createElementVNode("div", { class: "mb-6" }, [
                _createElementVNode("h3", { class: "font-display text-2xl font-semibold text-moss" }, "Informasi Pemesanan"),
                _createElementVNode("p", { class: "text-sm text-bark/70 mt-1" }, "Silakan lengkapi form berikut sebelum kami arahkan ke WhatsApp.")
              ], -1 /* CACHED */)),
              _createElementVNode("form", {
                onSubmit: _withModifiers($setup.submitLead, ["prevent"]),
                class: "space-y-4"
              }, [
                _createElementVNode("div", null, [
                  _cache[43] || (_cache[43] = _createElementVNode("label", { class: "block text-sm font-medium text-bark/80 mb-1" }, [
                    _createTextVNode("Nama Lengkap "),
                    _createElementVNode("span", { class: "text-red-500" }, "*")
                  ], -1 /* CACHED */)),
                  _withDirectives(_createElementVNode("input", {
                    "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => (($setup.leadForm.name) = $event)),
                    type: "text",
                    required: "",
                    class: "w-full rounded-xl border border-leaf/20 bg-white px-4 py-3 text-sm focus:border-moss focus:outline-none focus:ring-1 focus:ring-moss",
                    placeholder: "Masukkan nama Anda"
                  }, null, 512 /* NEED_PATCH */), [
                    [_vModelText, $setup.leadForm.name]
                  ])
                ]),
                _createElementVNode("div", null, [
                  _cache[44] || (_cache[44] = _createElementVNode("label", { class: "block text-sm font-medium text-bark/80 mb-1" }, [
                    _createTextVNode("Nomor WhatsApp "),
                    _createElementVNode("span", { class: "text-red-500" }, "*")
                  ], -1 /* CACHED */)),
                  _withDirectives(_createElementVNode("input", {
                    "onUpdate:modelValue": _cache[9] || (_cache[9] = $event => (($setup.leadForm.phone) = $event)),
                    type: "tel",
                    required: "",
                    class: "w-full rounded-xl border border-leaf/20 bg-white px-4 py-3 text-sm focus:border-moss focus:outline-none focus:ring-1 focus:ring-moss",
                    placeholder: "081234567890"
                  }, null, 512 /* NEED_PATCH */), [
                    [_vModelText, $setup.leadForm.phone]
                  ])
                ]),
                ($setup.leadProductName)
                  ? (_openBlock(), _createElementBlock("div", _hoisted_91, [
                      _withDirectives(_createElementVNode("input", {
                        type: "hidden",
                        "onUpdate:modelValue": _cache[10] || (_cache[10] = $event => (($setup.leadForm.message) = $event))
                      }, null, 512 /* NEED_PATCH */), [
                        [_vModelText, $setup.leadForm.message]
                      ])
                    ]))
                  : _createCommentVNode("v-if", true),
                _createElementVNode("button", {
                  type: "submit",
                  disabled: $setup.leadForm.processing,
                  class: "w-full mt-4 flex items-center justify-center gap-2 rounded-full bg-moss px-5 py-3.5 font-semibold text-cream transition-colors hover:bg-leaf disabled:opacity-70 disabled:cursor-not-allowed"
                }, [
                  ($setup.leadForm.processing)
                    ? (_openBlock(), _createElementBlock("span", _hoisted_93, "Sedang memproses..."))
                    : (_openBlock(), _createElementBlock("span", _hoisted_94, [
                        _createVNode($setup["Icon"], {
                          name: "whatsapp",
                          class: "w-5 h-5"
                        }),
                        _cache[45] || (_cache[45] = _createTextVNode(" Lanjutkan ke WhatsApp", -1 /* CACHED */))
                      ]))
                ], 8 /* PROPS */, _hoisted_92)
              ], 32 /* NEED_HYDRATION */)
            ])
          ]))
        : _createCommentVNode("v-if", true)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "54e96d65"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
export const _rerender_only = __VUE_HMR_RUNTIME__.CHANGED_FILE === "C:/laragon/www/pandawa-kencana/resources/js/Pages/Landing.vue"
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Landing.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTGFuZGluZy52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IHJlZiwgY29tcHV0ZWQgfSBmcm9tICd2dWUnO1xuaW1wb3J0IEljb24gZnJvbSAnQC9Db21wb25lbnRzL0ljb24udnVlJztcbmltcG9ydCB7IEhlYWQsIExpbmssIHVzZUZvcm0gfSBmcm9tICdAaW5lcnRpYWpzL3Z1ZTMnO1xuXG5jb25zdCBwcm9wcyA9IGRlZmluZVByb3BzKHtcbiAgcHJvZHVjdHM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBkZWZhdWx0OiAoKSA9PiBbXVxuICB9LFxuICBhcnRpY2xlczoge1xuICAgIHR5cGU6IEFycmF5LFxuICAgIGRlZmF1bHQ6ICgpID0+IFtdXG4gIH1cbn0pO1xuXG5pbXBvcnQgeyB1c2VQYWdlIH0gZnJvbSAnQGluZXJ0aWFqcy92dWUzJztcbmNvbnN0IHBhZ2UgPSB1c2VQYWdlKCk7XG5jb25zdCBXSEFUU0FQUF9OVU1CRVIgPSBjb21wdXRlZCgoKSA9PiB7XG4gIGxldCBudW0gPSBwYWdlLnByb3BzLnNldHRpbmdzPy53aGF0c2FwcCB8fCAnMDgxMi0zNDU2LTc4OTAnO1xuICAvLyBjb252ZXJ0IDA4Li4uIHRvIDYyOC4uLiBhbmQgc3RyaXAgbm9uLWRpZ2l0c1xuICBudW0gPSBudW0ucmVwbGFjZSgvXFxEL2csJycpO1xuICBpZiAobnVtLnN0YXJ0c1dpdGgoJzAnKSkgbnVtID0gJzYyJyArIG51bS5zdWJzdHJpbmcoMSk7XG4gIHJldHVybiBudW07XG59KTtcblxuY29uc3QgTkFWX0xJTktTID0gW1xuICB7IGxhYmVsOiAnQmVyYW5kYScsIGhyZWY6ICcjYmVyYW5kYScgfSxcbiAgeyBsYWJlbDogJ1Byb2ZpbCcsIGhyZWY6ICcjcHJvZmlsJyB9LFxuICB7IGxhYmVsOiAnS2F0YWxvZycsIGhyZWY6ICcja2F0YWxvZycgfSxcbiAgeyBsYWJlbDogJ0FydGlrZWwgRWR1a2FzaScsIGhyZWY6ICcjYXJ0aWtlbCcgfSxcbiAgeyBsYWJlbDogJ0tvbnRhaycsIGhyZWY6ICcja29udGFrJyB9LFxuXTtcblxuY29uc3QgREVGQVVMVF9BUlRJQ0xFX0lNQUdFUyA9IFtcbiAgJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTkyOTgyNTM3NDQ3LTZmMjk2ZDBiYTk2Nz93PTcwMCZoPTQ4MCZmaXQ9Y3JvcCZhdXRvPWZvcm1hdCcsXG4gICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU4Njc3MTEwNzQ0NS1kM2FmOWUxNzNjNTI/dz03MDAmaD00ODAmZml0PWNyb3AmYXV0bz1mb3JtYXQnLFxuICAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MzA4MzYzNjkyNTAtZWY3MWEzZjVlNDNkP3c9NzAwJmg9NDgwJmZpdD1jcm9wJmF1dG89Zm9ybWF0JyxcbiAgJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTg1NDM3ODEyNTEzLTQzMzhlOTMyYjFiYT93PTcwMCZoPTQ4MCZmaXQ9Y3JvcCZhdXRvPWZvcm1hdCcsXG4gICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTYyMDY3NTUwNjUxOC0zZGYwNjZiYjJiMzA/dz03MDAmaD00ODAmZml0PWNyb3AmYXV0bz1mb3JtYXQnXG5dO1xuXG5cblxuY29uc3QgRklMVEVSUyA9IFsnU2VtdWEnLCAnUHVwdWsgT3JnYW5paycsICdQcm9iaW90aWsgUGV0ZXJuYWthbicsICdUZXJsYXJpcycsICdQb3B1bGVyJ107XG5cbmNvbnN0IFNUQVRTID0gW1xuICB7IHZhbHVlOiAnNTArJywgbGFiZWw6ICdNaXRyYSBUYW5pJyB9LFxuICB7IHZhbHVlOiAnMTAwJScsIGxhYmVsOiAnQmFoYW4gT3JnYW5paycgfSxcbiAgeyB2YWx1ZTogJzEwKycsIGxhYmVsOiAnVGFodW4gUGVuZ2FsYW1hbicgfSxcbiAgeyB2YWx1ZTogJ0RJWSAmIEphdGVuZycsIGxhYmVsOiAnSmFuZ2thdWFuIFBlbmdpcmltYW4nIH0sXG5dO1xuXG5jb25zdCBTVEVQUyA9IFtcbiAge1xuICAgIG46ICcwMScsXG4gICAgdGl0bGU6ICdQaWxpaCBQcm9kdWsnLFxuICAgIGRlc2M6ICdUZWx1c3VyaSBrYXRhbG9nIGRhbiB0ZW50dWthbiBwdXB1ayBhdGF1IHByb2Jpb3RpayB5YW5nIHNlc3VhaSBrZWJ1dHVoYW4gbGFoYW4gQW5kYS4nLFxuICAgIGljb246ICdiYXNrZXQnLFxuICB9LFxuICB7XG4gICAgbjogJzAyJyxcbiAgICB0aXRsZTogJ0h1YnVuZ2kgV2hhdHNBcHAnLFxuICAgIGRlc2M6ICdLbGlrIHRvbWJvbCBwZXNhbiwgY2hhdCBvdG9tYXRpcyB0ZXJpc2kuIFRpbSBrYW1pIHNpYXAgbWVtYmFudHUganVtbGFoIGRhbiBwZW5naXJpbWFuLicsXG4gICAgaWNvbjogJ2NoYXQnLFxuICB9LFxuICB7XG4gICAgbjogJzAzJyxcbiAgICB0aXRsZTogJ0tvbmZpcm1hc2kgJiBLaXJpbScsXG4gICAgZGVzYzogJ0tvbmZpcm1hc2kgcGVzYW5hbiBkYW4gYWxhbWF0LCBwcm9kdWsgZGlraXJpbSBrZSBzZWx1cnVoIERJWSBkYW4gSmF3YSBUZW5nYWguJyxcbiAgICBpY29uOiAndHJ1Y2snLFxuICB9LFxuXTtcblxuXG5cbmNvbnN0IFRFU1RJTU9OSUFMUyA9IFtcbiAge1xuICAgIHF1b3RlOiAnU2VqYWsgcGFrYWkgcHVwdWsgb3JnYW5payBQYW5kYXdhLCBzdHJ1a3R1ciB0YW5haCBzYXdhaCBtYWtpbiBnZW1idXIuIEhhc2lsIHBhbmVuIHBhZGkgbXVzaW0gaW5pIG1lbmluZ2thdCBkcmFzdGlzIGRhbiBiaWF5YSBwdXB1ayBraW1pYSBqYWRpIGphdWggbGViaWggaGVtYXQuJyxcbiAgICBuYW1lOiAnUGFrIE1hcm5vJyxcbiAgICByb2xlOiAnS2V0dWEgS2Vsb21wb2sgVGFuaSwgQ2FuZ2tyaW5nYW4nLFxuICAgIGltYWdlOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1OTk1NjYxNTAxNjMtMjkxOTRkY2FhZDM2P3c9MTUwJmg9MTUwJmZpdD1jcm9wJmF1dG89Zm9ybWF0J1xuICB9LFxuICB7XG4gICAgcXVvdGU6ICdQcm9iaW90aWsgdGVybmFrIGRhcmkgUGFuZGF3YSBiZW5hci1iZW5hciBhbXB1aCBtZW5naGlsYW5na2FuIGJhdSBrYW5kYW5nIGthbWJpbmcuIFNlbGFpbiBpdHUsIHRlcm5hayBqYWRpIGxlYmloIHNlaGF0IGRhbiBtYWthbm55YSBsYWhhcCBiYW5nZXQuJyxcbiAgICBuYW1lOiAnQnVkaSBTYW50b3NvJyxcbiAgICByb2xlOiAnUGV0ZXJuYWsgS2FtYmluZyBFdGF3YSwgU2xlbWFuJyxcbiAgICBpbWFnZTogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTM1NzEzODc1MDAyLWQxZDBjZjM3N2ZkZT93PTE1MCZoPTE1MCZmaXQ9Y3JvcCZhdXRvPWZvcm1hdCdcbiAgfSxcbiAge1xuICAgIHF1b3RlOiAnQXdhbG55YSByYWd1IGJlcmFsaWgga2Ugb3JnYW5paywgdGFwaSBzZXRlbGFoIGRpZGFtcGluZ2kgbGFuZ3N1bmcgb2xlaCB0aW0gUGFuZGF3YSwgc2VrYXJhbmcga2VidW4gc2F5dXIgc2F5YSAxMDAlIGJlYmFzIGtpbWlhLiBQYW5lbiBtZWxpbXBhaC4nLFxuICAgIG5hbWU6ICdJYnUgTmluZ3NpaCcsXG4gICAgcm9sZTogJ1BldGFuaSBTYXl1ciwgS2FsaXVyYW5nJyxcbiAgICBpbWFnZTogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTczNDk2MzU5MTQyLWI4ZDg3NzM0YTVhMj93PTE1MCZoPTE1MCZmaXQ9Y3JvcCZhdXRvPWZvcm1hdCdcbiAgfVxuXTtcblxuY29uc3QgRkFRUyA9IFtcbiAge1xuICAgIHE6ICdBcGFrYWggbWVsYXlhbmkgcGVtYmVsaWFuIGVjZXJhbiAoQjJDKT8nLFxuICAgIGE6ICdZYSwga2FtaSBtZWxheWFuaSBwZW1iZWxpYW4gZGFsYW0ganVtbGFoIGtlY2lsIHVudHVrIGtvbnN1bWVuIHVtdW0gbWF1cHVuIGtlYnV0dWhhbiBydW1haCB0YW5nZ2EuJ1xuICB9LFxuICB7XG4gICAgcTogJ0JhZ2FpbWFuYSBjYXJhIG1lbmphZGkgYWdlbiBhdGF1IG1pdHJhIFBhbmRhd2E/JyxcbiAgICBhOiAnQW5kYSBkYXBhdCBtZW5naHVidW5naSBrYW1pIHZpYSBXaGF0c0FwcC4gS2FtaSBtZW1pbGlraSBwcm9ncmFtIGtlbWl0cmFhbiBraHVzdXMgZGVuZ2FuIGhhcmdhIGdyb3NpciB1bnR1ayBrZWxvbXBvayB0YW5pIGRhbiB0b2tvIHBlcnRhbmlhbi4nXG4gIH0sXG4gIHtcbiAgICBxOiAnQXBha2FoIHB1cHVrIG9yZ2FuaWsgY2FpciAoUE9DKSBiaXNhIGRpY2FtcHVyIHBlc3Rpc2lkYSBraW1pYT8nLFxuICAgIGE6ICdTZWJhaWtueWEgaGluZGFyaSBtZW5jYW1wdXIgUE9DIGRlbmdhbiBiYWhhbiBraW1pYSBzaW50ZXRpcyBhZ2FyIG1pa3JvYmEgYmFpayBkaSBkYWxhbSBwdXB1ayB0ZXRhcCBoaWR1cCBkYW4gYmVrZXJqYSBtYWtzaW1hbCBkaSB0YW5haC4nXG4gIH0sXG4gIHtcbiAgICBxOiAnQXBha2FoIGFkYSBiaWF5YSBwZW5naXJpbWFuPycsXG4gICAgYTogJ0dyYXRpcyBvbmdrb3Mga2lyaW0gdW50dWsgd2lsYXlhaCBTbGVtYW4gZGVuZ2FuIG1pbmltYWwgcGVtYmVsaWFuIHRlcnRlbnR1LiBVbnR1ayBsdWFyIGRhZXJhaCwgb25na2lyIGRpc2VzdWFpa2FuIGRlbmdhbiBqYXNhIGVrc3BlZGlzaS9rYXJnby4nXG4gIH1cbl07XG5cbmZ1bmN0aW9uIHdhTGluayhwcm9kdWN0TmFtZSA9ICcnKSB7XG4gIGNvbnN0IHRleHQgPSBwcm9kdWN0TmFtZVxuICAgID8gYEhhbG8gUGFuZGF3YSBLZW5jYW5hIE11bHRpIEZhcm0sIHNheWEgaW5naW4gbWVtZXNhbiAqJHtwcm9kdWN0TmFtZX0qLlxcblxcbkp1bWxhaDogXFxuQWxhbWF0IHBlbmdpcmltYW46IFxcblxcbk1vaG9uIGluZm8ga2V0ZXJzZWRpYWFuIGRhbiB0b3RhbG55YS4gVGVyaW1hIGthc2loLmBcbiAgICA6ICdIYWxvIFBhbmRhd2EgS2VuY2FuYSBNdWx0aSBGYXJtLCBzYXlhIGluZ2luIGJlcnRhbnlhIHRlbnRhbmcgcHJvZHVrIHB1cHVrIG9yZ2FuaWsgZGFuIHByb2Jpb3Rpa255YS4nO1xuICByZXR1cm4gYGh0dHBzOi8vd2EubWUvJHtXSEFUU0FQUF9OVU1CRVIudmFsdWV9P3RleHQ9JHtlbmNvZGVVUklDb21wb25lbnQodGV4dCl9YDtcbn1cblxuY29uc3QgbWVudU9wZW4gPSByZWYoZmFsc2UpO1xuY29uc3QgZmlsdGVyID0gcmVmKCdTZW11YScpO1xuY29uc3QgYWN0aXZlRmFxID0gcmVmKG51bGwpO1xuXG5jb25zdCB0b2dnbGVGYXEgPSAoaWR4KSA9PiB7XG4gIGFjdGl2ZUZhcS52YWx1ZSA9IGFjdGl2ZUZhcS52YWx1ZSA9PT0gaWR4ID8gbnVsbCA6IGlkeDtcbn07XG5cbmNvbnN0IHZpc2libGVQcm9kdWN0cyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgaWYgKGZpbHRlci52YWx1ZSA9PT0gJ1NlbXVhJykgcmV0dXJuIHByb3BzLnByb2R1Y3RzO1xuICBpZiAoZmlsdGVyLnZhbHVlID09PSAnVGVybGFyaXMnIHx8IGZpbHRlci52YWx1ZSA9PT0gJ1BvcHVsZXInKSB7XG4gICAgcmV0dXJuIHByb3BzLnByb2R1Y3RzLmZpbHRlcihwID0+IHAuYmFkZ2UgJiYgcC5iYWRnZS50b0xvd2VyQ2FzZSgpID09PSBmaWx0ZXIudmFsdWUudG9Mb3dlckNhc2UoKSk7XG4gIH1cbiAgcmV0dXJuIHByb3BzLnByb2R1Y3RzLmZpbHRlcihwID0+IHAuY2F0ZWdvcnkgPT09IGZpbHRlci52YWx1ZSk7XG59KTtcblxuY29uc3Qgc2hvd0xlYWRNb2RhbCA9IHJlZihmYWxzZSk7XG5jb25zdCBsZWFkUHJvZHVjdE5hbWUgPSByZWYoJycpO1xuXG5jb25zdCBsZWFkRm9ybSA9IHVzZUZvcm0oe1xuICBuYW1lOiAnJyxcbiAgcGhvbmU6ICcnLFxuICBtZXNzYWdlOiAnJ1xufSk7XG5cbmNvbnN0IG9wZW5Nb2RhbCA9IChwcm9kdWN0TmFtZSA9ICcnKSA9PiB7XG4gIGxlYWRQcm9kdWN0TmFtZS52YWx1ZSA9IHByb2R1Y3ROYW1lO1xuICBsZWFkRm9ybS5tZXNzYWdlID0gcHJvZHVjdE5hbWUgPyBgU2F5YSBpbmdpbiBwZXNhbiAke3Byb2R1Y3ROYW1lfWAgOiAnJztcbiAgc2hvd0xlYWRNb2RhbC52YWx1ZSA9IHRydWU7XG59O1xuXG5jb25zdCBjbG9zZU1vZGFsID0gKCkgPT4ge1xuICBzaG93TGVhZE1vZGFsLnZhbHVlID0gZmFsc2U7XG4gIGxlYWRGb3JtLnJlc2V0KCk7XG59O1xuXG5jb25zdCBzdWJtaXRMZWFkID0gKCkgPT4ge1xuICBsZWFkRm9ybS5wb3N0KCcvbGVhZCcsIHtcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcbiAgICAgIHdpbmRvdy5vcGVuKHdhTGluayhsZWFkUHJvZHVjdE5hbWUudmFsdWUpLCAnX2JsYW5rJyk7XG4gICAgICBjbG9zZU1vZGFsKCk7XG4gICAgfVxuICB9KTtcbn07XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8SGVhZCB0aXRsZT1cIlBhbmRhd2EgS2VuY2FuYSB8IFBlcnRhbmlhbiBCZXJrZWxhbmp1dGFuXCIgLz5cblxuICA8ZGl2IGNsYXNzPVwibWluLWgtc2NyZWVuIGJnLWNyZWFtIHRleHQtYmFyayBmb250LXNhbnNcIj5cbiAgICA8IS0tIFRvcCBCYXIgLS0+XG4gICAgPGRpdiBjbGFzcz1cImhpZGRlbiBiZy1tb3NzIHRleHQtY3JlYW0vOTAgbWQ6YmxvY2tcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJteC1hdXRvIGZsZXggbWF4LXctNnhsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBweS0yIHRleHQteHNcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImNsb2NrXCIgY2xhc3M9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICBCdWthIFNlbuKAk0p1bTogMDguMDDigJMxNi4wMCBXSUJcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInBpblwiIGNsYXNzPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgRGVzYSBDYW5na3JpbmdhbiwgU2xlbWFuXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBAY2xpY2s9XCJvcGVuTW9kYWwoKVwiIGNsYXNzPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1zcHJvdXRcIj5cbiAgICAgICAgICA8SWNvbiBuYW1lPVwiY2hhdFwiIGNsYXNzPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgIEN1c3RvbWVyIFNlcnZpY2U6IHt7ICRwYWdlLnByb3BzLnNldHRpbmdzPy53aGF0c2FwcCB8fCAnMDgxMi0zNDU2LTc4OTAnIH19XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8IS0tIE5hdmJhciAtLT5cbiAgICA8aGVhZGVyIGNsYXNzPVwic3RpY2t5IHRvcC0wIHotNTAgYm9yZGVyLWIgYm9yZGVyLWxlYWYvMTUgYmctY3JlYW0vODUgYmFja2Ryb3AtYmx1ci1tZFwiPlxuICAgICAgPGRpdiBjbGFzcz1cIm14LWF1dG8gZmxleCBtYXgtdy02eGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTRcIj5cbiAgICAgICAgPGEgaHJlZj1cIiNiZXJhbmRhXCIgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLW1vc3MgdGV4dC1jcmVhbVwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImxlYWZcIiBjbGFzcz1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImxlYWRpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmxvY2sgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LW1vc3NcIj5QYW5kYXdhIEtlbmNhbmE8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJsb2NrIHRleHQtWzAuN3JlbV0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjJlbV0gdGV4dC1sZWFmXCI+TXVsdGkgRmFybTwvc3Bhbj5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvYT5cblxuICAgICAgICA8bmF2IGNsYXNzPVwiaGlkZGVuIGl0ZW1zLWNlbnRlciBnYXAtOCBsZzpmbGV4XCI+XG4gICAgICAgICAgPGEgdi1mb3I9XCJsIGluIE5BVl9MSU5LU1wiIDprZXk9XCJsLmhyZWZcIiA6aHJlZj1cImwuaHJlZlwiIGNsYXNzPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJhcmsvNzAgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1tb3NzXCI+XG4gICAgICAgICAgICB7eyBsLmxhYmVsIH19XG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L25hdj5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8YnV0dG9uIEBjbGljaz1cIm9wZW5Nb2RhbCgpXCIgY2xhc3M9XCJoaWRkZW4gcm91bmRlZC1mdWxsIGJnLW1vc3MgcHgtNSBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWNyZWFtIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWxlYWYgc206aW5saW5lLWZsZXhcIj5cbiAgICAgICAgICAgIFBlc2FuIFNla2FyYW5nXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGVhZi8yMCB0ZXh0LW1vc3MgbGc6aGlkZGVuXCIgQGNsaWNrPVwibWVudU9wZW4gPSAhbWVudU9wZW5cIiBhcmlhLWxhYmVsPVwiQnVrYSBtZW51XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJibG9jayBoLTAuNSB3LTUgYmctY3VycmVudFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJibG9jayBoLTAuNSB3LTUgYmctY3VycmVudFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJibG9jayBoLTAuNSB3LTUgYmctY3VycmVudFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8bmF2IHYtaWY9XCJtZW51T3BlblwiIGNsYXNzPVwiYm9yZGVyLXQgYm9yZGVyLWxlYWYvMTUgYmctY3JlYW0gcHgtNiBweS00IGxnOmhpZGRlblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgIDxhIHYtZm9yPVwibCBpbiBOQVZfTElOS1NcIiA6a2V5PVwibC5ocmVmXCIgOmhyZWY9XCJsLmhyZWZcIiBAY2xpY2s9XCJtZW51T3BlbiA9IGZhbHNlXCIgY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYmFyay84MFwiPlxuICAgICAgICAgICAge3sgbC5sYWJlbCB9fVxuICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8YnV0dG9uIEBjbGljaz1cIm9wZW5Nb2RhbCgpXCIgY2xhc3M9XCJtdC0xIHJvdW5kZWQtZnVsbCBiZy1tb3NzIHB4LTUgcHktMi41IHRleHQtY2VudGVyIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWNyZWFtXCI+XG4gICAgICAgICAgICBQZXNhbiBTZWthcmFuZ1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbmF2PlxuICAgIDwvaGVhZGVyPlxuXG4gICAgPCEtLSBIZXJvIC0tPlxuICAgIDxzZWN0aW9uIGlkPVwiYmVyYW5kYVwiIGNsYXNzPVwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMFwiPlxuICAgICAgICA8aW1nIHNyYz1cImh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTU4Mzg4NTU2LTIyNjFkNGNjMTkzOD93PTE2MDAmaD0xMDAwJmZpdD1jcm9wJmF1dG89Zm9ybWF0XCIgYWx0PVwiTGFoYW4gcGVydGFuaWFuIG9yZ2FuaWsgZGkgRGVzYSBDYW5na3JpbmdhblwiIGNsYXNzPVwiaC1mdWxsIHctZnVsbCBiZy1tb3NzIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWxpbmVhci10by1yIGZyb20tYmFyay84NSB2aWEtbW9zcy83MCB0by1tb3NzLzI1XCI+PC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIG14LWF1dG8gZ3JpZCBtYXgtdy02eGwgZ3JpZC1jb2xzLTEgZ2FwLTEwIHB4LTYgcHktMjAgbWQ6cHktMzIgbGc6Z3JpZC1jb2xzLTEyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsZzpjb2wtc3Bhbi04XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItY3JlYW0vMzAgYmctY3JlYW0vMTAgcHgtNCBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMThlbV0gdGV4dC1jcmVhbS85MFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJoLTEuNSB3LTEuNSByb3VuZGVkLWZ1bGwgYmctc3Byb3V0XCI+PC9zcGFuPlxuICAgICAgICAgICAgQ1YgUGFuZGF3YSBLZW5jYW5hIE11bHRpIEZhcm0gwrcgU2xlbWFuLCBZb2d5YWthcnRhXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxoMSBjbGFzcz1cIm10LTYgZm9udC1kaXNwbGF5IHRleHQtNHhsIGZvbnQtc2VtaWJvbGQgbGVhZGluZy1bMS4wNV0gdGV4dC1jcmVhbSBzbTp0ZXh0LTV4bCBtZDp0ZXh0LTZ4bFwiPlxuICAgICAgICAgICAge3sgJHBhZ2UucHJvcHMuc2V0dGluZ3M/LmhlYWRsaW5lIHx8ICdQdXB1ayBPcmdhbmlrICYgUHJvYmlvdGlrIEJlcmt1YWxpdGFzIHVudHVrIFBhbmVuIE1lbGltcGFoJyB9fVxuICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPHAgY2xhc3M9XCJtdC01IG1heC13LXhsIHRleHQtbGcgbGVhZGluZy1yZWxheGVkIHRleHQtY3JlYW0vODVcIj5cbiAgICAgICAgICAgIFByb2R1c2VuIHB1cHVrIG9yZ2FuaWsgZGFuIHByb2Jpb3RpayB0ZXJwZXJjYXlhIGRhcmkgRGVzYSBDYW5na3JpbmdhbiB1bnR1ayBoYXNpbCBwYW5lbiBvcHRpbWFsIGRhbiByYW1haCBsaW5na3VuZ2FuLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtOCBmbGV4IGZsZXgtd3JhcCBnYXAtM1wiPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNrYXRhbG9nXCIgY2xhc3M9XCJyb3VuZGVkLWZ1bGwgYmctc3Byb3V0IHB4LTcgcHktMy41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJhcmsgc2hhZG93LWxnIHNoYWRvdy1iYXJrLzIwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6YmctY3JlYW1cIj5cbiAgICAgICAgICAgICAgTGloYXQgS2F0YWxvZ1xuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNwcm9maWxcIiBjbGFzcz1cInJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWNyZWFtLzQwIHB4LTcgcHktMy41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWNyZWFtIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWNyZWFtLzEwXCI+XG4gICAgICAgICAgICAgIFBlbGFqYXJpIExlYmloIExhbmp1dFxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cblxuICAgIDwhLS0gU3RhdGlzdGlrIC0tPlxuICAgIDxzZWN0aW9uIGNsYXNzPVwiYm9yZGVyLXkgYm9yZGVyLWxlYWYvMTUgYmctc2FuZFwiPlxuICAgICAgPGRpdiBjbGFzcz1cIm14LWF1dG8gZ3JpZCBtYXgtdy02eGwgZ3JpZC1jb2xzLTIgZ2FwLTYgcHgtNiBweS04IGxnOmdyaWQtY29scy00XCI+XG4gICAgICAgIDxkaXYgdi1mb3I9XCJzIGluIFNUQVRTXCIgOmtleT1cInMubGFiZWxcIiBjbGFzcz1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPHAgY2xhc3M9XCJmb250LWRpc3BsYXkgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LW1vc3MgbWQ6dGV4dC0zeGxcIj57eyBzLnZhbHVlIH19PC9wPlxuICAgICAgICAgIDxwIGNsYXNzPVwibXQtMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtYmFyay82MCBtZDp0ZXh0LXNtXCI+e3sgcy5sYWJlbCB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8IS0tIFRlbnRhbmcgS2FtaSAmIFByb2ZpbCBQZXJ1c2FoYWFuIC0tPlxuICAgIDxzZWN0aW9uIGlkPVwicHJvZmlsXCIgY2xhc3M9XCJteC1hdXRvIG1heC13LTZ4bCBweC02IHB5LTIwIG1kOnB5LTI4XCI+XG4gICAgICA8IS0tIFRFTlRBTkcgS0FNSSAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIGl0ZW1zLWNlbnRlciBnYXAtMTIgbGc6Z3JpZC1jb2xzLTEyIG1iLTIwIG1kOm1iLTI0XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBsZzpjb2wtc3Bhbi01XCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTN4bFwiPlxuICAgICAgICAgICAgPGltZyBzcmM9XCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU5Nzg2ODE2NTk1Ni0wM2E2ODI3OTU1YjE/dz05MDAmaD0xMDAwJmZpdD1jcm9wJmF1dG89Zm9ybWF0XCIgYWx0PVwiUHJvc2VzIHByb2R1a3NpIHB1cHVrIG9yZ2FuaWtcIiBjbGFzcz1cImgtZnVsbCB3LWZ1bGwgYmctcGFyY2htZW50IG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIC1ib3R0b20tNiAtcmlnaHQtNCBoaWRkZW4gcm91bmRlZC0yeGwgYmctbW9zcyBweC02IHB5LTUgdGV4dC1jcmVhbSBzaGFkb3cteGwgc206YmxvY2tcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzPVwiZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtc2VtaWJvbGRcIj4xMCs8L3A+XG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtWzAuNjVyZW1dIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1jcmVhbS84MCBtdC0xXCI+VGFodW4gTWVsYXlhbmkgUGV0YW5pPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwibGc6Y29sLXNwYW4tN1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4yZW1dIHRleHQtbGVhZlwiPlRlbnRhbmcgS2FtaTwvc3Bhbj5cbiAgICAgICAgICA8aDIgY2xhc3M9XCJtdC0zIGZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LXNlbWlib2xkIGxlYWRpbmctdGlnaHQgdGV4dC1tb3NzIG1kOnRleHQtNHhsXCI+XG4gICAgICAgICAgICBMYWhpciBkYXJpIHRhbmFoIENhbmdrcmluZ2FuLCB0dW1idWggYmVyc2FtYSBwZXRhbmkuXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzcz1cIm10LTUgbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay83NVwiPlxuICAgICAgICAgICAgUGFuZGF3YSBLZW5jYW5hIE11bHRpIEZhcm0gYWRhbGFoIHVzYWhhIHBlcnRhbmlhbiB5YW5nIGJlcmxva2FzaSBkaSBEZXNhIENhbmdrcmluZ2FuLCBTbGVtYW4uIEthbWkgbWVtcHJvZHVrc2kgcHVwdWsgb3JnYW5payBkYW4gcHJvYmlvdGlrIHVudHVrIG1lbmdlbWJhbGlrYW4ga2VzdWJ1cmFuIHRhbmFoIHNlY2FyYSBhbGFtaSB0YW5wYSBtZXJ1c2FrIGxpbmdrdW5nYW4uXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwIGNsYXNzPVwibXQtNCBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1iYXJrLzc1XCI+XG4gICAgICAgICAgICBLb21pdG1lbiBrYW1pIHNlZGVyaGFuYTogbWVuZHVrdW5nIHBlcnRhbmlhbiBiZXJrZWxhbmp1dGFuIHlhbmcgc2VoYXQgYmFnaSB0YW5haCwgdGFuYW1hbiwgZGFuIGdlbmVyYXNpIG1lbmRhdGFuZy4gU2V0aWFwIHByb2R1ayBrYW1pIGRpYnVhdCBkZW5nYW4ga2V0ZWxpdGlhbiBhZ2FyIG1pdHJhIHRhbmkgbWVtcGVyb2xlaCBoYXNpbCBwYW5lbiB0ZXJiYWlrLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICBcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibXktOCBoLXB4IHctZnVsbCBiZy1sZWFmLzE1XCI+PC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZ2FwLTEyXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cImZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LXNlbWlib2xkIHRleHQtbW9zc1wiPjUwMCs8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJhcmsvNjAgbXQtMVwiPk1pdHJhIFRhbmkgVGVyYmFudHU8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzPVwiZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzXCI+MTAwJTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYmFyay82MCBtdC0xXCI+QmFoYW4gT3JnYW5payBBbGFtaTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8IS0tIFBST0ZJTCBQRVJVU0FIQUFOIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cIm1heC13LTR4bFwiPlxuICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMmVtXSB0ZXh0LWxlYWZcIj5Qcm9maWwgUGVydXNhaGFhbjwvc3Bhbj5cbiAgICAgICAgPGgyIGNsYXNzPVwibXQtMyBmb250LWRpc3BsYXkgdGV4dC0zeGwgZm9udC1zZW1pYm9sZCBsZWFkaW5nLXRpZ2h0IHRleHQtbW9zcyBtZDp0ZXh0LTR4bFwiPlxuICAgICAgICAgIE1lbmR1a3VuZyBla29zaXN0ZW0gcGVydGFuaWFuIGxva2FsIFNsZW1hblxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzcz1cIm10LTUgbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay83NVwiPlxuICAgICAgICAgIENWIFBhbmRhd2EgS2VuY2FuYSBNdWx0aSBGYXJtIGJlcmRpcmkgZGkgRGVzYSBDYW5na3JpbmdhbiBkZW5nYW4gdmlzaSBtZW1hanVrYW4gcGVydGFuaWFuIGJlcmtlbGFuanV0YW4uIEthbWkgbWVtcHJvZHVrc2kgcHVwdWsgb3JnYW5payBkYW4gcHJvYmlvdGlrIGJlcmt1YWxpdGFzIHVudHVrIG1lbmdlbWJhbGlrYW4ga2VzdWJ1cmFuIHRhbmFoIHNlY2FyYSBhbGFtaS5cbiAgICAgICAgPC9wPlxuICAgICAgICA8cCBjbGFzcz1cIm10LTQgbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay83NVwiPlxuICAgICAgICAgIExlYmloIGRhcmkgc2VrYWRhciBwcm9kdXNlbiwga2FtaSBoYWRpciBzZWJhZ2FpIG1pdHJhIGVkdWthc2kgYmFnaSBrZWxvbXBvayB0YW5pIOKAlCBtZW5kYW1waW5naSBkYXJpIHBlbWlsaWhhbiBwcm9kdWssIGFwbGlrYXNpLCBoaW5nZ2EgcGFuZW4sIGFnYXIgaGFzaWwgbWVsaW1wYWggZGFuIHJhbWFoIGxpbmdrdW5nYW4uXG4gICAgICAgIDwvcD5cbiAgICAgICAgPHVsIGNsYXNzPVwibXQtNyBncmlkIGdhcC00IHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgPGxpIHYtZm9yPVwiaXRlbSBpbiBbJ1Byb2R1a3NpIGxva2FsIERlc2EgQ2FuZ2tyaW5nYW4nLCAnUGVuZGFtcGluZ2FuIG1pdHJhIHRhbmkgQjJCJywgJ01lbGF5YW5pIGtvbnN1bWVuIHVtdW0gQjJDJywgJ1BlbmdpcmltYW4gc2UtRElZICYgSmF0ZW5nJ11cIiA6a2V5PVwiaXRlbVwiIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSB0ZXh0LXNtIHRleHQtYmFyay84MFwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImNoZWNrXCIgY2xhc3M9XCJoLTQgdy00IHNocmluay0wIHRleHQtbGVhZlwiIC8+XG4gICAgICAgICAgICB7eyBpdGVtIH19XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgPC91bD5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cblxuICAgIDwhLS0gS2F0YWxvZyBQcm9kdWsgLS0+XG4gICAgPHNlY3Rpb24gaWQ9XCJrYXRhbG9nXCIgY2xhc3M9XCJiZy1zYW5kIHB5LTIwIG1kOnB5LTI4XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibXgtYXV0byBtYXgtdy02eGwgcHgtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibXgtYXV0byBtYXgtdy0yeGwgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMmVtXSB0ZXh0LWxlYWZcIj5LYXRhbG9nIFByb2R1azwvc3Bhbj5cbiAgICAgICAgICA8aDIgY2xhc3M9XCJtdC0zIGZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LXNlbWlib2xkIHRleHQtbW9zcyBtZDp0ZXh0LTR4bFwiPlxuICAgICAgICAgICAgTnV0cmlzaSB0ZXJiYWlrIHVudHVrIGxhaGFuICYgdGVybmFrXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzcz1cIm10LTQgdGV4dC1iYXJrLzcwXCI+XG4gICAgICAgICAgICBTYXJpbmcgYmVyZGFzYXJrYW4ga2F0ZWdvcmksIGxhbHUgcGVzYW4gbGFuZ3N1bmcgdmlhIFdoYXRzQXBwIGRlbmdhbiBmb3JtIG90b21hdGlzLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBGaWx0ZXIgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xMCBmbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxidXR0b24gdi1mb3I9XCJmIGluIEZJTFRFUlNcIiA6a2V5PVwiZlwiIEBjbGljaz1cImZpbHRlciA9IGZcIiA6Y2xhc3M9XCJbJ3JvdW5kZWQtZnVsbCBweC01IHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzJywgZmlsdGVyID09PSBmID8gJ2JnLW1vc3MgdGV4dC1jcmVhbScgOiAnYm9yZGVyIGJvcmRlci1sZWFmLzI1IGJnLWNyZWFtIHRleHQtYmFyay83MCBob3Zlcjpib3JkZXItbGVhZi81MCddXCI+XG4gICAgICAgICAgICB7eyBmIH19XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xMCBncmlkIGdyaWQtY29scy0xIGdhcC03IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgPGFydGljbGUgdi1mb3I9XCJwIGluIHZpc2libGVQcm9kdWN0c1wiIDprZXk9XCJwLm5hbWVcIiBjbGFzcz1cImdyb3VwIGZsZXggZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItbGVhZi8xMCBiZy1jcmVhbSBzaGFkb3ctc20gdHJhbnNpdGlvbi1zaGFkb3cgaG92ZXI6c2hhZG93LWxnXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgYXNwZWN0LTQvMyBvdmVyZmxvdy1oaWRkZW4gYmctcGFyY2htZW50XCI+XG4gICAgICAgICAgICAgIDxpbWcgOnNyYz1cInAuaW1hZ2VfcGF0aCA/ICcvc3RvcmFnZS8nICsgcC5pbWFnZV9wYXRoIDogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTk5ODM5NjE5NzIyLTM5NzUxNDExZWE2Mz9peGxpYj1yYi00LjAuMyZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZ3PTQwMCZxPTgwJ1wiIDphbHQ9XCJwLm5hbWVcIiBjbGFzcz1cImgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvdmVyIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMCBncm91cC1ob3ZlcjpzY2FsZS0xMDVcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiB2LWlmPVwicC5iYWRnZVwiIDpjbGFzcz1cIlsnYWJzb2x1dGUgbGVmdC0zIHRvcC0zIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEgdGV4dC1bMC43cmVtXSBmb250LXNlbWlib2xkIHRleHQtY3JlYW0nLCBwLmJhZGdlVG9uZSA9PT0gJ2NsYXknID8gJ2JnLWNsYXknIDogJ2JnLWxlYWYnXVwiPlxuICAgICAgICAgICAgICAgIHt7IHAuYmFkZ2UgfX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTMgcm91bmRlZC1mdWxsIGJnLWNyZWFtLzkwIHB4LTMgcHktMSB0ZXh0LVswLjdyZW1dIGZvbnQtbWVkaXVtIHRleHQtbW9zc1wiPlxuICAgICAgICAgICAgICAgIHt7IHAuY2F0ZWdvcnkgfX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgcC01XCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzcz1cImZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzXCI+e3sgcC5uYW1lIH19PC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJtdC0yIGZsZXgtMSB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWJhcmsvNzBcIj57eyBwLmRlc2MgfX08L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzPVwibXQtNCBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtY2xheVwiPnt7IHAucHJpY2UgfX08L3A+XG4gICAgICAgICAgICAgIDxidXR0b24gQGNsaWNrPVwib3Blbk1vZGFsKHAubmFtZSlcIiBjbGFzcz1cIm10LTQgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtZnVsbCBiZy1tb3NzIHB4LTQgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWNyZWFtIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWxlYWZcIj5cbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwid2hhdHNhcHBcIiBjbGFzcz1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgIFBlc2FuIHZpYSBXaGF0c0FwcFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8IS0tIFRlc3RpbW9uaSAtLT5cbiAgICA8c2VjdGlvbiBjbGFzcz1cImJnLXNhbmQgcHktMjAgbWQ6cHktMjhcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJteC1hdXRvIG1heC13LTZ4bCBweC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBtYi0xNFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4yZW1dIHRleHQtbGVhZlwiPkthdGEgTWVyZWthPC9zcGFuPlxuICAgICAgICAgIDxoMiBjbGFzcz1cIm10LTMgZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzIG1kOnRleHQtNHhsXCI+XG4gICAgICAgICAgICBCdWt0aSBueWF0YSBkaSBsYWhhbiBwZXRhbmlcbiAgICAgICAgICA8L2gyPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICA8ZGl2IHYtZm9yPVwiKHQsIGkpIGluIFRFU1RJTU9OSUFMU1wiIDprZXk9XCJpXCIgY2xhc3M9XCJyb3VuZGVkLTN4bCBiZy1jcmVhbSBwLTggc2hhZG93LXNtIGJvcmRlciBib3JkZXItbGVhZi8xMCByZWxhdGl2ZSBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiY2hhdFwiIGNsYXNzPVwiYWJzb2x1dGUgcmlnaHQtOCB0b3AtOCBoLTggdy04IHRleHQtbGVhZi8xMFwiIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWItNiBmbGV4IGdhcC0xIHRleHQtYW1iZXItNDAwXCI+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjaGVja1wiIGNsYXNzPVwiaC00IHctNFwiIHYtZm9yPVwibiBpbiA1XCIgOmtleT1cIm5cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay84MCBtYi04IGl0YWxpY1wiPlwie3sgdC5xdW90ZSB9fVwiPC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG10LWF1dG9cIj5cbiAgICAgICAgICAgICAgPGltZyA6c3JjPVwidC5pbWFnZVwiIGNsYXNzPVwiaC0xMiB3LTEyIHJvdW5kZWQtZnVsbCBvYmplY3QtY292ZXIgYm9yZGVyIGJvcmRlci1sZWFmLzIwXCIgLz5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LW1vc3MgdGV4dC1zbVwiPnt7IHQubmFtZSB9fTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtWzAuNjVyZW1dIHRleHQtYmFyay82MCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+e3sgdC5yb2xlIH19PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cblxuICAgIDwhLS0gQWx1ciBQZW1lc2FuYW4gLS0+XG4gICAgPHNlY3Rpb24gY2xhc3M9XCJteC1hdXRvIG1heC13LTZ4bCBweC02IHB5LTIwIG1kOnB5LTI4XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibXgtYXV0byBtYXgtdy0yeGwgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjJlbV0gdGV4dC1sZWFmXCI+QWx1ciBQZW1lc2FuYW48L3NwYW4+XG4gICAgICAgIDxoMiBjbGFzcz1cIm10LTMgZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzIG1kOnRleHQtNHhsXCI+XG4gICAgICAgICAgVGlnYSBsYW5na2FoIG11ZGFoIHVudHVrIG1lbWVzYW5cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPHAgY2xhc3M9XCJtdC00IHRleHQtYmFyay83MFwiPlxuICAgICAgICAgIFNlZGVyaGFuYSBkYW4gY2VwYXQg4oCUIGRpcmFuY2FuZyBhZ2FyIHNlbXVhIGthbGFuZ2FuIHBldGFuaSBiaXNhIG1lbWVzYW4gdGFucGEgcmliZXQuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzPVwibXQtMTQgZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBtZDpncmlkLWNvbHMtM1wiPlxuICAgICAgICA8ZGl2IHYtZm9yPVwiKHMsIGkpIGluIFNURVBTXCIgOmtleT1cInMublwiIGNsYXNzPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaC1mdWxsIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItbGVhZi8xMiBiZy1jcmVhbSBwLTdcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmbGV4IGgtMTIgdy0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1zYW5kIHRleHQtbW9zc1wiPlxuICAgICAgICAgICAgICAgIDxJY29uIDpuYW1lPVwicy5pY29uXCIgY2xhc3M9XCJoLTYgdy02XCIgLz5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LXNlbWlib2xkIHRleHQtbGVhZi8yNVwiPnt7IHMubiB9fTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgzIGNsYXNzPVwibXQtNSBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtbW9zc1wiPnt7IHMudGl0bGUgfX08L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3M9XCJtdC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay83MFwiPnt7IHMuZGVzYyB9fTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHYtaWY9XCJpIDwgU1RFUFMubGVuZ3RoIC0gMVwiIGNsYXNzPVwiYWJzb2x1dGUgLXJpZ2h0LTMgdG9wLTEvMiBoaWRkZW4gLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWxlYWYvNDAgbWQ6YmxvY2tcIj5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwiaC02IHctNlwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuXG4gICAgPCEtLSBGQVEgLS0+XG4gICAgPHNlY3Rpb24gY2xhc3M9XCJteC1hdXRvIG1heC13LTN4bCBweC02IHB5LTIwIG1kOnB5LTI4XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgbWItMTJcIj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjJlbV0gdGV4dC1sZWFmXCI+VGFueWEgSmF3YWI8L3NwYW4+XG4gICAgICAgIDxoMiBjbGFzcz1cIm10LTMgZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzIG1kOnRleHQtNHhsXCI+XG4gICAgICAgICAgUGVydGFueWFhbiB5YW5nIHNlcmluZyBkaWFqdWthblxuICAgICAgICA8L2gyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS00XCI+XG4gICAgICAgIDxkaXYgdi1mb3I9XCIoZmFxLCBpKSBpbiBGQVFTXCIgOmtleT1cImlcIiBjbGFzcz1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItbGVhZi8xNSBiZy1jcmVhbSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8YnV0dG9uIEBjbGljaz1cInRvZ2dsZUZhcShpKVwiIGNsYXNzPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTUgdGV4dC1sZWZ0IGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWxlYWYvNVwiPlxuICAgICAgICAgICAgPHNwYW4+e3sgZmFxLnEgfX08L3NwYW4+XG4gICAgICAgICAgICA8SWNvbiA6bmFtZT1cImFjdGl2ZUZhcSA9PT0gaSA/ICdjaGVjaycgOiAncGx1cydcIiBjbGFzcz1cImgtNSB3LTUgc2hyaW5rLTAgdGV4dC1sZWFmIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiIDpjbGFzcz1cInsgJ3JvdGF0ZS0xODAnOiBhY3RpdmVGYXEgPT09IGkgfVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGRpdiB2LXNob3c9XCJhY3RpdmVGYXEgPT09IGlcIiBjbGFzcz1cInB4LTYgcGItNiBwdC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay83NVwiPlxuICAgICAgICAgICAge3sgZmFxLmEgfX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8IS0tIEFydGlrZWwgLyBFZHVrYXNpIFRhbmkgLS0+XG4gICAgPHNlY3Rpb24gaWQ9XCJhcnRpa2VsXCIgY2xhc3M9XCJiZy1zYW5kIHB5LTIwIG1kOnB5LTI4XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibXgtYXV0byBtYXgtdy02eGwgcHgtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgc206ZmxleC1yb3cgc206aXRlbXMtZW5kXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm1heC13LXhsXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMmVtXSB0ZXh0LWxlYWZcIj5BcnRpa2VsICYgRWR1a2FzaSBUYW5pPC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzPVwibXQtMyBmb250LWRpc3BsYXkgdGV4dC0zeGwgZm9udC1zZW1pYm9sZCB0ZXh0LW1vc3MgbWQ6dGV4dC00eGxcIj5cbiAgICAgICAgICAgICAgQmVsYWphciBiZXJ0YW5pIGxlYmloIGNlcmRhc1xuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzPVwibXQtNCB0ZXh0LWJhcmsvNzBcIj5cbiAgICAgICAgICAgICAgQmFnaWFuIGRhcmkgcHJvZ3JhbSBsaXRlcmFzaSB0YW5pIHVudHVrIG1hc3lhcmFrYXQgRGVzYSBDYW5na3Jpbmdhbi5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8TGluayBocmVmPVwiL2FydGljbGVzXCIgY2xhc3M9XCJzaHJpbmstMCByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1sZWFmLzMwIHB4LTUgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LW1vc3MgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctY3JlYW1cIj5cbiAgICAgICAgICAgIExpaGF0IFNlbXVhIEFydGlrZWxcbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xMiBncmlkIGdyaWQtY29scy0xIGdhcC03IG1kOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgPGFydGljbGUgdi1mb3I9XCIoYSwgaSkgaW4gYXJ0aWNsZXNcIiA6a2V5PVwiYS50aXRsZVwiIGNsYXNzPVwiZ3JvdXAgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1sZWFmLzEwIGJnLWNyZWFtIHNoYWRvdy1zbSB0cmFuc2l0aW9uLXNoYWRvdyBob3ZlcjpzaGFkb3ctbGdcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhc3BlY3QtMTYvMTAgb3ZlcmZsb3ctaGlkZGVuIGJnLXBhcmNobWVudFwiPlxuICAgICAgICAgICAgICA8aW1nIDpzcmM9XCJhLmltYWdlX3BhdGggPyAoYS5pbWFnZV9wYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IGEuaW1hZ2VfcGF0aCA6ICcvc3RvcmFnZS8nICsgYS5pbWFnZV9wYXRoKSA6IERFRkFVTFRfQVJUSUNMRV9JTUFHRVNbaSAlIERFRkFVTFRfQVJUSUNMRV9JTUFHRVMubGVuZ3RoXVwiIDphbHQ9XCJhLnRpdGxlXCIgY2xhc3M9XCJoLWZ1bGwgdy1mdWxsIG9iamVjdC1jb3ZlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC0xIGZsZXgtY29sIHAtNlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctZml0IHJvdW5kZWQtZnVsbCBiZy1zYW5kIHB4LTMgcHktMSB0ZXh0LVswLjdyZW1dIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1sZWFmXCI+XG4gICAgICAgICAgICAgICAge3sgYS50YWcgfX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJtdC0zIGZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgbGVhZGluZy1zbnVnIHRleHQtbW9zc1wiPnt7IGEudGl0bGUgfX08L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cIm10LTIgZmxleC0xIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtYmFyay83MFwiPnt7IGEuZXhjZXJwdCB9fTwvcD5cbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzcz1cIm10LTQgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtY2xheSB0cmFuc2l0aW9uLWNvbG9ycyBob3Zlcjp0ZXh0LW1vc3NcIj5cbiAgICAgICAgICAgICAgICBCYWNhIHNlbGVuZ2thcG55YVxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJhcnJvd1wiIGNsYXNzPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8IS0tIENUQSBiYW5kIC0tPlxuICAgIDxzZWN0aW9uIGNsYXNzPVwiYmctbW9zc1wiPlxuICAgICAgPGRpdiBjbGFzcz1cIm14LWF1dG8gZmxleCBtYXgtdy02eGwgZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC02IHB4LTYgcHktMTQgdGV4dC1jZW50ZXIgbWQ6ZmxleC1yb3cgbWQ6anVzdGlmeS1iZXR3ZWVuIG1kOnRleHQtbGVmdFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzcz1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtY3JlYW0gbWQ6dGV4dC0zeGxcIj5cbiAgICAgICAgICAgIFNpYXAgbWVtdWxhaSBwZXJ0YW5pYW4geWFuZyBsZWJpaCBzZWhhdD9cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzPVwibXQtMiB0ZXh0LWNyZWFtLzgwXCI+XG4gICAgICAgICAgICBLb25zdWx0YXNpa2FuIGtlYnV0dWhhbiBsYWhhbiBhdGF1IHRlcm5hayBBbmRhIGJlcnNhbWEgdGltIGthbWkuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBAY2xpY2s9XCJvcGVuTW9kYWwoKVwiIGNsYXNzPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtZnVsbCBiZy1zcHJvdXQgcHgtNyBweS0zLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmFyayB0cmFuc2l0aW9uLXRyYW5zZm9ybSBob3ZlcjotdHJhbnNsYXRlLXktMC41IGhvdmVyOmJnLWNyZWFtXCI+XG4gICAgICAgICAgPEljb24gbmFtZT1cIndoYXRzYXBwXCIgY2xhc3M9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICBIdWJ1bmdpIHZpYSBXaGF0c0FwcFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cblxuICAgIDwhLS0gRm9vdGVyIC0tPlxuICAgIDxmb290ZXIgaWQ9XCJrb250YWtcIiBjbGFzcz1cImJnLWJhcmsgdGV4dC1jcmVhbS84MFwiPlxuICAgICAgPGRpdiBjbGFzcz1cIm14LWF1dG8gZ3JpZCBtYXgtdy02eGwgZ3JpZC1jb2xzLTEgZ2FwLTEwIHB4LTYgcHktMTYgbGc6Z3JpZC1jb2xzLTEyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsZzpjb2wtc3Bhbi00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1tb3NzIHRleHQtY3JlYW1cIj5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImxlYWZcIiBjbGFzcz1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtY3JlYW1cIj5QYW5kYXdhIEtlbmNhbmE8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3M9XCJtdC00IG1heC13LXNtIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtY3JlYW0vNzBcIj5cbiAgICAgICAgICAgIENWIFBhbmRhd2EgS2VuY2FuYSBNdWx0aSBGYXJtIOKAlCBwcm9kdXNlbiBwdXB1ayBvcmdhbmlrIGRhbiBwcm9iaW90aWsgdW50dWsgcGVydGFuaWFuIGJlcmtlbGFuanV0YW4uIE1lbnl1YnVya2FuIHRhbmFoLCBtZW51bWJ1aGthbiBoYXJhcGFuLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxnOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICA8aDQgY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWNyZWFtXCI+VGF1dGFuIENlcGF0PC9oND5cbiAgICAgICAgICA8dWwgY2xhc3M9XCJtdC00IHNwYWNlLXktMyB0ZXh0LXNtIHRleHQtY3JlYW0vNzBcIj5cbiAgICAgICAgICAgIDxsaSB2LWZvcj1cImwgaW4gTkFWX0xJTktTXCIgOmtleT1cImwuaHJlZlwiPlxuICAgICAgICAgICAgICA8YSA6aHJlZj1cImwuaHJlZlwiIGNsYXNzPVwidHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1zcHJvdXRcIj57eyBsLmxhYmVsIH19PC9hPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwibGc6Y29sLXNwYW4tM1wiPlxuICAgICAgICAgIDxoNCBjbGFzcz1cInRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtY3JlYW1cIj5Lb250YWs8L2g0PlxuICAgICAgICAgIDx1bCBjbGFzcz1cIm10LTQgc3BhY2UteS0zIHRleHQtc20gdGV4dC1jcmVhbS83MFwiPlxuICAgICAgICAgICAgPGxpIGNsYXNzPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwicGluXCIgY2xhc3M9XCJtdC0wLjUgaC00IHctNCBzaHJpbmstMCB0ZXh0LXNwcm91dFwiIC8+XG4gICAgICAgICAgICAgIHt7ICRwYWdlLnByb3BzLnNldHRpbmdzPy5hZGRyZXNzIHx8ICdKbC4gS2FsaXVyYW5nIEtNIDIwLCBEZXNhIENhbmdrcmluZ2FuLCBTbGVtYW4sIFlvZ3lha2FydGEnIH19XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICA8YnV0dG9uIEBjbGljaz1cIm9wZW5Nb2RhbCgpXCIgY2xhc3M9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1zcHJvdXRcIj5cbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwid2hhdHNhcHBcIiBjbGFzcz1cImgtNCB3LTQgdGV4dC1zcHJvdXRcIiAvPlxuICAgICAgICAgICAgICAgIHt7ICRwYWdlLnByb3BzLnNldHRpbmdzPy53aGF0c2FwcCB8fCAnMDgxMi0zNDU2LTc4OTAnIH19XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgPGEgaHJlZj1cIm1haWx0bzpoYWxvQHBhbmRhd2FrZW5jYW5hLmlkXCIgY2xhc3M9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1zcHJvdXRcIj5cbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwibWFpbFwiIGNsYXNzPVwiaC00IHctNCB0ZXh0LXNwcm91dFwiIC8+XG4gICAgICAgICAgICAgICAgaGFsb0BwYW5kYXdha2VuY2FuYS5pZFxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3M9XCJsZzpjb2wtc3Bhbi0zXCI+XG4gICAgICAgICAgPGg0IGNsYXNzPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1jcmVhbVwiPkxva2FzaSBLYW1pPC9oND5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtNCBmbGV4IGFzcGVjdC00LzMgZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1jcmVhbS8xNSBiZy1jcmVhbS81IHRleHQtY2VudGVyIHRleHQtY3JlYW0vNjBcIj5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJwaW5cIiBjbGFzcz1cImgtOCB3LTggdGV4dC1zcHJvdXRcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzXCI+UGxhY2Vob2xkZXIgUGV0YSBHb29nbGUgTWFwczwvc3Bhbj5cbiAgICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL21hcHMuZ29vZ2xlLmNvbS8/cT1DYW5na3JpbmdhbitTbGVtYW4rWW9neWFrYXJ0YVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIiBjbGFzcz1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNwcm91dCB1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC0yXCI+XG4gICAgICAgICAgICAgIEJ1a2EgZGkgR29vZ2xlIE1hcHNcbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzcz1cImJvcmRlci10IGJvcmRlci1jcmVhbS8xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibXgtYXV0byBmbGV4IG1heC13LTZ4bCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNiBweS01IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1jcmVhbS81MFwiPlxuICAgICAgICAgIDxzcGFuPsKpIDIwMjYgQ1YgUGFuZGF3YSBLZW5jYW5hIE11bHRpIEZhcm0uIFNlbHVydWggaGFrIGNpcHRhIGRpbGluZHVuZ2kuPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9vdGVyPlxuXG4gICAgPCEtLSBNb2RhbCBGb3JtIFBlbWVzYW5hbiAtLT5cbiAgICA8ZGl2IHYtaWY9XCJzaG93TGVhZE1vZGFsXCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJhcmsvNjAgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgPGRpdiBjbGFzcz1cImJnLWNyZWFtIHctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTN4bCBwLTggc2hhZG93LXhsIHJlbGF0aXZlIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICA8YnV0dG9uIEBjbGljaz1cImNsb3NlTW9kYWwoKVwiIGNsYXNzPVwiYWJzb2x1dGUgcmlnaHQtNiB0b3AtNiB0ZXh0LWJhcmsvNTAgaG92ZXI6dGV4dC1tb3NzIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgPEljb24gbmFtZT1cInBsdXNcIiBjbGFzcz1cInctNiBoLTYgcm90YXRlLTQ1XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYi02XCI+XG4gICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1tb3NzXCI+SW5mb3JtYXNpIFBlbWVzYW5hbjwvaDM+XG4gICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtYmFyay83MCBtdC0xXCI+U2lsYWthbiBsZW5na2FwaSBmb3JtIGJlcmlrdXQgc2ViZWx1bSBrYW1pIGFyYWhrYW4ga2UgV2hhdHNBcHAuPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGZvcm0gQHN1Ym1pdC5wcmV2ZW50PVwic3VibWl0TGVhZFwiIGNsYXNzPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1iYXJrLzgwIG1iLTFcIj5OYW1hIExlbmdrYXAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImxlYWRGb3JtLm5hbWVcIiB0eXBlPVwidGV4dFwiIHJlcXVpcmVkIGNsYXNzPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1sZWFmLzIwIGJnLXdoaXRlIHB4LTQgcHktMyB0ZXh0LXNtIGZvY3VzOmJvcmRlci1tb3NzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1tb3NzXCIgcGxhY2Vob2xkZXI9XCJNYXN1a2thbiBuYW1hIEFuZGFcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYmFyay84MCBtYi0xXCI+Tm9tb3IgV2hhdHNBcHAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImxlYWRGb3JtLnBob25lXCIgdHlwZT1cInRlbFwiIHJlcXVpcmVkIGNsYXNzPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1sZWFmLzIwIGJnLXdoaXRlIHB4LTQgcHktMyB0ZXh0LXNtIGZvY3VzOmJvcmRlci1tb3NzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1tb3NzXCIgcGxhY2Vob2xkZXI9XCIwODEyMzQ1Njc4OTBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgdi1pZj1cImxlYWRQcm9kdWN0TmFtZVwiIGNsYXNzPVwiaGlkZGVuXCI+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImhpZGRlblwiIHYtbW9kZWw9XCJsZWFkRm9ybS5tZXNzYWdlXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiA6ZGlzYWJsZWQ9XCJsZWFkRm9ybS5wcm9jZXNzaW5nXCIgY2xhc3M9XCJ3LWZ1bGwgbXQtNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLWZ1bGwgYmctbW9zcyBweC01IHB5LTMuNSBmb250LXNlbWlib2xkIHRleHQtY3JlYW0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctbGVhZiBkaXNhYmxlZDpvcGFjaXR5LTcwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiPlxuICAgICAgICAgICAgPHNwYW4gdi1pZj1cImxlYWRGb3JtLnByb2Nlc3NpbmdcIj5TZWRhbmcgbWVtcHJvc2VzLi4uPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gdi1lbHNlIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48SWNvbiBuYW1lPVwid2hhdHNhcHBcIiBjbGFzcz1cInctNSBoLTVcIiAvPiBMYW5qdXRrYW4ga2UgV2hhdHNBcHA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG4iXSwibWFwcGluZ3MiOiJBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFhckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQVh6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FTWjs7QUFHRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQzs7QUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDOztBQUVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRyxDQUFDOzs7O0FBSUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV6RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQzs7OztBQUlELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pHLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pHLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUosQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RyxDQUFDLENBQUM7QUFDRixDQUFDOztBQUVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvSSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEosQ0FBQyxDQUFDO0FBQ0YsQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUUzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RHLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDOztBQUVGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUUvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQzs7QUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUM7O0FBRUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7Ozs7Ozs7Ozs7cUJBTU0sS0FBSyxFQUFDLDJDQUEyQztxQkFFL0MsS0FBSyxFQUFDLHVDQUF1QztxQkFDM0MsS0FBSyxFQUFDLHVFQUF1RTtxQkFDM0UsS0FBSyxFQUFDLHlCQUF5QjtxQkFDNUIsS0FBSyxFQUFDLGtDQUFrQztxQkFJeEMsS0FBSyxFQUFDLGtDQUFrQztxQkFhNUMsS0FBSyxFQUFDLHdFQUF3RTtxQkFDL0UsS0FBSyxFQUFDLCtEQUErRDs7RUFDckUsSUFBSSxFQUFDLFVBQVU7RUFBQyxLQUFLLEVBQUMsMkJBQTJCOztzQkFDNUMsS0FBSyxFQUFDLDRFQUE0RTtzQkFTckYsS0FBSyxFQUFDLG1DQUFtQzs7c0JBTXpDLEtBQUssRUFBQyx5QkFBeUI7OztFQWNqQixLQUFLLEVBQUMsc0RBQXNEOztzQkFDMUUsS0FBSyxFQUFDLHFCQUFxQjs7O0VBWTNCLEVBQUUsRUFBQyxTQUFTO0VBQUMsS0FBSyxFQUFDLDBCQUEwQjs7c0JBTS9DLEtBQUssRUFBQyx3RkFBd0Y7c0JBQzVGLEtBQUssRUFBQyxlQUFlO3NCQUtwQixLQUFLLEVBQUMsNEZBQTRGO3NCQW1CbkcsS0FBSyxFQUFDLGlDQUFpQztzQkFDekMsS0FBSyxFQUFDLG1FQUFtRTtzQkFFdkUsS0FBSyxFQUFDLDJEQUEyRDtzQkFDakUsS0FBSyxFQUFDLDBFQUEwRTs7RUFNaEYsRUFBRSxFQUFDLFFBQVE7RUFBQyxLQUFLLEVBQUMsdUNBQXVDOztzQkF5QzNELEtBQUssRUFBQyxXQUFXO3NCQVdoQixLQUFLLEVBQUMsZ0NBQWdDOztFQVVyQyxFQUFFLEVBQUMsU0FBUztFQUFDLEtBQUssRUFBQyx3QkFBd0I7O3NCQUM3QyxLQUFLLEVBQUMsd0JBQXdCO3NCQVk1QixLQUFLLEVBQUMsMkNBQTJDOztzQkFNakQsS0FBSyxFQUFDLDREQUE0RDtzQkFFOUQsS0FBSyxFQUFDLGtEQUFrRDs7c0JBS3JELEtBQUssRUFBQywrRkFBK0Y7c0JBSXhHLEtBQUssRUFBQywwQkFBMEI7c0JBQy9CLEtBQUssRUFBQyw4Q0FBOEM7c0JBQ3JELEtBQUssRUFBQyxrREFBa0Q7c0JBQ3hELEtBQUssRUFBQyxtREFBbUQ7O3NCQVk3RCxLQUFLLEVBQUMsd0JBQXdCO3NCQUNoQyxLQUFLLEVBQUMsd0JBQXdCO3NCQU81QixLQUFLLEVBQUMsdUNBQXVDO3NCQUd6QyxLQUFLLEVBQUMsZ0NBQWdDO3NCQUd4QyxLQUFLLEVBQUMsa0RBQWtEO3NCQUN0RCxLQUFLLEVBQUMsaUNBQWlDOztzQkFHckMsS0FBSyxFQUFDLDZCQUE2QjtzQkFDbkMsS0FBSyxFQUFDLHVEQUF1RDtzQkFTbkUsS0FBSyxFQUFDLHVDQUF1QztzQkFXL0MsS0FBSyxFQUFDLDZDQUE2QztzQkFFL0MsS0FBSyxFQUFDLHVEQUF1RDtzQkFDM0QsS0FBSyxFQUFDLG1DQUFtQztzQkFDdEMsS0FBSyxFQUFDLHlFQUF5RTtzQkFHL0UsS0FBSyxFQUFDLGtEQUFrRDtzQkFFNUQsS0FBSyxFQUFDLG1EQUFtRDtzQkFDMUQsS0FBSyxFQUFDLDJDQUEyQzs7O0VBRXJCLEtBQUssRUFBQyx5RUFBeUU7O3NCQVE3RyxLQUFLLEVBQUMsdUNBQXVDO3NCQU8vQyxLQUFLLEVBQUMsV0FBVzs7O0VBY2YsRUFBRSxFQUFDLFNBQVM7RUFBQyxLQUFLLEVBQUMsd0JBQXdCOztzQkFDN0MsS0FBSyxFQUFDLHdCQUF3QjtzQkFDNUIsS0FBSyxFQUFDLDBFQUEwRTtzQkFlaEYsS0FBSyxFQUFDLDZDQUE2QztzQkFFL0MsS0FBSyxFQUFDLDJDQUEyQzs7c0JBR2pELEtBQUssRUFBQywwQkFBMEI7c0JBQzdCLEtBQUssRUFBQyxvR0FBb0c7c0JBRzVHLEtBQUssRUFBQyxnRUFBZ0U7c0JBQ3ZFLEtBQUssRUFBQyxrREFBa0Q7O0VBQ3hELElBQUksRUFBQyxHQUFHO0VBQUMsS0FBSyxFQUFDLHlHQUF5Rzs7c0JBVzVILEtBQUssRUFBQyxTQUFTO3NCQUNqQixLQUFLLEVBQUMsdUhBQXVIOztFQWlCNUgsRUFBRSxFQUFDLFFBQVE7RUFBQyxLQUFLLEVBQUMsdUJBQXVCOztzQkFDMUMsS0FBSyxFQUFDLHNFQUFzRTtzQkFDMUUsS0FBSyxFQUFDLGVBQWU7c0JBQ25CLEtBQUssRUFBQywyQkFBMkI7c0JBQzlCLEtBQUssRUFBQyw0RUFBNEU7c0JBVXZGLEtBQUssRUFBQyxlQUFlO3NCQUVwQixLQUFLLEVBQUMsc0NBQXNDOztzQkFPN0MsS0FBSyxFQUFDLGVBQWU7c0JBRXBCLEtBQUssRUFBQyxzQ0FBc0M7c0JBQzFDLEtBQUssRUFBQyxZQUFZOztFQVdqQixJQUFJLEVBQUMsK0JBQStCO0VBQUMsS0FBSyxFQUFDLG9FQUFvRTs7c0JBUW5ILEtBQUssRUFBQyxlQUFlO3NCQUVuQixLQUFLLEVBQUMsd0lBQXdJOzs7RUFrQi9ILEtBQUssRUFBQyxxRkFBcUY7O3NCQUM5RyxLQUFLLEVBQUMscUdBQXFHOzs7RUFpQmhGLEtBQUssRUFBQyxRQUFROzs7Ozs7RUFLM0IsS0FBSyxFQUFDLHlCQUF5Qjs7Ozs7SUExYnRELGFBQTBELGtCQUFwRCxLQUFLLEVBQUMsMkNBQTJDO0lBRXZELG9CQTZiTSxPQTdiTixVQTZiTTtNQTViSixnQ0FBZ0I7TUFDaEIsb0JBaUJNLE9BakJOLFVBaUJNO1FBaEJKLG9CQWVNLE9BZk4sVUFlTTtVQWRKLG9CQVNNLE9BVE4sVUFTTTtZQVJKLG9CQUdPLFFBSFAsVUFHTztjQUZMLGFBQXlDO2dCQUFuQyxJQUFJLEVBQUMsT0FBTztnQkFBQyxLQUFLLEVBQUMsYUFBYTs7MkRBQUcsaUNBRTNDOztZQUNBLG9CQUdPLFFBSFAsVUFHTztjQUZMLGFBQXVDO2dCQUFqQyxJQUFJLEVBQUMsS0FBSztnQkFBQyxLQUFLLEVBQUMsYUFBYTs7MkRBQUcsNEJBRXpDOzs7VUFFRixvQkFHUztZQUhBLE9BQUssdUNBQUUsZ0JBQVM7WUFBSSxLQUFLLEVBQUMsa0ZBQWtGOztZQUNuSCxhQUF3QztjQUFsQyxJQUFJLEVBQUMsTUFBTTtjQUFDLEtBQUssRUFBQyxhQUFhOzs2QkFBRyxxQkFDdEIsb0JBQUcsVUFBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsUUFBUTs7OztNQUt6RCwrQkFBZTtNQUNmLG9CQTBDUyxVQTFDVCxVQTBDUztRQXpDUCxvQkE2Qk0sT0E3Qk4sVUE2Qk07VUE1Qkosb0JBUUksS0FSSixVQVFJO1lBUEYsb0JBRU8sUUFGUCxXQUVPO2NBREwsYUFBb0M7Z0JBQTlCLElBQUksRUFBQyxNQUFNO2dCQUFDLEtBQUssRUFBQyxTQUFTOzs7d0NBRW5DLG9CQUdPLFVBSEQsS0FBSyxFQUFDLGVBQWU7Y0FDekIsb0JBQXVGLFVBQWpGLEtBQUssRUFBQyxvREFBb0QsSUFBQyxpQkFBZTtjQUNoRixvQkFBb0csVUFBOUYsS0FBSyxFQUFDLHNFQUFzRSxJQUFDLFlBQVU7OztVQUlqRyxvQkFJTSxPQUpOLFdBSU07MkJBSEosb0JBRUksNkJBRlcsZ0JBQVMsR0FBZCxDQUFDO3FCQUFYLG9CQUVJO2dCQUZ1QixHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUk7Z0JBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJO2dCQUFFLEtBQUssRUFBQyxvRUFBb0U7a0NBQzVILENBQUMsQ0FBQyxLQUFLOzs7VUFJZCxvQkFXTSxPQVhOLFdBV007WUFWSixvQkFFUztjQUZBLE9BQUssdUNBQUUsZ0JBQVM7Y0FBSSxLQUFLLEVBQUMsdUhBQXVIO2VBQUMsa0JBRTNKO1lBQ0Esb0JBTVM7Y0FORCxLQUFLLEVBQUMsaUdBQWlHO2NBQUUsT0FBSyx1Q0FBRSxlQUFRLElBQUksZUFBUTtjQUFFLFlBQVUsRUFBQyxXQUFXOztjQUNsSyxvQkFJTSxTQUpELEtBQUssRUFBQyxhQUFhO2dCQUN0QixvQkFBZ0QsVUFBMUMsS0FBSyxFQUFDLDRCQUE0QjtnQkFDeEMsb0JBQWdELFVBQTFDLEtBQUssRUFBQyw0QkFBNEI7Z0JBQ3hDLG9CQUFnRCxVQUExQyxLQUFLLEVBQUMsNEJBQTRCOzs7OztTQU1yQyxlQUFROzJCQUFuQixvQkFTTSxPQVROLFdBU007Y0FSSixvQkFPTSxPQVBOLFdBT007K0JBTkosb0JBRUksNkJBRlcsZ0JBQVMsR0FBZCxDQUFDO3lCQUFYLG9CQUVJO29CQUZ1QixHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUk7b0JBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJO29CQUFHLE9BQUssdUNBQUUsZUFBUTtvQkFBVSxLQUFLLEVBQUMsa0NBQWtDO3NDQUNwSCxDQUFDLENBQUMsS0FBSzs7Z0JBRVosb0JBRVM7a0JBRkEsT0FBSyx1Q0FBRSxnQkFBUztrQkFBSSxLQUFLLEVBQUMsb0ZBQW9GO21CQUFDLGtCQUV4SDs7Ozs7TUFLTiw2QkFBYTtNQUNiLG9CQTRCVSxXQTVCVixXQTRCVTtvQ0EzQlIsb0JBR00sU0FIRCxLQUFLLEVBQUMsa0JBQWtCO1VBQzNCLG9CQUF1TTtZQUFsTSxHQUFHLEVBQUMsOEZBQThGO1lBQUMsR0FBRyxFQUFDLDZDQUE2QztZQUFDLEtBQUssRUFBQyxvQ0FBb0M7O1VBQ3BNLG9CQUF1RixTQUFsRixLQUFLLEVBQUMscUVBQXFFOztRQUdsRixvQkFxQk0sT0FyQk4sV0FxQk07VUFwQkosb0JBbUJNLE9BbkJOLFdBbUJNO3dDQWxCSixvQkFHTyxVQUhELEtBQUssRUFBQywwSkFBMEo7Y0FDcEssb0JBQXdELFVBQWxELEtBQUssRUFBQyxvQ0FBb0M7K0JBQVEsc0RBRTFEOztZQUNBLG9CQUVLLE1BRkwsV0FFSyxtQkFEQSxVQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxRQUFRO3dDQUVuQyxvQkFFSSxPQUZELEtBQUssRUFBQyxxREFBcUQsSUFBQyx5SEFFL0Q7d0NBQ0Esb0JBT00sU0FQRCxLQUFLLEVBQUMsMkJBQTJCO2NBQ3BDLG9CQUVJO2dCQUZELElBQUksRUFBQyxVQUFVO2dCQUFDLEtBQUssRUFBQyx3SkFBd0o7aUJBQUMsaUJBRWxMO2NBQ0Esb0JBRUk7Z0JBRkQsSUFBSSxFQUFDLFNBQVM7Z0JBQUMsS0FBSyxFQUFDLHNIQUFzSDtpQkFBQyx5QkFFL0k7Ozs7O01BTVIsa0NBQWtCO01BQ2xCLG9CQU9VLFdBUFYsV0FPVTtRQU5SLG9CQUtNLE9BTE4sV0FLTTt5QkFKSixvQkFHTSw2QkFIVyxZQUFLLEdBQVYsQ0FBQzttQkFBYixvQkFHTTtjQUhtQixHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUs7Y0FBRSxLQUFLLEVBQUMsYUFBYTs7Y0FDeEQsb0JBQXNGLEtBQXRGLFdBQXNGLG1CQUFkLENBQUMsQ0FBQyxLQUFLO2NBQy9FLG9CQUFxRyxLQUFyRyxXQUFxRyxtQkFBZCxDQUFDLENBQUMsS0FBSzs7Ozs7TUFLcEcseURBQXlDO01BQ3pDLG9CQTJEVSxXQTNEVixXQTJEVTtRQTFEUixxQ0FBcUI7O1FBdUNyQiwwQ0FBMEI7UUFDMUIsb0JBaUJNLE9BakJOLFdBaUJNO3NDQWhCSixvQkFBaUcsVUFBM0YsS0FBSyxFQUFDLDREQUE0RCxJQUFDLG1CQUFpQjtzQ0FDMUYsb0JBRUssUUFGRCxLQUFLLEVBQUMsOEVBQThFLElBQUMsOENBRXpGO3NDQUNBLG9CQUVJLE9BRkQsS0FBSyxFQUFDLG1DQUFtQyxJQUFDLHVOQUU3QztzQ0FDQSxvQkFFSSxPQUZELEtBQUssRUFBQyxtQ0FBbUMsSUFBQywyTEFFN0M7VUFDQSxvQkFLSyxNQUxMLFdBS0s7MkJBSkgsb0JBR0ssNkJBSGMsOEhBQThILEdBQXRJLElBQUk7cUJBQWYsb0JBR0s7Z0JBSCtJLEdBQUcsRUFBRSxJQUFJO2dCQUFFLEtBQUssRUFBQyxnREFBZ0Q7O2dCQUNuTixhQUF3RDtrQkFBbEQsSUFBSSxFQUFDLE9BQU87a0JBQUMsS0FBSyxFQUFDLDRCQUE0Qjs7aUNBQUcsR0FDeEQsb0JBQUcsSUFBSTs7Ozs7O01BTWYsdUNBQXVCO01BQ3ZCLG9CQTBDVSxXQTFDVixXQTBDVTtRQXpDUixvQkF3Q00sT0F4Q04sV0F3Q007c0NBdkNKLG9CQVFNLFNBUkQsS0FBSyxFQUFDLCtCQUErQjtZQUN4QyxvQkFBOEYsVUFBeEYsS0FBSyxFQUFDLDREQUE0RCxJQUFDLGdCQUFjO1lBQ3ZGLG9CQUVLLFFBRkQsS0FBSyxFQUFDLGdFQUFnRSxJQUFDLHdDQUUzRTtZQUNBLG9CQUVJLE9BRkQsS0FBSyxFQUFDLG1CQUFtQixJQUFDLHVGQUU3Qjs7VUFHRiwrQkFBZTtVQUNmLG9CQUlNLE9BSk4sV0FJTTsyQkFISixvQkFFUyw2QkFGVyxjQUFPLEdBQVosQ0FBQztxQkFBaEIsb0JBRVM7Z0JBRnFCLEdBQUcsRUFBRSxDQUFDO2dCQUFHLE9BQUssYUFBRSxhQUFNLEdBQUcsQ0FBQztnQkFBRyxLQUFLLHFGQUFxRSxhQUFNLEtBQUssQ0FBQztrQ0FDNUksQ0FBQzs7O1VBSVIsb0JBcUJNLE9BckJOLFdBcUJNOytCQXBCSixvQkFtQlUsNkJBbkJXLHNCQUFlLEdBQXBCLENBQUM7b0NBQWpCLG9CQW1CVTtnQkFuQjZCLEdBQUcsRUFBRSxDQUFDLENBQUMsSUFBSTtnQkFBRSxLQUFLLEVBQUMsNEhBQTRIOztnQkFDcEwsb0JBUU0sT0FSTixXQVFNO2tCQVBKLG9CQUFpUjtvQkFBM1EsR0FBRyxFQUFFLENBQUMsQ0FBQyxVQUFVLGlCQUFpQixDQUFDLENBQUMsVUFBVTtvQkFBbUgsR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJO29CQUFFLEtBQUssRUFBQyxvRkFBb0Y7O21CQUNsUSxDQUFDLENBQUMsS0FBSztxQ0FBbkIsb0JBRU87O3dCQUZlLEtBQUssMEdBQTBGLENBQUMsQ0FBQyxTQUFTOzBDQUMzSCxDQUFDLENBQUMsS0FBSzs7a0JBRVosb0JBRU8sUUFGUCxXQUVPLG1CQURGLENBQUMsQ0FBQyxRQUFROztnQkFHakIsb0JBUU0sT0FSTixXQVFNO2tCQVBKLG9CQUEwRSxNQUExRSxXQUEwRSxtQkFBZCxDQUFDLENBQUMsSUFBSTtrQkFDbEUsb0JBQTRFLEtBQTVFLFdBQTRFLG1CQUFiLENBQUMsQ0FBQyxJQUFJO2tCQUNyRSxvQkFBOEUsS0FBOUUsV0FBOEUsbUJBQWQsQ0FBQyxDQUFDLEtBQUs7a0JBQ3ZFLG9CQUdTO29CQUhBLE9BQUssYUFBRSxnQkFBUyxDQUFDLENBQUMsQ0FBQyxJQUFJO29CQUFHLEtBQUssRUFBQyxzSkFBc0o7O29CQUM3TCxhQUF3QztzQkFBbEMsSUFBSSxFQUFDLFVBQVU7c0JBQUMsS0FBSyxFQUFDLFNBQVM7O2lFQUFHLHNCQUUxQzs7Ozs7Ozs7TUFPVixrQ0FBa0I7TUFDbEIsb0JBeUJVLFdBekJWLFdBeUJVO1FBeEJSLG9CQXVCTSxPQXZCTixXQXVCTTtzQ0F0Qkosb0JBS00sU0FMRCxLQUFLLEVBQUMsbUJBQW1CO1lBQzVCLG9CQUEyRixVQUFyRixLQUFLLEVBQUMsNERBQTRELElBQUMsYUFBVztZQUNwRixvQkFFSyxRQUZELEtBQUssRUFBQyxnRUFBZ0UsSUFBQywrQkFFM0U7O1VBRUYsb0JBZU0sT0FmTixXQWVNOzJCQWRKLG9CQWFNLDZCQWJnQixtQkFBWSxHQUFyQixDQUFDLEVBQUUsQ0FBQztxQkFBakIsb0JBYU07Z0JBYitCLEdBQUcsRUFBRSxDQUFDO2dCQUFFLEtBQUssRUFBQyxpRkFBaUY7O2dCQUNsSSxhQUF3RTtrQkFBbEUsSUFBSSxFQUFDLE1BQU07a0JBQUMsS0FBSyxFQUFDLDZDQUE2Qzs7Z0JBQ3JFLG9CQUVNLE9BRk4sV0FFTTtpQ0FESixvQkFBNkQsNkJBQWQsQ0FBQyxHQUFOLENBQUM7MkJBQTNDLGFBQTZEO3NCQUF2RCxJQUFJLEVBQUMsT0FBTztzQkFBQyxLQUFLLEVBQUMsU0FBUztzQkFBaUIsR0FBRyxFQUFFLENBQUM7Ozs7Z0JBRTNELG9CQUErRSxLQUEvRSxXQUErRSxFQUFuQixJQUFDLG9CQUFHLENBQUMsQ0FBQyxLQUFLLElBQUcsSUFBQztnQkFDM0Usb0JBTU0sT0FOTixXQU1NO2tCQUxKLG9CQUF3RjtvQkFBbEYsR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFLO29CQUFFLEtBQUssRUFBQywyREFBMkQ7O2tCQUNyRixvQkFHTTtvQkFGSixvQkFBdUQsS0FBdkQsV0FBdUQsbUJBQWIsQ0FBQyxDQUFDLElBQUk7b0JBQ2hELG9CQUFpRixLQUFqRixXQUFpRixtQkFBYixDQUFDLENBQUMsSUFBSTs7Ozs7Ozs7TUFRdEYsdUNBQXVCO01BQ3ZCLG9CQTRCVSxXQTVCVixXQTRCVTtvQ0EzQlIsb0JBUU0sU0FSRCxLQUFLLEVBQUMsK0JBQStCO1VBQ3hDLG9CQUE4RixVQUF4RixLQUFLLEVBQUMsNERBQTRELElBQUMsZ0JBQWM7VUFDdkYsb0JBRUssUUFGRCxLQUFLLEVBQUMsZ0VBQWdFLElBQUMsb0NBRTNFO1VBQ0Esb0JBRUksT0FGRCxLQUFLLEVBQUMsbUJBQW1CLElBQUMsd0ZBRTdCOztRQUdGLG9CQWdCTSxPQWhCTixXQWdCTTt5QkFmSixvQkFjTSw2QkFkZ0IsWUFBSyxHQUFkLENBQUMsRUFBRSxDQUFDO21CQUFqQixvQkFjTTtjQWR3QixHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7Y0FBRSxLQUFLLEVBQUMsVUFBVTs7Y0FDdEQsb0JBU00sT0FUTixXQVNNO2dCQVJKLG9CQUtNLE9BTE4sV0FLTTtrQkFKSixvQkFFTyxRQUZQLFdBRU87b0JBREwsYUFBdUM7c0JBQWhDLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSTtzQkFBRSxLQUFLLEVBQUMsU0FBUzs7O2tCQUV0QyxvQkFBK0UsUUFBL0UsV0FBK0UsbUJBQWIsQ0FBQyxDQUFDLENBQUM7O2dCQUV2RSxvQkFBZ0YsTUFBaEYsV0FBZ0YsbUJBQWYsQ0FBQyxDQUFDLEtBQUs7Z0JBQ3hFLG9CQUFxRSxLQUFyRSxXQUFxRSxtQkFBYixDQUFDLENBQUMsSUFBSTs7ZUFFckQsQ0FBQyxHQUFHLFlBQUssQ0FBQyxNQUFNO2lDQUEzQixvQkFFTSxPQUZOLFdBRU07b0JBREosYUFBcUM7c0JBQS9CLElBQUksRUFBQyxPQUFPO3NCQUFDLEtBQUssRUFBQyxTQUFTOzs7Ozs7OztNQU0xQyw0QkFBWTtNQUNaLG9CQWtCVSxXQWxCVixXQWtCVTtvQ0FqQlIsb0JBS00sU0FMRCxLQUFLLEVBQUMsbUJBQW1CO1VBQzVCLG9CQUEyRixVQUFyRixLQUFLLEVBQUMsNERBQTRELElBQUMsYUFBVztVQUNwRixvQkFFSyxRQUZELEtBQUssRUFBQyxnRUFBZ0UsSUFBQyxtQ0FFM0U7O1FBRUYsb0JBVU0sT0FWTixXQVVNO3lCQVRKLG9CQVFNLDZCQVJrQixXQUFJLEdBQWYsR0FBRyxFQUFFLENBQUM7bUJBQW5CLG9CQVFNO2NBUnlCLEdBQUcsRUFBRSxDQUFDO2NBQUUsS0FBSyxFQUFDLDREQUE0RDs7Y0FDdkcsb0JBR1M7Z0JBSEEsT0FBSyxhQUFFLGdCQUFTLENBQUMsQ0FBQztnQkFBRyxLQUFLLEVBQUMsd0hBQXdIOztnQkFDMUosb0JBQXdCLCtCQUFmLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLGFBQW1LO2tCQUE1SixJQUFJLEVBQUUsZ0JBQVMsS0FBSyxDQUFDO2tCQUFxQixLQUFLLG1CQUFDLDhEQUE4RCxrQkFBeUIsZ0JBQVMsS0FBSyxDQUFDOzs7OEJBRS9KLG9CQUVNLFNBRndCLEtBQUssRUFBQyxxREFBcUQscUJBQ3BGLEdBQUcsQ0FBQyxDQUFDO3lCQURHLGdCQUFTLEtBQUssQ0FBQzs7Ozs7O01BT2xDLCtDQUErQjtNQUMvQixvQkFvQ1UsV0FwQ1YsV0FvQ1U7UUFuQ1Isb0JBa0NNLE9BbENOLFdBa0NNO1VBakNKLG9CQWFNLE9BYk4sV0FhTTt3Q0FaSixvQkFRTSxTQVJELEtBQUssRUFBQyxVQUFVO2NBQ25CLG9CQUFzRyxVQUFoRyxLQUFLLEVBQUMsNERBQTRELElBQUMsd0JBQXNCO2NBQy9GLG9CQUVLLFFBRkQsS0FBSyxFQUFDLGdFQUFnRSxJQUFDLGdDQUUzRTtjQUNBLG9CQUVJLE9BRkQsS0FBSyxFQUFDLG1CQUFtQixJQUFDLHdFQUU3Qjs7WUFFRixhQUVPO2NBRkQsSUFBSSxFQUFDLFdBQVc7Y0FBQyxLQUFLLEVBQUMsMEhBQTBIOztnQ0FBQyxDQUV4SjtpQ0FGd0osdUJBRXhKOzs7OztVQUdGLG9CQWlCTSxPQWpCTixXQWlCTTsrQkFoQkosb0JBZVUsNkJBZmdCLGVBQVEsR0FBakIsQ0FBQyxFQUFFLENBQUM7b0NBQXJCLG9CQWVVO2dCQWYyQixHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUs7Z0JBQUUsS0FBSyxFQUFDLDRIQUE0SDs7Z0JBQ25MLG9CQUVNLE9BRk4sV0FFTTtrQkFESixvQkFBaVI7b0JBQTNRLEdBQUcsRUFBRSxDQUFDLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsVUFBVSxXQUFXLENBQUMsQ0FBQyxVQUFVLGlCQUFpQixDQUFDLENBQUMsVUFBVSxJQUFJLDZCQUFzQixDQUFDLENBQUMsR0FBRyw2QkFBc0IsQ0FBQyxNQUFNO29CQUFJLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSztvQkFBRSxLQUFLLEVBQUMsb0ZBQW9GOzs7Z0JBRWhSLG9CQVVNLE9BVk4sV0FVTTtrQkFUSixvQkFFTyxRQUZQLFdBRU8sbUJBREYsQ0FBQyxDQUFDLEdBQUc7a0JBRVYsb0JBQTZGLE1BQTdGLFdBQTZGLG1CQUFmLENBQUMsQ0FBQyxLQUFLO2tCQUNyRixvQkFBK0UsS0FBL0UsV0FBK0UsbUJBQWhCLENBQUMsQ0FBQyxPQUFPO2tCQUN4RSxvQkFHSSxLQUhKLFdBR0k7aUVBSHdILHFCQUUxSDtvQkFBQSxhQUFxQztzQkFBL0IsSUFBSSxFQUFDLE9BQU87c0JBQUMsS0FBSyxFQUFDLFNBQVM7Ozs7Ozs7OztNQVE5QyxpQ0FBaUI7TUFDakIsb0JBZVUsV0FmVixXQWVVO1FBZFIsb0JBYU0sT0FiTixXQWFNO3NDQVpKLG9CQU9NO1lBTkosb0JBRUssUUFGRCxLQUFLLEVBQUMsNERBQTRELElBQUMsNENBRXZFO1lBQ0Esb0JBRUksT0FGRCxLQUFLLEVBQUMsb0JBQW9CLElBQUMsb0VBRTlCOztVQUVGLG9CQUdTO1lBSEEsT0FBSyx1Q0FBRSxnQkFBUztZQUFJLEtBQUssRUFBQyw4SkFBOEo7O1lBQy9MLGFBQXdDO2NBQWxDLElBQUksRUFBQyxVQUFVO2NBQUMsS0FBSyxFQUFDLFNBQVM7O3lEQUFHLHdCQUUxQzs7OztNQUlKLCtCQUFlO01BQ2Ysb0JBOERTLFVBOURULFdBOERTO1FBN0RQLG9CQXNETSxPQXRETixXQXNETTtVQXJESixvQkFVTSxPQVZOLFdBVU07WUFUSixvQkFLTSxPQUxOLFdBS007Y0FKSixvQkFFTyxRQUZQLFdBRU87Z0JBREwsYUFBb0M7a0JBQTlCLElBQUksRUFBQyxNQUFNO2tCQUFDLEtBQUssRUFBQyxTQUFTOzs7MENBRW5DLG9CQUFrRixVQUE1RSxLQUFLLEVBQUMsK0NBQStDLElBQUMsaUJBQWU7O3dDQUU3RSxvQkFFSSxPQUZELEtBQUssRUFBQyxxREFBcUQsSUFBQywrSUFFL0Q7O1VBR0Ysb0JBT00sT0FQTixXQU9NO3dDQU5KLG9CQUF3RixRQUFwRixLQUFLLEVBQUMsNERBQTRELElBQUMsY0FBWTtZQUNuRixvQkFJSyxNQUpMLFdBSUs7NkJBSEgsb0JBRUssNkJBRlcsZ0JBQVMsR0FBZCxDQUFDO3VCQUFaLG9CQUVLO2tCQUZ1QixHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUk7O2tCQUNyQyxvQkFBK0U7b0JBQTNFLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSTtvQkFBRSxLQUFLLEVBQUMscUNBQXFDO3NDQUFJLENBQUMsQ0FBQyxLQUFLOzs7OztVQUs5RSxvQkFvQk0sT0FwQk4sV0FvQk07d0NBbkJKLG9CQUFrRixRQUE5RSxLQUFLLEVBQUMsNERBQTRELElBQUMsUUFBTTtZQUM3RSxvQkFpQkssTUFqQkwsV0FpQks7Y0FoQkgsb0JBR0ssTUFITCxXQUdLO2dCQUZILGFBQStEO2tCQUF6RCxJQUFJLEVBQUMsS0FBSztrQkFBQyxLQUFLLEVBQUMscUNBQXFDOztpQ0FBRyxHQUMvRCxvQkFBRyxVQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxPQUFPOztjQUVsQyxvQkFLSztnQkFKSCxvQkFHUztrQkFIQSxPQUFLLHVDQUFFLGdCQUFTO2tCQUFJLEtBQUssRUFBQyxvRUFBb0U7O2tCQUNyRyxhQUFvRDtvQkFBOUMsSUFBSSxFQUFDLFVBQVU7b0JBQUMsS0FBSyxFQUFDLHFCQUFxQjs7bUNBQUcsR0FDcEQsb0JBQUcsVUFBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsUUFBUTs7O2NBR3JDLG9CQUtLO2dCQUpILG9CQUdJLEtBSEosV0FHSTtrQkFGRixhQUFnRDtvQkFBMUMsSUFBSSxFQUFDLE1BQU07b0JBQUMsS0FBSyxFQUFDLHFCQUFxQjs7K0RBQUcsMEJBRWxEOzs7OztVQUtOLG9CQVNNLE9BVE4sV0FTTTt3Q0FSSixvQkFBdUYsUUFBbkYsS0FBSyxFQUFDLDREQUE0RCxJQUFDLGFBQVc7WUFDbEYsb0JBTU0sT0FOTixXQU1NO2NBTEosYUFBK0M7Z0JBQXpDLElBQUksRUFBQyxLQUFLO2dCQUFDLEtBQUssRUFBQyxxQkFBcUI7OzBDQUM1QyxvQkFBeUQsVUFBbkQsS0FBSyxFQUFDLFNBQVMsSUFBQyw4QkFBNEI7MENBQ2xELG9CQUVJO2dCQUZELElBQUksRUFBQywwREFBMEQ7Z0JBQUMsTUFBTSxFQUFDLFFBQVE7Z0JBQUMsR0FBRyxFQUFDLFlBQVk7Z0JBQUMsS0FBSyxFQUFDLGdFQUFnRTtpQkFBQyx1QkFFM0s7Ozs7b0NBS04sb0JBSU0sU0FKRCxLQUFLLEVBQUMsMEJBQTBCO1VBQ25DLG9CQUVNLFNBRkQsS0FBSyxFQUFDLCtHQUErRztZQUN4SCxvQkFBZ0YsY0FBMUUscUVBQW1FOzs7O01BSy9FLDZDQUE2QjtPQUNsQixvQkFBYTt5QkFBeEIsb0JBMkJNLE9BM0JOLFdBMkJNO1lBMUJKLG9CQXlCTSxPQXpCTixXQXlCTTtjQXhCSixvQkFFUztnQkFGQSxPQUFLLHVDQUFFLGlCQUFVO2dCQUFJLEtBQUssRUFBQyx1RUFBdUU7O2dCQUN6RyxhQUE4QztrQkFBeEMsSUFBSSxFQUFDLE1BQU07a0JBQUMsS0FBSyxFQUFDLG1CQUFtQjs7OzBDQUU3QyxvQkFHTSxTQUhELEtBQUssRUFBQyxNQUFNO2dCQUNmLG9CQUFrRixRQUE5RSxLQUFLLEVBQUMsK0NBQStDLElBQUMscUJBQW1CO2dCQUM3RSxvQkFBd0csT0FBckcsS0FBSyxFQUFDLDJCQUEyQixJQUFDLGlFQUErRDs7Y0FFdEcsb0JBZ0JPO2dCQWhCQSxRQUFNLGlCQUFVLGlCQUFVO2dCQUFFLEtBQUssRUFBQyxXQUFXOztnQkFDbEQsb0JBR007OENBRkosb0JBQW1ILFdBQTVHLEtBQUssRUFBQyw2Q0FBNkM7cUNBQUMsZUFBYTtvQkFBQSxvQkFBbUMsVUFBN0IsS0FBSyxFQUFDLGNBQWMsSUFBQyxHQUFDOztrQ0FDcEcsb0JBQW9PO2lGQUFwTixlQUFRLENBQUMsSUFBSTtvQkFBRSxJQUFJLEVBQUMsTUFBTTtvQkFBQyxRQUFRLEVBQVIsRUFBUTtvQkFBQyxLQUFLLEVBQUMsc0lBQXNJO29CQUFDLFdBQVcsRUFBQyxvQkFBb0I7O2tDQUFqTixlQUFRLENBQUMsSUFBSTs7O2dCQUUvQixvQkFHTTs4Q0FGSixvQkFBcUgsV0FBOUcsS0FBSyxFQUFDLDZDQUE2QztxQ0FBQyxpQkFBZTtvQkFBQSxvQkFBbUMsVUFBN0IsS0FBSyxFQUFDLGNBQWMsSUFBQyxHQUFDOztrQ0FDdEcsb0JBQThOO2lGQUE5TSxlQUFRLENBQUMsS0FBSztvQkFBRSxJQUFJLEVBQUMsS0FBSztvQkFBQyxRQUFRLEVBQVIsRUFBUTtvQkFBQyxLQUFLLEVBQUMsc0lBQXNJO29CQUFDLFdBQVcsRUFBQyxjQUFjOztrQ0FBM00sZUFBUSxDQUFDLEtBQUs7OztpQkFFckIsc0JBQWU7bUNBQTFCLG9CQUVNLE9BRk4sV0FFTTtzQ0FESixvQkFBa0Q7d0JBQTNDLElBQUksRUFBQyxRQUFRO3VGQUFVLGVBQVEsQ0FBQyxPQUFPOztzQ0FBaEIsZUFBUSxDQUFDLE9BQU87Ozs7Z0JBRWhELG9CQUdTO2tCQUhELElBQUksRUFBQyxRQUFRO2tCQUFFLFFBQVEsRUFBRSxlQUFRLENBQUMsVUFBVTtrQkFBRSxLQUFLLEVBQUMsOExBQThMOzttQkFDNU8sZUFBUSxDQUFDLFVBQVU7cUNBQS9CLG9CQUEyRCxxQkFBMUIscUJBQW1CO3FDQUNwRCxvQkFBa0gsUUFBbEgsV0FBa0g7d0JBQXJFLGFBQXdDOzBCQUFsQyxJQUFJLEVBQUMsVUFBVTswQkFBQyxLQUFLLEVBQUMsU0FBUzs7cUVBQUcsd0JBQXNCIiwiaWdub3JlTGlzdCI6W119