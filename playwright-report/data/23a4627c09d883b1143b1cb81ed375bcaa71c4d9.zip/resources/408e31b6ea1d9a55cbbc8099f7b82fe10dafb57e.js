import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/resources/js/Pages/Admin/Products/Create.vue");import AdminLayout from "/resources/js/Layouts/AdminLayout.vue?t=1790135341305";
import { Link, useForm } from "/node_modules/.vite/deps/@inertiajs_vue3.js?v=cebe2491";
import { ref } from "/node_modules/.vite/deps/vue.js?v=cebe2491";


const _sfc_main = /*@__PURE__*/Object.assign({ layout: AdminLayout }, {
  __name: 'Create',
  setup(__props, { expose: __expose }) {
  __expose();



const form = useForm({
    name: '',
    category: 'Pupuk Organik',
    desc: '',
    price: '',
    badge: '',
    badgeTone: 'leaf',
    image: null,
});

const imagePreview = ref(null);

const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
        form.image = file;
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.value = e.target.result;
        };
        reader.readAsDataURL(file);
    }
};

const submit = () => {
    form.post('/admin/products', {
        preserveScroll: true,
    });
};

const __returned__ = { form, imagePreview, handleImageUpload, submit, AdminLayout, get Link() { return Link }, get useForm() { return useForm }, ref }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

})
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, createCommentVNode as _createCommentVNode, vModelText as _vModelText, withDirectives as _withDirectives, toDisplayString as _toDisplayString, vModelSelect as _vModelSelect, withModifiers as _withModifiers, createStaticVNode as _createStaticVNode, Fragment as _Fragment } from "/node_modules/.vite/deps/vue.js?v=cebe2491"

const _hoisted_1 = { class: "mb-8" }
const _hoisted_2 = { class: "bg-white rounded-3xl shadow-sm border border-emerald-50 overflow-hidden max-w-4xl" }
const _hoisted_3 = { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }
const _hoisted_4 = { class: "space-y-2" }
const _hoisted_5 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_6 = { class: "space-y-2" }
const _hoisted_7 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_8 = { class: "space-y-2" }
const _hoisted_9 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_10 = { class: "space-y-2" }
const _hoisted_11 = { class: "flex gap-2" }
const _hoisted_12 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_13 = { class: "space-y-2" }
const _hoisted_14 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_15 = { class: "space-y-2" }
const _hoisted_16 = { class: "mt-2 flex justify-center rounded-xl border border-dashed border-gray-300 px-6 py-10 bg-gray-50 hover:bg-emerald-50 hover:border-emerald-300 transition-all cursor-pointer relative overflow-hidden group" }
const _hoisted_17 = {
  key: 0,
  class: "text-center"
}
const _hoisted_18 = {
  key: 1,
  class: "relative w-full max-w-sm h-48 rounded-lg overflow-hidden border border-gray-200"
}
const _hoisted_19 = ["src"]
const _hoisted_20 = {
  key: 0,
  class: "text-red-500 text-xs"
}
const _hoisted_21 = { class: "pt-6 border-t border-gray-100 flex justify-end gap-3" }
const _hoisted_22 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("div", _hoisted_1, [
      _createVNode($setup["Link"], {
        href: "/admin/products",
        class: "text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-2 mb-4"
      }, {
        default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
          _createElementVNode("svg", {
            class: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            _createElementVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M10 19l-7-7m0 0l7-7m-7 7h18"
            })
          ], -1 /* CACHED */),
          _createTextVNode(" Kembali ke Kelola Produk ", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      }),
      _cache[7] || (_cache[7] = _createElementVNode("h2", { class: "text-3xl font-bold text-gray-900 tracking-tight" }, "Tambah Produk Baru", -1 /* CACHED */)),
      _cache[8] || (_cache[8] = _createElementVNode("p", { class: "text-gray-500 mt-2" }, "Masukkan informasi detail untuk produk yang akan ditambahkan.", -1 /* CACHED */))
    ]),
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("form", {
        onSubmit: _withModifiers($setup.submit, ["prevent"]),
        class: "p-8 space-y-6"
      }, [
        _createElementVNode("div", _hoisted_3, [
          _createCommentVNode(" Nama Produk "),
          _createElementVNode("div", _hoisted_4, [
            _cache[9] || (_cache[9] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Nama Produk", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.name) = $event)),
              type: "text",
              placeholder: "Masukkan nama produk...",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.name]
            ]),
            ($setup.form.errors.name)
              ? (_openBlock(), _createElementBlock("p", _hoisted_5, _toDisplayString($setup.form.errors.name), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Harga "),
          _createElementVNode("div", _hoisted_6, [
            _cache[10] || (_cache[10] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Harga (Teks/Format Bebas)", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.price) = $event)),
              type: "text",
              placeholder: "Misal: Rp 45.000",
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all",
              required: ""
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.price]
            ]),
            ($setup.form.errors.price)
              ? (_openBlock(), _createElementBlock("p", _hoisted_7, _toDisplayString($setup.form.errors.price), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Kategori "),
          _createElementVNode("div", _hoisted_8, [
            _cache[12] || (_cache[12] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Kategori", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("select", {
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.category) = $event)),
              class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
            }, [...(_cache[11] || (_cache[11] = [
              _createElementVNode("option", { value: "Pupuk Organik" }, "Pupuk Organik", -1 /* CACHED */),
              _createElementVNode("option", { value: "Probiotik Peternakan" }, "Probiotik Peternakan", -1 /* CACHED */)
            ]))], 512 /* NEED_PATCH */), [
              [_vModelSelect, $setup.form.category]
            ]),
            ($setup.form.errors.category)
              ? (_openBlock(), _createElementBlock("p", _hoisted_9, _toDisplayString($setup.form.errors.category), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ]),
          _createCommentVNode(" Badge "),
          _createElementVNode("div", _hoisted_10, [
            _cache[14] || (_cache[14] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Badge/Label (Opsional)", -1 /* CACHED */)),
            _createElementVNode("div", _hoisted_11, [
              _withDirectives(_createElementVNode("input", {
                "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.badge) = $event)),
                type: "text",
                placeholder: "Misal: Terlaris",
                class: "flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.form.badge]
              ]),
              _withDirectives(_createElementVNode("select", {
                "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.form.badgeTone) = $event)),
                class: "w-32 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
              }, [...(_cache[13] || (_cache[13] = [
                _createElementVNode("option", { value: "leaf" }, "Hijau", -1 /* CACHED */),
                _createElementVNode("option", { value: "clay" }, "Coklat", -1 /* CACHED */)
              ]))], 512 /* NEED_PATCH */), [
                [_vModelSelect, $setup.form.badgeTone]
              ])
            ]),
            ($setup.form.errors.badge)
              ? (_openBlock(), _createElementBlock("p", _hoisted_12, _toDisplayString($setup.form.errors.badge), 1 /* TEXT */))
              : _createCommentVNode("v-if", true)
          ])
        ]),
        _createCommentVNode(" Deskripsi "),
        _createElementVNode("div", _hoisted_13, [
          _cache[15] || (_cache[15] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Deskripsi Singkat", -1 /* CACHED */)),
          _withDirectives(_createElementVNode("textarea", {
            "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => (($setup.form.desc) = $event)),
            rows: "3",
            placeholder: "Tuliskan deskripsi singkat atau manfaat produk...",
            class: "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-700 transition-all"
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.form.desc]
          ]),
          ($setup.form.errors.desc)
            ? (_openBlock(), _createElementBlock("p", _hoisted_14, _toDisplayString($setup.form.errors.desc), 1 /* TEXT */))
            : _createCommentVNode("v-if", true)
        ]),
        _createCommentVNode(" Foto "),
        _createElementVNode("div", _hoisted_15, [
          _cache[18] || (_cache[18] = _createElementVNode("label", { class: "block text-sm font-bold text-gray-700" }, "Foto Produk (Opsional)", -1 /* CACHED */)),
          _createElementVNode("div", _hoisted_16, [
            _createElementVNode("input", {
              type: "file",
              onChange: $setup.handleImageUpload,
              class: "absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10",
              accept: "image/*"
            }, null, 32 /* NEED_HYDRATION */),
            (!$setup.imagePreview)
              ? (_openBlock(), _createElementBlock("div", _hoisted_17, [...(_cache[16] || (_cache[16] = [
                  _createStaticVNode("<svg class=\"mx-auto h-12 w-12 text-gray-300 group-hover:text-emerald-500 transition-colors\" viewBox=\"0 0 24 24\" fill=\"currentColor\" aria-hidden=\"true\"><path fill-rule=\"evenodd\" d=\"M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z\" clip-rule=\"evenodd\"></path></svg><div class=\"mt-4 flex text-sm leading-6 text-gray-600 justify-center\"><span class=\"relative rounded-md font-semibold text-emerald-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-emerald-600 focus-within:ring-offset-2 hover:text-emerald-500\"><span>Upload a file</span></span><p class=\"pl-1\">or drag and drop</p></div><p class=\"text-xs leading-5 text-gray-500\">PNG, JPG, GIF up to 2MB</p>", 3)
                ]))]))
              : (_openBlock(), _createElementBlock("div", _hoisted_18, [
                  _createElementVNode("img", {
                    src: $setup.imagePreview,
                    class: "w-full h-full object-cover"
                  }, null, 8 /* PROPS */, _hoisted_19),
                  _cache[17] || (_cache[17] = _createElementVNode("div", { class: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center" }, [
                    _createElementVNode("p", { class: "text-white text-sm font-bold" }, "Ganti Foto")
                  ], -1 /* CACHED */))
                ]))
          ]),
          ($setup.form.errors.image)
            ? (_openBlock(), _createElementBlock("p", _hoisted_20, _toDisplayString($setup.form.errors.image), 1 /* TEXT */))
            : _createCommentVNode("v-if", true)
        ]),
        _createCommentVNode(" Submit Button "),
        _createElementVNode("div", _hoisted_21, [
          _createVNode($setup["Link"], {
            href: "/admin/products",
            class: "px-6 py-3 border border-gray-200 text-gray-600 font-medium rounded-xl hover:bg-gray-50 transition-colors"
          }, {
            default: _withCtx(() => [...(_cache[19] || (_cache[19] = [
              _createTextVNode("Batal", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }),
          _createElementVNode("button", {
            type: "submit",
            disabled: $setup.form.processing,
            class: "px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all disabled:opacity-50"
          }, " Simpan Produk ", 8 /* PROPS */, _hoisted_22)
        ])
      ], 32 /* NEED_HYDRATION */)
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "dcd1da3f"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/laragon/www/pandawa-kencana/resources/js/Pages/Admin/Products/Create.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ3JlYXRlLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuaW1wb3J0IEFkbWluTGF5b3V0IGZyb20gJ0AvTGF5b3V0cy9BZG1pbkxheW91dC52dWUnO1xuaW1wb3J0IHsgTGluaywgdXNlRm9ybSB9IGZyb20gJ0BpbmVydGlhanMvdnVlMyc7XG5pbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnO1xuXG5kZWZpbmVPcHRpb25zKHsgbGF5b3V0OiBBZG1pbkxheW91dCB9KTtcblxuY29uc3QgZm9ybSA9IHVzZUZvcm0oe1xuICAgIG5hbWU6ICcnLFxuICAgIGNhdGVnb3J5OiAnUHVwdWsgT3JnYW5paycsXG4gICAgZGVzYzogJycsXG4gICAgcHJpY2U6ICcnLFxuICAgIGJhZGdlOiAnJyxcbiAgICBiYWRnZVRvbmU6ICdsZWFmJyxcbiAgICBpbWFnZTogbnVsbCxcbn0pO1xuXG5jb25zdCBpbWFnZVByZXZpZXcgPSByZWYobnVsbCk7XG5cbmNvbnN0IGhhbmRsZUltYWdlVXBsb2FkID0gKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXNbMF07XG4gICAgaWYgKGZpbGUpIHtcbiAgICAgICAgZm9ybS5pbWFnZSA9IGZpbGU7XG4gICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICAgIHJlYWRlci5vbmxvYWQgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaW1hZ2VQcmV2aWV3LnZhbHVlID0gZS50YXJnZXQucmVzdWx0O1xuICAgICAgICB9O1xuICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICB9XG59O1xuXG5jb25zdCBzdWJtaXQgPSAoKSA9PiB7XG4gICAgZm9ybS5wb3N0KCcvYWRtaW4vcHJvZHVjdHMnLCB7XG4gICAgICAgIHByZXNlcnZlU2Nyb2xsOiB0cnVlLFxuICAgIH0pO1xufTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJtYi04XCI+XG4gICAgPExpbmsgaHJlZj1cIi9hZG1pbi9wcm9kdWN0c1wiIGNsYXNzPVwidGV4dC1zbSB0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxuICAgICAgPHN2ZyBjbGFzcz1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIyXCIgZD1cIk0xMCAxOWwtNy03bTAgMGw3LTdtLTcgN2gxOFwiPjwvcGF0aD48L3N2Zz5cbiAgICAgIEtlbWJhbGkga2UgS2Vsb2xhIFByb2R1a1xuICAgIDwvTGluaz5cbiAgICA8aDIgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cmFja2luZy10aWdodFwiPlRhbWJhaCBQcm9kdWsgQmFydTwvaDI+XG4gICAgPHAgY2xhc3M9XCJ0ZXh0LWdyYXktNTAwIG10LTJcIj5NYXN1a2thbiBpbmZvcm1hc2kgZGV0YWlsIHVudHVrIHByb2R1ayB5YW5nIGFrYW4gZGl0YW1iYWhrYW4uPC9wPlxuICA8L2Rpdj5cblxuICA8ZGl2IGNsYXNzPVwiYmctd2hpdGUgcm91bmRlZC0zeGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZW1lcmFsZC01MCBvdmVyZmxvdy1oaWRkZW4gbWF4LXctNHhsXCI+XG4gICAgPGZvcm0gQHN1Ym1pdC5wcmV2ZW50PVwic3VibWl0XCIgY2xhc3M9XCJwLTggc3BhY2UteS02XCI+XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgIDwhLS0gTmFtYSBQcm9kdWsgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+TmFtYSBQcm9kdWs8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dCB2LW1vZGVsPVwiZm9ybS5uYW1lXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk1hc3Vra2FuIG5hbWEgcHJvZHVrLi4uXCIgY2xhc3M9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBvdXRsaW5lLW5vbmUgdGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWFsbFwiIHJlcXVpcmVkIC8+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLm5hbWVcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMubmFtZSB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBIYXJnYSAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5IYXJnYSAoVGVrcy9Gb3JtYXQgQmViYXMpPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImZvcm0ucHJpY2VcIiB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiTWlzYWw6IFJwIDQ1LjAwMFwiIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIiByZXF1aXJlZCAvPlxuICAgICAgICAgIDxwIHYtaWY9XCJmb3JtLmVycm9ycy5wcmljZVwiIGNsYXNzPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57eyBmb3JtLmVycm9ycy5wcmljZSB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSBLYXRlZ29yaSAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5LYXRlZ29yaTwvbGFiZWw+XG4gICAgICAgICAgPHNlbGVjdCB2LW1vZGVsPVwiZm9ybS5jYXRlZ29yeVwiIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQdXB1ayBPcmdhbmlrXCI+UHVwdWsgT3JnYW5pazwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlByb2Jpb3RpayBQZXRlcm5ha2FuXCI+UHJvYmlvdGlrIFBldGVybmFrYW48L29wdGlvbj5cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMuY2F0ZWdvcnlcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuY2F0ZWdvcnkgfX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0gQmFkZ2UgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+QmFkZ2UvTGFiZWwgKE9wc2lvbmFsKTwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxpbnB1dCB2LW1vZGVsPVwiZm9ybS5iYWRnZVwiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJNaXNhbDogVGVybGFyaXNcIiBjbGFzcz1cImZsZXgtMSBweC00IHB5LTMgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIG91dGxpbmUtbm9uZSB0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tYWxsXCIgLz5cbiAgICAgICAgICAgIDxzZWxlY3Qgdi1tb2RlbD1cImZvcm0uYmFkZ2VUb25lXCIgY2xhc3M9XCJ3LTMyIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImxlYWZcIj5IaWphdTwvb3B0aW9uPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2xheVwiPkNva2xhdDwvb3B0aW9uPlxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgdi1pZj1cImZvcm0uZXJyb3JzLmJhZGdlXCIgY2xhc3M9XCJ0ZXh0LXJlZC01MDAgdGV4dC14c1wiPnt7IGZvcm0uZXJyb3JzLmJhZGdlIH19PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8IS0tIERlc2tyaXBzaSAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPkRlc2tyaXBzaSBTaW5na2F0PC9sYWJlbD5cbiAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJmb3JtLmRlc2NcIiByb3dzPVwiM1wiIHBsYWNlaG9sZGVyPVwiVHVsaXNrYW4gZGVza3JpcHNpIHNpbmdrYXQgYXRhdSBtYW5mYWF0IHByb2R1ay4uLlwiIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lIHRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1hbGxcIj48L3RleHRhcmVhPlxuICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMuZGVzY1wiIGNsYXNzPVwidGV4dC1yZWQtNTAwIHRleHQteHNcIj57eyBmb3JtLmVycm9ycy5kZXNjIH19PC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0gRm90byAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPkZvdG8gUHJvZHVrIChPcHNpb25hbCk8L2xhYmVsPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMiBmbGV4IGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIHB4LTYgcHktMTAgYmctZ3JheS01MCBob3ZlcjpiZy1lbWVyYWxkLTUwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTMwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBAY2hhbmdlPVwiaGFuZGxlSW1hZ2VVcGxvYWRcIiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgdy1mdWxsIGgtZnVsbCBvcGFjaXR5LTAgY3Vyc29yLXBvaW50ZXIgei0xMFwiIGFjY2VwdD1cImltYWdlLypcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiIHYtaWY9XCIhaW1hZ2VQcmV2aWV3XCI+XG4gICAgICAgICAgICA8c3ZnIGNsYXNzPVwibXgtYXV0byBoLTEyIHctMTIgdGV4dC1ncmF5LTMwMCBncm91cC1ob3Zlcjp0ZXh0LWVtZXJhbGQtNTAwIHRyYW5zaXRpb24tY29sb3JzXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgICAgICAgICAgPHBhdGggZmlsbC1ydWxlPVwiZXZlbm9kZFwiIGQ9XCJNMS41IDZhMi4yNSAyLjI1IDAgMDEyLjI1LTIuMjVoMTYuNUEyLjI1IDIuMjUgMCAwMTIyLjUgNnYxMmEyLjI1IDIuMjUgMCAwMS0yLjI1IDIuMjVIMy43NUEyLjI1IDIuMjUgMCAwMTEuNSAxOFY2ek0zIDE2LjA2VjE4YzAgLjQxNC4zMzYuNzUuNzUuNzVoMTYuNUEuNzUuNzUgMCAwMDIxIDE4di0xLjk0bC0yLjY5LTIuNjg5YTEuNSAxLjUgMCAwMC0yLjEyIDBsLS44OC44NzkuOTcuOTdhLjc1Ljc1IDAgMTEtMS4wNiAxLjA2bC01LjE2LTUuMTU5YTEuNSAxLjUgMCAwMC0yLjEyIDBMMyAxNi4wNjF6bTEwLjEyNS03LjgxYTEuMTI1IDEuMTI1IDAgMTEyLjI1IDAgMS4xMjUgMS4xMjUgMCAwMS0yLjI1IDB6XCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC00IGZsZXggdGV4dC1zbSBsZWFkaW5nLTYgdGV4dC1ncmF5LTYwMCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInJlbGF0aXZlIHJvdW5kZWQtbWQgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGZvY3VzLXdpdGhpbjpvdXRsaW5lLW5vbmUgZm9jdXMtd2l0aGluOnJpbmctMiBmb2N1cy13aXRoaW46cmluZy1lbWVyYWxkLTYwMCBmb2N1cy13aXRoaW46cmluZy1vZmZzZXQtMiBob3Zlcjp0ZXh0LWVtZXJhbGQtNTAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+VXBsb2FkIGEgZmlsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cInBsLTFcIj5vciBkcmFnIGFuZCBkcm9wPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgbGVhZGluZy01IHRleHQtZ3JheS01MDBcIj5QTkcsIEpQRywgR0lGIHVwIHRvIDJNQjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1zbSBoLTQ4IHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgIDxpbWcgOnNyYz1cImltYWdlUHJldmlld1wiIGNsYXNzPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNTAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtd2hpdGUgdGV4dC1zbSBmb250LWJvbGRcIj5HYW50aSBGb3RvPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCB2LWlmPVwiZm9ybS5lcnJvcnMuaW1hZ2VcIiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXhzXCI+e3sgZm9ybS5lcnJvcnMuaW1hZ2UgfX08L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPCEtLSBTdWJtaXQgQnV0dG9uIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cInB0LTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cbiAgICAgICAgPExpbmsgaHJlZj1cIi9hZG1pbi9wcm9kdWN0c1wiIGNsYXNzPVwicHgtNiBweS0zIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTYwMCBmb250LW1lZGl1bSByb3VuZGVkLXhsIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5CYXRhbDwvTGluaz5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgOmRpc2FibGVkPVwiZm9ybS5wcm9jZXNzaW5nXCIgY2xhc3M9XCJweC04IHB5LTMgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxuICAgICAgICAgIFNpbXBhbiBQcm9kdWtcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZm9ybT5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7OztBQUl6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUM7O0FBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRTlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQzs7Ozs7Ozs7OztxQkFJTSxLQUFLLEVBQUMsTUFBTTtxQkFTWixLQUFLLEVBQUMsbUZBQW1GO3FCQUdyRixLQUFLLEVBQUMsdUNBQXVDO3FCQUUzQyxLQUFLLEVBQUMsV0FBVzs7O0VBR08sS0FBSyxFQUFDLHNCQUFzQjs7cUJBSXBELEtBQUssRUFBQyxXQUFXOzs7RUFHUSxLQUFLLEVBQUMsc0JBQXNCOztxQkFJckQsS0FBSyxFQUFDLFdBQVc7OztFQU1XLEtBQUssRUFBQyxzQkFBc0I7O3NCQUl4RCxLQUFLLEVBQUMsV0FBVztzQkFFZixLQUFLLEVBQUMsWUFBWTs7O0VBT0ssS0FBSyxFQUFDLHNCQUFzQjs7c0JBS3ZELEtBQUssRUFBQyxXQUFXOzs7RUFHTyxLQUFLLEVBQUMsc0JBQXNCOztzQkFJcEQsS0FBSyxFQUFDLFdBQVc7c0JBRWYsS0FBSyxFQUFDLDBNQUEwTTs7O0VBRTlNLEtBQUssRUFBQyxhQUFhOzs7O0VBWVosS0FBSyxFQUFDLGlGQUFpRjs7Ozs7RUFPekUsS0FBSyxFQUFDLHNCQUFzQjs7c0JBSXJELEtBQUssRUFBQyxzREFBc0Q7Ozs7O0lBdEZyRSxvQkFPTSxPQVBOLFVBT007TUFOSixhQUdPO1FBSEQsSUFBSSxFQUFDLGlCQUFpQjtRQUFDLEtBQUssRUFBQywwRkFBMEY7OzBCQUMzSCxDQUE4TDtVQUE5TCxvQkFBOEw7WUFBekwsS0FBSyxFQUFDLFNBQVM7WUFBQyxJQUFJLEVBQUMsTUFBTTtZQUFDLE1BQU0sRUFBQyxjQUFjO1lBQUMsT0FBTyxFQUFDLFdBQVc7O1lBQUMsb0JBQTZHO2NBQXZHLGdCQUFjLEVBQUMsT0FBTztjQUFDLGlCQUFlLEVBQUMsT0FBTztjQUFDLGNBQVksRUFBQyxHQUFHO2NBQUMsQ0FBQyxFQUFDLDZCQUE2Qjs7OzJCQUFjLDRCQUVoTTs7OztnQ0FDQSxvQkFBbUYsUUFBL0UsS0FBSyxFQUFDLGlEQUFpRCxJQUFDLG9CQUFrQjtnQ0FDOUUsb0JBQStGLE9BQTVGLEtBQUssRUFBQyxvQkFBb0IsSUFBQywrREFBNkQ7O0lBRzdGLG9CQXFGTSxPQXJGTixVQXFGTTtNQXBGSixvQkFtRk87UUFuRkEsUUFBTSxpQkFBVSxhQUFNO1FBQUUsS0FBSyxFQUFDLGVBQWU7O1FBRWxELG9CQXFDTSxPQXJDTixVQXFDTTtVQXBDSixvQ0FBb0I7VUFDcEIsb0JBSU0sT0FKTixVQUlNO3NDQUhKLG9CQUF3RSxXQUFqRSxLQUFLLEVBQUMsdUNBQXVDLElBQUMsYUFBVzs0QkFDaEUsb0JBQXFROzJFQUFyUCxXQUFJLENBQUMsSUFBSTtjQUFFLElBQUksRUFBQyxNQUFNO2NBQUMsV0FBVyxFQUFDLHlCQUF5QjtjQUFDLEtBQUssRUFBQyxzS0FBc0s7Y0FBQyxRQUFRLEVBQVIsRUFBUTs7NEJBQWxQLFdBQUksQ0FBQyxJQUFJOzthQUNoQixXQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7K0JBQXpCLG9CQUFrRixLQUFsRixVQUFrRixtQkFBdkIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJOzs7VUFHN0UsOEJBQWM7VUFDZCxvQkFJTSxPQUpOLFVBSU07d0NBSEosb0JBQXNGLFdBQS9FLEtBQUssRUFBQyx1Q0FBdUMsSUFBQywyQkFBeUI7NEJBQzlFLG9CQUErUDsyRUFBL08sV0FBSSxDQUFDLEtBQUs7Y0FBRSxJQUFJLEVBQUMsTUFBTTtjQUFDLFdBQVcsRUFBQyxrQkFBa0I7Y0FBQyxLQUFLLEVBQUMsc0tBQXNLO2NBQUMsUUFBUSxFQUFSLEVBQVE7OzRCQUE1TyxXQUFJLENBQUMsS0FBSzs7YUFDakIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOytCQUExQixvQkFBb0YsS0FBcEYsVUFBb0YsbUJBQXhCLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzs7O1VBRy9FLGlDQUFpQjtVQUNqQixvQkFPTSxPQVBOLFVBT007d0NBTkosb0JBQXFFLFdBQTlELEtBQUssRUFBQyx1Q0FBdUMsSUFBQyxVQUFROzRCQUM3RCxvQkFHUzsyRUFIUSxXQUFJLENBQUMsUUFBUTtjQUFFLEtBQUssRUFBQyxzS0FBc0s7O2NBQzFNLG9CQUFvRCxZQUE1QyxLQUFLLEVBQUMsZUFBZSxJQUFDLGVBQWE7Y0FDM0Msb0JBQWtFLFlBQTFELEtBQUssRUFBQyxzQkFBc0IsSUFBQyxzQkFBb0I7OzhCQUYxQyxXQUFJLENBQUMsUUFBUTs7YUFJckIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFROytCQUE3QixvQkFBMEYsS0FBMUYsVUFBMEYsbUJBQTNCLFdBQUksQ0FBQyxNQUFNLENBQUMsUUFBUTs7O1VBR3JGLDhCQUFjO1VBQ2Qsb0JBVU0sT0FWTixXQVVNO3dDQVRKLG9CQUFtRixXQUE1RSxLQUFLLEVBQUMsdUNBQXVDLElBQUMsd0JBQXNCO1lBQzNFLG9CQU1NLE9BTk4sV0FNTTs4QkFMSixvQkFBcVA7NkVBQXJPLFdBQUksQ0FBQyxLQUFLO2dCQUFFLElBQUksRUFBQyxNQUFNO2dCQUFDLFdBQVcsRUFBQyxpQkFBaUI7Z0JBQUMsS0FBSyxFQUFDLHNLQUFzSzs7OEJBQWxPLFdBQUksQ0FBQyxLQUFLOzs4QkFDMUIsb0JBR1M7NkVBSFEsV0FBSSxDQUFDLFNBQVM7Z0JBQUUsS0FBSyxFQUFDLG9LQUFvSzs7Z0JBQ3pNLG9CQUFtQyxZQUEzQixLQUFLLEVBQUMsTUFBTSxJQUFDLE9BQUs7Z0JBQzFCLG9CQUFvQyxZQUE1QixLQUFLLEVBQUMsTUFBTSxJQUFDLFFBQU07O2dDQUZaLFdBQUksQ0FBQyxTQUFTOzs7YUFLeEIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOytCQUExQixvQkFBb0YsS0FBcEYsV0FBb0YsbUJBQXhCLFdBQUksQ0FBQyxNQUFNLENBQUMsS0FBSzs7OztRQUlqRixrQ0FBa0I7UUFDbEIsb0JBSU0sT0FKTixXQUlNO3NDQUhKLG9CQUE4RSxXQUF2RSxLQUFLLEVBQUMsdUNBQXVDLElBQUMsbUJBQWlCOzBCQUN0RSxvQkFBK1I7eUVBQTVRLFdBQUksQ0FBQyxJQUFJO1lBQUUsSUFBSSxFQUFDLEdBQUc7WUFBQyxXQUFXLEVBQUMsbURBQW1EO1lBQUMsS0FBSyxFQUFDLHNLQUFzSzs7MEJBQWhRLFdBQUksQ0FBQyxJQUFJOztXQUNuQixXQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7NkJBQXpCLG9CQUFrRixLQUFsRixXQUFrRixtQkFBdkIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJOzs7UUFHN0UsNkJBQWE7UUFDYixvQkF3Qk0sT0F4Qk4sV0F3Qk07c0NBdkJKLG9CQUFtRixXQUE1RSxLQUFLLEVBQUMsdUNBQXVDLElBQUMsd0JBQXNCO1VBQzNFLG9CQW9CTSxPQXBCTixXQW9CTTtZQW5CSixvQkFBdUk7Y0FBaEksSUFBSSxFQUFDLE1BQU07Y0FBRSxRQUFNLEVBQUUsd0JBQWlCO2NBQUUsS0FBSyxFQUFDLDhEQUE4RDtjQUFDLE1BQU0sRUFBQyxTQUFTOztjQUNwRyxtQkFBWTsrQkFBNUMsb0JBV00sT0FYTixXQVdNOzs7K0JBQ04sb0JBS00sT0FMTixXQUtNO2tCQUpKLG9CQUE4RDtvQkFBeEQsR0FBRyxFQUFFLG1CQUFZO29CQUFFLEtBQUssRUFBQyw0QkFBNEI7OzhDQUMzRCxvQkFFTSxTQUZELEtBQUssRUFBQyxvSEFBb0g7b0JBQzdILG9CQUFzRCxPQUFuRCxLQUFLLEVBQUMsOEJBQThCLElBQUMsWUFBVTs7OztXQUkvQyxXQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7NkJBQTFCLG9CQUFvRixLQUFwRixXQUFvRixtQkFBeEIsV0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLOzs7UUFHL0Usc0NBQXNCO1FBQ3RCLG9CQUtNLE9BTE4sV0FLTTtVQUpKLGFBQTBKO1lBQXBKLElBQUksRUFBQyxpQkFBaUI7WUFBQyxLQUFLLEVBQUMsMEdBQTBHOzs4QkFBQyxDQUFLOytCQUFMLE9BQUs7Ozs7VUFDbkosb0JBRVM7WUFGRCxJQUFJLEVBQUMsUUFBUTtZQUFFLFFBQVEsRUFBRSxXQUFJLENBQUMsVUFBVTtZQUFFLEtBQUssRUFBQyw0SEFBNEg7YUFBQyxpQkFFckwiLCJpZ25vcmVMaXN0IjpbXX0=